
/**
 * STREETCOINZ BACKEND SERVER
 * Running on VPS (103.13.207.245)
 */

const express = require('express');
const mariadb = require('mariadb');
const cors = require('cors');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');

const app = express();
const port = 5000;

// Updated MariaDB Configuration with provided credentials
const pool = mariadb.createPool({
     host: '103.13.207.245',
     user: 'wadmin',
     password: 'dN9wlRdQMZ9t',
     database: 'streetcoinz_db',
     port: 3306,
     connectionLimit: 5
});

app.use(cors());
app.use(bodyParser.json());

// Initialize Database Table
async function initDb() {
    let conn;
    try {
        conn = await pool.getConnection();
        await conn.query(`
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                username VARCHAR(50) UNIQUE NOT NULL,
                email VARCHAR(100) UNIQUE NOT NULL,
                password_hash VARCHAR(255) NOT NULL,
                wallet_address VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log("Database StreetCoinz Ready at 103.13.207.245");
    } catch (err) {
        console.error("DB Initialization Failed:", err);
    } finally {
        if (conn) conn.release();
    }
}

initDb();

// API Auth: Login or Register
app.post('/api/auth', async (req, res) => {
    const { email, username, password } = req.body;
    let conn;
    try {
        conn = await pool.getConnection();
        
        // Check if user exists
        const users = await conn.query("SELECT * FROM users WHERE email = ? OR username = ?", [email, username]);
        
        if (users.length > 0) {
            const user = users[0];
            if (password) {
                const match = await bcrypt.compare(password, user.password_hash);
                if (!match) return res.status(401).json({ success: false, message: "Invalid credentials!" });
            }
            
            return res.json({
                success: true,
                message: "Welcome back!",
                user: {
                    name: user.username,
                    email: user.email,
                    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${user.username}`,
                    address: user.wallet_address || "0x..."
                }
            });
        } else {
            // Register new user
            const saltRounds = 10;
            const hash = await bcrypt.hash(password || 'street_default_pass', saltRounds);
            const walletAddr = `0x${Math.random().toString(16).substring(2, 10)}...${Math.random().toString(16).substring(2, 6)}`;
            
            await conn.query(
                "INSERT INTO users (username, email, password_hash, wallet_address) VALUES (?, ?, ?, ?)",
                [username, email, hash, walletAddr]
            );
            
            return res.json({
                success: true,
                message: "Street Identity Created!",
                user: {
                    name: username,
                    email: email,
                    avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`,
                    address: walletAddr
                }
            });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ success: false, message: "Database connection error." });
    } finally {
        if (conn) conn.release();
    }
});

app.listen(port, '0.0.0.0', () => {
    console.log(`StreetCoinz API running at http://103.13.207.245:${port}`);
});
