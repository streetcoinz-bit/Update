
import React from 'react';
import { VideoPost, Language } from '../types';

interface PublicProfileProps {
  username: string;
  posts: VideoPost[];
  language: Language;
  activeThemeClass: string;
  onBack: () => void;
}

const translations = {
  [Language.EN]: { follow: 'Follow', following: 'Following', posts: 'Posts', followers: 'Followers', trader: 'Trader' },
  [Language.ID]: { follow: 'Ikuti', following: 'Mengikuti', posts: 'Postingan', followers: 'Pengikut', trader: 'Trader' },
  [Language.ES]: { follow: 'Seguir', following: 'Siguiendo', posts: 'Posts', followers: 'Seguidores', trader: 'Trader' },
  [Language.CN]: { follow: '关注', following: '正在关注', posts: '帖子', followers: '粉丝', trader: '交易者' }
};

const PublicProfile: React.FC<PublicProfileProps> = ({ username, posts, language, activeThemeClass, onBack }) => {
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';
  
  // Filter posts for this specific user
  const userPosts = posts.filter(p => p.username === username);
  
  // Generate pseudo-data for display
  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`;
  const followerCount = Math.floor(Math.random() * 5000) + 100;
  const followingCount = Math.floor(Math.random() * 200) + 20;

  const formatCount = (num: number) => {
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  return (
    <div className={`flex flex-col h-full overflow-y-auto scrollbar-hide transition-colors duration-300 ${isDark ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      {/* Header Bar */}
      <div className={`sticky top-0 z-10 p-4 flex items-center gap-4 backdrop-blur-md border-b ${isDark ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'}`}>
        <button onClick={onBack} className="p-2 hover:bg-zinc-800/20 rounded-xl transition-all">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h2 className="text-sm font-black uppercase italic tracking-tighter">@{username}</h2>
      </div>

      {/* Profile Info */}
      <div className="flex flex-col items-center p-8">
        <div className="relative mb-6">
          <div className={`absolute -inset-1 rounded-full blur opacity-25 bg-gradient-to-r from-purple-600 to-pink-600`}></div>
          <img 
            src={avatarUrl} 
            alt={username} 
            className={`relative w-24 h-24 rounded-full border-4 object-cover ${isDark ? 'border-zinc-900' : 'border-white'}`}
          />
        </div>
        
        <h1 className="text-xl font-black italic uppercase tracking-tighter mb-1">@{username}</h1>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-6">{t.trader}</p>

        {/* Stats */}
        <div className="flex items-center gap-8 mb-8">
          <div className="flex flex-col items-center">
            <span className="text-lg font-black tracking-tighter">{userPosts.length}</span>
            <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">{t.posts}</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-lg font-black tracking-tighter">{formatCount(followerCount)}</span>
            <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">{t.followers}</span>
          </div>
          <div className="flex flex-col items-center">
            <span className="text-lg font-black tracking-tighter">{formatCount(followingCount)}</span>
            <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">{t.following}</span>
          </div>
        </div>

        <button className="w-full max-w-[200px] py-3 bg-purple-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-purple-500/20 active:scale-95 transition-all">
          {t.follow}
        </button>
      </div>

      {/* Video Grid */}
      <div className="px-1 pb-24">
        <div className="grid grid-cols-3 gap-1">
          {userPosts.map((post) => (
            <div key={post.id} className="aspect-[3/4] bg-zinc-900 overflow-hidden group relative">
              {post.mediaType === 'video' ? (
                <video src={post.url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" muted />
              ) : (
                <img src={post.url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
              )}
              <div className="absolute bottom-2 left-2 flex items-center gap-1">
                <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                </svg>
                <span className="text-[9px] font-black text-white">{formatCount(post.likes)}</span>
              </div>
            </div>
          ))}
          
          {userPosts.length === 0 && (
            <div className="col-span-3 py-20 flex flex-col items-center opacity-30">
               <svg className="w-12 h-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
               </svg>
               <span className="text-[10px] font-black uppercase tracking-widest italic">No flexing yet...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PublicProfile;
