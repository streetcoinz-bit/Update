
import React, { useState, useRef, useEffect } from 'react';
import { Language } from '../types';

interface DeleteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: () => void;
  language: Language;
  customTitle?: string;
  customSub?: string;
}

const translations = {
  [Language.EN]: { 
    title: 'Scrub this play?', 
    sub: 'This media will be deleted from the street forever. Are you sure, fam?', 
    confirm: 'SLIDE TO BURN', 
    cancel: 'Keep it',
    swipeHint: 'Slide right to confirm'
  },
  [Language.ID]: { 
    title: 'Hapus aksi ini?', 
    sub: 'Media ini akan dihapus dari jalanan selamanya. Kamu yakin, kawan?', 
    confirm: 'GESER UNTUK HAPUS', 
    cancel: 'Simpan saja',
    swipeHint: 'Geser ke kanan untuk konfirmasi'
  },
  [Language.ES]: { 
    title: '¿Eliminar jugada?', 
    sub: 'Este medio se eliminará de la calle para siempre. ¿Estás seguro, compa?', 
    confirm: 'DESLIZA PARA BORRAR', 
    cancel: 'Mantenerlo',
    swipeHint: 'Desliza para confirmar'
  },
  [Language.CN]: { 
    title: '清除这一手？', 
    sub: '该媒体将永久从街道上删除。你确定吗，兄弟？', 
    confirm: '滑动以销毁', 
    cancel: '保留它',
    swipeHint: '向右滑动确认'
  }
};

const DeleteModal: React.FC<DeleteModalProps> = ({ isOpen, onClose, onConfirm, language, customTitle, customSub }) => {
  const [sliderPos, setSliderPos] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const sliderRef = useRef<HTMLDivElement>(null);
  const t = translations[language];

  useEffect(() => {
    if (!isOpen) {
      setSliderPos(0);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!isDragging || !sliderRef.current) return;
    
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const rect = sliderRef.current.getBoundingClientRect();
    const width = rect.width - 64; // Subtract handle width
    const offset = clientX - rect.left - 32;
    
    const newPos = Math.max(0, Math.min(width, offset));
    setSliderPos(newPos);

    if (newPos >= width * 0.95) {
      handleComplete();
    }
  };

  const handleComplete = () => {
    setIsDragging(false);
    setSliderPos(100); // Trigger visual completion
    if ('vibrate' in navigator) navigator.vibrate([40, 30, 100]);
    onConfirm();
  };

  const handleRelease = () => {
    if (sliderPos < 80) {
      setSliderPos(0);
    }
    setIsDragging(false);
  };

  return (
    <div className="fixed inset-0 z-[250] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/95 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative w-full max-w-[300px] bg-zinc-950 border border-rose-500/20 rounded-[40px] overflow-hidden shadow-[0_0_50px_rgba(244,63,94,0.15)] animate-in zoom-in-95 duration-200">
        <div className="p-8 text-center">
          <div className="w-20 h-20 bg-rose-500/10 rounded-[28px] flex items-center justify-center mx-auto mb-6 border border-rose-500/20 shadow-[0_0_20px_rgba(244,63,94,0.1)]">
            <svg className="w-10 h-10 text-rose-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </div>
          
          <h2 className="text-xl font-black text-white mb-2 italic uppercase tracking-tighter leading-tight">{customTitle || t.title}</h2>
          <p className="text-zinc-500 text-[10px] mb-10 uppercase tracking-widest font-bold leading-relaxed">
            {customSub || t.sub}
          </p>
          
          <div className="space-y-6">
            {/* Slide to Confirm Slider */}
            <div 
              ref={sliderRef}
              className="relative h-16 bg-zinc-900 border border-zinc-800 rounded-2xl p-1 overflow-hidden"
              onMouseMove={handleTouchMove}
              onMouseUp={handleRelease}
              onMouseLeave={handleRelease}
              onTouchMove={handleTouchMove}
              onTouchEnd={handleRelease}
            >
              <div className="absolute inset-0 flex items-center justify-center">
                 <span className="text-[9px] font-black text-zinc-700 uppercase tracking-[0.2em] pointer-events-none">
                    {t.swipeHint}
                 </span>
              </div>

              <div 
                className="absolute left-1 top-1 bottom-1 bg-gradient-to-r from-rose-600 to-rose-500 rounded-xl transition-all duration-75"
                style={{ width: `calc(${sliderPos}px + 56px)` }}
              ></div>

              <div 
                onMouseDown={() => setIsDragging(true)}
                onTouchStart={() => setIsDragging(true)}
                className="absolute top-1 bottom-1 w-14 bg-white rounded-xl shadow-xl flex items-center justify-center cursor-grab active:cursor-grabbing transition-transform duration-75 touch-none"
                style={{ transform: `translateX(${sliderPos}px)` }}
              >
                <svg className="w-6 h-6 text-rose-600 animate-pulse" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.99 7.99 0 0120 13a7.98 7.98 0 01-2.343 5.657z" />
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9.879 16.121A3 3 0 1012.015 11L11 14l-1.121 2.121z" />
                </svg>
              </div>
            </div>
            
            <button 
              onClick={onClose}
              className="w-full text-zinc-600 py-2 text-[10px] font-black uppercase tracking-[0.3em] hover:text-white transition-colors"
            >
              {t.cancel}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeleteModal;
