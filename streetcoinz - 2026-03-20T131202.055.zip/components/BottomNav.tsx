
import React from 'react';
import { AppTab, Language } from '../types';

interface BottomNavProps {
  activeTab: AppTab;
  setActiveTab: (tab: AppTab) => void;
  language: Language;
  activeThemeClass: string;
}

const translations = {
  [Language.EN]: { home: 'HOME', chat: 'CHAT', predict: 'PREDICT', wallet: 'WALLET', post: 'POST' },
  [Language.ID]: { home: 'HOME', chat: 'CHAT', predict: 'PREDICT', wallet: 'WALLET', post: 'POST' },
  [Language.ES]: { home: 'INICIO', chat: 'CHAT', predict: 'PREDECIR', wallet: 'BILLETERA', post: 'POST' },
  [Language.CN]: { home: '首页', chat: '聊天', predict: '预测', wallet: '钱包', post: '发布' }
};

const BottomNav: React.FC<BottomNavProps> = ({ activeTab, setActiveTab, language, activeThemeClass }) => {
  const t = translations[language] || translations[Language.EN];
  const isDark = activeThemeClass === 'theme-dark';

  return (
    <nav className={`glass-nav h-20 px-2 flex items-center justify-around border-t transition-colors duration-300 z-[100] ${isDark ? 'bg-zinc-950/90 border-zinc-900' : 'bg-white/90 border-zinc-200'}`}>
      
      {/* Home Feed */}
      <button 
        onClick={() => setActiveTab(AppTab.HOME)}
        className={`flex flex-col items-center justify-center gap-1 transition-all flex-1 h-full ${activeTab === AppTab.HOME ? 'text-purple-500' : (isDark ? 'text-zinc-600' : 'text-zinc-400')}`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={activeTab === AppTab.HOME ? 2.5 : 2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M3 12l2-2m0 0l7-7 7-7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6" />
        </svg>
        <span className="text-[8px] font-black tracking-widest">{t.home}</span>
      </button>

      {/* Predict */}
      <button 
        onClick={() => setActiveTab(AppTab.PREDICT)}
        className={`flex flex-col items-center justify-center gap-1 transition-all flex-1 h-full ${activeTab === AppTab.PREDICT ? 'text-purple-500' : (isDark ? 'text-zinc-600' : 'text-zinc-400')}`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={activeTab === AppTab.PREDICT ? 2.5 : 2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>
        <span className="text-[8px] font-black tracking-widest">{t.predict}</span>
      </button>

      {/* Post + Center Button (Always Purple) */}
      <button 
        onClick={() => setActiveTab(AppTab.POST)}
        className={`flex flex-col items-center justify-center gap-1 transition-all flex-1 h-full ${activeTab === AppTab.POST ? 'text-purple-500' : (isDark ? 'text-zinc-600' : 'text-zinc-400')}`}
      >
        <div className={`w-11 h-11 flex items-center justify-center rounded-2xl transition-all bg-purple-600 text-white shadow-lg ${activeTab === AppTab.POST ? 'shadow-purple-500/50 scale-110' : 'shadow-purple-500/20 opacity-90'}`}>
          <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3.5}>
            <path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" />
          </svg>
        </div>
        <span className="text-[8px] font-black tracking-widest">{t.post}</span>
      </button>

      {/* Chat */}
      <button 
        onClick={() => setActiveTab(AppTab.CHAT)}
        className={`flex flex-col items-center justify-center gap-1 transition-all flex-1 h-full ${activeTab === AppTab.CHAT ? 'text-purple-500' : (isDark ? 'text-zinc-600' : 'text-zinc-400')}`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={activeTab === AppTab.CHAT ? 2.5 : 2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
        </svg>
        <span className="text-[8px] font-black tracking-widest">{t.chat}</span>
      </button>

      {/* Wallet */}
      <button 
        onClick={() => setActiveTab(AppTab.TOPUP)}
        className={`flex flex-col items-center justify-center gap-1 transition-all flex-1 h-full ${activeTab === AppTab.TOPUP ? 'text-purple-500' : (isDark ? 'text-zinc-600' : 'text-zinc-400')}`}
      >
        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={activeTab === AppTab.TOPUP ? 2.5 : 2}>
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
        <span className="text-[8px] font-black tracking-widest">{t.wallet}</span>
      </button>
    </nav>
  );
};

export default BottomNav;
