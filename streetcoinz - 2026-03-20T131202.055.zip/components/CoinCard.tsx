import React from 'react';
import { motion } from 'motion/react';
import { TrendingUp, TrendingDown, DollarSign, Activity } from 'lucide-react';
import { Coin } from '../types';

interface CoinCardProps {
  coin: Coin;
  onTrade: (coin: Coin) => void;
}

export const CoinCard: React.FC<CoinCardProps> = ({ coin, onTrade }) => {
  const isPositive = coin.change24h >= 0;

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="bg-street-dark border border-street-gray p-6 rounded-xl relative overflow-hidden group"
    >
      <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:opacity-20 transition-opacity">
        <Activity size={64} />
      </div>
      
      <div className="relative z-10">
        <div className="flex justify-between items-start mb-4">
          <div>
            <h3 className="font-display text-2xl tracking-wide">{coin.name}</h3>
            <span className="font-mono text-gray-400 text-sm">{coin.symbol}</span>
          </div>
          <div className={`flex items-center gap-1 px-2 py-1 rounded ${isPositive ? 'bg-green-900/30 text-neon-green' : 'bg-red-900/30 text-red-500'}`}>
            {isPositive ? <TrendingUp size={16} /> : <TrendingDown size={16} />}
            <span className="font-mono text-sm font-bold">{Math.abs(coin.change24h)}%</span>
          </div>
        </div>

        <div className="mb-6">
          <div className="text-3xl font-bold font-mono flex items-center">
            <span className="text-gray-500 text-xl mr-1">$</span>
            {coin.price.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
          </div>
          <div className="text-xs text-gray-500 mt-1 font-mono">Vol: {coin.volume}</div>
        </div>

        <button
          onClick={() => onTrade(coin)}
          className="w-full bg-white text-black font-bold py-3 px-4 rounded-lg hover:bg-neon-green transition-colors font-mono uppercase tracking-wider flex items-center justify-center gap-2"
        >
          <DollarSign size={18} />
          Predict
        </button>
      </div>
    </motion.div>
  );
};
