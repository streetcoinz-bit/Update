
import React, { useState, useEffect, useRef } from 'react';
import { VideoPost, UserProfile, Language } from '../types';
import CommentSection from './CommentSection';

interface HomeFeedProps {
  posts: VideoPost[];
  currentUser: UserProfile | null;
  language: Language;
  followingList: Set<string>;
  onToggleFollow: (username: string) => void;
  onDelete: (id: string) => void;
  onShare: (post: VideoPost) => void;
  onViewProfile: (username: string) => void;
  onAddComment: (postId: string, text: string, parentId?: string) => void;
  onDeleteComment: (postId: string, commentId: string, parentId?: string) => void;
  activeThemeClass: string;
  initialPostId?: string;
  onBack?: () => void;
}

const translations = {
  [Language.EN]: { follow: 'Follow', following: 'Following', share: 'Share', delete: 'Delete', searchPlaceholder: 'Search traders or alpha...', trending: 'Trending Now', users: 'Traders', topics: 'Alpha Topics' },
  [Language.ID]: { follow: 'Ikuti', following: 'Mengikuti', share: 'Bagikan', delete: 'Hapus', searchPlaceholder: 'Cari trader atau info...', trending: 'Sedang Tren', users: 'Trader', topics: 'Topik Alpha' },
  [Language.ES]: { follow: 'Seguir', following: 'Siguiendo', share: 'Compartir', delete: 'Eliminar', searchPlaceholder: 'Buscar traders...', trending: 'Tendencias', users: 'Traders', topics: 'Temas Alpha' },
  [Language.CN]: { follow: '关注', following: '正在关注', share: '分享', delete: '删除', searchPlaceholder: '搜索交易者或动态...', trending: '当前热门', users: '交易者', topics: '热门话题' }
};

const TRENDING_TOPICS = ['#BTC100K', '#EthereumMerge', '#SolanaSummer', '#MemeMagic', '#DexGems', '#StreetAlpha', '#Layer2War', '#NFTArt'];
const MOCK_TRADERS = ['crypto_whale_99', 'scalp_queen', 'street_trader_id', 'alpha_king', 'dex_demon', 'moon_walker', 'bull_runner', 'bear_trap', 'pump_master', 'liquid_gold', 'satoshi_spirit'];

/**
 * Custom Video Player Component for each item in the feed.
 */
const VideoItem: React.FC<{
  post: VideoPost;
  isMuted: boolean;
  toggleMute: () => void;
  onViewProfile: (u: string) => void;
}> = ({ post, isMuted, toggleMute, onViewProfile }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showPlayIcon, setShowPlayIcon] = useState(false);

  useEffect(() => {
    const options = { threshold: 0.6 };
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          videoRef.current?.play().catch(() => {});
          setIsPlaying(true);
        } else {
          videoRef.current?.pause();
          setIsPlaying(false);
        }
      });
    }, options);

    if (videoRef.current) observer.observe(videoRef.current);
    return () => observer.disconnect();
  }, []);

  const handleTogglePlay = () => {
    if (videoRef.current) {
      if (videoRef.current.paused) {
        videoRef.current.play();
        setIsPlaying(true);
      } else {
        videoRef.current.pause();
        setIsPlaying(false);
      }
      setShowPlayIcon(true);
      setTimeout(() => setShowPlayIcon(false), 800);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const p = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(p);
    }
  };

  return (
    <div className="relative w-full h-full group" onClick={handleTogglePlay}>
      {post.mediaType === 'video' ? (
        <video 
          ref={videoRef}
          src={post.url} 
          className="h-full w-full object-cover"
          loop 
          muted={isMuted}
          playsInline
          onTimeUpdate={handleTimeUpdate}
        />
      ) : (
        <img 
          src={post.url} 
          className="h-full w-full object-cover"
          alt={post.caption}
        />
      )}

      {/* Play/Pause Large Overlay Icon */}
      {showPlayIcon && (
        <div className="absolute inset-0 flex items-center justify-center z-30 pointer-events-none">
          <div className="bg-black/20 p-6 rounded-full backdrop-blur-sm animate-ping">
            {isPlaying ? (
              <svg className="w-12 h-12 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
            ) : (
              <svg className="w-12 h-12 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg>
            )}
          </div>
        </div>
      )}

      {/* Mute/Unmute Control */}
      {post.mediaType === 'video' && (
        <button 
          onClick={(e) => { e.stopPropagation(); toggleMute(); }}
          className="absolute top-20 right-4 z-[45] p-2 bg-black/40 backdrop-blur-md rounded-xl border border-white/10 text-white/80 hover:text-white transition-all active:scale-90"
        >
          {isMuted ? (
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75L19.5 12m0 0l2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6h4.5l4.5-4.5v15l-4.5-4.5h-4.5a1.125 1.125 0 01-1.125-1.125V11a1.125 1.125 0 011.125-1.125z" />
            </svg>
          ) : (
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" />
            </svg>
          )}
        </button>
      )}

      {/* Progress Bar */}
      {post.mediaType === 'video' && (
        <div className="absolute bottom-0 left-0 w-full h-1 bg-white/20 z-50">
          <div 
            className="h-full bg-purple-500 shadow-[0_0_8px_rgba(168,85,247,0.8)] transition-all duration-300"
            style={{ width: `${progress}%` }}
          />
        </div>
      )}
    </div>
  );
};

const HomeFeed: React.FC<HomeFeedProps> = ({ 
  posts, 
  currentUser, 
  language, 
  followingList, 
  onToggleFollow, 
  onDelete, 
  onShare, 
  onViewProfile,
  onAddComment,
  onDeleteComment,
  activeThemeClass,
  initialPostId,
  onBack
}) => {
  const currentUsername = currentUser?.name.toLowerCase().replace(/\s/g, '_') || '';
  const t = translations[language];
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [isGlobalMuted, setIsGlobalMuted] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Search State
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  // Auto-scroll to initialPostId if provided (used for deep linking or fresh uploads)
  useEffect(() => {
    if (initialPostId && containerRef.current) {
      const targetElement = document.getElementById(`post-${initialPostId}`);
      if (targetElement) {
        targetElement.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    }
  }, [initialPostId, posts]);

  const calculateTotalComments = (post: VideoPost) => {
    let count = post.comments;
    if (post.commentsList) {
      count += post.commentsList.length;
      post.commentsList.forEach(c => {
        if (c.replies) count += c.replies.length;
      });
    }
    return count;
  };

  const filteredTraders = MOCK_TRADERS.filter(u => 
    u.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const filteredTopics = TRENDING_TOPICS.filter(topic => 
    topic.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div 
      ref={containerRef}
      className="video-container snap-y snap-mandatory overflow-y-scroll h-full scrollbar-hide relative bg-black"
    >
      
      {/* Feed Header (Search or Back button) */}
      <div className="absolute top-0 left-0 w-full z-[40] px-4 pt-4 pb-12 bg-gradient-to-b from-black/80 to-transparent pointer-events-none">
        <div className="relative pointer-events-auto flex items-center gap-3">
          {onBack && (
            <button 
              onClick={onBack}
              className="p-2.5 bg-zinc-900/90 border border-zinc-800 rounded-2xl text-white shadow-xl backdrop-blur-xl active:scale-90 transition-all pointer-events-auto"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          
          {!onBack && (
            <div className={`flex-1 flex items-center gap-3 px-4 py-2.5 rounded-2xl border backdrop-blur-xl ${isSearchFocused ? 'bg-zinc-900/90 border-zinc-800' : 'bg-white/10 border-white/10'}`}>
              <div className={`duration-500 ${isSearchFocused ? 'rotate-90' : ''}`}>
                <svg className={`w-4 h-4 ${isSearchFocused ? 'text-purple-500' : 'text-zinc-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
              <input 
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onFocus={() => setIsSearchFocused(true)}
                placeholder={t.searchPlaceholder}
                className="flex-1 bg-transparent border-none focus:outline-none focus:ring-0 text-xs font-black text-white placeholder:text-zinc-500 uppercase tracking-tight"
              />
              {isSearchFocused && (
                <button 
                  onClick={() => { setSearchQuery(''); setIsSearchFocused(false); }}
                  className="p-1 text-zinc-500 hover:text-white"
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
                </button>
              )}
            </div>
          )}

          {/* Search Results Panel */}
          {isSearchFocused && !onBack && (
            <div className="absolute top-full left-0 w-full mt-2 bg-zinc-950/95 border border-zinc-800 rounded-3xl overflow-hidden backdrop-blur-2xl shadow-2xl animate-in slide-in-from-top-4 duration-300">
              <div className="p-4 max-h-[60vh] overflow-y-auto scrollbar-hide">
                
                {/* Topics Section */}
                <div className="mb-8">
                  <div className="flex items-center justify-between mb-4 px-2">
                    <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-[0.2em]">{t.topics}</h4>
                    <span className="text-[8px] font-black bg-purple-500/20 text-purple-400 px-2 py-0.5 rounded-full animate-pulse">TRENDING</span>
                  </div>
                  <div className="flex wrap gap-2 px-1">
                    {filteredTopics.length > 0 ? filteredTopics.map(topic => (
                      <button 
                        key={topic}
                        onClick={() => setSearchQuery(topic)}
                        className="px-3 py-2 bg-white/5 border border-zinc-800 rounded-xl text-[10px] font-black text-zinc-300 hover:text-white hover:border-purple-500 hover:bg-purple-500/10 transition-all uppercase italic tracking-tighter shadow-sm"
                      >
                        {topic}
                      </button>
                    )) : (
                      <p className="text-[9px] text-zinc-600 font-bold uppercase tracking-widest px-2 italic">No topics found</p>
                    )}
                  </div>
                </div>

                <div className="h-px bg-zinc-900 mx-2 mb-6"></div>

                {/* Users Section */}
                <div>
                  <h4 className="text-[10px] font-black text-purple-500 uppercase tracking-[0.2em] mb-4 px-2">{t.users}</h4>
                  <div className="space-y-1">
                    {filteredTraders.length > 0 ? filteredTraders.map(username => (
                      <button 
                        key={username}
                        onClick={() => { onViewProfile(username); setIsSearchFocused(false); }}
                        className="w-full flex items-center gap-3 p-3 hover:bg-white/5 rounded-2xl transition-all group"
                      >
                        <div className="relative">
                          <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`} className="w-10 h-10 rounded-xl border border-zinc-800" alt={username} />
                          <div className="absolute -bottom-1 -right-1 w-3 h-3 bg-emerald-500 border-2 border-zinc-950 rounded-full"></div>
                        </div>
                        <div className="text-left">
                          <span className="text-xs font-black text-zinc-300 group-hover:text-white uppercase tracking-tight block">@{username}</span>
                          <span className="text-[8px] font-bold text-zinc-600 uppercase tracking-widest">Alpha Provider</span>
                        </div>
                        <div className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
                          <svg className="w-4 h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" /></svg>
                        </div>
                      </button>
                    )) : (
                      <p className="text-[9px] text-zinc-600 font-bold uppercase tracking-widest px-2 italic">No traders found</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {posts.map((post) => (
        <div 
          key={post.id} 
          id={`post-${post.id}`}
          className="video-card h-full w-full relative snap-start"
        >
          <VideoItem 
            post={post} 
            isMuted={isGlobalMuted} 
            toggleMute={() => setIsGlobalMuted(!isGlobalMuted)}
            onViewProfile={onViewProfile}
          />
          
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent pointer-events-none" />
          
          {/* Side Action Bar */}
          <div className="absolute right-4 bottom-24 flex flex-col gap-6 items-center z-20">
            {/* User Avatar with Follow Button */}
            <div className="relative mb-2">
              <div 
                onClick={(e) => { e.stopPropagation(); onViewProfile(post.username); }}
                className="w-12 h-12 rounded-full border-2 border-white overflow-hidden shadow-xl cursor-pointer"
              >
                <img 
                  src={post.username === currentUsername ? currentUser?.avatar : `https://api.dicebear.com/7.x/avataaars/svg?seed=${post.username}`} 
                  alt="Avatar" 
                  className="w-full h-full object-cover"
                />
              </div>
              {post.username !== currentUsername && !followingList.has(post.username) && (
                <button 
                  onClick={(e) => { e.stopPropagation(); onToggleFollow(post.username); }}
                  className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-purple-600 text-white rounded-full w-5 h-5 flex items-center justify-center border-2 border-black"
                >
                  <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path d="M12 4v16m8-8H4" /></svg>
                </button>
              )}
            </div>

            <div className="flex flex-col items-center">
              <button className="text-white hover:text-purple-500 transition-colors drop-shadow-xl" onClick={(e) => e.stopPropagation()}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                </svg>
              </button>
              <span className="text-[10px] font-black mt-1 text-white shadow-black drop-shadow-lg">{(post.likes / 1000).toFixed(1)}K</span>
            </div>
            
            <div className="flex flex-col items-center">
              <button 
                onClick={(e) => { e.stopPropagation(); setActiveCommentPostId(post.id); }}
                className="text-white hover:text-white/80 transition-colors drop-shadow-xl"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" />
                </svg>
              </button>
              <span className="text-[10px] font-black mt-1 text-white shadow-black drop-shadow-lg">{calculateTotalComments(post)}</span>
            </div>

            <div className="flex flex-col items-center">
              <button 
                onClick={(e) => { e.stopPropagation(); onShare(post); }}
                className="text-white hover:text-emerald-400 transition-colors drop-shadow-xl"
              >
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92z" />
                </svg>
              </button>
              <span className="text-[10px] font-black mt-1 text-white shadow-black drop-shadow-lg uppercase tracking-widest">{t.share}</span>
            </div>

            {post.username === currentUsername && (
               <div className="flex flex-col items-center">
               <button 
                 onClick={(e) => { e.stopPropagation(); onDelete(post.id); }}
                 className="text-rose-500 hover:text-rose-400 transition-colors drop-shadow-xl"
               >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z" />
                  </svg>
               </button>
             </div>
            )}
          </div>

          {/* Bottom Info Bar */}
          <div className="absolute left-4 bottom-8 max-w-[80%] z-20 text-white pointer-events-none">
            <h3 
              onClick={(e) => { e.stopPropagation(); onViewProfile(post.username); }}
              className="font-black text-lg mb-1 italic tracking-tighter cursor-pointer hover:text-purple-400 transition-colors drop-shadow-lg pointer-events-auto"
            >
              @{post.username}
            </h3>
            <p className="text-sm font-medium leading-snug drop-shadow-md line-clamp-2">
              {post.caption}
            </p>
            <div className="flex items-center gap-2 mt-3">
               <div className="bg-white/20 backdrop-blur-md px-2 py-1 rounded-lg flex items-center gap-2">
                  <svg className="w-3 h-3 animate-spin" fill="currentColor" viewBox="0 0 24 24"><path d="M12 3v9l8 5" stroke="white" strokeWidth="2" strokeLinecap="round" /></svg>
                  <span className="text-[10px] font-black tracking-widest uppercase">Street Music Loop</span>
               </div>
            </div>
          </div>

          {activeCommentPostId === post.id && (
            <CommentSection 
              comments={post.commentsList || []}
              onAddComment={(text, parentId) => onAddComment(post.id, text, parentId)}
              onDeleteComment={(commentId, parentId) => onDeleteComment(post.id, commentId, parentId)}
              currentUserUsername={currentUsername}
              onClose={() => setActiveCommentPostId(null)}
              onViewProfile={onViewProfile}
              language={language}
              activeThemeClass={activeThemeClass}
            />
          )}
        </div>
      ))}
    </div>
  );
};

export default HomeFeed;
