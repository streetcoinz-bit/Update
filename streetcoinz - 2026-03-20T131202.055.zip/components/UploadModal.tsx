
import React, { useState, useRef } from 'react';
import { Language } from '../types';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (data: { file: File; caption: string; type: 'video' | 'image' }) => void;
  language: Language;
  isPosting: boolean;
}

const translations = {
  [Language.EN]: { 
    title: 'Upload to Street', 
    select: 'Select Media', 
    label: 'Street Caption (Optional)', 
    placeholder: "What's the play? #btc #moon...", 
    button: 'Post to Street',
    posting: 'SECURING YOUR FLEX...',
    network: 'Verifying on Street Protocol'
  },
  [Language.ID]: { 
    title: 'Unggah ke Jalanan', 
    select: 'Pilih Media', 
    label: 'Caption Jalanan (Opsional)', 
    placeholder: "Bagaimana permainannya? #btc #cuan...", 
    button: 'Unggah ke Jalanan',
    posting: 'MENGAMANKAN FLEX ANDA...',
    network: 'Verifikasi di Protokol Jalanan'
  },
  [Language.ES]: { 
    title: 'Subir a la Calle', 
    select: 'Seleccionar Media', 
    label: 'Pie de Calle (Opcional)', 
    placeholder: "¿Cuál es la jugada? #btc #luna...", 
    button: 'Publicar en la Calle',
    posting: 'ASEGURANDO TU FLEX...',
    network: 'Verificando en Protocolo Callejero'
  },
  [Language.CN]: { 
    title: '上传到街道', 
    select: '选择媒体', 
    label: '街道说明（可选）', 
    placeholder: "有什么玩法？#btc #登月...", 
    button: '发布到街道',
    posting: '正在保存您的操作...',
    network: '在街道协议上验证'
  }
};

const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose, onUpload, language, isPosting }) => {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [caption, setCaption] = useState('');
  const [type, setType] = useState<'video' | 'image'>('image');
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;
  const t = translations[language];

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile) {
      setFile(selectedFile);
      const url = URL.createObjectURL(selectedFile);
      setPreview(url);
      setType(selectedFile.type.startsWith('video') ? 'video' : 'image');
    }
  };

  const handleSubmit = () => {
    if (file) {
      onUpload({ file, caption, type });
    }
  };

  const clearForm = () => {
    setFile(null);
    setPreview(null);
    setCaption('');
  };

  // Close effect: if we were posting and it finishes, the parent will close us.
  // We can also clear when we manually close.
  const handleManualClose = () => {
    if (isPosting) return;
    clearForm();
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md" onClick={handleManualClose}></div>
      
      <div className="relative w-full max-sm bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black text-white uppercase tracking-widest italic">{t.title}</h3>
            <button onClick={handleManualClose} disabled={isPosting} className="text-zinc-500 hover:text-white disabled:opacity-0">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="space-y-6">
            {/* Media Selector/Preview */}
            <div 
              onClick={() => !isPosting && fileInputRef.current?.click()}
              className={`relative w-full aspect-square bg-zinc-950 border-2 border-dashed rounded-3xl flex flex-col items-center justify-center cursor-pointer overflow-hidden group transition-all ${isPosting ? 'border-zinc-800 cursor-default' : 'border-zinc-800 hover:border-purple-500/50'}`}
            >
              {preview ? (
                type === 'video' ? (
                  <video src={preview} className="w-full h-full object-cover" autoPlay loop muted />
                ) : (
                  <img src={preview} className="w-full h-full object-cover" alt="Preview" />
                )
              ) : (
                <>
                  <div className="w-12 h-12 bg-purple-600/10 rounded-2xl flex items-center justify-center mb-3 group-hover:scale-110 transition-transform">
                    <svg className="w-6 h-6 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                    </svg>
                  </div>
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">{t.select}</span>
                </>
              )}
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*,video/*" 
                onChange={handleFileChange} 
                disabled={isPosting}
              />
            </div>

            {/* Caption Input */}
            <div className="space-y-2">
              <label className="text-[10px] font-black text-zinc-600 uppercase tracking-widest ml-1">{t.label}</label>
              <textarea 
                value={caption}
                onChange={(e) => setCaption(e.target.value)}
                disabled={isPosting}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-3 px-4 text-white text-sm focus:outline-none font-medium resize-none h-24 disabled:opacity-50"
                placeholder={t.placeholder}
              />
            </div>

            <button 
              onClick={handleSubmit}
              disabled={!file || isPosting}
              className="w-full bg-purple-600 disabled:opacity-50 disabled:cursor-not-allowed text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-purple-500/20 active:scale-95 transition-all"
            >
              {isPosting ? (
                <div className="flex items-center justify-center gap-2">
                   <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                   <span>UPLOADING...</span>
                </div>
              ) : t.button}
            </button>
          </div>
        </div>

        {/* HIGH ENERGY POSTING OVERLAY */}
        {isPosting && (
          <div className="absolute inset-0 z-50 bg-zinc-950/80 backdrop-blur-xl flex flex-col items-center justify-center p-8 animate-in fade-in duration-500">
             <div className="relative mb-8">
                {/* Outer Ring */}
                <div className="absolute -inset-8 bg-purple-600/20 rounded-full blur-3xl animate-pulse"></div>
                <div className="relative w-24 h-24">
                   <svg className="w-full h-full animate-spin text-purple-500" viewBox="0 0 100 100">
                      <circle className="opacity-10" cx="50" cy="50" r="40" stroke="currentColor" strokeWidth="8" fill="transparent"></circle>
                      <path className="opacity-100" fill="transparent" stroke="currentColor" strokeWidth="8" strokeLinecap="round" d="M50 10 a 40 40 0 0 1 40 40"></path>
                   </svg>
                   <div className="absolute inset-0 flex items-center justify-center">
                      <svg width="32" height="48" viewBox="0 0 46 70" fill="none" className="drop-shadow-[0_0_15px_rgba(168,85,247,0.8)]">
                        <path d="M41.5 0L0 38.5H18.5L4.5 70L46 31.5H27.5L41.5 0Z" fill="#A855F7"/>
                      </svg>
                   </div>
                </div>
             </div>
             
             <h2 className="text-xl font-black italic text-white uppercase tracking-tighter text-center mb-2 animate-bounce">
                {t.posting}
             </h2>
             <div className="flex flex-col items-center">
                <span className="text-[8px] font-black text-purple-500 uppercase tracking-[0.4em] animate-pulse">
                   {t.network}
                </span>
                <div className="mt-4 flex gap-1">
                   <div className="w-1 h-1 bg-purple-500 rounded-full animate-ping [animation-delay:-0.3s]"></div>
                   <div className="w-1 h-1 bg-purple-500 rounded-full animate-ping [animation-delay:-0.15s]"></div>
                   <div className="w-1 h-1 bg-purple-500 rounded-full animate-ping"></div>
                </div>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default UploadModal;
