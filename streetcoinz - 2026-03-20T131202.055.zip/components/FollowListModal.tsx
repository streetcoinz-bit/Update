
import React from 'react';
import { Language } from '../types';

interface FollowListUser {
  username: string;
  avatar: string;
  isFollowing?: boolean;
}

interface FollowListModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  users: FollowListUser[];
  onViewUser: (username: string) => void;
  language: Language;
  activeThemeClass: string;
}

const FollowListModal: React.FC<FollowListModalProps> = ({ 
  isOpen, 
  onClose, 
  title, 
  users, 
  onViewUser, 
  language, 
  activeThemeClass 
}) => {
  if (!isOpen) return null;
  const isDark = activeThemeClass === 'theme-dark';

  return (
    <div className="fixed inset-0 z-[160] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm" onClick={onClose}></div>
      
      <div className={`relative w-full max-sm max-h-[70vh] flex flex-col border rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
        <div className={`p-6 border-b flex justify-between items-center ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
          <h3 className={`text-sm font-black uppercase tracking-widest italic ${isDark ? 'text-white' : 'text-zinc-900'}`}>{title}</h3>
          <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-2 scrollbar-hide">
          {users.length > 0 ? users.map((u) => (
            <button
              key={u.username}
              onClick={() => {
                onViewUser(u.username);
                onClose();
              }}
              className={`w-full flex items-center gap-4 p-3 rounded-2xl border transition-all active:scale-[0.98] group ${isDark ? 'bg-zinc-950 border-zinc-800 hover:bg-zinc-800' : 'bg-zinc-50 border-zinc-100 hover:bg-white hover:shadow-md'}`}
            >
              <img 
                src={u.avatar} 
                className={`w-10 h-10 rounded-xl border p-0.5 ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`} 
                alt={u.username} 
              />
              <div className="flex-1 text-left">
                <span className={`text-xs font-black uppercase tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>@{u.username}</span>
                <p className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">Trader</p>
              </div>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${isDark ? 'bg-zinc-800' : 'bg-white shadow-sm'}`}>
                <svg className="w-4 h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            </button>
          )) : (
            <div className="py-12 flex flex-col items-center opacity-30">
               <svg className="w-12 h-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
               </svg>
               <span className="text-[10px] font-black uppercase tracking-widest italic">The street is quiet...</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default FollowListModal;
