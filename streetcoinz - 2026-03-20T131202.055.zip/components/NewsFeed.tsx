import React from 'react';
import { motion } from 'motion/react';
import { Newspaper, ExternalLink } from 'lucide-react';

const NEWS_ITEMS = [
  {
    id: 1,
    title: "Whales Spotted Dumping 'Concrete' Tokens in Lower East Side",
    source: "StreetWire",
    time: "2m ago",
    sentiment: "negative"
  },
  {
    id: 2,
    title: "Neon Protocol Upgrade Promises 100x Speed, 0x Gas",
    source: "CyberDaily",
    time: "15m ago",
    sentiment: "positive"
  },
  {
    id: 3,
    title: "Police Raid Underground Mining Farm in Abandoned Subway",
    source: "MetroNews",
    time: "1h ago",
    sentiment: "neutral"
  },
  {
    id: 4,
    title: "Graffiti Coin (TAG) Listed on Major Black Market Exchange",
    source: "DarkNet Digest",
    time: "3h ago",
    sentiment: "positive"
  }
];

export const NewsFeed: React.FC = () => {
  return (
    <div className="mt-12">
      <h2 className="font-display text-3xl flex items-center gap-3 mb-6">
        <Newspaper className="text-neon-blue" />
        STREET WIRE
      </h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {NEWS_ITEMS.map((item, index) => (
          <motion.div
            key={item.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
            className="bg-street-dark border border-street-gray p-4 rounded-lg hover:border-white/20 transition-colors group cursor-pointer"
          >
            <div className="flex justify-between items-start mb-2">
              <span className={`text-xs font-mono px-2 py-1 rounded ${
                item.sentiment === 'positive' ? 'bg-green-900/30 text-neon-green' :
                item.sentiment === 'negative' ? 'bg-red-900/30 text-red-500' :
                'bg-gray-800 text-gray-400'
              }`}>
                {item.source}
              </span>
              <span className="text-xs text-gray-500 font-mono">{item.time}</span>
            </div>
            <h3 className="font-bold text-lg leading-tight group-hover:text-neon-blue transition-colors">
              {item.title}
            </h3>
            <div className="mt-3 flex justify-end opacity-0 group-hover:opacity-100 transition-opacity">
              <ExternalLink size={16} className="text-gray-400" />
            </div>
          </motion.div>
        ))}
      </div>
    </div>
  );
};
