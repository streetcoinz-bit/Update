
import React, { useState } from 'react';
import { Notification, NotificationType, Language } from '../types';

interface NotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  notifications: Notification[];
  onMarkRead: (id: string) => void;
  onClearAll: () => void;
  language: Language;
  onViewProfile: (username: string) => void;
  activeThemeClass: string;
}

enum NotificationFilter {
  ALL = 'ALL',
  FOLLOW = 'FOLLOW',
  LIKE = 'LIKE',
  SHARE = 'SHARE'
}

const translations = {
  [Language.EN]: { 
    title: 'STREET PULSE', 
    clear: 'Clear Tab', 
    empty: 'The street is quiet.', 
    emptyFollows: 'No new traders joined your crew.',
    emptyLikes: 'No one flexed on your plays yet.',
    emptyShares: 'No alpha shared with you recently.',
    like: 'liked your flex', 
    reply: 'replied to you', 
    follow: 'is now following you', 
    system: 'System Update', 
    share: 'shared content with you', 
    profileShare: 'shared a trader profile',
    tabs: {
      all: 'All',
      follows: 'Follows',
      likes: 'Likes',
      shares: 'Shares'
    }
  },
  [Language.ID]: { 
    title: 'SINYAL JALANAN', 
    clear: 'Bersihkan Tab', 
    empty: 'Jalanan sedang sepi.', 
    emptyFollows: 'Belum ada pengikut baru.',
    emptyLikes: 'Belum ada yang menyukai kontenmu.',
    emptyShares: 'Belum ada info yang dibagikan.',
    like: 'menyukai flex Anda', 
    reply: 'membalas Anda', 
    follow: 'mulai mengikuti Anda', 
    system: 'Pembaruan Sistem', 
    share: 'membagikan konten dengan Anda', 
    profileShare: 'membagikan profil trader',
    tabs: {
      all: 'Semua',
      follows: 'Pengikut',
      likes: 'Suka',
      shares: 'Bagikan'
    }
  },
  [Language.ES]: { 
    title: 'PULSO CALLEJERO', 
    clear: 'Limpiar Tab', 
    empty: 'La calle está tranquila.', 
    emptyFollows: 'Sin nuevos seguidores.',
    emptyLikes: 'Sin nuevos likes.',
    emptyShares: 'Nada compartido.',
    like: 'le gustó tu flex', 
    reply: 'te respondió', 
    follow: 'te está siguiendo', 
    system: 'Actualización', 
    share: 'compartió contenido contigo', 
    profileShare: 'compartió un perfil',
    tabs: {
      all: 'Todo',
      follows: 'Seguidores',
      likes: 'Likes',
      shares: 'Compartido'
    }
  },
  [Language.CN]: { 
    title: '街道动态', 
    clear: '清除当前', 
    empty: '街上很安静。', 
    emptyFollows: '还没有新关注者。',
    emptyLikes: '还没有人点赞。',
    emptyShares: '最近没有分享。',
    like: '赞了你的动态', 
    reply: '回复了你', 
    follow: '关注了你', 
    system: '系统更新', 
    share: '分享了一个动态给你', 
    profileShare: '分享了一个交易者资料',
    tabs: {
      all: '全部',
      follows: '关注',
      likes: '点赞',
      shares: '分享'
    }
  }
};

const NotificationModal: React.FC<NotificationModalProps> = ({ isOpen, onClose, notifications, onMarkRead, onClearAll, language, onViewProfile, activeThemeClass }) => {
  const [activeFilter, setActiveFilter] = useState<NotificationFilter>(NotificationFilter.ALL);
  
  if (!isOpen) return null;
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';

  const filteredNotifications = notifications.filter(n => {
    if (activeFilter === NotificationFilter.ALL) return true;
    if (activeFilter === NotificationFilter.FOLLOW) return n.type === NotificationType.FOLLOW;
    if (activeFilter === NotificationFilter.LIKE) return n.type === NotificationType.LIKE || n.type === NotificationType.REPLY;
    if (activeFilter === NotificationFilter.SHARE) return n.type === NotificationType.SHARE;
    return true;
  });

  const getIcon = (type: NotificationType) => {
    switch (type) {
      case NotificationType.LIKE:
        return <div className="bg-rose-500 p-1.5 rounded-full shadow-[0_0_10px_rgba(244,63,94,0.4)]"><svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" /></svg></div>;
      case NotificationType.REPLY:
        return <div className="bg-purple-600 p-1.5 rounded-full shadow-[0_0_10px_rgba(168,85,247,0.4)]"><svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" /></svg></div>;
      case NotificationType.FOLLOW:
        return <div className="bg-blue-600 p-1.5 rounded-full shadow-[0_0_10px_rgba(37,99,235,0.4)]"><svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2M8 7a4 4 0 100-8 4 4 0 000 8zm12 11l-3-3m0 0l-3 3m3-3v8" /></svg></div>;
      case NotificationType.SHARE:
        return <div className="bg-emerald-500 p-1.5 rounded-full shadow-[0_0_10px_rgba(16,185,129,0.4)]"><svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" /></svg></div>;
      default:
        return <div className="bg-zinc-700 p-1.5 rounded-full"><svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg></div>;
    }
  };

  const getContent = (notification: Notification) => {
    switch (notification.type) {
      case NotificationType.LIKE: return t.like;
      case NotificationType.REPLY: return t.reply;
      case NotificationType.FOLLOW: return t.follow;
      case NotificationType.SHARE: return notification.sharedProfileUsername ? t.profileShare : t.share;
      default: return notification.content;
    }
  };

  const handleNotificationClick = (n: Notification) => {
    onMarkRead(n.id);
    if (n.sharedProfileUsername) {
      onViewProfile(n.sharedProfileUsername);
    } else if (n.type === NotificationType.FOLLOW) {
      onViewProfile(n.username);
    }
  };

  const getEmptyMessage = () => {
    switch (activeFilter) {
      case NotificationFilter.FOLLOW: return t.emptyFollows;
      case NotificationFilter.LIKE: return t.emptyLikes;
      case NotificationFilter.SHARE: return t.emptyShares;
      default: return t.empty;
    }
  };

  const hasUnreadInTab = (type: NotificationFilter) => {
    return notifications.some(n => {
      if (!n.isRead) {
        if (type === NotificationFilter.FOLLOW) return n.type === NotificationType.FOLLOW;
        if (type === NotificationFilter.LIKE) return n.type === NotificationType.LIKE || n.type === NotificationType.REPLY;
        if (type === NotificationFilter.SHARE) return n.type === NotificationType.SHARE;
      }
      return false;
    });
  };

  return (
    <div className="fixed inset-0 z-[240] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose}></div>
      <div className={`relative w-full max-w-[380px] h-[80vh] max-h-[700px] flex flex-col rounded-[40px] border overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 ${isDark ? 'bg-zinc-950 border-zinc-800' : 'bg-white border-zinc-200'}`}>
        
        {/* Header */}
        <div className={`p-6 pb-4 flex justify-between items-center ${isDark ? 'border-zinc-900' : 'border-zinc-100'}`}>
          <h3 className="text-sm font-black italic uppercase tracking-[0.2em] font-heading">{t.title}</h3>
          <button 
            onClick={onClearAll} 
            className="text-[9px] font-black text-rose-500 uppercase hover:text-rose-400 transition-all active:scale-90"
          >
            {t.clear}
          </button>
        </div>

        {/* Categories Tab Bar */}
        <div className="px-4 mb-4">
           <div className={`flex gap-1 p-1 rounded-2xl border ${isDark ? 'bg-zinc-900/50 border-zinc-800/50' : 'bg-zinc-50 border-zinc-200'}`}>
              {[
                { id: NotificationFilter.ALL, label: t.tabs.all, dot: 'bg-white' },
                { id: NotificationFilter.FOLLOW, label: t.tabs.follows, dot: 'bg-blue-500' },
                { id: NotificationFilter.LIKE, label: t.tabs.likes, dot: 'bg-rose-500' },
                { id: NotificationFilter.SHARE, label: t.tabs.shares, dot: 'bg-emerald-500' }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setActiveFilter(tab.id)}
                  className={`flex-1 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-wider transition-all relative ${activeFilter === tab.id ? (isDark ? 'bg-zinc-800 text-white shadow-lg' : 'bg-white text-zinc-900 shadow-md') : 'text-zinc-500 hover:text-zinc-400'}`}
                >
                  {tab.label}
                  {tab.id !== NotificationFilter.ALL && hasUnreadInTab(tab.id) && (
                    <span className={`absolute top-1.5 right-1.5 w-1.5 h-1.5 rounded-full animate-pulse ${tab.dot}`}></span>
                  )}
                </button>
              ))}
           </div>
        </div>

        {/* Notification List */}
        <div className="flex-1 overflow-y-auto p-4 pt-0 space-y-2.5 scrollbar-hide">
          {filteredNotifications.length > 0 ? filteredNotifications.map((n) => (
            <div 
              key={n.id} 
              onClick={() => handleNotificationClick(n)}
              className={`group flex items-center gap-3.5 p-3.5 rounded-[24px] border transition-all cursor-pointer active:scale-[0.98] ${n.isRead ? 'bg-transparent border-transparent opacity-40' : (isDark ? 'bg-zinc-900 border-zinc-800 shadow-lg' : 'bg-zinc-50 border-zinc-100 shadow-sm')}`}
            >
              <div className="relative">
                <img src={n.avatar} className="w-11 h-11 rounded-2xl object-cover border-2 border-transparent group-hover:border-purple-500/30 transition-all" alt={n.username} />
                <div className="absolute -bottom-1 -right-1">
                  {getIcon(n.type)}
                </div>
              </div>
              <div className="flex-1 min-w-0">
                <p className={`text-[11px] leading-snug font-medium ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>
                  <span className={`font-black uppercase tracking-tight mr-1.5 ${isDark ? 'text-white' : 'text-zinc-900'}`}>@{n.username}</span>
                  {getContent(n)}
                </p>
                {(n.type === NotificationType.REPLY || n.type === NotificationType.SHARE) && (
                  <p className="text-[9px] text-zinc-500 mt-1.5 italic truncate bg-black/10 p-1 rounded">"{n.content}"</p>
                )}
                <div className="flex items-center gap-2 mt-2">
                   <span className="text-[7px] font-black text-zinc-500 uppercase tracking-widest">
                    {new Date(n.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                   </span>
                   {!n.isRead && <span className="w-1 h-1 rounded-full bg-purple-500"></span>}
                </div>
              </div>
              <div className="opacity-0 group-hover:opacity-100 transition-opacity">
                 <svg className="w-4 h-4 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path d="M9 5l7 7-7 7" /></svg>
              </div>
            </div>
          )) : (
            <div className="h-full flex flex-col items-center justify-center opacity-30 text-center animate-in fade-in duration-500">
               <div className={`w-16 h-16 rounded-[24px] mb-4 flex items-center justify-center border-2 border-dashed ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
                  <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
               </div>
               <span className="text-[10px] font-black uppercase tracking-[0.2em] italic max-w-[200px] leading-relaxed">
                  {getEmptyMessage()}
               </span>
            </div>
          )}
        </div>
        
        {/* Footer info */}
        <div className={`p-4 text-center ${isDark ? 'bg-zinc-950' : 'bg-white'}`}>
           <span className="text-[7px] font-black text-zinc-600 uppercase tracking-[0.4em]">Synced with Street Protocol Network</span>
        </div>
      </div>
    </div>
  );
};

export default NotificationModal;
