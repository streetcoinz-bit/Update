
import React, { useState, useRef, useMemo } from 'react';
import { UserProfile, UserWallet, VideoPost, UserStatus, Language, AppTheme, Message } from '../types';
import { uploadFile } from '../storage';
import StatusViewer from './StatusViewer';

interface ProfileDetailsProps {
  user: UserProfile;
  wallet: UserWallet;
  posts: VideoPost[];
  statuses: UserStatus[];
  viewedStatusIds: Set<string>;
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: AppTheme;
  setTheme: (theme: AppTheme) => void;
  activeThemeClass: string;
  onLogout: () => void;
  onUpdateProfile: (updatedUser: UserProfile) => void;
  onOpenList: (type: 'Followers' | 'Following') => void;
  onBack: () => void;
  onViewPost?: (postId: string) => void;
  onShareProfile?: () => void;
  onDeleteStatus: (id: string) => void;
  onShareStatus: (status: UserStatus) => void;
  onSendMessage: (targetId: string, msg: Partial<Message>) => void;
  onMarkStatusRead: (id: string) => void;
}

const translations = {
  [Language.EN]: {
    settings: 'Settings',
    switchTheme: 'Theme',
    themeClean: 'Light',
    themeDark: 'Dark',
    language: 'Language',
    edit: 'Edit Profile',
    logout: 'Sign Out',
    save: 'Save Changes',
    cancel: 'Cancel',
    referral: 'Referral',
    inviteEarn: 'Invite & Earn',
    yourCode: 'Your Code',
    copy: 'Copy Link',
    copied: 'Link Copied!',
    posts: 'Posts',
    followers: 'Followers',
    following: 'Following',
    likes: 'Likes',
    bioLabel: 'Bio',
    linksLabel: 'STREET LINKS',
    addLink: 'Add Link',
    linkPlaceholder: 'https://...',
    uploading: 'SECURING IDENTITY...',
    pickMedia: 'PICK FROM DEVICE',
    myGallery: 'MY FLEXES',
    noFlex: 'No flexes recorded. Start trading!',
    myAlphas: 'YOUR ACTIVE ALPHAS'
  },
  [Language.ID]: {
    settings: 'Pengaturan',
    switchTheme: 'Tema',
    themeClean: 'Terang',
    themeDark: 'Gelap',
    language: 'Pilih Bahasa',
    edit: 'Edit Profil',
    logout: 'Keluar',
    save: 'Simpan Perubahan',
    cancel: 'Batal',
    referral: 'Referral',
    inviteEarn: 'Undang & Cuan',
    yourCode: 'Kode Anda',
    copy: 'Salin Tautan',
    copied: 'Tautan Disalin!',
    posts: 'Postingan',
    following: 'Mengikuti',
    followers: 'Pengikut',
    likes: 'Likes',
    bioLabel: 'Bio',
    linksLabel: 'TAUTAN JALANAN',
    addLink: 'Tambah Tautan',
    linkPlaceholder: 'https://...',
    uploading: 'MENGAMANKAN IDENTITAS...',
    pickMedia: 'AMBIL DARI PERANGKAT',
    myGallery: 'FLEX SAYA',
    noFlex: 'Belum ada flex. Mulai trading!',
    myAlphas: 'ALPHA AKTIF ANDA'
  },
  [Language.ES]: {
    settings: 'Ajustes',
    switchTheme: 'Tema',
    themeClean: 'Claro',
    themeDark: 'Oscuro',
    language: 'Seleccionar Idioma',
    edit: 'Editar Perfil',
    logout: 'Cerrar Sesión',
    save: 'Guardar Cambios',
    cancel: 'Cancelar',
    referral: 'Referencia',
    inviteEarn: 'Invita y Gana',
    yourCode: 'Tu Código',
    copy: 'Copiar Enlace',
    copied: '¡Enlace Copiado!',
    posts: 'Posts',
    followers: 'Seguidores',
    following: 'Siguiendo',
    likes: 'Likes',
    bioLabel: 'Bio',
    linksLabel: 'ENLACES CALLEJEROS',
    addLink: 'Añadir Enlace',
    linkPlaceholder: 'https://...',
    uploading: 'ASEGURANDO IDENTIDAD...',
    pickMedia: 'ELEGIR DEL DISPOSITIVO',
    myGallery: 'MIS FLEXES',
    noFlex: 'Sin flexes. ¡Empieza a operar!',
    myAlphas: 'TUS ALPHAS ACTIVOS'
  },
  [Language.CN]: {
    settings: '设置',
    switchTheme: '主题',
    themeClean: '明亮',
    themeDark: '深色',
    language: '选择语言',
    edit: '编辑资料',
    logout: '退出登录',
    save: '保存更改',
    cancel: '取消',
    referral: '推荐',
    inviteEarn: '邀请赚取',
    yourCode: '您的代码',
    copy: '复制链接',
    copied: '链接已复制!',
    posts: '帖子',
    followers: '关注者',
    following: '正在关注',
    likes: '获赞',
    bioLabel: '简介',
    linksLabel: '外部链接',
    addLink: '添加链接',
    linkPlaceholder: 'https://...',
    uploading: '正在保护身份...',
    pickMedia: '从设备中选择',
    myGallery: '我的秀操作',
    noFlex: '目前没有秀操作。开始交易吧！',
    myAlphas: '您的活跃阿尔法'
  }
};

const ProfileDetails: React.FC<ProfileDetailsProps> = ({ user, wallet, posts, statuses, viewedStatusIds, language, setLanguage, theme, setTheme, activeThemeClass, onLogout, onUpdateProfile, onOpenList, onBack, onViewPost, onShareProfile, onDeleteStatus, onShareStatus, onSendMessage, onMarkStatusRead }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [editedName, setEditedName] = useState(user.name);
  const [editedBio, setEditedBio] = useState(user.bio || '');
  const [editedLinks, setEditedLinks] = useState<string[]>(user.links || []);
  const [currentPreviewAvatar, setCurrentPreviewAvatar] = useState(user.avatar);
  const [isUploading, setIsUploading] = useState(false);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerStartIndex, setViewerStartIndex] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';

  const currentUsername = user.name.toLowerCase().replace(/\s/g, '_');
  const myPosts = posts.filter(p => p.username === currentUsername);
  const myStatuses = statuses.filter(s => s.username === currentUsername);

  const hasUnreadAlpha = useMemo(() => {
    return myStatuses.some(s => !viewedStatusIds.has(s.id));
  }, [myStatuses, viewedStatusIds]);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setCurrentPreviewAvatar(reader.result as string);
      };
      reader.readAsDataURL(file);

      setIsUploading(true);
      try {
        const uploadedUrl = await uploadFile(file, user.name);
        setCurrentPreviewAvatar(uploadedUrl);
      } catch (err) {
        console.error("Avatar upload failed", err);
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handleSave = () => {
    onUpdateProfile({
      ...user,
      name: editedName,
      bio: editedBio,
      links: editedLinks.filter(l => l.trim() !== ''),
      avatar: currentPreviewAvatar
    });
    setIsEditing(false);
  };

  const handleCancel = () => {
    setEditedName(user.name);
    setEditedBio(user.bio || '');
    setEditedLinks(user.links || []);
    setCurrentPreviewAvatar(user.avatar);
    setIsEditing(false);
  };

  const addLinkField = () => {
    setEditedLinks([...editedLinks, '']);
  };

  const updateLinkValue = (index: number, value: string) => {
    const newLinks = [...editedLinks];
    newLinks[index] = value;
    setEditedLinks(newLinks);
  };

  const removeLinkField = (index: number) => {
    setEditedLinks(editedLinks.filter((_, i) => i !== index));
  };

  const formatCount = (num: number) => {
    if (num >= 1000000) return (num / 1000000).toFixed(1) + 'M';
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const getLinkMetadata = (url: string) => {
    const lowerUrl = url.toLowerCase();
    if (lowerUrl.includes('twitter.com') || lowerUrl.includes('x.com')) return { icon: '𝕏', color: 'text-white' };
    if (lowerUrl.includes('t.me') || lowerUrl.includes('telegram')) return { icon: '✈️', color: 'text-sky-400' };
    if (lowerUrl.includes('youtube.com')) return { icon: '📺', color: 'text-rose-500' };
    if (lowerUrl.includes('instagram.com')) return { icon: '📸', color: 'text-pink-500' };
    if (lowerUrl.includes('discord')) return { icon: '👾', color: 'text-indigo-400' };
    if (lowerUrl.includes('github.com')) return { icon: '🐙', color: 'text-white' };
    if (lowerUrl.includes('linkedin.com')) return { icon: '💼', color: 'text-blue-500' };
    return { icon: '🔗', color: 'text-purple-500' };
  };

  const themes = [
    { 
      code: AppTheme.CLEAN, 
      label: t.themeClean, 
      icon: (
        <svg className="w-5 h-5 mb-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364-6.364l-.707.707M6.343 17.657l-.707.707m12.728 0l-.707-.707M6.343 6.343l-.707-.707M12 8a4 4 0 100 8 4 4 0 000-8z" />
        </svg>
      )
    },
    { 
      code: AppTheme.DARK, 
      label: t.themeDark, 
      icon: (
        <svg className="w-5 h-5 mb-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
        </svg>
      )
    }
  ];

  const handleOpenStatus = () => {
    const idx = statuses.findIndex(s => s.username === currentUsername);
    if (idx !== -1) {
      setViewerStartIndex(idx);
      setIsViewerOpen(true);
    }
  };

  if (isViewerOpen) {
    return (
      <StatusViewer
        statuses={statuses}
        initialIndex={viewerStartIndex}
        onClose={() => setIsViewerOpen(false)}
        onDelete={(id) => {
          onDeleteStatus(id);
          if (statuses.length <= 1) setIsViewerOpen(false);
        }}
        onShare={(status) => {
          onShareStatus(status);
          setIsViewerOpen(false);
        }}
        onReplyToDM={() => {}}
        onViewProfile={() => {}}
        onMarkAsRead={onMarkStatusRead}
        currentUserUsername={currentUsername}
        activeThemeClass={activeThemeClass}
        language={language}
      />
    );
  }

  return (
    <div className={`flex flex-col h-full overflow-y-auto scrollbar-hide transition-colors duration-300 ${isDark ? 'text-white' : 'text-zinc-900'}`}>
      
      {/* Immersive Header */}
      <div className="flex justify-between items-center p-6 pt-2">
        <button 
          onClick={onBack}
          className={`p-3 rounded-2xl border transition-all active:scale-90 ${isDark ? 'bg-zinc-950 border-zinc-900 text-zinc-400 hover:text-white' : 'bg-white border-zinc-200 text-zinc-500 hover:text-zinc-900'}`}
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
          </svg>
        </button>

        <div className="flex items-center gap-2">
          {!isEditing && onShareProfile && (
            <button 
              onClick={onShareProfile}
              className={`p-3 rounded-2xl border transition-all active:scale-90 ${isDark ? 'bg-zinc-950 border-zinc-900 text-zinc-400 hover:text-white' : 'bg-white border-zinc-200 text-zinc-500 hover:text-zinc-900'}`}
            >
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
            </button>
          )}
          <button 
            onClick={() => setIsMenuOpen(true)}
            className={`p-3 rounded-2xl border transition-all active:scale-90 ${isDark ? 'bg-zinc-950 border-zinc-900 text-zinc-400 hover:text-white' : 'bg-white border-zinc-200 text-zinc-500 hover:text-zinc-900'}`}
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M4 6h16M4 12h16m-7 6h7" />
            </svg>
          </button>
        </div>
      </div>

      {/* Settings Menu */}
      <div className={`fixed inset-0 z-[100] transition-opacity duration-300 ${isMenuOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setIsMenuOpen(false)}></div>
        <div className={`absolute top-0 right-0 h-full w-4/5 max-sm:w-full transition-transform duration-300 ease-out flex flex-col ${isMenuOpen ? 'translate-x-0' : 'translate-x-full'} ${isDark ? 'bg-zinc-900 border-l border-zinc-800' : 'bg-white border-l border-zinc-200'}`}>
          <div className={`p-6 flex justify-between items-center border-b ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
            <h3 className={`text-xs font-black uppercase tracking-[0.3em] font-heading ${isDark ? 'text-white' : 'text-zinc-900'}`}>{t.settings}</h3>
            <button onClick={() => setIsMenuOpen(false)} className="text-zinc-500 hover:text-white transition-colors">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
          
          <div className="flex-1 overflow-y-auto p-6 space-y-8">
            <section>
              <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-4">{t.switchTheme}</h4>
              <div className="grid grid-cols-2 gap-2">
                {themes.map((tItem) => (
                  <button 
                    key={tItem.code}
                    onClick={() => setTheme(tItem.code)}
                    className={`flex flex-col items-center justify-center py-3 rounded-2xl border-2 transition-all active:scale-95 ${theme === tItem.code ? 'border-purple-500 bg-purple-500/10 text-purple-500' : (isDark ? 'border-zinc-800 bg-zinc-950 text-zinc-500' : 'border-zinc-200 bg-zinc-50 text-zinc-400')}`}
                  >
                    {tItem.icon}
                    <span className="text-[9px] font-black uppercase tracking-tighter">{tItem.label}</span>
                  </button>
                ))}
              </div>
            </section>
            
            <button 
              onClick={onLogout}
              className="w-full bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 py-4 rounded-2xl font-black text-xs uppercase tracking-widest border border-rose-500/20 transition-all active:scale-95"
            >
              {t.logout}
            </button>
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center px-6 mb-8">
        <div 
          className="relative group cursor-pointer" 
          onClick={() => {
            if (isEditing) {
              if (!isUploading) fileInputRef.current?.click();
            } else if (myStatuses.length > 0) {
              handleOpenStatus();
            }
          }}
        >
          <div className={`absolute -inset-2 rounded-full blur transition duration-1000 ${isDark ? 'opacity-40' : 'opacity-20'} ${myStatuses.length > 0 ? (hasUnreadAlpha ? 'bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 animate-pulse' : 'bg-zinc-800') : (isDark ? 'bg-zinc-800' : 'bg-zinc-200')}`}></div>
          
          {/* Status Indicator Ring */}
          {myStatuses.length > 0 && !isEditing && (
            <div className={`absolute -inset-2.5 rounded-full border-4 border-transparent ${hasUnreadAlpha ? 'bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 p-1.5 shadow-[0_0_20px_rgba(168,85,247,0.4)]' : 'bg-zinc-800 p-1'} [mask-image:linear-gradient(white,white),linear-gradient(white,white)] [mask-clip:content-box,padding-box] [mask-composite:exclude] animate-in zoom-in-50 duration-500`}></div>
          )}

          <div className="relative">
            <img 
              src={isEditing ? currentPreviewAvatar : user.avatar} 
              alt="Profile" 
              className={`w-32 h-32 rounded-full border-4 shadow-2xl transition-all duration-500 object-cover ${isDark ? 'border-zinc-950' : 'border-white'} ${isUploading ? 'opacity-50 blur-sm' : ''} ${!isEditing && myStatuses.length > 0 ? 'hover:scale-105 transition-transform' : ''}`}
            />
            {isEditing && !isUploading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/50 rounded-full transition-opacity opacity-100 group-hover:bg-black/40">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-white mb-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                </svg>
                <span className="text-[7px] font-black text-white uppercase tracking-widest">{t.pickMedia}</span>
              </div>
            )}
            {isUploading && (
              <div className="absolute inset-0 flex flex-col items-center justify-center rounded-full z-20">
                <div className="w-8 h-8 border-4 border-white/20 border-t-white rounded-full animate-spin mb-2"></div>
                <span className="text-[6px] font-black text-white uppercase tracking-[0.2em]">{t.uploading}</span>
              </div>
            )}
          </div>
          <input 
            type="file" 
            ref={fileInputRef} 
            onChange={handleFileChange} 
            className="hidden" 
            accept="image/*" 
          />
        </div>

        {isEditing ? (
          <div className="w-full mt-8 space-y-6 animate-in fade-in slide-in-from-top-4 duration-300">
            <div className="space-y-4">
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-1 block">Street Name</label>
                <input 
                  type="text" 
                  value={editedName}
                  onChange={(e) => setEditedName(e.target.value)}
                  className={`w-full border rounded-2xl py-3.5 px-5 text-sm focus:outline-none font-black uppercase tracking-tight ${isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-200 text-zinc-900'}`}
                  placeholder="Name"
                />
              </div>
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-1 block">{t.bioLabel}</label>
                <textarea 
                  value={editedBio}
                  onChange={(e) => setEditedBio(e.target.value)}
                  className={`w-full border rounded-2xl py-3.5 px-5 text-sm focus:outline-none font-medium h-24 resize-none ${isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-200 text-zinc-900'}`}
                  placeholder="Tell the street who you are..."
                />
              </div>

              {/* Editable Links */}
              <div>
                <div className="flex justify-between items-center mb-2 px-1">
                  <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest block">{t.linksLabel}</label>
                  <button 
                    onClick={addLinkField}
                    className="flex items-center gap-1.5 px-3 py-1 bg-purple-600/10 border border-purple-500/20 rounded-lg text-[9px] font-black text-purple-500 uppercase tracking-widest hover:bg-purple-600 hover:text-white transition-all shadow-[0_0_10px_rgba(168,85,247,0.1)] active:scale-95"
                  >
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path d="M12 4v16m8-8H4" /></svg>
                    {t.addLink}
                  </button>
                </div>
                <div className="space-y-3">
                  {editedLinks.map((link, idx) => (
                    <div key={idx} className="flex gap-2 animate-in slide-in-from-right-2 duration-300">
                      <div className="relative flex-1 group">
                        <div className="absolute left-4 top-1/2 -translate-y-1/2 text-lg opacity-50 group-focus-within:opacity-100 transition-opacity">
                          {getLinkMetadata(link).icon}
                        </div>
                        <input 
                          type="text" 
                          value={link}
                          onChange={(e) => updateLinkValue(idx, e.target.value)}
                          className={`w-full border rounded-2xl py-3 pl-12 pr-4 text-xs focus:outline-none font-bold tracking-tight transition-all ${isDark ? 'bg-zinc-900 border-zinc-800 text-white focus:border-purple-500/50' : 'bg-white border-zinc-200 text-zinc-900 focus:border-purple-500'}`}
                          placeholder={t.linkPlaceholder}
                        />
                      </div>
                      <button 
                        onClick={() => removeLinkField(idx)}
                        className="p-3 text-rose-500 hover:bg-rose-500/10 rounded-2xl transition-all border border-transparent hover:border-rose-500/20 active:scale-90"
                      >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex gap-2">
              <button 
                onClick={handleSave} 
                disabled={isUploading}
                className="flex-1 bg-white text-zinc-900 py-4 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] active:scale-95 disabled:opacity-50 transition-all shadow-xl shadow-white/5"
              >
                {t.save}
              </button>
              <button 
                onClick={handleCancel} 
                className="flex-1 bg-zinc-800 text-white py-4 rounded-2xl font-black text-[11px] uppercase tracking-[0.2em] active:scale-95 transition-all"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        ) : (
          <div className="flex flex-col items-center w-full">
            <h2 className={`mt-5 text-2xl font-black font-heading italic tracking-tighter uppercase ${isDark ? 'text-white' : 'text-zinc-900'}`}>{user.name}</h2>
            <p className="text-zinc-500 text-[10px] font-bold tracking-widest uppercase mb-3">{user.email}</p>
            {user.bio && (
              <p className={`text-center px-4 mb-4 text-xs font-medium max-w-[300px] leading-relaxed ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
                {user.bio}
              </p>
            )}

            {/* Display Links */}
            {user.links && user.links.length > 0 && (
              <div className="flex flex-wrap justify-center gap-2 px-6 mb-6">
                {user.links.map((link, idx) => {
                  const meta = getLinkMetadata(link);
                  const displayUrl = link.replace(/^https?:\/\/(www\.)?/, '').split('/')[0] + (link.includes('/') ? '/' + link.split('/').slice(1,2) : '');
                  return (
                    <a 
                      key={idx} 
                      href={link.startsWith('http') ? link : `https://${link}`} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className={`flex items-center gap-2 px-4 py-2 rounded-2xl border text-[10px] font-black uppercase tracking-wider transition-all active:scale-90 animate-in fade-in zoom-in duration-300 ${isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-100 hover:text-white hover:border-purple-500/50 hover:bg-zinc-800 shadow-xl' : 'bg-white border-zinc-200 text-zinc-700 hover:bg-zinc-50 shadow-sm'}`}
                      style={{ animationDelay: `${idx * 100}ms` }}
                    >
                      <span className={`text-sm ${meta.color}`}>{meta.icon}</span>
                      <span className="max-w-[120px] truncate">{displayUrl}</span>
                    </a>
                  );
                })}
              </div>
            )}
            
            {/* Horizontal Stats Grid: POSTS | FOLLOWING | FOLLOWERS | LIKES */}
            <div className="flex items-center justify-center gap-4 mt-6 w-full px-6">
              <div className="flex flex-col items-center flex-1">
                <span className={`text-xl font-black italic tracking-tighter leading-none ${isDark ? 'text-white' : 'text-zinc-900'}`}>{myPosts.length}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.posts}</span>
              </div>
              
              <div className="w-px h-6 bg-zinc-800/50"></div>
              
              <button onClick={() => onOpenList('Following')} className="flex flex-col items-center flex-1 group transition-transform hover:scale-105">
                <span className={`text-xl font-black italic tracking-tighter leading-none group-hover:text-purple-500 transition-colors ${isDark ? 'text-white' : 'text-zinc-900'}`}>{formatCount(user.followingCount)}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.following}</span>
              </button>
              
              <div className="w-px h-6 bg-zinc-800/50"></div>
              
              <button onClick={() => onOpenList('Followers')} className="flex flex-col items-center flex-1 group transition-transform hover:scale-105">
                <span className={`text-xl font-black italic tracking-tighter leading-none group-hover:text-purple-500 transition-colors ${isDark ? 'text-white' : 'text-zinc-900'}`}>{formatCount(user.followerCount)}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.followers}</span>
              </button>
              
              <div className="w-px h-6 bg-zinc-800/50"></div>
              
              <div className="flex flex-col items-center flex-1">
                <span className={`text-xl font-black italic tracking-tighter leading-none ${isDark ? 'text-white' : 'text-zinc-900'}`}>{formatCount(user.totalLikes)}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.likes}</span>
              </div>
            </div>
            
            <button 
              onClick={() => setIsEditing(true)}
              className={`mt-10 px-12 py-3.5 rounded-2xl border font-black text-[10px] uppercase tracking-[0.2em] transition-all active:scale-95 ${isDark ? 'bg-zinc-900 border-zinc-800 text-white shadow-xl shadow-black/40' : 'bg-white border-zinc-200 text-zinc-900 shadow-lg shadow-zinc-200/50'}`}
            >
              {t.edit}
            </button>
          </div>
        )}
      </div>

      {/* Gallery Section */}
      {!isEditing && (
        <div className="mt-12 px-6 pb-32">
          <div className="flex items-center justify-between mb-4 px-1">
             <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">{t.myGallery}</h3>
             <span className="text-[9px] font-black text-purple-500 uppercase">{myPosts.length} Items</span>
          </div>

          {myPosts.length > 0 ? (
            <div className="grid grid-cols-3 gap-1 animate-in fade-in slide-in-from-bottom-4 duration-500">
               {myPosts.map((post) => (
                 <div 
                  key={post.id} 
                  onClick={() => onViewPost?.(post.id)}
                  className="aspect-[3/4] bg-zinc-900 rounded-lg overflow-hidden relative group cursor-pointer shadow-lg shadow-black/20"
                >
                    {post.mediaType === 'video' ? (
                      <video 
                        src={post.url} 
                        className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" 
                        muted 
                        playsInline
                        onMouseOver={(e) => e.currentTarget.play()}
                        onMouseOut={(e) => { e.currentTarget.pause(); e.currentTarget.currentTime = 0; }}
                      />
                    ) : (
                      <img src={post.url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" alt={post.caption} />
                    )}
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-2">
                       <div className="flex items-center gap-1">
                          <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" /></svg>
                          <span className="text-[8px] font-black text-white">{post.likes}</span>
                       </div>
                    </div>
                 </div>
               ))}
            </div>
          ) : (
            <div className="py-16 flex flex-col items-center justify-center border-2 border-dashed border-zinc-800/50 rounded-[32px] opacity-30">
               <div className="w-16 h-16 rounded-[24px] bg-zinc-900 flex items-center justify-center mb-4">
                  <svg className="w-8 h-8 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2-2v8a2 2 0 002 2z" />
                  </svg>
               </div>
               <span className="text-[10px] font-black uppercase tracking-[0.2em] italic text-center px-8">{t.noFlex}</span>
            </div>
          )}
          
          <div className="mt-12 text-center opacity-10">
             <span className="text-[9px] font-black uppercase tracking-[0.3em] italic">Identity Secured by Street Protocol</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProfileDetails;
