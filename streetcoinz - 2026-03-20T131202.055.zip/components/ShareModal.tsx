
import React, { useState } from 'react';
import { VideoPost, UserStatus, Language } from '../types';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  post: VideoPost | null;
  status: UserStatus | null;
  profileUsername?: string | null;
  language: Language;
  onInternalShare: (usernames: string[]) => void;
}

const translations = {
  [Language.EN]: { title: 'Share to', internal: 'Send to Traders', external: 'Share to Apps', copy: 'Copy Link', copied: 'Copied!', sendBtn: 'Send to {n} Traders', sharingProfile: 'Sharing Trader Profile', sharingStatus: 'Sharing Alpha Status' },
  [Language.ID]: { title: 'Bagikan ke', internal: 'Kirim ke Trader', external: 'Bagikan ke Aplikasi', copy: 'Salin Tautan', copied: 'Tersalin!', sendBtn: 'Kirim ke {n} Trader', sharingProfile: 'Berbagi Profil Trader', sharingStatus: 'Berbagi Status Alpha' },
  [Language.ES]: { title: 'Compartir en', internal: 'Enviar a Traders', external: 'Compartir en Apps', copy: 'Copiar Enlace', copied: '¡Copiado!', sendBtn: 'Enviar a {n} Traders', sharingProfile: 'Compartir Perfil', sharingStatus: 'Compartir Alpha' },
  [Language.CN]: { title: '分享至', internal: '发送给交易者', external: '分享到应用', copy: '复制链接', copied: '已复制!', sendBtn: '发送给 {n} 位交易者', sharingProfile: '分享交易者资料', sharingStatus: '分享阿尔法状态' }
};

const TRADERS = [
  { username: 'crypto_whale_99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto_whale_99' },
  { username: 'scalp_queen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=scalp_queen' },
  { username: 'street_trader_id', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=street_trader_id' },
  { username: 'alpha_king', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alpha_king' },
  { username: 'dex_demon', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dex_demon' },
  { username: 'moon_walker', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=moon_walker' },
  { username: 'bull_runner', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bull_runner' },
  { username: 'bear_trap', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bear_trap' },
];

const ShareModal: React.FC<ShareModalProps> = ({ isOpen, onClose, post, status, profileUsername, language, onInternalShare }) => {
  const [copied, setCopied] = useState(false);
  const [selectedTraders, setSelectedTraders] = useState<string[]>([]);
  const [isSending, setIsSending] = useState(false);
  
  if (!isOpen || (!post && !profileUsername && !status)) return null;
  const t = translations[language];

  const shareUrl = post 
    ? `${window.location.origin}/post/${post.id}`
    : status
      ? `${window.location.origin}/status/${status.id}`
      : `${window.location.origin}/profile/${profileUsername}`;
    
  const shareText = post
    ? `Check out this flex by @${post.username} on StreetCoinz! 🚀`
    : status
      ? `Check out this Alpha by @${status.username}: "${status.text}"`
      : `Check out the alpha from @${profileUsername} on StreetCoinz! 📈`;

  const handleCopy = () => {
    navigator.clipboard.writeText(`${shareText} ${shareUrl}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const toggleTrader = (username: string) => {
    setSelectedTraders(prev => 
      prev.includes(username) 
        ? prev.filter(u => u !== username) 
        : [...prev, username]
    );
  };

  const handleFinalSend = () => {
    if (selectedTraders.length === 0) return;
    setIsSending(true);
    // Simulate API delay
    setTimeout(() => {
      onInternalShare(selectedTraders);
      setIsSending(false);
      setSelectedTraders([]);
    }, 1000);
  };

  const shareExternal = (platform: string) => {
    let url = '';
    const encodedUrl = encodeURIComponent(shareUrl);
    const encodedText = encodeURIComponent(shareText);

    switch (platform) {
      case 'x': url = `https://twitter.com/intent/tweet?text=${encodedText}&url=${encodedUrl}`; break;
      case 'whatsapp': url = `https://api.whatsapp.com/send?text=${encodedText} ${encodedUrl}`; break;
      case 'telegram': url = `https://t.me/share/url?url=${encodedUrl}&text=${encodedText}`; break;
      case 'native': 
        if (navigator.share) {
          navigator.share({ title: 'StreetCoinz', text: shareText, url: shareUrl });
          return;
        }
        break;
    }
    if (url) window.open(url, '_blank');
  };

  return (
    <div className="fixed inset-0 z-[230] flex items-end justify-center px-4 pb-24 sm:items-center sm:pb-0">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md animate-in fade-in duration-300" onClick={onClose}></div>
      
      <div className="relative w-full max-w-[360px] bg-zinc-950 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl animate-in slide-in-from-bottom-10 duration-300">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black text-white uppercase tracking-widest italic">{t.title}</h3>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Preview Panel for Profiles */}
          {profileUsername && !post && !status && (
            <div className="mb-6 p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center gap-4 animate-in fade-in zoom-in-95 duration-300">
              <img 
                src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${profileUsername}`} 
                className="w-14 h-14 rounded-2xl border-2 border-purple-500/30" 
                alt={profileUsername} 
              />
              <div className="flex-1">
                <span className="text-[8px] font-black text-purple-500 uppercase tracking-widest block mb-0.5">{t.sharingProfile}</span>
                <span className="text-sm font-black text-white uppercase tracking-tight italic">@{profileUsername}</span>
              </div>
            </div>
          )}

          {/* Preview Panel for Statuses */}
          {status && !post && !profileUsername && (
            <div className="mb-6 p-4 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center gap-4 animate-in fade-in zoom-in-95 duration-300">
              <div className={`w-14 h-14 rounded-2xl border-2 border-purple-500/30 flex items-center justify-center overflow-hidden ${status.bgColor}`}>
                 {status.imageUrl ? (
                   <img src={status.imageUrl} className="w-full h-full object-cover" alt="Status" />
                 ) : (
                   <svg className="w-6 h-6 text-white/50" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
                 )}
              </div>
              <div className="flex-1 min-w-0">
                <span className="text-[8px] font-black text-purple-500 uppercase tracking-widest block mb-0.5">{t.sharingStatus}</span>
                <span className="text-xs font-bold text-white uppercase truncate block">@{status.username}</span>
                <p className="text-[9px] text-zinc-500 italic truncate">"{status.text}"</p>
              </div>
            </div>
          )}

          {/* Internal Share */}
          <div className="mb-4">
            <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-4">{t.internal}</h4>
            <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
              {TRADERS.map((trader) => (
                <div key={trader.username} className="flex flex-col items-center gap-2 flex-shrink-0">
                  <button 
                    onClick={() => toggleTrader(trader.username)}
                    className="relative group active:scale-90 transition-transform"
                  >
                    <img src={trader.avatar} className={`w-14 h-14 rounded-2xl border-2 p-0.5 transition-all ${selectedTraders.includes(trader.username) ? 'border-purple-500 scale-110 shadow-[0_0_15px_rgba(168,85,247,0.4)]' : 'border-zinc-800'}`} alt={trader.username} />
                    {selectedTraders.includes(trader.username) && (
                      <div className="absolute -top-1 -right-1 bg-purple-600 rounded-full w-5 h-5 flex items-center justify-center border-2 border-zinc-950 animate-in zoom-in duration-200">
                        <svg className="w-3 h-3 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}>
                          <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                        </svg>
                      </div>
                    )}
                  </button>
                  <span className={`text-[8px] font-black uppercase tracking-tighter truncate w-14 text-center ${selectedTraders.includes(trader.username) ? 'text-purple-500' : 'text-zinc-400'}`}>
                    @{trader.username.split('_')[0]}
                  </span>
                </div>
              ))}
            </div>

            {selectedTraders.length > 0 && (
              <button 
                onClick={handleFinalSend}
                disabled={isSending}
                className="w-full mt-2 bg-purple-600 hover:bg-purple-500 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-purple-500/20 active:scale-95 transition-all flex items-center justify-center gap-2 animate-in slide-in-from-top-2"
              >
                {isSending ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                    <span>SENDING...</span>
                  </>
                ) : (
                  <>
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                      <path strokeLinecap="round" strokeLinejoin="round" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                    </svg>
                    <span>{t.sendBtn.replace('{n}', selectedTraders.length.toString())}</span>
                  </>
                )}
              </button>
            )}
          </div>

          <div className="flex items-center gap-4 my-6">
             <div className="h-px flex-1 bg-zinc-900"></div>
             <span className="text-[7px] font-black text-zinc-800 uppercase tracking-widest">or</span>
             <div className="h-px flex-1 bg-zinc-900"></div>
          </div>

          {/* External Share */}
          <div className="mb-6">
            <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-4">{t.external}</h4>
            <div className="grid grid-cols-4 gap-4">
              <button onClick={() => shareExternal('x')} className="flex flex-col items-center gap-2 group">
                <div className="w-12 h-12 rounded-2xl bg-white/5 border border-zinc-800 flex items-center justify-center group-hover:bg-white/10 group-hover:scale-110 transition-all">
                  <svg className="w-5 h-5 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                  </svg>
                </div>
                <span className="text-[8px] font-black text-zinc-500 uppercase">X</span>
              </button>

              <button onClick={() => shareExternal('whatsapp')} className="flex flex-col items-center gap-2 group">
                <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center group-hover:bg-emerald-500/20 group-hover:scale-110 transition-all">
                  <svg className="w-6 h-6 text-emerald-500" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.335-1.662c1.72.94 3.675 1.438 5.662 1.438h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
                  </svg>
                </div>
                <span className="text-[8px] font-black text-zinc-500 uppercase">WA</span>
              </button>

              <button onClick={() => shareExternal('telegram')} className="flex flex-col items-center gap-2 group">
                <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/20 flex items-center justify-center group-hover:bg-sky-500/20 group-hover:scale-110 transition-all">
                  <svg className="w-6 h-6 text-sky-500" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M11.944 0C5.347 0 0 5.347 0 11.944c0 6.597 5.347 11.944 11.944 11.944 6.597 0 11.944-5.347 11.944-11.944C23.888 5.347 18.541 0 11.944 0zm5.204 8.16l-1.744 8.225c-.131.581-.475.722-.961.444l-2.656-1.956-1.281 1.231c-.141.141-.26.26-.531.26l.191-2.703 4.919-4.441c.213-.189-.047-.294-.331-.106l-6.081 3.828-2.619-.819c-.569-.178-.581-.569.119-.841l10.231-3.941c.475-.172.891.112.753.865z"/>
                  </svg>
                </div>
                <span className="text-[8px] font-black text-zinc-500 uppercase">TG</span>
              </button>

              <button onClick={() => shareExternal('native')} className="flex flex-col items-center gap-2 group">
                <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-center group-hover:bg-zinc-800 group-hover:scale-110 transition-all">
                  <svg className="w-6 h-6 text-zinc-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
                  </svg>
                </div>
                <span className="text-[8px] font-black text-zinc-500 uppercase">More</span>
              </button>
            </div>
          </div>

          {/* Copy Link */}
          <button 
            onClick={handleCopy}
            className={`w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-[0.2em] transition-all active:scale-95 flex items-center justify-center gap-2 ${copied ? 'bg-emerald-600 text-white' : 'bg-zinc-900 text-white border border-zinc-800'}`}
          >
            {copied ? (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
              </svg>
            )}
            {copied ? t.copied : t.copy}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ShareModal;
