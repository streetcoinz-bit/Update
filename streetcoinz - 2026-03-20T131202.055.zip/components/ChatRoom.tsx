
import React, { useState, useEffect, useRef } from 'react';
import { Language, UserProfile, Message } from '../types';

interface ChatRoomProps {
  chatPartner: {
    id: string;
    name: string;
    avatar: string;
    isAi?: boolean;
    online?: boolean;
    isGroup?: boolean;
    memberCount?: number;
    description?: string;
    owner?: string;
  };
  messages: Message[];
  onSendMessage: (msg: Partial<Message>) => void;
  language: Language;
  activeThemeClass: string;
  onBack: () => void;
  onViewProfile: (username: string) => void;
  onViewSquad?: (squadId: string) => void;
  onLeaveGroup?: (groupId: string) => void;
  onDissolveGroup?: (groupId: string) => void;
  onBlockUser?: (username: string) => void;
  onToggleMute?: (chatId: string) => void;
  isMuted?: boolean;
  currentUser: UserProfile | null;
}

const translations = {
  [Language.EN]: { 
    placeholder: 'Type street alpha...', 
    typing: 'Typing...', 
    status: 'Trader is active', 
    groupStatus: 'Squad Active', 
    members: 'members', 
    replyingTo: 'Replying to',
    blockUser: 'Block User',
    mute: 'Mute Chat',
    unmute: 'Unmute Chat',
    sharedFlex: 'Shared a Flex',
    sharedProfile: 'Shared a Profile',
    sharedStatus: 'Shared an Alpha'
  },
  [Language.ID]: { 
    placeholder: 'Ketik info jalanan...', 
    typing: 'Mengetik...', 
    status: 'Trader aktif', 
    groupStatus: 'Squad Aktif', 
    members: 'anggota', 
    replyingTo: 'Membalas',
    blockUser: 'Blokir Trader',
    mute: 'Bisukan Obrolan',
    unmute: 'Bunyikan Obrolan',
    sharedFlex: 'Membagikan Flex',
    sharedProfile: 'Membagikan Profil',
    sharedStatus: 'Membagikan Alpha'
  },
  [Language.ES]: { 
    placeholder: 'Escribe algo...', 
    typing: 'Escribiendo...', 
    status: 'Trader activo', 
    groupStatus: 'Escuadra Activa', 
    members: 'miembros',
    replyingTo: 'Respondiendo a',
    blockUser: 'Bloquear',
    mute: 'Silenciar Chat',
    unmute: 'Desactivar Silencio',
    sharedFlex: 'Flex Compartido',
    sharedProfile: 'Perfil Compartido',
    sharedStatus: 'Alpha Compartido'
  },
  [Language.CN]: { 
    placeholder: '输入街道动态...', 
    typing: '正在输入...', 
    status: '交易者在线', 
    groupStatus: '战队活跃', 
    members: '成员',
    replyingTo: '回复',
    blockUser: '屏蔽用户',
    mute: '静音聊天',
    unmute: '取消静音',
    sharedFlex: '分享了秀操作',
    sharedProfile: '分享了资料',
    sharedStatus: '分享了阿尔法'
  }
};

const ChatRoom: React.FC<ChatRoomProps> = ({ chatPartner, messages, onSendMessage, language, activeThemeClass, onBack, onViewProfile, onViewSquad, onLeaveGroup, onDissolveGroup, onBlockUser, onToggleMute, isMuted, currentUser }) => {
  const [inputText, setInputText] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [replyingTo, setReplyingTo] = useState<Message | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';
  const currentUsername = currentUser?.name.toLowerCase().replace(/\s/g, '_') || 'anon';
  const isOwner = chatPartner.isGroup && chatPartner.owner === currentUsername;

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'auto' });
  }, [messages, isTyping]);

  const handleSend = async (text?: string, metadata?: Partial<Message>) => {
    const messageContent = text || inputText;
    if (!messageContent.trim() && !metadata) return;

    onSendMessage({
      text: text || inputText,
      ...metadata,
      replyTo: replyingTo ? { text: replyingTo.text || 'Media', username: replyingTo.username } : undefined
    });

    if (!metadata) setInputText('');
    setReplyingTo(null);

    // Auto-reply simulation for DMs
    if (!chatPartner.isGroup && !metadata) {
      setIsTyping(true);
      setTimeout(() => {
        setIsTyping(false);
        onSendMessage({
          text: "Copy that. Let's cook. 🔥",
          sender: 'partner',
          username: chatPartner.name
        });
      }, 2000);
    }
  };

  const renderSharedContent = (msg: Message) => {
    if (msg.sharedPostId) {
      return (
        <div className={`mt-2 p-3 rounded-2xl border ${isDark ? 'bg-black/40 border-purple-500/30' : 'bg-purple-50 border-purple-200'}`}>
          <div className="flex items-center gap-3 mb-2">
            <div className="w-8 h-8 rounded-lg bg-purple-600 flex items-center justify-center text-white">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2-2v8a2 2 0 002 2z" /></svg>
            </div>
            <span className="text-[10px] font-black uppercase tracking-widest text-purple-500">{t.sharedFlex}</span>
          </div>
          {msg.imageUrl && (
            <div className="relative group/media cursor-pointer">
               {msg.imageUrl.includes('.mp4') ? (
                 <video src={msg.imageUrl} className="w-full h-32 object-cover rounded-xl mb-2 grayscale group-hover/media:grayscale-0 transition-all" muted />
               ) : (
                 <img src={msg.imageUrl} className="w-full h-32 object-cover rounded-xl mb-2 grayscale group-hover/media:grayscale-0 transition-all" alt="Shared flex" />
               )}
               <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover/media:opacity-100 transition-opacity bg-black/20 rounded-xl">
                  <svg className="w-8 h-8 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
               </div>
            </div>
          )}
          <button 
            className="w-full py-2 bg-purple-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest active:scale-95 transition-transform"
          >
            View Full Flex
          </button>
        </div>
      );
    }
    if (msg.sharedProfileUsername) {
      return (
        <div className={`mt-2 p-3 rounded-2xl border ${isDark ? 'bg-black/40 border-purple-500/30' : 'bg-purple-50 border-purple-200'}`}>
           <div className="flex items-center gap-3 mb-3">
             <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${msg.sharedProfileUsername}`} className="w-10 h-10 rounded-full border-2 border-purple-500/20" alt="Avatar" />
             <div className="min-w-0">
               <span className="text-[8px] font-black uppercase tracking-widest text-purple-500 block">{t.sharedProfile}</span>
               <span className="text-[11px] font-black uppercase text-white truncate block">@{msg.sharedProfileUsername}</span>
             </div>
           </div>
           <button 
             onClick={() => onViewProfile(msg.sharedProfileUsername!)}
             className="w-full py-2 bg-purple-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest active:scale-95 transition-transform"
           >
             Go to Profile
           </button>
        </div>
      );
    }
    if (msg.sharedStatusId) {
      // Find the message text for context if shared in textual form
      return (
        <div className={`mt-2 p-3 rounded-2xl border ${isDark ? 'bg-black/40 border-purple-500/30' : 'bg-purple-50 border-purple-200 shadow-sm'}`}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-600 flex items-center justify-center text-white shadow-lg">
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 24 24"><path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/></svg>
            </div>
            <span className="text-[9px] font-black uppercase tracking-widest text-indigo-500">{t.sharedStatus}</span>
          </div>
          <div className={`p-4 rounded-xl mb-3 flex items-center justify-center text-center italic font-black uppercase text-[10px] text-white ${msg.imageUrl ? 'bg-zinc-800' : 'bg-indigo-600/50'}`}>
            "{msg.text || 'View Alpha'}"
          </div>
          <button 
            className="w-full py-2 bg-indigo-600 text-white rounded-xl text-[9px] font-black uppercase tracking-widest active:scale-95 transition-transform shadow-lg shadow-indigo-600/20"
          >
            View Full Status
          </button>
        </div>
      );
    }
    return null;
  };

  return (
    <div className={`flex flex-col h-full transition-colors duration-300 ${isDark ? 'bg-zinc-950' : 'bg-zinc-50'}`}>
      <header className={`p-4 flex items-center gap-4 border-b backdrop-blur-md sticky top-0 z-50 ${isDark ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'}`}>
        <button onClick={onBack} className="p-2 -ml-2 text-zinc-500 hover:text-purple-500 transition-colors">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" /></svg>
        </button>
        
        <div className="flex items-center gap-3 cursor-pointer flex-1" onClick={() => chatPartner.isGroup ? onViewSquad?.(chatPartner.id) : onViewProfile(chatPartner.name)}>
          <img src={chatPartner.avatar} className={`w-10 h-10 rounded-2xl border-2 p-0.5 ${isDark ? 'border-zinc-800' : 'border-white'}`} />
          <div className="flex flex-col">
            <div className="flex items-center gap-1.5">
              <h3 className={`text-xs font-black uppercase tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>{chatPartner.name}</h3>
            </div>
            <span className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest leading-none">
              {chatPartner.isGroup ? `${chatPartner.memberCount} ${t.members}` : t.status}
            </span>
          </div>
        </div>

        <div className="relative">
          <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-zinc-500">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 5v.01M12 12v.01M12 19v.01" /></svg>
          </button>
          {isMenuOpen && (
            <div className={`absolute right-0 mt-2 w-48 py-2 rounded-2xl border shadow-2xl z-[100] animate-in slide-in-from-top-2 duration-200 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
              <button onClick={() => { onToggleMute?.(chatPartner.id); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest">{isMuted ? t.unmute : t.mute}</button>
              {chatPartner.isGroup ? (
                isOwner ? <button onClick={() => { onDissolveGroup?.(chatPartner.id); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest text-rose-500">Dissolve Squad</button>
                : <button onClick={() => { onLeaveGroup?.(chatPartner.id); setIsMenuOpen(false); }} className="w-full text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest text-rose-500">Leave Squad</button>
              ) : (
                <button onClick={() => onBlockUser?.(chatPartner.name)} className="w-full text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest text-rose-500">{t.blockUser}</button>
              )}
            </div>
          )}
        </div>
      </header>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide pb-10">
        {messages.map((msg) => (
          <div key={msg.id} className={`flex flex-col ${msg.sender === 'me' ? 'items-end' : 'items-start'} relative group`}>
            <div className="flex items-center gap-2 max-w-[85%] relative">
               <div className={`px-4 py-3 rounded-3xl ${msg.sender === 'me' ? 'bg-purple-600 text-white rounded-br-none' : (isDark ? 'bg-zinc-900 text-zinc-100 rounded-bl-none' : 'bg-white text-zinc-900 rounded-bl-none')}`}>
                 {msg.username && msg.sender !== 'me' && chatPartner.isGroup && (
                   <span className="text-[8px] font-black uppercase text-purple-500 block mb-1">@{msg.username}</span>
                 )}
                 {msg.imageUrl && !msg.sharedPostId && !msg.sharedStatusId && (
                   <div className="relative rounded-2xl overflow-hidden mb-2 bg-black/20">
                      {msg.imageUrl.includes('.mp4') ? (
                        <video src={msg.imageUrl} className="max-w-full h-auto rounded-xl" controls />
                      ) : (
                        <img src={msg.imageUrl} className="max-w-full h-auto rounded-xl" alt="Media" />
                      )}
                   </div>
                 )}
                 {msg.text && <p className="text-xs font-medium leading-relaxed">{msg.text}</p>}
                 {renderSharedContent(msg)}
               </div>
            </div>
            <span className="text-[8px] font-bold text-zinc-500 uppercase mt-1 px-1">
              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
        ))}
        {isTyping && (
          <div className="flex items-center gap-1.5 p-2 px-4 rounded-full bg-zinc-900/50 w-fit animate-pulse border border-zinc-800">
            <div className="w-1 h-1 bg-purple-500 rounded-full animate-bounce"></div>
            <div className="w-1 h-1 bg-purple-500 rounded-full animate-bounce" style={{animationDelay:'0.2s'}}></div>
            <div className="w-1 h-1 bg-purple-500 rounded-full animate-bounce" style={{animationDelay:'0.4s'}}></div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      <div className={`p-4 border-t sticky bottom-0 z-50 ${isDark ? 'bg-zinc-950 border-zinc-900' : 'bg-white border-zinc-200'}`}>
        <div className="flex items-center gap-2">
          <form className="flex-1 flex gap-2" onSubmit={(e) => { e.preventDefault(); handleSend(); }}>
            <input 
              type="text" 
              value={inputText} 
              onChange={(e) => setInputText(e.target.value)} 
              placeholder={t.placeholder} 
              className={`flex-1 py-3.5 px-5 rounded-2xl text-xs font-bold focus:outline-none ${isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-zinc-50 border-zinc-200 shadow-inner'}`} 
            />
            <button 
              type="submit" 
              disabled={!inputText.trim()} 
              className="bg-purple-600 hover:bg-purple-500 text-white p-3.5 rounded-2xl shadow-lg shadow-purple-500/20 disabled:opacity-50 disabled:grayscale transition-all active:scale-95"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path d="M5 12h14M12 5l7 7-7 7" /></svg>
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ChatRoom;
