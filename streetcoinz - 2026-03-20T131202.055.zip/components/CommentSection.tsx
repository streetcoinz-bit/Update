
import React, { useState } from 'react';
import { Comment, Language } from '../types';

interface CommentSectionProps {
  comments: Comment[];
  onAddComment: (text: string, parentId?: string) => void;
  onDeleteComment: (commentId: string, parentId?: string) => void;
  currentUserUsername: string;
  onClose: () => void;
  onViewProfile: (username: string) => void;
  language: Language;
  activeThemeClass: string;
}

const translations = {
  [Language.EN]: { title: 'Comments', placeholder: 'Add a comment...', post: 'Post', reply: 'Reply', replyingTo: 'Replying to', delete: 'Delete' },
  [Language.ID]: { title: 'Komentar', placeholder: 'Tambah komentar...', post: 'Kirim', reply: 'Balas', replyingTo: 'Membalas', delete: 'Hapus' },
  [Language.ES]: { title: 'Comentarios', placeholder: 'Añadir comentario...', post: 'Publicar', reply: 'Responder', replyingTo: 'Respondiendo a', delete: 'Borrar' },
  [Language.CN]: { title: '评论', placeholder: '添加评论...', post: '发布', reply: '回复', replyingTo: '正在回复', delete: '删除' }
};

const CommentSection: React.FC<CommentSectionProps> = ({ comments, onAddComment, onDeleteComment, currentUserUsername, onClose, onViewProfile, language, activeThemeClass }) => {
  const [text, setText] = useState('');
  const [replyingTo, setReplyingTo] = useState<{ id: string, username: string } | null>(null);
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';

  const renderTextWithMentions = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(@\w+)/g);
    return parts.map((part, i) => {
      if (part.startsWith('@')) {
        const username = part.substring(1);
        return (
          <span 
            key={i} 
            onClick={(e) => { e.stopPropagation(); onViewProfile(username); }}
            className="text-purple-500 font-bold cursor-pointer hover:underline"
          >
            {part}
          </span>
        );
      }
      return part;
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (text.trim()) {
      onAddComment(text, replyingTo?.id);
      setText('');
      setReplyingTo(null);
    }
  };

  const renderComment = (comment: Comment, isReply: boolean = false, parentId?: string) => {
    const isMine = comment.username === currentUserUsername;
    
    return (
      <div key={comment.id} className={`flex flex-col ${isReply ? 'ml-8 mt-2' : 'mt-4'} animate-in fade-in slide-in-from-left duration-300 group`}>
        <div className="flex gap-3 items-start relative">
          <img 
            src={comment.avatar} 
            className={`${isReply ? 'w-6 h-6' : 'w-8 h-8'} rounded-full border border-purple-500/30 object-cover cursor-pointer`} 
            alt={comment.username}
            onClick={() => onViewProfile(comment.username)}
          />
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-0.5">
              <span 
                className={`${isReply ? 'text-[9px]' : 'text-[10px]'} font-black uppercase tracking-tight cursor-pointer ${isDark ? 'text-white' : 'text-zinc-900'}`}
                onClick={() => onViewProfile(comment.username)}
              >
                @{comment.username}
              </span>
              <span className="text-[8px] text-zinc-500 font-bold">
                {new Date(comment.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
              {!isReply && (
                <button 
                  onClick={() => setReplyingTo({ id: comment.id, username: comment.username })}
                  className="text-[8px] font-black text-purple-500 uppercase hover:text-purple-400 transition-colors"
                >
                  {t.reply}
                </button>
              )}
            </div>
            <div className={`${isReply ? 'text-[10px]' : 'text-[11px]'} font-medium leading-relaxed break-words ${isDark ? 'text-zinc-300' : 'text-zinc-700'}`}>
              {renderTextWithMentions(comment.text)}
            </div>
          </div>
          
          {isMine && (
            <button 
              onClick={() => onDeleteComment(comment.id, parentId)}
              className="opacity-0 group-hover:opacity-100 p-1 text-rose-500/50 hover:text-rose-500 transition-all active:scale-90"
              title={t.delete}
            >
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
              </svg>
            </button>
          )}
        </div>
        
        {comment.replies && comment.replies.length > 0 && (
          <div className="flex flex-col gap-1">
            {comment.replies.map(reply => renderComment(reply, true, comment.id))}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className={`absolute inset-0 z-[100] flex flex-col animate-in slide-in-from-bottom duration-300 ${isDark ? 'bg-zinc-950/95' : 'bg-white/95'} backdrop-blur-md`}>
      <div className={`p-4 flex justify-between items-center border-b ${isDark ? 'border-zinc-800' : 'border-zinc-100'}`}>
        <h3 className="text-sm font-black uppercase tracking-widest italic">{t.title}</h3>
        <button onClick={onClose} className="p-2 text-zinc-500 hover:text-white transition-colors">
          <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4 scrollbar-hide">
        {comments.map((comment) => renderComment(comment))}
        {comments.length === 0 && (
          <div className="h-full flex flex-col items-center justify-center opacity-30 py-10">
            <svg className="w-12 h-12 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
            </svg>
            <span className="text-[10px] font-black uppercase tracking-widest">No noise yet...</span>
          </div>
        )}
      </div>

      <form onSubmit={handleSubmit} className={`p-4 pb-10 border-t ${isDark ? 'border-zinc-800 bg-zinc-950' : 'border-zinc-200 bg-white'}`}>
        {replyingTo && (
          <div className={`flex items-center justify-between px-3 py-1.5 rounded-t-xl mb-px animate-in slide-in-from-bottom-2 duration-200 ${isDark ? 'bg-purple-600/10 text-purple-400' : 'bg-purple-50 text-purple-600'}`}>
            <span className="text-[9px] font-black uppercase tracking-wider">{t.replyingTo} @{replyingTo.username}</span>
            <button type="button" onClick={() => setReplyingTo(null)} className="p-1">
              <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
        )}
        <div className={`flex items-center gap-2 p-1.5 rounded-2xl border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-zinc-50 border-zinc-200 shadow-inner'} ${replyingTo ? 'rounded-t-none' : ''}`}>
          <input 
            type="text" 
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder={t.placeholder}
            className="flex-1 bg-transparent border-none focus:outline-none focus:ring-0 text-xs font-bold px-3 placeholder:text-zinc-600"
          />
          <button 
            type="submit"
            disabled={!text.trim()}
            className="bg-purple-600 disabled:opacity-50 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-90"
          >
            {t.post}
          </button>
        </div>
      </form>
    </div>
  );
};

export default CommentSection;
