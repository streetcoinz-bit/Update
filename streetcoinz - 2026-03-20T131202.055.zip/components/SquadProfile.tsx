
import React from 'react';
import { Language, ChatGroup } from '../types';

interface SquadProfileProps {
  squad: ChatGroup;
  language: Language;
  activeThemeClass: string;
  currentUserUsername: string;
  onBack: () => void;
  onLeave: (id: string) => void;
  onDissolve: (id: string) => void;
  onToggleMute: (id: string) => void;
  onViewMember: (username: string) => void;
}

const translations = {
  [Language.EN]: { 
    creed: 'Squad Creed', 
    members: 'Squad Members', 
    leave: 'Leave Squad', 
    dissolve: 'Dissolve Squad', 
    mute: 'Mute Notifications',
    unmute: 'Unmute Notifications',
    owner: 'Squad Leader'
  },
  [Language.ID]: { 
    creed: 'Visi Squad', 
    members: 'Anggota Squad', 
    leave: 'Keluar Squad', 
    dissolve: 'Bubarkan Squad', 
    mute: 'Bisukan Notifikasi',
    unmute: 'Bunyikan Notifikasi',
    owner: 'Ketua Squad'
  },
  [Language.ES]: { 
    creed: 'Credo de Escuadra', 
    members: 'Miembros', 
    leave: 'Salir de Escuadra', 
    dissolve: 'Disolver Escuadra', 
    mute: 'Silenciar',
    unmute: 'Desactivar Silencio',
    owner: 'Líder'
  },
  [Language.CN]: { 
    creed: '战队信念', 
    members: '战队成员', 
    leave: '退出战队', 
    dissolve: '解散战队', 
    mute: '静音通知',
    unmute: '取消静音',
    owner: '战队领袖'
  }
};

const MOCK_MEMBERS = [
  'crypto_whale_99', 'scalp_queen', 'alpha_king', 'dex_demon', 'moon_walker', 'bull_runner'
];

const SquadProfile: React.FC<SquadProfileProps> = ({ squad, language, activeThemeClass, currentUserUsername, onBack, onLeave, onDissolve, onToggleMute, onViewMember }) => {
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';
  const isOwner = squad.owner === currentUserUsername;

  return (
    <div className={`flex flex-col h-full overflow-y-auto scrollbar-hide transition-colors duration-300 ${isDark ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      {/* Sticky Header */}
      <div className={`sticky top-0 z-10 p-4 flex items-center gap-4 backdrop-blur-md border-b ${isDark ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'}`}>
        <button onClick={onBack} className="p-2 hover:bg-zinc-800/20 rounded-xl transition-all">
          <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        <h2 className="text-sm font-black uppercase italic tracking-tighter">Squad Profile</h2>
      </div>

      <div className="flex flex-col items-center p-8">
        <div className="relative mb-6">
          <div className={`absolute -inset-1.5 rounded-[32px] blur opacity-30 bg-gradient-to-tr from-indigo-500 to-purple-600`}></div>
          <img 
            src={squad.avatar} 
            alt={squad.name} 
            className={`relative w-24 h-24 rounded-[28px] border-4 p-2 object-cover ${isDark ? 'bg-zinc-900 border-zinc-900' : 'bg-white border-white shadow-xl'}`}
          />
        </div>
        
        <h1 className="text-2xl font-black italic uppercase tracking-tighter mb-1 text-center">{squad.name}</h1>
        <p className="text-indigo-500 text-[10px] font-black uppercase tracking-widest mb-6">
          {squad.memberCount >= 1000 ? `${(squad.memberCount / 1000).toFixed(1)}K` : squad.memberCount} TRADERS ACTIVE
        </p>

        <div className={`w-full p-5 rounded-3xl border mb-8 ${isDark ? 'bg-zinc-900/50 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
          <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2">{t.creed}</h4>
          <p className={`text-sm font-medium italic ${isDark ? 'text-zinc-300' : 'text-zinc-600'}`}>
            "{squad.description || 'No creed defined yet. We trade in shadows.'}"
          </p>
        </div>

        <div className="w-full space-y-3 mb-10">
          <button 
            onClick={() => onToggleMute(squad.id)}
            className={`w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest border transition-all active:scale-95 flex items-center justify-center gap-2 ${isDark ? 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:text-white' : 'bg-white border-zinc-200 text-zinc-600 shadow-sm'}`}
          >
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
            </svg>
            {squad.isMuted ? t.unmute : t.mute}
          </button>

          {isOwner ? (
            <button 
              onClick={() => onDissolve(squad.id)}
              className="w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest bg-rose-600/10 border border-rose-500/20 text-rose-500 transition-all active:scale-95"
            >
              {t.dissolve}
            </button>
          ) : (
            <button 
              onClick={() => onLeave(squad.id)}
              className="w-full py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest bg-rose-600/10 border border-rose-500/20 text-rose-500 transition-all active:scale-95"
            >
              {t.leave}
            </button>
          )}
        </div>

        <div className="w-full">
          <h4 className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-4 ml-1">{t.members}</h4>
          <div className="space-y-2">
            {MOCK_MEMBERS.map(member => (
              <div 
                key={member}
                onClick={() => onViewMember(member)}
                className={`flex items-center justify-between p-3 rounded-2xl border transition-all cursor-pointer hover:scale-[1.01] ${isDark ? 'bg-zinc-900/30 border-zinc-900/50 hover:bg-zinc-900' : 'bg-white border-zinc-200 hover:shadow-md'}`}
              >
                <div className="flex items-center gap-3">
                  <img src={`https://api.dicebear.com/7.x/avataaars/svg?seed=${member}`} className="w-9 h-9 rounded-xl border border-zinc-800" alt={member} />
                  <div>
                    <span className="text-xs font-black uppercase tracking-tight block">@{member}</span>
                    {member === squad.owner && (
                      <span className="text-[7px] font-black text-indigo-500 uppercase tracking-widest">{t.owner}</span>
                    )}
                  </div>
                </div>
                <svg className="w-4 h-4 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M9 5l7 7-7 7" />
                </svg>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="mt-12 px-8 pb-32 flex flex-col items-center opacity-10">
         <div className={`w-16 h-16 rounded-3xl border-2 border-dashed flex items-center justify-center mb-4 ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`}>
           <svg className="w-8 h-8 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
             <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" />
           </svg>
         </div>
         <span className="text-[10px] font-black uppercase tracking-[0.3em] italic text-center">Squad Data Encrypted</span>
      </div>
    </div>
  );
};

export default SquadProfile;
