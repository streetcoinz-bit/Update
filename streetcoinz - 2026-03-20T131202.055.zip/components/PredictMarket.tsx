
import React from 'react';
import { UserWallet, Language } from '../types';

interface PredictMarketProps {
  wallet: UserWallet;
  language: Language;
  onBet: (amount: number) => void;
  activeThemeClass: string;
}

const translations = {
  [Language.EN]: { title: 'Predict Market', sub: 'The street is currently recalibrating. Real-time prediction markets will be live shortly.', status: 'Status', sync: 'Syncing...', pools: 'Pools', locked: 'Locked' },
  [Language.ID]: { title: 'Pasar Prediksi', sub: 'Jalanan sedang kalibrasi ulang. Pasar prediksi Bitcoin akan segera aktif.', status: 'Status', sync: 'Sinkronisasi...', pools: 'Kolam', locked: 'Terkunci' },
  [Language.ES]: { title: 'Mercado de Predicción', sub: 'La calle se está recalibrando. Los mercados en tiempo real estarán disponibles pronto.', status: 'Estado', sync: 'Sincronizando...', pools: 'Fondos', locked: 'Bloqueado' },
  [Language.CN]: { title: '预测市场', sub: '街道目前正在重新校准。实时比特币预测市场即将上线。', status: '状态', sync: '同步中...', pools: '资金池', locked: '已锁定' }
};

const PredictMarket: React.FC<PredictMarketProps> = ({ wallet, language, onBet, activeThemeClass }) => {
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';

  return (
    <div className={`flex flex-col h-full items-center justify-center p-8 text-center transition-colors duration-300 ${isDark ? 'bg-zinc-950' : 'bg-zinc-50'}`}>
      <div className={`w-20 h-20 rounded-3xl flex items-center justify-center mb-6 border animate-pulse ${isDark ? 'bg-purple-600/10 border-purple-500/20' : 'bg-purple-50 border-purple-200'}`}>
        <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6" />
        </svg>
      </div>
      <h2 className={`text-2xl font-black mb-2 italic font-heading tracking-tight uppercase ${isDark ? 'text-white' : 'text-zinc-900'}`}>{t.title}</h2>
      <p className="text-zinc-500 text-xs max-w-[240px] leading-relaxed font-medium mb-8">
        {t.sub}
      </p>
      <div className={`w-full h-px mb-8 ${isDark ? 'bg-gradient-to-r from-transparent via-zinc-800 to-transparent' : 'bg-gradient-to-r from-transparent via-zinc-200 to-transparent'}`}></div>
      <div className="flex gap-4 w-full">
        <div className={`flex-1 border p-4 rounded-2xl opacity-60 ${isDark ? 'bg-zinc-900/50 border-zinc-800' : 'bg-white border-zinc-200'}`}>
          <div className="text-[10px] font-black text-zinc-400 uppercase mb-1">{t.status}</div>
          <div className={`text-sm font-bold italic ${isDark ? 'text-zinc-300' : 'text-zinc-600'}`}>{t.sync}</div>
        </div>
        <div className={`flex-1 border p-4 rounded-2xl opacity-60 ${isDark ? 'bg-zinc-900/50 border-zinc-800' : 'bg-white border-zinc-200'}`}>
          <div className="text-[10px] font-black text-zinc-400 uppercase mb-1">{t.pools}</div>
          <div className={`text-sm font-bold italic ${isDark ? 'text-zinc-300' : 'text-zinc-600'}`}>{t.locked}</div>
        </div>
      </div>
    </div>
  );
};

export default PredictMarket;
