
import React, { useState, useRef, useMemo } from 'react';
import { Language, UserProfile, UserStatus, ChatGroup, Message } from '../types';
import ChatRoom from './ChatRoom';
import StatusViewer from './StatusViewer';
import DeleteModal from './DeleteModal';

interface ChatListProps {
  user: UserProfile | null;
  statuses: UserStatus[];
  viewedStatusIds: Set<string>;
  groups: ChatGroup[];
  chatsList: any[];
  allMessages: Record<string, Message[]>;
  onSendMessage: (targetId: string, msg: Partial<Message>) => void;
  blockedUsers: Set<string>;
  mutedChatIds: Set<string>;
  language: Language;
  activeThemeClass: string;
  onViewProfile: (username: string) => void;
  onViewSquad: (squadId: string) => void;
  onLeaveGroup: (groupId: string) => void;
  onDissolveGroup: (groupId: string) => void;
  onBlockUser: (username: string) => void;
  onToggleMute: (chatId: string) => void;
  onCreateStatus: () => void;
  onCreateGroup: () => void;
  onDeleteStatus: (id: string) => void;
  onAddComment: (statusId: string, text: string) => void;
  onShareStatus: (status: UserStatus) => void;
  onMarkStatusRead: (id: string) => void;
}

enum ChatSubTab {
  MESSAGES = 'MESSAGES',
  SQUADS = 'SQUADS',
  REQUESTS = 'REQUESTS'
}

const translations = {
  [Language.EN]: { 
    title: 'STREET HUB', 
    messages: 'DMs', 
    squads: 'Squads', 
    requests: 'Requests',
    search: 'Search traders...', 
    emptyMsgs: 'No direct noise yet.', 
    emptySquads: 'No squads joined.', 
    emptyRequests: 'No pending requests.',
    aiName: 'Street AI', 
    aiMotto: 'Your market companion', 
    yourStatus: 'Post Alpha', 
    createSquad: 'Form Squad',
    storySub: '24H ALPHAS',
    deleteChatTitle: 'Burn this thread?',
    deleteChatSub: 'This conversation will be wiped from your device forever.',
    deleteSquadTitle: 'Abandon Squad?',
    deleteSquadTitle: 'Abandon Squad?',
    deleteSquadSub: 'You will leave this squad and its alpha feed.',
    deleteRequestTitle: 'Trash Request?',
    deleteRequestSub: 'This message request will be ignored forever.',
    mute: 'Mute Chat',
    unmute: 'Unmute Chat',
    delete: 'Delete Chat',
    actions: 'Street Actions'
  },
  [Language.ID]: { 
    title: 'STREET HUB', 
    messages: 'DM', 
    squads: 'Squad', 
    requests: 'Permintaan',
    search: 'Cari trader...', 
    emptyMsgs: 'Belum ada obrolan pribadi.', 
    emptySquads: 'Belum gabung squad.', 
    emptyRequests: 'Belum ada permintaan.',
    aiName: 'AI Jalanan', 
    aiMotto: 'Teman trading Anda', 
    yourStatus: 'Post Alpha', 
    createSquad: 'Buat Squad',
    storySub: '24J ALPHA',
    deleteChatTitle: 'Bakar obrolan?',
    deleteChatSub: 'Percakapan ini akan dihapus dari perangkat Anda selamanya.',
    deleteSquadTitle: 'Tinggalkan Squad?',
    deleteSquadSub: 'Anda akan keluar dari squad ini dan feed alpha-nya.',
    deleteRequestTitle: 'Buang Permintaan?',
    deleteRequestSub: 'Permintaan pesan ini akan diabaikan selamanya.',
    mute: 'Bisukan Obrolan',
    unmute: 'Bunyikan Obrolan',
    delete: 'Hapus Obrolan',
    actions: 'Aksi Jalanan'
  },
  [Language.ES]: { 
    title: 'STREET HUB', 
    messages: 'Mensajes', 
    squads: 'Escuadras', 
    requests: 'Solicitudes',
    search: 'Buscar traders...', 
    emptyMsgs: 'Sin ruido directo aún.', 
    emptySquads: 'Sin escuadras unidas.', 
    emptyRequests: 'Sin solicitudes pendientes.',
    aiName: 'IA de Calle', 
    aiMotto: 'Tu compañero de mercado', 
    yourStatus: 'Post Alpha', 
    createSquad: 'Formar Escuadra',
    storySub: '24H ALPHAS',
    deleteChatTitle: '¿Borrar chat?',
    deleteChatSub: 'Esta conversación se borrará para siempre.',
    deleteSquadTitle: '¿Abandonar Escuadra?',
    deleteSquadSub: 'Saldrás de esta escuadra y su feed alpha.',
    deleteRequestTitle: '¿Eliminar Solicitud?',
    deleteRequestSub: 'Esta solicitud será ignorada.',
    mute: 'Silenciar Chat',
    unmute: 'Desactivar Silencio',
    delete: 'Borrar Chat',
    actions: 'Acciones'
  },
  [Language.CN]: { 
    title: '街道中心', 
    messages: '私信', 
    squads: '战队', 
    requests: '请求',
    search: '搜索交易者...', 
    emptyMsgs: '目前还没有直接消息。', 
    emptySquads: '尚未加入战队。', 
    emptyRequests: '没有待处理的请求。',
    aiName: '街道 AI', 
    aiMotto: '您的市场伴侣', 
    yourStatus: '发布动态', 
    createSquad: '创建战队',
    storySub: '24小时动态',
    deleteChatTitle: '销毁此线程？',
    deleteChatSub: '此对话将永久从您的设备中擦除。',
    deleteSquadTitle: '退出战队？',
    deleteSquadSub: '你将离开这个战队及其动态。',
    deleteRequestTitle: '丢弃请求？',
    deleteRequestSub: '此消息请求将被永久忽略。',
    mute: '静音聊天',
    unmute: '取消静音',
    delete: '删除聊天',
    actions: '操作'
  }
};

const INITIAL_REQUESTS = [
  { id: 'r1', name: 'unknown_trader_42', lastMsg: 'Yo, I have some alpha on the next meme coin. Interested?', time: '2h', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=unknown42', online: false },
  { id: 'r2', name: 'pump_master_flex', lastMsg: 'Check your wallet, sent you a gift.', time: '5h', avatar: 'https://api.dicebear.com/7.x/pumpreq', online: true },
];

const ChatList: React.FC<ChatListProps> = ({ user, statuses, viewedStatusIds, groups, chatsList, allMessages, onSendMessage, blockedUsers, mutedChatIds, language, activeThemeClass, onViewProfile, onViewSquad, onLeaveGroup, onDissolveGroup, onBlockUser, onToggleMute, onCreateStatus, onCreateGroup, onDeleteStatus, onAddComment, onShareStatus, onMarkStatusRead }) => {
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';
  const [search, setSearch] = useState('');
  const [activeSubTab, setActiveSubTab] = useState<ChatSubTab>(ChatSubTab.MESSAGES);
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerStartIndex, setViewerStartIndex] = useState(0);
  const [requests, setRequests] = useState(INITIAL_REQUESTS);

  // Audio Context for Feedback
  const playMuteSound = (isMuting: boolean) => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      if (isMuting) {
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(300, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(150, audioCtx.currentTime + 0.15);
      } else {
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(400, audioCtx.currentTime);
        oscillator.frequency.exponentialRampToValueAtTime(800, audioCtx.currentTime + 0.15);
      }
      gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.15);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.15);
    } catch (e) {
      console.warn("Audio feedback failed:", e);
    }
  };

  const [actionItem, setActionItem] = useState<{ id: string, name: string, type: ChatSubTab } | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<{ id: string, type: ChatSubTab } | null>(null);
  // Fix: Replaced NodeJS.Timeout with any for broader environment compatibility in browser.
  const longPressTimer = useRef<any>(null);
  const touchStartPos = useRef<{ x: number, y: number } | null>(null);
  const MOVE_THRESHOLD = 15;

  const filteredChats = chatsList
    .filter(c => !blockedUsers.has(c.name))
    .filter(c => c.name.toLowerCase().includes(search.toLowerCase()));

  const filteredGroups = groups.filter(g => g.name.toLowerCase().includes(search.toLowerCase()));
  
  const filteredRequests = requests
    .filter(r => !blockedUsers.has(r.name))
    .filter(r => r.name.toLowerCase().includes(search.toLowerCase()));
  
  // Group unique users for status bubbles
  const uniqueStatusUsers = useMemo(() => {
    const users: Record<string, { username: string, avatar: string, hasUnread: boolean }> = {};
    statuses.filter(s => !blockedUsers.has(s.username)).forEach(s => {
      const isUnread = !viewedStatusIds.has(s.id);
      if (!users[s.username]) {
        users[s.username] = { username: s.username, avatar: s.avatar, hasUnread: isUnread };
      } else if (isUnread) {
        users[s.username].hasUnread = true;
      }
    });
    return Object.values(users);
  }, [statuses, viewedStatusIds, blockedUsers]);
  
  const activeChatPartner = [...chatsList, ...groups, ...requests].find(c => c.id === selectedChatId);

  const handleLongPressStart = (e: React.MouseEvent | React.TouchEvent, item: any, type: ChatSubTab) => {
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    touchStartPos.current = { x: clientX, y: clientY };
    longPressTimer.current = setTimeout(() => {
      if ('vibrate' in navigator) navigator.vibrate(60);
      setActionItem({ id: item.id, name: item.name || item.id, type });
      touchStartPos.current = null;
    }, 700);
  };

  const handleLongPressMove = (e: React.MouseEvent | React.TouchEvent) => {
    if (!touchStartPos.current || !longPressTimer.current) return;
    const clientX = 'touches' in e ? e.touches[0].clientX : (e as React.MouseEvent).clientX;
    const clientY = 'touches' in e ? e.touches[0].clientY : (e as React.MouseEvent).clientY;
    const dx = Math.abs(clientX - touchStartPos.current.x);
    const dy = Math.abs(clientY - touchStartPos.current.y);
    if (dx > MOVE_THRESHOLD || dy > MOVE_THRESHOLD) {
      if (longPressTimer.current) {
        clearTimeout(longPressTimer.current);
        longPressTimer.current = null;
      }
      touchStartPos.current = null;
    }
  };

  const handleLongPressEnd = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
    touchStartPos.current = null;
  };

  const confirmDeletion = () => {
    if (!deleteTarget) return;
    if (deleteTarget.type === ChatSubTab.REQUESTS) {
      setRequests(prev => prev.filter(r => r.id !== deleteTarget.id));
    } else if (deleteTarget.type === ChatSubTab.SQUADS) {
      onLeaveGroup(deleteTarget.id);
    }
    setDeleteTarget(null);
  };

  const handleActionMute = () => {
    if (!actionItem) return;
    const muteId = actionItem.type === ChatSubTab.SQUADS ? actionItem.id : actionItem.name;
    const isCurrentlyMuted = mutedChatIds.has(muteId);
    playMuteSound(!isCurrentlyMuted);
    onToggleMute(muteId);
    setActionItem(null);
  };

  const handleActionDelete = () => {
    if (!actionItem) return;
    setDeleteTarget({ id: actionItem.id, type: actionItem.type });
    setActionItem(null);
  };

  if (selectedChatId && activeChatPartner) {
    return (
      <ChatRoom 
        chatPartner={activeChatPartner as any} 
        messages={allMessages[selectedChatId] || []}
        onSendMessage={(msg) => onSendMessage(selectedChatId, msg)}
        language={language} 
        activeThemeClass={activeThemeClass} 
        onBack={() => setSelectedChatId(null)} 
        onViewProfile={onViewProfile}
        onViewSquad={onViewSquad}
        onLeaveGroup={onLeaveGroup}
        onDissolveGroup={onDissolveGroup}
        onBlockUser={(username) => {
          onBlockUser(username);
          setSelectedChatId(null);
        }}
        onToggleMute={onToggleMute}
        isMuted={mutedChatIds.has(activeChatPartner.id) || (activeChatPartner as any).name && mutedChatIds.has((activeChatPartner as any).name)}
        currentUser={user}
      />
    );
  }

  const handleOpenUserStatus = (username: string) => {
    const idx = statuses.findIndex(s => s.username === username);
    if (idx !== -1) {
      setViewerStartIndex(idx);
      setIsViewerOpen(true);
    }
  };

  if (isViewerOpen) {
    return (
      <StatusViewer
        statuses={statuses}
        initialIndex={viewerStartIndex}
        onClose={() => setIsViewerOpen(false)}
        onDelete={(id) => {
          onDeleteStatus(id);
          // If we delete all statuses in viewer mode, we might want to check if any left
          if (statuses.length <= 1) setIsViewerOpen(false);
        }}
        onShare={(status) => {
          onShareStatus(status);
          setIsViewerOpen(false);
        }}
        onReplyToDM={(username, text) => {
          const existing = chatsList.find(c => c.name === username);
          const cid = existing?.id || 'c' + Date.now();
          onSendMessage(cid, { text, sender: 'me', username: user?.name });
          setSelectedChatId(cid);
          setIsViewerOpen(false);
        }}
        onViewProfile={onViewProfile}
        onMarkAsRead={onMarkStatusRead}
        currentUserUsername={user?.name.toLowerCase().replace(/\s/g, '_')}
        activeThemeClass={activeThemeClass}
        language={language}
      />
    );
  }

  return (
    <div className={`flex flex-col h-full transition-colors duration-300 ${isDark ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      {actionItem && (
        <div className="fixed inset-0 z-[260] flex items-center justify-center p-4">
          <div className="fixed inset-0 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300" onClick={() => setActionItem(null)}></div>
          <div className="relative w-full max-w-[280px] bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
            <div className="p-6">
              <h3 className="text-xs font-black text-zinc-500 uppercase tracking-widest mb-4 text-center">{t.actions}</h3>
              <div className="space-y-2">
                <button 
                  onClick={handleActionMute}
                  className={`w-full flex items-center gap-4 p-4 bg-zinc-950 border border-zinc-800 rounded-2xl transition-all active:scale-95 ${mutedChatIds.has(actionItem.type === ChatSubTab.SQUADS ? actionItem.id : actionItem.name) ? 'hover:border-emerald-500/50' : 'hover:border-purple-500/50'}`}
                >
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${mutedChatIds.has(actionItem.type === ChatSubTab.SQUADS ? actionItem.id : actionItem.name) ? 'bg-emerald-600/10 text-emerald-500' : 'bg-purple-600/10 text-purple-500'}`}>
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                       <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15.536 8.464a5 5 0 010 7.072m2.828-9.9a9 9 0 010 12.728M5.586 15H4a1 1 0 01-1-1v-4a1 1 0 011-1h1.586l4.707-4.707C10.923 3.663 12 4.109 12 5v14c0 .891-1.077 1.337-1.707.707L5.586 15z" />
                    </svg>
                  </div>
                  <span className="text-xs font-black text-white uppercase tracking-wider">
                    {mutedChatIds.has(actionItem.type === ChatSubTab.SQUADS ? actionItem.id : actionItem.name) ? t.unmute : t.mute}
                  </span>
                </button>
                <button 
                  onClick={handleActionDelete}
                  className="w-full flex items-center gap-4 p-4 bg-zinc-950 border border-zinc-800 rounded-2xl hover:border-rose-500/50 transition-all active:scale-95"
                >
                  <div className="w-10 h-10 rounded-xl bg-rose-600/10 flex items-center justify-center text-rose-500">
                    <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </div>
                  <span className="text-xs font-black text-white uppercase tracking-wider">{t.delete}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <DeleteModal
        isOpen={deleteTarget !== null}
        onClose={() => setDeleteTarget(null)}
        onConfirm={confirmDeletion}
        language={language}
        customTitle={deleteTarget?.type === ChatSubTab.SQUADS ? t.deleteSquadTitle : t.deleteRequestTitle}
        customSub={deleteTarget?.type === ChatSubTab.SQUADS ? t.deleteSquadSub : t.deleteRequestSub}
      />

      <div className="p-6 overflow-y-auto scrollbar-hide flex-1 pb-24">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-black italic uppercase tracking-tighter font-heading">{t.title}</h2>
          {activeSubTab === ChatSubTab.SQUADS && (
             <button 
              onClick={onCreateGroup}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-purple-600 rounded-xl text-[9px] font-black uppercase text-white shadow-lg shadow-purple-500/20 active:scale-90 transition-all"
            >
              <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
              {t.createSquad}
            </button>
          )}
        </div>
        
        <div className="mb-6">
          <div className="flex items-center justify-between px-1 mb-3">
             <span className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em]">{t.storySub}</span>
          </div>
          <div className="flex gap-4 overflow-x-auto pb-4 scrollbar-hide">
            <div className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer" onClick={onCreateStatus}>
              <div className={`relative w-16 h-16 rounded-[28px] border-2 border-dashed flex items-center justify-center transition-all hover:border-purple-500 group ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
                {user ? (
                   <img 
                    src={user.avatar} 
                    className={`w-12 h-12 rounded-2xl transition-all ${statuses.some(s => s.username === user.name.toLowerCase().replace(/\s/g, '_')) ? 'opacity-100 p-0.5 border-2 border-purple-500' : 'opacity-50'}`} 
                    alt="You" 
                    onClick={(e) => {
                      const myUsername = user.name.toLowerCase().replace(/\s/g, '_');
                      if (statuses.some(s => s.username === myUsername)) {
                        e.stopPropagation();
                        handleOpenUserStatus(myUsername);
                      }
                    }}
                   />
                ) : (
                  <svg className="w-6 h-6 text-zinc-600" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" /></svg>
                )}
                <div className="absolute -bottom-1 -right-1 bg-purple-600 text-white w-6 h-6 rounded-full flex items-center justify-center border-2 border-zinc-950 shadow-lg">
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M12 4v16m8-8H4" /></svg>
                </div>
              </div>
              <span className="text-[9px] font-black uppercase tracking-tighter text-zinc-500">{t.yourStatus}</span>
            </div>

            {uniqueStatusUsers.map((statUser) => (
              <div 
                key={statUser.username} 
                className="flex flex-col items-center gap-2 flex-shrink-0 cursor-pointer group"
                onClick={() => handleOpenUserStatus(statUser.username)}
              >
                <div className={`relative p-0.5 rounded-[28px] ${statUser.hasUnread ? 'bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 shadow-lg shadow-purple-500/20' : 'bg-zinc-800 shadow-none'} group-hover:scale-105 transition-transform`}>
                  <img 
                    src={statUser.avatar} 
                    className={`w-14 h-14 rounded-[24px] border-4 ${isDark ? 'border-zinc-950' : 'border-zinc-50'}`} 
                    alt={statUser.username} 
                  />
                </div>
                <span className={`text-[9px] font-black uppercase tracking-tighter truncate w-16 text-center ${statUser.hasUnread ? (isDark ? 'text-white' : 'text-zinc-900') : 'text-zinc-500'}`}>@{statUser.username}</span>
              </div>
            ))}
          </div>
        </div>

        <div className={`grid grid-cols-3 p-1 rounded-2xl mb-6 border transition-colors ${isDark ? 'bg-zinc-900/50 border-zinc-800/50' : 'bg-white border-zinc-200 shadow-inner'}`}>
          <button 
            onClick={() => setActiveSubTab(ChatSubTab.MESSAGES)}
            className={`py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeSubTab === ChatSubTab.MESSAGES ? (isDark ? 'bg-zinc-800 text-purple-400 shadow-xl' : 'bg-white text-purple-600 shadow-md') : 'text-zinc-500'}`}
          >
            {t.messages}
          </button>
          <button 
            onClick={() => setActiveSubTab(ChatSubTab.SQUADS)}
            className={`py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${activeSubTab === ChatSubTab.SQUADS ? (isDark ? 'bg-zinc-800 text-purple-400 shadow-xl' : 'bg-white text-purple-600 shadow-md') : 'text-zinc-500'}`}
          >
            {t.squads}
          </button>
          <button 
            onClick={() => setActiveSubTab(ChatSubTab.REQUESTS)}
            className={`py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all relative ${activeSubTab === ChatSubTab.REQUESTS ? (isDark ? 'bg-zinc-800 text-purple-400 shadow-xl' : 'bg-white text-purple-600 shadow-md') : 'text-zinc-500'}`}
          >
            {t.requests}
          </button>
        </div>

        <div className={`relative flex items-center mb-6`}>
          <svg className="absolute left-4 w-4 h-4 text-zinc-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
          </svg>
          <input 
            type="text" 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder={t.search}
            className={`w-full py-3.5 pl-10 pr-4 rounded-2xl text-xs font-bold focus:outline-none ${isDark ? 'bg-zinc-900 border-zinc-800 text-white' : 'bg-white border-zinc-200 text-zinc-900 shadow-sm'}`}
          />
        </div>

        <div className="space-y-2 animate-in fade-in duration-300">
          {activeSubTab === ChatSubTab.MESSAGES ? (
            filteredChats.length > 0 ? filteredChats.map((chat) => {
              const userStatuses = statuses.filter(s => s.username === chat.name);
              const hasUnreadStatus = userStatuses.some(s => !viewedStatusIds.has(s.id));
              const hasStatus = userStatuses.length > 0;
              const isMuted = mutedChatIds.has(chat.name);

              return (
                <div 
                  key={chat.id}
                  onMouseDown={(e) => handleLongPressStart(e, chat, ChatSubTab.MESSAGES)}
                  onMouseMove={handleLongPressMove}
                  onMouseUp={handleLongPressEnd}
                  onMouseLeave={handleLongPressEnd}
                  onTouchStart={(e) => handleLongPressStart(e, chat, ChatSubTab.MESSAGES)}
                  onTouchMove={handleLongPressMove}
                  onTouchEnd={handleLongPressEnd}
                  className={`w-full flex items-center gap-4 p-4 rounded-[28px] border transition-all active:scale-[0.98] group cursor-pointer ${isDark ? 'bg-zinc-900/40 border-zinc-900/50 hover:bg-zinc-900' : 'bg-white border-zinc-200 hover:bg-zinc-50 shadow-sm'}`}
                >
                  <div 
                    className="relative flex-shrink-0"
                    onClick={(e) => {
                      if (hasStatus) {
                        e.stopPropagation();
                        handleOpenUserStatus(chat.name);
                      }
                    }}
                  >
                    <div className={`relative p-0.5 rounded-2xl ${hasStatus ? (hasUnreadStatus ? 'bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 animate-in zoom-in-50 duration-500 shadow-[0_0_10px_rgba(168,85,247,0.3)]' : 'bg-zinc-800') : ''}`}>
                      <img src={chat.avatar} alt={chat.name} className={`w-12 h-12 rounded-2xl border ${isDark ? 'border-zinc-800 bg-zinc-900' : 'border-zinc-200 bg-white'}`} />
                    </div>
                    {chat.online && (
                      <div className="absolute -right-0.5 -bottom-0.5 w-3 h-3 bg-emerald-500 border-2 border-zinc-950 rounded-full z-10"></div>
                    )}
                  </div>
                  <div className="flex-1 text-left overflow-hidden" onClick={() => setSelectedChatId(chat.id)}>
                    <div className="flex justify-between items-center mb-0.5">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className={`text-xs font-black uppercase tracking-tight truncate ${isDark ? 'text-white' : 'text-zinc-900'}`}>{chat.name}</span>
                        {isMuted && (
                          <svg className="w-3 h-3 text-zinc-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75L19.5 12m0 0l2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6h4.5l4.5-4.5v15l-4.5-4.5h-4.5a1.125 1.125 0 01-1.125-1.125V11a1.125 1.125 0 011.125-1.125z" />
                          </svg>
                        )}
                      </div>
                      <span className="text-[8px] font-bold text-zinc-500 uppercase">{chat.time}</span>
                    </div>
                    <p className="text-[10px] text-zinc-500 font-medium truncate italic">{chat.lastMsg}</p>
                  </div>
                </div>
              );
            }) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-40">
                <span className="text-[9px] font-black uppercase tracking-[0.2em]">{t.emptyMsgs}</span>
              </div>
            )
          ) : activeSubTab === ChatSubTab.SQUADS ? (
            filteredGroups.length > 0 ? filteredGroups.map(group => {
              const isMuted = mutedChatIds.has(group.id);
              
              return (
                <div
                  key={group.id}
                  onMouseDown={(e) => handleLongPressStart(e, group, ChatSubTab.SQUADS)}
                  onMouseMove={handleLongPressMove}
                  onMouseUp={handleLongPressEnd}
                  onMouseLeave={handleLongPressEnd}
                  onTouchStart={(e) => handleLongPressStart(e, group, ChatSubTab.SQUADS)}
                  onTouchMove={handleLongPressMove}
                  onTouchEnd={handleLongPressEnd}
                  onClick={() => setSelectedChatId(group.id)}
                  className={`w-full flex items-center gap-4 p-4 rounded-[28px] border transition-all active:scale-[0.98] group cursor-pointer ${isDark ? 'bg-zinc-900/40 border-zinc-900/50 hover:bg-zinc-900' : 'bg-white border-zinc-200 hover:bg-zinc-50 shadow-sm'}`}
                >
                  <div className="relative">
                    <img src={group.avatar} alt={group.name} className={`w-12 h-12 rounded-2xl border ${isDark ? 'border-indigo-500/30' : 'border-indigo-200'}`} />
                  </div>
                  <div className="flex-1 text-left overflow-hidden">
                    <div className="flex justify-between items-center mb-0.5">
                      <div className="flex items-center gap-1.5 min-w-0">
                        <span className={`text-xs font-black uppercase tracking-tight truncate ${isDark ? 'text-white' : 'text-zinc-900'}`}>{group.name}</span>
                        {isMuted && (
                          <svg className="w-3 h-3 text-zinc-500 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}>
                            <path strokeLinecap="round" strokeLinejoin="round" d="M17.25 9.75L19.5 12m0 0l2.25 2.25M19.5 12l2.25-2.25M19.5 12l-2.25 2.25m-10.5-6h4.5l4.5-4.5v15l-4.5-4.5h-4.5a1.125 1.125 0 01-1.125-1.125V11a1.125 1.125 0 011.125-1.125z" />
                          </svg>
                        )}
                      </div>
                      <span className="text-[8px] font-bold text-zinc-500 uppercase">{group.time}</span>
                    </div>
                    <p className="text-[10px] text-zinc-500 font-medium truncate italic">"{group.lastMsg}"</p>
                  </div>
                </div>
              );
            }) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-40">
                <span className="text-[9px] font-black uppercase tracking-[0.2em]">{t.emptySquads}</span>
              </div>
            )
          ) : (
            filteredRequests.length > 0 ? filteredRequests.map(req => (
              <div
                key={req.id}
                onMouseDown={(e) => handleLongPressStart(e, req, ChatSubTab.REQUESTS)}
                onMouseMove={handleLongPressMove}
                onMouseUp={handleLongPressEnd}
                onMouseLeave={handleLongPressEnd}
                onTouchStart={(e) => handleLongPressStart(e, req, ChatSubTab.REQUESTS)}
                onTouchMove={handleLongPressMove}
                onTouchEnd={handleLongPressEnd}
                onClick={() => setSelectedChatId(req.id)}
                className={`w-full flex items-center gap-4 p-4 rounded-[28px] border transition-all active:scale-[0.98] group cursor-pointer ${isDark ? 'bg-zinc-900/40 border-zinc-900/50 hover:bg-zinc-900' : 'bg-white border-zinc-200 hover:bg-zinc-50 shadow-sm'}`}
              >
                <div className="relative">
                  <img src={req.avatar} alt={req.name} className={`w-12 h-12 rounded-2xl border ${isDark ? 'border-zinc-800' : 'border-zinc-200'}`} />
                </div>
                <div className="flex-1 text-left overflow-hidden">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className={`text-xs font-black uppercase tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>{req.name}</span>
                    <span className="text-[8px] font-bold text-zinc-500 uppercase">{req.time}</span>
                  </div>
                  <p className="text-[10px] text-zinc-500 font-medium truncate italic">{req.lastMsg}</p>
                </div>
              </div>
            )) : (
              <div className="flex flex-col items-center justify-center py-20 opacity-40">
                <span className="text-[9px] font-black uppercase tracking-[0.2em]">{t.emptyRequests}</span>
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default ChatList;
