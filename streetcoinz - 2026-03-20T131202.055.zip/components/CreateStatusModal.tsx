
import React, { useState, useRef } from 'react';
import { Language, UserProfile } from '../types';
import { uploadFile } from '../storage';

interface CreateStatusModalProps {
  isOpen: boolean;
  onClose: () => void;
  onPost: (data: { text: string; bgColor: string; imageUrl?: string }) => void;
  language: Language;
  user: UserProfile | null;
}

const translations = {
  [Language.EN]: { title: 'Share Your Alpha', placeholder: 'What are the vibes today?', post: 'Post Status', photo: 'Add Photo', uploading: 'Uploading...' },
  [Language.ID]: { title: 'Bagikan Alpha', placeholder: 'Bagaimana hari ini?', post: 'Unggah Status', photo: 'Tambah Foto', uploading: 'Mengunggah...' },
  [Language.ES]: { title: 'Comparte Tu Alpha', placeholder: '¿Cómo están las vibras hoy?', post: 'Publicar Estado', photo: 'Añadir Foto', uploading: 'Subiendo...' },
  [Language.CN]: { title: '分享你的动态', placeholder: '今天行情如何？', post: '发布动态', photo: '添加图片', uploading: '正在上传...' }
};

const BG_COLORS = [
  'bg-zinc-900', 'bg-purple-900', 'bg-rose-900', 'bg-indigo-900', 'bg-emerald-900', 'bg-amber-900'
];

const CreateStatusModal: React.FC<CreateStatusModalProps> = ({ isOpen, onClose, onPost, language, user }) => {
  const [text, setText] = useState('');
  const [bgColor, setBgColor] = useState(BG_COLORS[0]);
  const [imageUrl, setImageUrl] = useState<string | undefined>(undefined);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;
  const t = translations[language];

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setImageUrl(reader.result as string);
      };
      reader.readAsDataURL(file);

      setIsUploading(true);
      try {
        const uploadedUrl = await uploadFile(file, user?.name || "anonymous");
        setImageUrl(uploadedUrl);
      } catch (err) {
        console.error("Upload failed", err);
      } finally {
        setIsUploading(false);
      }
    }
  };

  const handlePost = () => {
    onPost({ text, bgColor, imageUrl });
    reset();
  };

  const reset = () => {
    setText('');
    setImageUrl(undefined);
    setBgColor(BG_COLORS[0]);
  };

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative w-full max-sm bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black text-white uppercase tracking-widest italic">{t.title}</h3>
            <button onClick={onClose} className="text-zinc-500 hover:text-white">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div className={`relative w-full aspect-video rounded-3xl p-8 flex flex-col items-center justify-center mb-6 overflow-hidden ${imageUrl ? '' : bgColor}`}>
            {imageUrl && (
              <img src={imageUrl} className={`absolute inset-0 w-full h-full object-cover ${isUploading ? 'opacity-30 blur-sm' : 'opacity-60'}`} alt="Status" />
            )}
            
            {isUploading && (
              <div className="absolute inset-0 z-20 flex items-center justify-center flex-col gap-2">
                <div className="w-6 h-6 border-2 border-white/20 border-t-white rounded-full animate-spin"></div>
                <span className="text-[10px] font-black text-white uppercase tracking-widest">{t.uploading}</span>
              </div>
            )}

            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder={t.placeholder}
              className="relative z-10 bg-transparent border-none focus:ring-0 focus:outline-none text-white text-2xl font-black italic uppercase tracking-tighter text-center placeholder:text-white/30 resize-none w-full h-full flex items-center justify-center pt-8 drop-shadow-lg"
              maxLength={80}
            />
            
            <button 
              onClick={() => fileInputRef.current?.click()}
              disabled={isUploading}
              className="absolute top-4 right-4 z-10 p-2 bg-black/40 rounded-xl border border-white/10 text-white/80 hover:text-white disabled:opacity-50"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2-2v12a2 2 0 002 2z" /></svg>
            </button>
            <input type="file" ref={fileInputRef} onChange={handlePhotoUpload} className="hidden" accept="image/*" />
          </div>

          <div className="space-y-6">
            {!imageUrl && (
              <div>
                <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3 block">Color Theme</label>
                <div className="flex gap-2">
                  {BG_COLORS.map(color => (
                    <button
                      key={color}
                      onClick={() => setBgColor(color)}
                      className={`w-8 h-8 rounded-full border-2 ${color} ${bgColor === color ? 'border-white scale-110 shadow-lg' : 'border-transparent'}`}
                    />
                  ))}
                </div>
              </div>
            )}

            <button
              onClick={handlePost}
              disabled={(!text.trim() && !imageUrl) || isUploading}
              className="w-full bg-purple-600 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-purple-500/20 active:scale-95 transition-all"
            >
              {t.post}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CreateStatusModal;
