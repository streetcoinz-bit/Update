import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, DollarSign, Wallet, ArrowRight } from 'lucide-react';
import { Coin, UserPortfolio } from '../types';

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  coin: Coin | null;
  portfolio: UserPortfolio;
  onTrade: (coinId: string, amount: number, isBuy: boolean) => void;
}

export const TradeModal: React.FC<TradeModalProps> = ({ isOpen, onClose, coin, portfolio, onTrade }) => {
  const [amount, setAmount] = useState<string>('');
  const [isBuy, setIsBuy] = useState(true);

  // Reset state when modal opens/changes coin
  useEffect(() => {
    setAmount('');
    setIsBuy(true);
  }, [coin, isOpen]);

  if (!isOpen || !coin) return null;

  const numericAmount = parseFloat(amount) || 0;
  const totalCost = numericAmount * coin.price;
  const maxBuy = portfolio.balance / coin.price;
  const maxSell = portfolio.holdings[coin.id] || 0;

  const isValid = numericAmount > 0 && (isBuy ? totalCost <= portfolio.balance : numericAmount <= maxSell);

  const handleExecute = () => {
    if (isValid) {
      onTrade(coin.id, numericAmount, isBuy);
      onClose();
    }
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              onClick={(e) => e.stopPropagation()}
              className="bg-street-dark border border-street-gray w-full max-w-md rounded-2xl overflow-hidden shadow-2xl relative"
            >
              {/* Header */}
              <div className="p-6 border-b border-white/10 flex justify-between items-center bg-street-black/50">
                <div>
                  <h2 className="font-display text-2xl tracking-wide flex items-center gap-2">
                    PREDICT <span className="text-neon-green">{coin.symbol}</span>
                  </h2>
                  <p className="font-mono text-xs text-gray-400">Current Price: ${coin.price.toFixed(2)}</p>
                </div>
                <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
                  <X size={20} />
                </button>
              </div>

              {/* Body */}
              <div className="p-6 space-y-6">
                
                {/* Buy/Sell Toggle */}
                <div className="flex bg-street-black p-1 rounded-lg">
                  <button
                    onClick={() => setIsBuy(true)}
                    className={`flex-1 py-2 font-mono font-bold text-sm rounded-md transition-all ${
                      isBuy ? 'bg-neon-green text-black shadow-lg' : 'text-gray-500 hover:text-white'
                    }`}
                  >
                    BUY (UP)
                  </button>
                  <button
                    onClick={() => setIsBuy(false)}
                    className={`flex-1 py-2 font-mono font-bold text-sm rounded-md transition-all ${
                      !isBuy ? 'bg-red-500 text-white shadow-lg' : 'text-gray-500 hover:text-white'
                    }`}
                  >
                    SELL (DOWN)
                  </button>
                </div>

                {/* Amount Input */}
                <div>
                  <div className="flex justify-between mb-2">
                    <label className="font-mono text-xs text-gray-400 uppercase">Amount ({coin.symbol})</label>
                    <span className="font-mono text-xs text-gray-500">
                      Max: {isBuy ? maxBuy.toFixed(4) : maxSell.toFixed(4)}
                    </span>
                  </div>
                  <div className="relative">
                    <input
                      type="number"
                      value={amount}
                      onChange={(e) => setAmount(e.target.value)}
                      placeholder="0.00"
                      className="w-full bg-street-black border border-street-gray rounded-lg py-4 pl-4 pr-12 text-2xl font-mono focus:outline-none focus:border-neon-green transition-colors"
                    />
                    <button 
                      onClick={() => setAmount((isBuy ? maxBuy : maxSell).toFixed(4))}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-xs font-mono bg-street-gray px-2 py-1 rounded text-neon-green hover:bg-white/10"
                    >
                      MAX
                    </button>
                  </div>
                </div>

                {/* Summary */}
                <div className="bg-street-black/50 p-4 rounded-lg border border-white/5 space-y-2">
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Total Value</span>
                    <span className="font-mono">${totalCost.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-400">Wallet Balance</span>
                    <span className="font-mono flex items-center gap-1">
                      <Wallet size={12} />
                      ${portfolio.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                    </span>
                  </div>
                  {!isBuy && (
                     <div className="flex justify-between text-sm">
                     <span className="text-gray-400">Holdings</span>
                     <span className="font-mono flex items-center gap-1">
                       {portfolio.holdings[coin.id]?.toFixed(4) || '0.0000'} {coin.symbol}
                     </span>
                   </div>
                  )}
                </div>

                {/* Action Button */}
                <button
                  onClick={handleExecute}
                  disabled={!isValid}
                  className={`w-full py-4 rounded-xl font-display text-xl tracking-wide uppercase flex items-center justify-center gap-2 transition-all ${
                    isValid
                      ? isBuy 
                        ? 'bg-neon-green text-black hover:shadow-[0_0_20px_rgba(0,255,148,0.4)]' 
                        : 'bg-red-500 text-white hover:shadow-[0_0_20px_rgba(239,68,68,0.4)]'
                      : 'bg-street-gray text-gray-500 cursor-not-allowed'
                  }`}
                >
                  {isBuy ? 'Confirm Prediction (UP)' : 'Confirm Prediction (DOWN)'} <ArrowRight size={20} />
                </button>

              </div>
            </motion.div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
};
