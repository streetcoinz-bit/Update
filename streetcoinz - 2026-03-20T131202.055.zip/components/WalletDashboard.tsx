
import React, { useState } from 'react';
import { UserWallet, UserProfile, Language } from '../types';

interface WalletDashboardProps {
  wallet: UserWallet;
  user: UserProfile | null;
  language: Language;
  activeThemeClass: string;
  onLogin: () => void;
  onDeposit: (amount: number) => void;
  onWithdraw: (amount: number) => void;
}

const translations = {
  [Language.EN]: { 
    locked: 'YOUR VAULT IS LOCKED', 
    subLock: 'Link your Street Identity to unlock high-frequency trading.', 
    login: 'CONNECT GMAIL', 
    power: 'Liquid Street Power', 
    deposit: 'Deposit', 
    withdraw: 'Withdraw', 
    amount: 'Amount (USD)', 
    confirm: 'Confirm Action', 
    vault: 'Vault Log', 
    active: 'Active', 
    max: 'Max',
    withdrawAddr: 'Withdrawal Address',
    withdrawNote: 'Ensure the address is correct. Funds lost are gone forever.',
    errorInsufficient: 'Insufficient funds in your vault.',
    successDeposit: 'Funds secured!',
    successWithdraw: 'Transfer initiated.',
    holdings: 'BALANCE',
    totalBalance: 'TOTAL BALANCE'
  },
  [Language.ID]: { 
    locked: 'BRANKAS TERKUNCI', 
    subLock: 'Hubungkan Identitas Jalanan untuk buka fitur trading.', 
    login: 'HUBUNGKAN GMAIL', 
    power: 'Kekuatan Cairan Jalanan', 
    deposit: 'Deposit', 
    withdraw: 'Tarik Saldo', 
    amount: 'Jumlah (USD)', 
    confirm: 'Konfirmasi Aksi', 
    vault: 'Log Brankas', 
    active: 'Aktif', 
    max: 'Maks',
    withdrawAddr: 'Alamat Penarikan',
    withdrawNote: 'Pastikan alamat benar. Dana yang hilang tidak bisa kembali.',
    errorInsufficient: 'Saldo brankas tidak cukup.',
    successDeposit: 'Dana diamankan!',
    successWithdraw: 'Transfer dimulai.',
    holdings: 'SALDO',
    totalBalance: 'TOTAL SALDO'
  },
  [Language.ES]: { 
    locked: 'TU BOVEDA ESTA BLOQUEADA', 
    subLock: 'Vincula tu Identidad de Calle para desbloquear trading.', 
    login: 'CONECTAR GMAIL', 
    power: 'Poder Líquido Callejero', 
    deposit: 'Depositar', 
    withdraw: 'Retirar', 
    amount: 'Monto (USD)', 
    confirm: 'Confirmar Acción', 
    vault: 'Registro de Bóveda', 
    active: 'Activo', 
    max: 'Máx',
    withdrawAddr: 'Dirección de Retiro',
    withdrawNote: 'Asegúrese de que la dirección sea correcta.',
    errorInsufficient: 'Fondos insuficientes.',
    successDeposit: '¡Fondos asegurados!',
    successWithdraw: 'Transferencia iniciada.',
    holdings: 'SALDO',
    totalBalance: 'SALDO TOTAL'
  },
  [Language.CN]: { 
    locked: '您的保险库已锁定', 
    subLock: '关联街道身份以解锁高频交易。', 
    login: '连接 GMAIL', 
    power: '流动街道动力', 
    deposit: '充值', 
    withdraw: '提现', 
    amount: '金额 (USD)', 
    confirm: '确认操作', 
    vault: '保险库日志', 
    active: '已激活', 
    max: '最大',
    withdrawAddr: '提现地址',
    withdrawNote: '请确保地址正确。',
    errorInsufficient: '保险库余额不足。',
    successDeposit: '资金已安全！',
    successWithdraw: '转账已发起。',
    holdings: '余额',
    totalBalance: '总余额'
  }
};

const WalletDashboard: React.FC<WalletDashboardProps> = ({ wallet, user, language, activeThemeClass, onLogin, onDeposit, onWithdraw }) => {
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';
  const [activeMode, setActiveMode] = useState<'DEPOSIT' | 'WITHDRAW'>('DEPOSIT');
  const [inputAmount, setInputAmount] = useState('');
  const [feedback, setFeedback] = useState<{ msg: string; type: 'success' | 'error' } | null>(null);

  if (!user) {
    return (
      <div className={`p-8 h-full flex flex-col items-center justify-center text-center transition-colors duration-300 ${isDark ? 'bg-zinc-950' : 'bg-zinc-50'}`}>
        <div className={`w-24 h-24 rounded-[32px] flex items-center justify-center mb-6 border rotate-3 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
          <svg className={`w-12 h-12 ${isDark ? 'text-zinc-700' : 'text-zinc-300'}`} fill="currentColor" viewBox="0 0 24 24">
            <path d="M12 12c2.21 0 4-1.79 4-4s-1.79-4-4-4-4 1.79-4 4 1.79 4 4 4zm0 2c-2.67 0-8 1.34-8 4v2h16v-2c0-2.66-5.33-4-8-4z"/>
          </svg>
        </div>
        <h2 className={`text-2xl font-black mb-3 tracking-tight italic uppercase ${isDark ? 'text-white' : 'text-zinc-900'}`}>{t.locked}</h2>
        <p className="text-zinc-500 text-xs px-6 mb-10 leading-relaxed font-medium">{t.subLock}</p>
        <button 
          onClick={onLogin}
          className={`w-full py-4 rounded-2xl font-black text-sm shadow-2xl transition-all active:scale-95 ${isDark ? 'bg-white text-zinc-900' : 'bg-zinc-900 text-white'}`}
        >
          {t.login}
        </button>
      </div>
    );
  }

  const handleAction = () => {
    const amt = parseFloat(inputAmount);
    if (isNaN(amt) || amt <= 0) return;

    if (activeMode === 'DEPOSIT') {
      onDeposit(amt);
      setFeedback({ msg: t.successDeposit, type: 'success' });
      setInputAmount('');
    } else {
      if (amt > wallet.balance) {
        setFeedback({ msg: t.errorInsufficient, type: 'error' });
        return;
      }
      onWithdraw(amt);
      setFeedback({ msg: t.successWithdraw, type: 'success' });
      setInputAmount('');
    }

    setTimeout(() => setFeedback(null), 3000);
  };

  // Removed Street Balance from assetList as requested. 
  // It only appears in the Hero Balance display now.
  const assetList: any[] = [];

  return (
    <div className={`p-6 h-full flex flex-col gap-6 overflow-y-auto pb-32 transition-colors duration-300 ${isDark ? 'bg-zinc-950' : 'bg-zinc-50'}`}>
      
      {/* Dynamic Profile/Network Bar */}
      <div className={`flex items-center justify-between p-4 rounded-3xl border transition-colors ${isDark ? 'bg-zinc-900/40 border-zinc-800/50' : 'bg-white border-zinc-200 shadow-sm'}`}>
        <div className="flex items-center gap-3">
          <div className="relative">
            <img src={user.avatar} alt="Avatar" className={`w-12 h-12 rounded-2xl border-2 p-0.5 ${isDark ? 'border-purple-500/50' : 'border-purple-200'}`} />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-emerald-500 border-2 border-zinc-950 rounded-full"></div>
          </div>
          <div>
            <h4 className={`font-black text-sm tracking-tight italic uppercase ${isDark ? 'text-white' : 'text-zinc-900'}`}>{user.name}</h4>
            <div className="flex items-center gap-1">
               <span className={`text-[7px] font-black px-1.5 py-0.5 rounded uppercase tracking-tighter ${isDark ? 'text-zinc-400 bg-zinc-800' : 'text-zinc-600 bg-zinc-100'}`}>
                 {wallet.address?.substring(0, 10)}...
               </span>
            </div>
          </div>
        </div>
        <div className="text-right">
           <span className="text-[7px] font-black text-zinc-500 uppercase tracking-widest block">Mainnet Alpha</span>
           <span className={`text-[9px] font-bold ${isDark ? 'text-emerald-400' : 'text-emerald-600'}`}>ONLINE</span>
        </div>
      </div>

      {/* Hero Balance Section */}
      <div className="relative group">
        <div className="absolute -inset-1 bg-gradient-to-r from-purple-600 to-indigo-600 rounded-[36px] blur opacity-20 group-hover:opacity-40 transition duration-1000"></div>
        <div className="relative bg-gradient-to-br from-zinc-900 to-black p-8 rounded-[32px] shadow-2xl overflow-hidden border border-white/5">
          <div className="absolute right-0 top-0 w-32 h-32 bg-purple-600/10 blur-[60px] rounded-full"></div>
          <div className="relative z-10">
            <div className="flex justify-between items-center mb-6">
              <div className="flex flex-col">
                <span className="text-white/40 text-[9px] font-black uppercase tracking-[0.2em]">{t.totalBalance}</span>
                <div className="flex items-baseline gap-1">
                  <span className="text-white/60 text-lg font-black font-heading">$</span>
                  <div className="text-5xl font-black font-heading text-white tracking-tighter italic">
                    {wallet.balance.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                </div>
              </div>
              <div className="p-3 bg-white/5 rounded-2xl border border-white/10 backdrop-blur-sm">
                <svg className="w-6 h-6 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 15V3m0 12l-4-4m4 4l4-4M2 17l.621 2.485A2 2 0 004.561 21h14.878a2 2 0 001.94-1.515L22 17" />
                </svg>
              </div>
            </div>

            {/* Micro Breakdown */}
            <div className="grid grid-cols-3 gap-2">
              <div className="bg-white/5 p-2 rounded-xl border border-white/5">
                <div className="text-[7px] font-black text-white/30 uppercase tracking-widest mb-1">STREET POWER</div>
                <div className="text-[10px] font-black text-purple-400 italic">{(wallet.balance / 10).toFixed(1)}k VP</div>
              </div>
              <div className={`bg-white/5 p-2 rounded-xl border border-white/5`}>
                <div className="text-[7px] font-black text-white/30 uppercase tracking-widest mb-1">STREAK</div>
                <div className="text-[10px] font-black text-amber-500 italic">12 DAYS</div>
              </div>
              <div className="bg-white/5 p-2 rounded-xl border border-white/5 text-right">
                <div className="text-[7px] font-black text-white/30 uppercase tracking-widest mb-1">ALPHA SCORE</div>
                <div className="text-[10px] font-black text-emerald-400 italic">A+</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Asset Holdings Section (Hidden if empty as requested) */}
      {assetList.length > 0 && (
        <div className="flex flex-col gap-3">
          <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] px-1">{t.holdings}</h3>
          <div className="flex flex-col gap-2">
            {assetList.map((asset) => (
              <div key={asset.symbol} className={`p-4 rounded-2xl border flex items-center justify-between transition-all hover:scale-[1.01] ${isDark ? 'bg-zinc-900/40 border-zinc-800/50' : 'bg-white border-zinc-200 shadow-sm'}`}>
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black text-lg bg-zinc-800/50 border border-white/5 ${asset.color}`}>
                    {asset.icon}
                  </div>
                  <div>
                    <div className={`text-xs font-black uppercase tracking-tight ${isDark ? 'text-white' : 'text-zinc-900'}`}>{asset.name}</div>
                    <div className="text-[8px] text-zinc-500 font-bold uppercase tracking-widest">{asset.amount} {asset.symbol}</div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`text-sm font-black italic ${isDark ? 'text-white' : 'text-zinc-900'}`}>${asset.value}</div>
                  <div className="text-[7px] font-bold text-emerald-500 uppercase tracking-tighter">Liquid</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Action Tabs */}
      <div className={`p-1 rounded-2xl flex border ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200 shadow-sm'}`}>
        <button 
          onClick={() => setActiveMode('DEPOSIT')}
          className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeMode === 'DEPOSIT' ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          {t.deposit}
        </button>
        <button 
          onClick={() => setActiveMode('WITHDRAW')}
          className={`flex-1 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all ${activeMode === 'WITHDRAW' ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/20' : 'text-zinc-500 hover:text-zinc-300'}`}
        >
          {t.withdraw}
        </button>
      </div>

      {/* Transaction Area */}
      <div className={`p-6 rounded-[32px] border animate-in fade-in zoom-in-95 duration-300 ${isDark ? 'bg-zinc-900/40 border-zinc-800/50' : 'bg-white border-zinc-200 shadow-sm'}`}>
        <div className="space-y-6">
          <div>
            <div className="flex justify-between items-center mb-3 px-1">
              <label className="text-[9px] font-black text-zinc-500 uppercase tracking-widest">{t.amount}</label>
              {activeMode === 'WITHDRAW' && (
                <button 
                  onClick={() => setInputAmount(wallet.balance.toString())}
                  className="text-[9px] font-black text-purple-500 uppercase tracking-widest hover:underline"
                >
                  {t.max}: ${wallet.balance.toFixed(2)}
                </button>
              )}
            </div>
            <div className="relative">
               <span className="absolute left-5 top-1/2 -translate-y-1/2 text-zinc-600 font-black text-xl">$</span>
               <input 
                type="number" 
                value={inputAmount}
                onChange={(e) => setInputAmount(e.target.value)}
                className={`w-full py-5 pl-10 pr-4 rounded-2xl border font-black text-2xl focus:outline-none ${isDark ? 'bg-zinc-950 border-zinc-800 text-white' : 'bg-zinc-50 border-zinc-200 text-zinc-900'}`}
                placeholder="0.00"
               />
            </div>
          </div>

          {activeMode === 'WITHDRAW' && (
            <div className="animate-in slide-in-from-top-2 duration-300">
               <label className="text-[9px] font-black text-zinc-500 uppercase tracking-widest mb-2 block px-1">{t.withdrawAddr}</label>
               <input 
                type="text" 
                defaultValue={wallet.address || ''}
                className={`w-full py-4 px-5 rounded-2xl border font-bold text-[11px] focus:outline-none ${isDark ? 'bg-zinc-950 border-zinc-800 text-zinc-400' : 'bg-zinc-50 border-zinc-200 text-zinc-600'}`}
                placeholder="0x..."
               />
               <p className="text-[8px] font-bold text-zinc-500 uppercase mt-3 leading-relaxed italic opacity-60 px-1">
                 {t.withdrawNote}
               </p>
            </div>
          )}

          {feedback && (
             <div className={`p-4 rounded-2xl text-[10px] font-black uppercase text-center border animate-in fade-in duration-300 ${feedback.type === 'success' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-500' : 'bg-rose-500/10 border-rose-500/20 text-rose-500'}`}>
                {feedback.msg}
             </div>
          )}

          <button 
            onClick={handleAction}
            disabled={!inputAmount || parseFloat(inputAmount) <= 0}
            className={`w-full py-5 rounded-2xl font-black text-sm uppercase tracking-[0.2em] shadow-xl transition-all active:scale-95 disabled:opacity-50 ${isDark ? 'bg-white text-zinc-950' : 'bg-zinc-950 text-white'}`}
          >
            {t.confirm}
          </button>
        </div>
      </div>

      {/* Vault Activity */}
      <div className="flex flex-col gap-4 mb-4">
        <h3 className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.2em] px-1">{t.vault}</h3>
        <div className="flex flex-col gap-2">
          {wallet.history.length > 0 ? wallet.history.map(tx => (
            <div key={tx.id} className={`p-4 rounded-2xl border flex items-center justify-between transition-colors ${isDark ? 'bg-zinc-900/30 border-zinc-900/50' : 'bg-white border-zinc-100 shadow-sm'}`}>
              <div className="flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center ${tx.amount > 0 ? (isDark ? 'bg-emerald-500/10 text-emerald-400' : 'bg-emerald-50 text-emerald-600') : (isDark ? 'bg-rose-500/10 text-rose-500' : 'bg-rose-50 text-rose-600')}`}>
                  {tx.type === 'WITHDRAW' ? (
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z" /><path strokeLinecap="round" strokeLinejoin="round" d="M2.458 12C3.732 7.943 7.523 5 12 5c4.478 0 8.268 2.943 9.542 7-1.274 4.057-5.064 7-9.542 7-4.477 0-8.268-2.943-9.542-7z" /></svg>
                  ) : tx.amount > 0 ? (
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M12 4v16m8-8H4" /></svg>
                  ) : (
                    <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M19 14l-7 7m0 0l-7-7m7 7V3" /></svg>
                  )}
                </div>
                <div>
                  <div className={`text-[10px] font-black uppercase italic ${isDark ? 'text-white' : 'text-zinc-900'}`}>{tx.type}</div>
                  <div className="text-[8px] text-zinc-500 font-bold uppercase tracking-tighter">{tx.timestamp.toLocaleDateString()} • {tx.status}</div>
                </div>
              </div>
              <div className={`text-sm font-black italic tracking-tighter ${tx.amount > 0 ? 'text-emerald-500' : 'text-rose-500'}`}>
                {tx.amount > 0 ? '+' : ''}{Math.abs(tx.amount).toLocaleString('en-US', { style: 'currency', currency: 'USD' })}
              </div>
            </div>
          )) : (
            <div className="py-12 flex flex-col items-center opacity-20">
               <svg className="w-10 h-10 mb-2" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
               <span className="text-[9px] font-black uppercase tracking-widest">No activity recorded</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default WalletDashboard;
