import React from 'react';
import { motion } from 'motion/react';
import { Wallet, ArrowUpRight, ArrowDownLeft, PieChart } from 'lucide-react';
import { UserPortfolio, Coin } from '../types';

interface PortfolioProps {
  portfolio: UserPortfolio;
  coins: Coin[];
}

export const Portfolio: React.FC<PortfolioProps> = ({ portfolio, coins }) => {
  const holdingsValue = Object.entries(portfolio.holdings).reduce((total: number, [coinId, amount]: [string, number]) => {
    const coin = coins.find(c => c.id === coinId);
    return total + (amount * (coin?.price || 0));
  }, 0);

  const totalValue = portfolio.balance + holdingsValue;

  return (
    <div className="bg-street-dark border border-street-gray p-6 rounded-xl mb-8 relative overflow-hidden">
      <div className="absolute top-0 right-0 p-8 opacity-5">
        <PieChart size={120} />
      </div>

      <div className="flex flex-col md:flex-row justify-between items-end md:items-center gap-6 relative z-10">
        <div className="space-y-4">
          <div>
            <h2 className="text-gray-400 font-mono text-sm uppercase tracking-wider mb-1 flex items-center gap-2">
              <Wallet size={16} /> Net Worth
            </h2>
            <div className="text-5xl font-display text-white tracking-tight">
              ${totalValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </div>
          </div>
          
          <div className="flex gap-6 text-sm font-mono">
            <div>
              <span className="text-gray-500 block text-xs">CASH BALANCE</span>
              <span className="text-neon-green">${portfolio.balance.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
            <div>
              <span className="text-gray-500 block text-xs">ASSET VALUE</span>
              <span className="text-neon-blue">${holdingsValue.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>
        
        <div className="flex gap-4">
          <button className="flex items-center gap-2 bg-neon-green text-black px-6 py-3 rounded-lg font-bold font-mono hover:opacity-90 transition-opacity shadow-[0_0_15px_rgba(0,255,148,0.2)]">
            <ArrowDownLeft size={20} /> DEPOSIT
          </button>
          <button className="flex items-center gap-2 bg-transparent border border-white/20 text-white px-6 py-3 rounded-lg font-bold font-mono hover:bg-white/5 transition-colors">
            <ArrowUpRight size={20} /> WITHDRAW
          </button>
        </div>
      </div>
    </div>
  );
};
