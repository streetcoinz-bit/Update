
import React, { useState, useMemo } from 'react';
import { VideoPost, UserStatus, Language, UserProfile, Message } from '../types';
import StatusViewer from './StatusViewer';

interface PublicProfileProps {
  username: string;
  posts: VideoPost[];
  statuses: UserStatus[];
  viewedStatusIds: Set<string>;
  language: Language;
  activeThemeClass: string;
  isFollowing: boolean;
  isBlocked?: boolean;
  onToggleFollow: () => void;
  onBlock: () => void;
  onUnblock: () => void;
  onBack: () => void;
  onShareProfile: () => void;
  onOpenList: (type: 'Followers' | 'Following') => void;
  onViewPost?: (postId: string) => void;
  onDeleteStatus: (id: string) => void;
  onShareStatus: (status: UserStatus) => void;
  onSendMessage: (targetId: string, msg: Partial<Message>) => void;
  onMarkStatusRead: (id: string) => void;
  currentUser: UserProfile | null;
}

const translations = {
  [Language.EN]: { follow: 'Follow', following: 'Following', posts: 'Posts', followers: 'Followers', followingLabel: 'Following', likes: 'Likes', trader: 'Trader', block: 'Block Trader', unblock: 'Unblock Trader', blockedMsg: 'This user is in your block list.', alphas: 'TRADER ALPHAS' },
  [Language.ID]: { follow: 'Ikuti', following: 'Mengikuti', posts: 'Postingan', followingLabel: 'Mengikuti', followers: 'Pengikut', likes: 'Likes', trader: 'Trader', block: 'Blokir Trader', unblock: 'Buka Blokir', blockedMsg: 'Trader ini ada di daftar blokir Anda.', alphas: 'ALPHA TRADER' },
  [Language.ES]: { follow: 'Seguir', following: 'Siguiendo', posts: 'Posts', followers: 'Seguidores', followingLabel: 'Siguiendo', likes: 'Likes', trader: 'Trader', block: 'Bloquear', unblock: 'Desbloquear', blockedMsg: 'Este usuario está bloqueado.', alphas: 'ALPHAS DEL TRADER' },
  [Language.CN]: { follow: '关注', following: '正在关注', posts: '帖子', followers: '粉丝', followingLabel: '关注中', likes: '获赞', trader: '交易者', block: '屏蔽', unblock: '取消屏蔽', blockedMsg: '该用户已被您屏蔽。', alphas: '交易者阿尔法' }
};

const DUMMY_BIOS: Record<string, string> = {
  'crypto_whale_99': 'Full time degen. Whale in the making. BTC to the moon! 🐋🚀',
  'street_trader_id': 'Just a street kid playing with charts. No financial advice.',
  'scalp_queen': 'I trade the noise so you don\'t have to. Scalping is my meditation. 📈',
};

const DUMMY_LINKS: Record<string, string[]> = {
  'crypto_whale_99': ['twitter.com/whale99', 't.me/whale_alpha'],
  'street_trader_id': ['streetcoinz.com/alpha'],
  'scalp_queen': ['linktr.ee/scalpqueen', 'youtube.com/@scalpqueen'],
};

const PublicProfile: React.FC<PublicProfileProps> = ({ username, posts, statuses, viewedStatusIds, language, activeThemeClass, isFollowing, isBlocked, onToggleFollow, onBlock, onUnblock, onBack, onShareProfile, onOpenList, onViewPost, onDeleteStatus, onShareStatus, onSendMessage, onMarkStatusRead, currentUser }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isViewerOpen, setIsViewerOpen] = useState(false);
  const [viewerStartIndex, setViewerStartIndex] = useState(0);
  const t = translations[language];
  const isDark = activeThemeClass === 'theme-dark';
  
  const avatarUrl = `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`;
  const baseFollowers = (username.length * 123) % 1000;
  const followerCount = baseFollowers + (isFollowing ? 1 : 0);
  const followingCount = (username.length * 42) % 200;
  const totalLikes = (username.length * 567) % 50000;
  const bio = DUMMY_BIOS[username] || "The street is my office. Trading is my game. 🔥";
  const links = DUMMY_LINKS[username] || [];

  const formatCount = (num: number) => {
    if (num >= 1000) return (num / 1000).toFixed(1) + 'K';
    return num.toString();
  };

  const userPosts = posts.filter(p => p.username === username);
  const userStatuses = statuses.filter(s => s.username === username);

  const hasUnreadAlpha = useMemo(() => {
    return userStatuses.some(s => !viewedStatusIds.has(s.id));
  }, [userStatuses, viewedStatusIds]);

  const handleOpenStatus = () => {
    const idx = statuses.findIndex(s => s.username === username);
    if (idx !== -1) {
      setViewerStartIndex(idx);
      setIsViewerOpen(true);
    }
  };

  if (isViewerOpen) {
    return (
      <StatusViewer
        statuses={statuses}
        initialIndex={viewerStartIndex}
        onClose={() => setIsViewerOpen(false)}
        onDelete={(id) => {
          onDeleteStatus(id);
          if (statuses.length <= 1) setIsViewerOpen(false);
        }}
        onShare={(status) => {
          onShareStatus(status);
          setIsViewerOpen(false);
        }}
        onReplyToDM={(un, text) => {
           // DM Reply logic could be here
        }}
        onViewProfile={() => {}}
        onMarkAsRead={onMarkStatusRead}
        currentUserUsername={currentUser?.name.toLowerCase().replace(/\s/g, '_')}
        activeThemeClass={activeThemeClass}
        language={language}
      />
    );
  }

  return (
    <div className={`flex flex-col h-full overflow-y-auto scrollbar-hide transition-colors duration-300 ${isDark ? 'bg-zinc-950 text-white' : 'bg-zinc-50 text-zinc-900'}`}>
      <div className={`sticky top-0 z-10 p-4 flex items-center justify-between backdrop-blur-md border-b ${isDark ? 'bg-zinc-950/80 border-zinc-900' : 'bg-white/80 border-zinc-200'}`}>
        <div className="flex items-center gap-4">
          <button onClick={onBack} className="p-2 hover:bg-zinc-800/20 rounded-xl transition-all">
            <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <h2 className="text-sm font-black uppercase italic tracking-tighter">@{username}</h2>
        </div>
        
        <div className="flex items-center gap-2">
          {!isBlocked && (
            <button 
              onClick={onShareProfile}
              className={`p-2 rounded-xl transition-all active:scale-90 ${isDark ? 'text-zinc-400 hover:text-white hover:bg-zinc-800' : 'text-zinc-500 hover:text-zinc-900 hover:bg-zinc-100'}`}
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
            </button>
          )}

          <div className="relative">
            <button onClick={() => setIsMenuOpen(!isMenuOpen)} className="p-2 text-zinc-500 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z" />
              </svg>
            </button>
            
            {isMenuOpen && (
              <div className={`absolute right-0 mt-2 w-48 py-2 rounded-2xl border shadow-2xl z-50 animate-in slide-in-from-top-2 duration-200 ${isDark ? 'bg-zinc-900 border-zinc-800' : 'bg-white border-zinc-200'}`}>
                <button 
                  onClick={() => {
                    isBlocked ? onUnblock() : onBlock();
                    setIsMenuOpen(false);
                  }}
                  className={`w-full text-left px-4 py-3 text-[10px] font-black uppercase tracking-widest flex items-center gap-2 hover:bg-rose-500/10 transition-colors ${isBlocked ? 'text-emerald-500' : 'text-rose-500'}`}
                >
                  <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728L5.636 5.636" /></svg>
                  {isBlocked ? t.unblock : t.block}
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="flex flex-col items-center p-8 pb-4 w-full">
        <div 
          className="relative mb-6 cursor-pointer"
          onClick={() => {
            if (!isBlocked && userStatuses.length > 0) {
              handleOpenStatus();
            }
          }}
        >
          <div className={`absolute -inset-1.5 rounded-full blur transition duration-1000 ${isDark ? 'opacity-40' : 'opacity-20'} ${!isBlocked && userStatuses.length > 0 ? (hasUnreadAlpha ? 'bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 animate-pulse' : 'bg-zinc-800') : (isDark ? 'bg-zinc-800' : 'bg-zinc-200')}`}></div>
          
          {/* Status Indicator Ring */}
          {!isBlocked && userStatuses.length > 0 && (
            <div className={`absolute -inset-3 rounded-full border-4 border-transparent ${hasUnreadAlpha ? 'bg-gradient-to-tr from-purple-600 via-pink-500 to-amber-400 p-1.5 shadow-[0_0_20px_rgba(168,85,247,0.4)]' : 'bg-zinc-800 p-1'} [mask-image:linear-gradient(white,white),linear-gradient(white,white)] [mask-clip:content-box,padding-box] [mask-composite:exclude] animate-in zoom-in-50 duration-500`}></div>
          )}

          <img 
            src={avatarUrl} 
            alt={username} 
            className={`relative w-24 h-24 rounded-full border-4 object-cover shadow-2xl transition-all ${isDark ? 'border-zinc-900 bg-zinc-950' : 'border-white bg-white'} ${isBlocked ? 'grayscale opacity-50' : ''} ${!isBlocked && userStatuses.length > 0 ? 'hover:scale-105 transition-transform' : ''}`}
          />
        </div>
        
        <h1 className="text-xl font-black italic uppercase tracking-tighter mb-1">@{username}</h1>
        <p className="text-zinc-500 text-[10px] font-black uppercase tracking-widest mb-3">{t.trader}</p>
        
        {!isBlocked ? (
          <>
            <p className={`text-center px-4 mb-4 text-xs font-medium max-w-[280px] ${isDark ? 'text-zinc-400' : 'text-zinc-600'}`}>
              {bio}
            </p>

            {/* Display Links */}
            {links.length > 0 && (
              <div className="flex flex-wrap justify-center gap-2 px-6 mb-6">
                {links.map((link, idx) => (
                  <a 
                    key={idx} 
                    href={link.startsWith('http') ? link : `https://${link}`} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl border text-[9px] font-black uppercase tracking-widest transition-all active:scale-90 ${isDark ? 'bg-zinc-900 border-zinc-800 text-purple-400 hover:text-white' : 'bg-white border-zinc-200 text-purple-600 hover:bg-purple-50'}`}
                  >
                    <svg className="w-3 h-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.826a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1" />
                    </svg>
                    {link.replace(/^https?:\/\/(www\.)?/, '').split('/')[0]}
                  </a>
                ))}
              </div>
            )}

            {/* Stats Grid: POSTINGAN | MENGIKUTI | PENGIKUT | LIKES */}
            <div className="flex items-center justify-center gap-4 mb-8 w-full px-6">
              <div className="flex flex-col items-center flex-1">
                <span className="text-lg font-black tracking-tighter leading-none">{userPosts.length}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.posts}</span>
              </div>
              
              <div className="w-px h-6 bg-zinc-800/50"></div>
              
              <button onClick={() => onOpenList('Following')} className="flex flex-col items-center flex-1 group transition-transform hover:scale-105">
                <span className="text-lg font-black tracking-tighter leading-none group-hover:text-purple-500 transition-colors">{formatCount(followingCount)}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.followingLabel}</span>
              </button>
              
              <div className="w-px h-6 bg-zinc-800/50"></div>
              
              <button onClick={() => onOpenList('Followers')} className="flex flex-col items-center flex-1 group transition-transform hover:scale-105">
                <span className="text-lg font-black tracking-tighter leading-none group-hover:text-purple-500 transition-colors">{formatCount(followerCount)}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.followers}</span>
              </button>
              
              <div className="w-px h-6 bg-zinc-800/50"></div>
              
              <div className="flex flex-col items-center flex-1">
                <span className="text-lg font-black tracking-tighter leading-none">{formatCount(totalLikes)}</span>
                <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest mt-1">{t.likes}</span>
              </div>
            </div>

            <button 
              onClick={onToggleFollow}
              className={`w-full max-w-[200px] py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl transition-all active:scale-95 ${
                isFollowing 
                  ? (isDark ? 'bg-zinc-800 text-white' : 'bg-zinc-200 text-zinc-900') 
                  : 'bg-purple-600 text-white shadow-purple-500/20'
              }`}
            >
              {isFollowing ? t.following : t.follow}
            </button>
          </>
        ) : (
          <div className="flex flex-col items-center gap-6 mt-4">
             <div className="bg-rose-500/10 border border-rose-500/20 px-6 py-3 rounded-2xl">
                <p className="text-[10px] font-black text-rose-500 uppercase tracking-widest text-center">{t.blockedMsg}</p>
             </div>
             <button 
              onClick={onUnblock}
              className="px-8 py-3 bg-zinc-800 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-zinc-700 transition-colors"
             >
               {t.unblock}
             </button>
          </div>
        )}
      </div>

      {!isBlocked && (
        <div className="px-1 pb-24">
          <div className="grid grid-cols-3 gap-1">
            {userPosts.map((post) => (
              <div 
                key={post.id} 
                onClick={() => onViewPost?.(post.id)}
                className="aspect-[3/4] bg-zinc-900 overflow-hidden group relative cursor-pointer"
              >
                {post.mediaType === 'video' ? (
                  <video src={post.url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" muted />
                ) : (
                  <img src={post.url} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                )}
                <div className="absolute bottom-2 left-2 flex items-center gap-1">
                  <svg className="w-3 h-3 text-white" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z" />
                  </svg>
                  <span className="text-[9px] font-black text-white">{formatCount(post.likes)}</span>
                </div>
              </div>
            ))}
            
            {userPosts.length === 0 && (
              <div className="col-span-3 py-20 flex flex-col items-center opacity-30">
                <svg className="w-12 h-12 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2-2v8a2 2 0 002 2z" />
                </svg>
                <span className="text-[10px] font-black uppercase tracking-widest italic">No flexing yet...</span>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default PublicProfile;
