
import React, { useState } from 'react';
import { Language, UserProfile } from '../types';

interface MutualUser {
  username: string;
  avatar: string;
}

interface CreateGroupModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreate: (data: { name: string; description: string; members: string[] }) => void;
  language: Language;
  mutualFollows: MutualUser[];
}

const translations = {
  [Language.EN]: { 
    title: 'Form a Squad', 
    nameLabel: 'Squad Name', 
    namePlaceholder: 'e.g. BTC Bull Runners', 
    descLabel: 'Squad Creed', 
    descPlaceholder: 'What is your squad about?', 
    addMembers: 'Add Mutual Friends',
    searchPlaceholder: 'Search friends...',
    button: 'Initiate Squad',
    noMutuals: 'Follow users back to add them to squads!'
  },
  [Language.ID]: { 
    title: 'Buat Squad', 
    nameLabel: 'Nama Squad', 
    namePlaceholder: 'misal: Pejuang BTC', 
    descLabel: 'Visi Squad', 
    descPlaceholder: 'Tentang apa squad ini?', 
    addMembers: 'Tambah Teman Mutual',
    searchPlaceholder: 'Cari teman...',
    button: 'Mulai Squad',
    noMutuals: 'Ikuti balik user untuk ajak mereka ke squad!'
  },
  [Language.ES]: { 
    title: 'Formar Escuadra', 
    nameLabel: 'Nombre de Escuadra', 
    namePlaceholder: 'ej. Corredores de BTC', 
    descLabel: 'Credo de Escuadra', 
    descPlaceholder: '¿De qué trata tu escuadra?', 
    addMembers: 'Añadir Amigos Mutuos',
    searchPlaceholder: 'Buscar amigos...',
    button: 'Iniciar Escuadra',
    noMutuals: '¡Sigue a usuarios de vuelta para agregarlos!'
  },
  [Language.CN]: { 
    title: '创建战队', 
    nameLabel: '战队名称', 
    namePlaceholder: '例如：比特币牛市冲锋队', 
    descLabel: '战队信念', 
    descPlaceholder: '你的战队是关于什么的？', 
    addMembers: '添加互粉好友',
    searchPlaceholder: '搜索好友...',
    button: '开启战队',
    noMutuals: '回粉用户以将其添加到战队！'
  }
};

const CreateGroupModal: React.FC<CreateGroupModalProps> = ({ isOpen, onClose, onCreate, language, mutualFollows }) => {
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [search, setSearch] = useState('');
  const [selectedMembers, setSelectedMembers] = useState<Set<string>>(new Set());

  if (!isOpen) return null;
  const t = translations[language];

  const filteredMutuals = mutualFollows.filter(u => u.username.toLowerCase().includes(search.toLowerCase()));

  const toggleMember = (username: string) => {
    setSelectedMembers(prev => {
      const next = new Set(prev);
      if (next.has(username)) next.delete(username);
      else next.add(username);
      return next;
    });
  };

  const handleSubmit = () => {
    if (name.trim()) {
      onCreate({ 
        name, 
        description: desc, 
        members: Array.from(selectedMembers) 
      });
      reset();
    }
  };

  const reset = () => {
    setName('');
    setDesc('');
    setSearch('');
    setSelectedMembers(new Set());
  };

  const previewAvatar = `https://api.dicebear.com/7.x/identicon/svg?seed=${name || 'temp'}`;

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md" onClick={onClose}></div>
      
      <div className="relative w-full max-sm bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl animate-in zoom-in-95 duration-200 flex flex-col max-h-[90vh]">
        <div className="p-8 pb-4 flex-1 overflow-y-auto scrollbar-hide">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-sm font-black text-white uppercase tracking-widest italic">{t.title}</h3>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>

          <div className="flex flex-col items-center mb-8">
            <div className="relative p-1 rounded-3xl bg-gradient-to-tr from-indigo-500 to-purple-500 mb-4 shadow-lg shadow-indigo-500/20">
              <img src={previewAvatar} className="w-20 h-20 rounded-2xl bg-zinc-950 p-2" alt="Group Preview" />
            </div>
            <p className="text-[10px] font-black text-zinc-500 uppercase tracking-widest">Squad Identity Generated</p>
          </div>

          <div className="space-y-6">
            <div>
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 block">{t.nameLabel}</label>
              <input 
                type="text" 
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder={t.namePlaceholder}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-4 px-5 text-white text-sm font-bold focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-2 block">{t.descLabel}</label>
              <textarea 
                value={desc}
                onChange={(e) => setDesc(e.target.value)}
                placeholder={t.descPlaceholder}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-2xl py-4 px-5 text-white text-sm font-medium focus:outline-none h-20 resize-none"
              />
            </div>

            <div className="pt-2">
              <label className="text-[10px] font-black text-zinc-500 uppercase tracking-widest mb-3 block">{t.addMembers}</label>
              <div className="relative mb-3">
                <input 
                  type="text"
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder={t.searchPlaceholder}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-2 px-4 text-[11px] text-white focus:outline-none"
                />
              </div>
              
              <div className="space-y-2 max-h-48 overflow-y-auto pr-2 scrollbar-hide">
                {filteredMutuals.length > 0 ? filteredMutuals.map((u) => (
                  <button
                    key={u.username}
                    onClick={() => toggleMember(u.username)}
                    className={`w-full flex items-center justify-between p-3 rounded-2xl border transition-all ${selectedMembers.has(u.username) ? 'bg-indigo-600/20 border-indigo-500' : 'bg-zinc-950 border-zinc-800 hover:border-zinc-700'}`}
                  >
                    <div className="flex items-center gap-3">
                      <img src={u.avatar} className="w-8 h-8 rounded-lg border border-zinc-800" alt={u.username} />
                      <span className="text-xs font-black text-zinc-300 uppercase tracking-tight">@{u.username}</span>
                    </div>
                    <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${selectedMembers.has(u.username) ? 'bg-indigo-500 border-indigo-500' : 'border-zinc-800'}`}>
                      {selectedMembers.has(u.username) && (
                        <svg className="w-3.5 h-3.5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={4}><path d="M5 13l4 4L19 7" /></svg>
                      )}
                    </div>
                  </button>
                )) : (
                  <div className="text-center py-4 opacity-50 text-[9px] uppercase font-black tracking-widest">{t.noMutuals}</div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="p-6 pt-0">
          <button 
            onClick={handleSubmit}
            disabled={!name.trim()}
            className="w-full bg-indigo-600 disabled:opacity-50 text-white py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-600/20 active:scale-95 transition-all"
          >
            {t.button} ({selectedMembers.size})
          </button>
        </div>
      </div>
    </div>
  );
};

export default CreateGroupModal;
