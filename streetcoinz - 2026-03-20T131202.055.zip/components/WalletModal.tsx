
import React from 'react';
import { Language } from '../types';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (provider: string) => void;
  language: Language;
  isConnecting?: boolean;
}

const translations = {
  [Language.EN]: { 
    title: 'STREET VAULT', 
    sub: 'Select your funding provider',
    connecting: 'CONNECTING...',
    footer: 'By connecting, you authorize StreetCoinz to view your public address. No transactions are made without approval.' 
  },
  [Language.ID]: { 
    title: 'BRANKAS JALANAN', 
    sub: 'Pilih penyedia dana Anda',
    connecting: 'MENGHUBUNGKAN...',
    footer: 'Dengan terhubung, Anda mengizinkan StreetCoinz melihat alamat publik Anda. Tidak ada transaksi tanpa persetujuan.' 
  },
  [Language.ES]: { 
    title: 'BÓVEDA DE CALLE', 
    sub: 'Selecciona tu proveedor de fondos',
    connecting: 'CONECTANDO...',
    footer: 'Al conectarte, autorizas a StreetCoinz a ver tu dirección pública. No se realizan transacciones tanpa aprobación.' 
  },
  [Language.CN]: { 
    title: '街道保险库', 
    sub: '选择您的资金提供商',
    connecting: '连接中...',
    footer: '连接即表示您授权 StreetCoinz 查看您的公开地址。未经批准不会进行任何交易。' 
  }
};

const WalletModal: React.FC<WalletModalProps> = ({ isOpen, onClose, onConnect, language, isConnecting }) => {
  if (!isOpen) return null;
  const t = translations[language];

  const wallets = [
    { 
      name: 'OKX', 
      label: 'OKX Wallet', 
      logo: 'https://registry.walletconnect.com/logo/sm/okx',
      color: 'hover:border-white/50', 
      brandColor: 'bg-white' 
    },
    { 
      name: 'MetaMask', 
      label: 'MetaMask', 
      logo: 'https://registry.walletconnect.com/logo/sm/metamask',
      color: 'hover:border-orange-500/50', 
      brandColor: 'bg-[#F6851B]/10' 
    },
    { 
      name: 'Phantom', 
      label: 'Phantom', 
      logo: 'https://registry.walletconnect.com/logo/sm/phantom',
      color: 'hover:border-purple-500/50', 
      brandColor: 'bg-[#AB9FF2]/10' 
    },
    { 
      name: 'Rainbow', 
      label: 'Rainbow', 
      logo: 'https://registry.walletconnect.com/logo/sm/rainbow',
      color: 'hover:border-blue-400/50', 
      brandColor: 'bg-[#001E59]/10' 
    },
    { 
      name: 'Coinbase', 
      label: 'Coinbase Wallet', 
      logo: 'https://registry.walletconnect.com/logo/sm/coinbase',
      color: 'hover:border-blue-600/50', 
      brandColor: 'bg-blue-600/10' 
    }
  ];

  return (
    <div className="fixed inset-0 z-[210] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md animate-in fade-in duration-300" onClick={onClose}></div>
      
      <div className="relative w-full max-w-[340px] bg-zinc-950 border border-zinc-800 rounded-[40px] overflow-hidden shadow-[0_32px_64px_-12px_rgba(0,0,0,0.8)] animate-in fade-in zoom-in-95 duration-300">
        <div className="p-8">
          <div className="flex justify-between items-center mb-1">
            <h3 className="text-lg font-black text-white uppercase tracking-tighter italic font-heading">{t.title}</h3>
            <button onClick={onClose} className="text-zinc-600 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <p className="text-[9px] text-zinc-500 font-black uppercase tracking-widest mb-8 leading-none">{t.sub}</p>
          
          <div className="grid grid-cols-1 gap-3">
            {wallets.map((wallet) => (
              <button
                key={wallet.name}
                onClick={() => onConnect(wallet.name)}
                disabled={isConnecting}
                className={`flex items-center justify-between p-3.5 bg-zinc-900/40 border border-zinc-800/60 rounded-[24px] transition-all ${wallet.color} group active:scale-95 disabled:opacity-50`}
              >
                <div className="flex items-center gap-4">
                  <div className={`w-11 h-11 rounded-xl flex items-center justify-center overflow-hidden shadow-lg p-1.5 ${wallet.brandColor}`}>
                    <img 
                      src={wallet.logo} 
                      alt={wallet.name} 
                      className="w-full h-full object-contain"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = `https://api.dicebear.com/7.x/identicon/svg?seed=${wallet.name}`;
                      }}
                    />
                  </div>
                  <span className="font-black text-[11px] uppercase tracking-wider text-zinc-400 group-hover:text-white transition-colors">
                    {wallet.label}
                  </span>
                </div>
                <div className="flex items-center pr-2">
                   <div className="w-1.5 h-1.5 rounded-full bg-zinc-800 group-hover:bg-purple-500 group-hover:shadow-[0_0_10px_rgba(168,85,247,0.8)] transition-all"></div>
                </div>
              </button>
            ))}
          </div>
          
          {isConnecting && (
            <div className="mt-6 flex items-center justify-center gap-3 py-2 animate-pulse bg-purple-500/5 rounded-2xl border border-purple-500/10">
               <div className="w-4 h-4 border-2 border-purple-500/20 border-t-purple-500 rounded-full animate-spin"></div>
               <span className="text-[10px] font-black text-purple-500 tracking-widest">{t.connecting}</span>
            </div>
          )}

          <div className="mt-8 p-5 bg-zinc-900/50 rounded-3xl border border-zinc-800/50">
            <p className="text-[8px] text-zinc-600 leading-relaxed font-bold uppercase tracking-widest text-center">
              {t.footer}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletModal;
