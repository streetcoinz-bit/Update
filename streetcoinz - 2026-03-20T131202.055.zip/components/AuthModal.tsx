
import React, { useState } from 'react';
import { Language } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  onClose: () => void;
  onEmailLogin: (email: string, username: string, password?: string) => void;
  onOpenWallet: () => void;
  language: Language;
  isLoading?: boolean;
  externalError?: string | null;
}

const translations = {
  [Language.EN]: { 
    join: 'JOIN THE STREET', 
    sub: 'Secure Identity Protocol', 
    emailLabel: 'STREET EMAIL',
    userLabel: 'STREET NAME',
    passLabel: 'STREET PASSWORD',
    emailPlaceholder: 'email@street.com',
    userPlaceholder: 'your_trader_name',
    passPlaceholder: '••••••••',
    emailBtn: 'ENTER SECURELY',
    walletBtn: 'CONNECT WEB3 WALLET',
    or: 'OR',
    later: 'Maybe later', 
    magic: 'STREET ENCRYPTION ACTIVE',
    terms: 'Identity protected by <span class="text-purple-500">Street Protocol Nodes</span>',
    configNote: 'Connecting to network...'
  },
  [Language.ID]: { 
    join: 'GABUNG JALANAN', 
    sub: 'Protokol Identitas Aman', 
    emailLabel: 'EMAIL JALANAN',
    userLabel: 'NAMA JALANAN',
    passLabel: 'PASSWORD JALANAN',
    emailPlaceholder: 'email@jalan.com',
    userPlaceholder: 'nama_trader_mu',
    passPlaceholder: '••••••••',
    emailBtn: 'MASUK AMAN',
    walletBtn: 'HUBUNGKAN DOMPET WEB3',
    or: 'ATAU',
    later: 'Nanti saja', 
    magic: 'ENKRIPSI JALANAN AKTIF',
    terms: 'Identitas dilindungi oleh <span class="text-purple-500">Node Protokol Jalanan</span>',
    configNote: 'Menghubungkan ke jaringan...'
  }
};

const AuthModal: React.FC<AuthModalProps> = ({ isOpen, onClose, onEmailLogin, onOpenWallet, language, isLoading, externalError }) => {
  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  
  if (!isOpen) return null;
  const t = translations[language] || translations[Language.EN];

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.includes('@') && username.length >= 3) {
      onEmailLogin(email, username, password);
    }
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4">
      {/* Background Overlay */}
      <div className="fixed inset-0 bg-black/90 backdrop-blur-md transition-opacity" onClick={onClose}></div>
      
      {/* Shrunk and Centered Modal Content */}
      <div className="relative w-full max-w-[340px] bg-zinc-950 border border-zinc-800 rounded-[28px] overflow-hidden shadow-[0_32px_80px_-12px_rgba(0,0,0,1)] animate-in fade-in zoom-in-95 duration-300">
        <div className="p-6 text-center">
          {/* Smaller Icon Container */}
          <div className="w-12 h-12 bg-purple-600/20 rounded-[18px] flex items-center justify-center mx-auto mb-4 border border-purple-500/20 shadow-[0_0_20px_rgba(168,85,247,0.3)] animate-up">
            <svg width="24" height="24" viewBox="0 0 46 70" fill="none">
              <path d="M41.5 0L0 38.5H18.5L4.5 70L46 31.5H27.5L41.5 0Z" fill="#A855F7"/>
            </svg>
          </div>
          
          <h2 className="text-lg font-black text-white mb-1 italic uppercase tracking-tighter font-heading">{t.join}</h2>
          <p className="text-zinc-500 text-[7px] mb-5 uppercase tracking-[0.2em] font-black">{t.sub}</p>
          
          {externalError && (
            <div className="mb-4 p-2 bg-rose-500/10 border border-rose-500/20 rounded-xl text-[9px] text-rose-500 font-bold uppercase">
              {externalError}
            </div>
          )}

          <form onSubmit={handleEmailSubmit} className="mb-4 space-y-3">
            <div className="text-left">
              <label className="text-[7px] font-black text-zinc-600 uppercase tracking-widest mb-1 ml-1 block">{t.userLabel}</label>
              <input 
                type="text" 
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder={t.userPlaceholder}
                disabled={isLoading}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2.5 px-4 text-white text-[11px] font-bold focus:outline-none placeholder:text-zinc-700 disabled:opacity-50"
                required
              />
            </div>

            <div className="text-left">
              <label className="text-[7px] font-black text-zinc-600 uppercase tracking-widest mb-1 ml-1 block">{t.emailLabel}</label>
              <input 
                type="email" 
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder={t.emailPlaceholder}
                disabled={isLoading}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2.5 px-4 text-white text-[11px] font-bold focus:outline-none placeholder:text-zinc-700 disabled:opacity-50"
                required
              />
            </div>

            <div className="text-left">
              <label className="text-[7px] font-black text-zinc-600 uppercase tracking-widest mb-1 ml-1 block">{t.passLabel}</label>
              <input 
                type="password" 
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder={t.passPlaceholder}
                disabled={isLoading}
                className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-2.5 px-4 text-white text-[11px] font-bold focus:outline-none placeholder:text-zinc-700 disabled:opacity-50"
              />
            </div>

            <button 
              type="submit"
              disabled={isLoading || !email.includes('@') || username.length < 3}
              className="w-full bg-white text-zinc-900 py-3 rounded-xl font-black text-[10px] uppercase tracking-widest shadow-xl shadow-white/5 active:scale-95 transition-all flex items-center justify-center gap-2 mt-2"
            >
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-3.5 h-3.5 border-2 border-zinc-900/20 border-t-zinc-900 rounded-full animate-spin"></div>
                  <span className="animate-pulse">CONNECTING...</span>
                </div>
              ) : t.emailBtn}
            </button>
          </form>

          <div className="flex items-center gap-3 mb-4">
             <div className="h-px flex-1 bg-zinc-900"></div>
             <span className="text-[6px] font-black text-zinc-700">{t.or}</span>
             <div className="h-px flex-1 bg-zinc-900"></div>
          </div>

          <button 
            onClick={onOpenWallet}
            disabled={isLoading}
            className="w-full bg-zinc-900 border border-zinc-800 text-white py-3 rounded-xl font-black text-[9px] uppercase tracking-widest hover:bg-zinc-800 active:scale-95 transition-all flex items-center justify-center gap-2 mb-4 disabled:opacity-50"
          >
            {t.walletBtn}
          </button>

          <button 
            onClick={onClose}
            disabled={isLoading}
            className="w-full text-zinc-600 py-1 text-[7px] font-black uppercase tracking-[0.3em] hover:text-zinc-400 transition-colors disabled:opacity-50"
          >
            {t.later}
          </button>
        </div>
        
        <div className="bg-zinc-950/80 p-4 border-t border-zinc-900 flex flex-col items-center gap-1.5">
          <div className="flex items-center gap-2">
            <span className="text-[6px] font-black text-emerald-500 uppercase tracking-widest">{t.magic}</span>
          </div>
          <p className="text-[6px] text-zinc-700 font-bold uppercase tracking-widest text-center leading-relaxed" dangerouslySetInnerHTML={{ __html: t.terms }}></p>
        </div>
      </div>
    </div>
  );
};

export default AuthModal;
