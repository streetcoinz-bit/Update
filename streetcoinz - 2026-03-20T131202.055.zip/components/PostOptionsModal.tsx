
import React from 'react';
import { Language } from '../types';

interface PostOptionsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectVibez: () => void;
  onSelectStatus: () => void;
  language: Language;
}

const translations = {
  [Language.EN]: { title: 'Create Play', vibez: 'Vibez', vibezSub: 'Post a flex video', status: 'Status', statusSub: 'Share your alpha' },
  [Language.ID]: { title: 'Buat Konten', vibez: 'Vibez', vibezSub: 'Unggah video pamer', status: 'Status', statusSub: 'Bagikan info alpha' },
  [Language.ES]: { title: 'Crear Contenido', vibez: 'Vibez', vibezSub: 'Publicar video de flex', status: 'Estado', statusSub: 'Comparte tu alpha' },
  [Language.CN]: { title: '创建内容', vibez: 'Vibez', vibezSub: '发布秀操作视频', status: '状态', statusSub: '分享你的阿尔法' }
};

const PostOptionsModal: React.FC<PostOptionsModalProps> = ({ isOpen, onClose, onSelectVibez, onSelectStatus, language }) => {
  if (!isOpen) return null;
  const t = translations[language];

  return (
    <div className="fixed inset-0 z-[105] flex items-end justify-center px-4 pb-24 sm:items-center sm:pb-0">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose}></div>
      
      <div className="relative w-full max-w-[320px] bg-zinc-900 border border-zinc-800 rounded-[32px] overflow-hidden shadow-2xl animate-in slide-in-from-bottom-10 duration-300">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-sm font-black text-white uppercase tracking-widest italic">{t.title}</h3>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {/* Vibez Option */}
            <button 
              onClick={() => { onSelectVibez(); onClose(); }}
              className="group relative flex items-center gap-4 p-4 bg-zinc-950 border border-zinc-800 rounded-2xl hover:border-purple-500/50 hover:bg-purple-500/5 transition-all active:scale-95"
            >
              <div className="w-12 h-12 rounded-xl bg-purple-600/20 flex items-center justify-center text-purple-500 group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
              </div>
              <div className="text-left">
                <div className="text-xs font-black text-white uppercase tracking-wider">{t.vibez}</div>
                <div className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">{t.vibezSub}</div>
              </div>
              <div className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
                 <svg className="w-4 h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
                 </svg>
              </div>
            </button>

            {/* Status Option */}
            <button 
              onClick={() => { onSelectStatus(); onClose(); }}
              className="group relative flex items-center gap-4 p-4 bg-zinc-950 border border-zinc-800 rounded-2xl hover:border-purple-500/50 hover:bg-purple-500/5 transition-all active:scale-95"
            >
              <div className="w-12 h-12 rounded-xl bg-purple-600/20 flex items-center justify-center text-purple-400 group-hover:scale-110 transition-transform shadow-[0_0_15px_rgba(168,85,247,0.2)]">
                <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
                </svg>
              </div>
              <div className="text-left">
                <div className="text-xs font-black text-white uppercase tracking-wider">{t.status}</div>
                <div className="text-[9px] text-zinc-500 font-bold uppercase tracking-widest">{t.statusSub}</div>
              </div>
              <div className="ml-auto opacity-0 group-hover:opacity-100 transition-opacity">
                 <svg className="w-4 h-4 text-purple-500" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M9 5l7 7-7 7" />
                 </svg>
              </div>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PostOptionsModal;
