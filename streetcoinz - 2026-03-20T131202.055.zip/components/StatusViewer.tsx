
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { UserStatus, Language } from '../types';
import DeleteModal from './DeleteModal';

interface StatusViewerProps {
  statuses: UserStatus[];
  initialIndex: number;
  onClose: () => void;
  onDelete: (id: string) => void;
  onShare: (status: UserStatus) => void;
  onReplyToDM: (username: string, text: string) => void;
  onViewProfile: (username: string) => void;
  onMarkAsRead?: (id: string) => void;
  currentUserUsername?: string;
  activeThemeClass: string;
  language: Language;
}

const translations = {
  [Language.EN]: { 
    reply: 'Type street alpha...', 
    post: 'Send', 
    swipeHint: 'Swipe up to reply', 
    swipeUpDetails: 'Swipe up for viewers',
    sent: 'Sent to DMs!',
    confirmTitle: 'Scrub this Alpha?',
    confirmSub: 'This info will be wiped from the street forever.',
    seenBy: 'Seen by',
    viewers: 'traders watched',
    viewerTitle: 'Alpha Intel',
    viewerSub: 'Traders who analyzed your status'
  },
  [Language.ID]: { 
    reply: 'Ketik info jalanan...', 
    post: 'Kirim', 
    swipeHint: 'Geser ke atas untuk balas', 
    swipeUpDetails: 'Geser ke atas untuk penonton',
    sent: 'Terkirim ke DM!',
    confirmTitle: 'Hapus Alpha ini?',
    confirmSub: 'Info ini akan dihapus dari jalanan selamanya.',
    seenBy: 'Dilihat oleh',
    viewers: 'trader menonton',
    viewerTitle: 'Intel Alpha',
    viewerSub: 'Trader yang menganalisa status Anda'
  },
  [Language.ES]: { 
    reply: 'Escribe algo...', 
    post: 'Enviar', 
    swipeHint: 'Desliza para responder', 
    swipeUpDetails: 'Desliza para ver quién vio',
    sent: '¡Enviado!',
    confirmTitle: '¿Eliminar Alpha?',
    confirmSub: 'Esta información se borrará para siempre.',
    seenBy: 'Visto por',
    viewers: 'traders vieron',
    viewerTitle: 'Intel Alpha',
    viewerSub: 'Traders que analizaron tu estado'
  },
  [Language.CN]: { 
    reply: '输入街道动态...', 
    post: '发送', 
    swipeHint: '向上滑动回复', 
    swipeUpDetails: '向上滑动查看访客',
    sent: '已发送!',
    confirmTitle: '清除此阿尔法？',
    confirmSub: '此信息将永久从街道上删除。',
    seenBy: '查看者',
    viewers: '名交易者已看',
    viewerTitle: '阿尔法情报',
    viewerSub: '分析过您动态的交易者'
  }
};

const MOCK_VIEWERS = [
  { username: 'crypto_whale_99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto_whale_99', time: '2m ago' },
  { username: 'scalp_queen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=scalp_queen', time: '12m ago' },
  { username: 'alpha_king', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alpha_king', time: '45m ago' },
  { username: 'dex_demon', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dex_demon', time: '1h ago' },
  { username: 'moon_walker', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=moon_walker', time: '2h ago' },
  { username: 'bull_runner', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bull_runner', time: '3h ago' },
  { username: 'bear_trap', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=bear_trap', time: '5h ago' },
  { username: 'pump_master', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=pump_master', time: '6h ago' },
];

const StatusViewer: React.FC<StatusViewerProps> = ({ 
  statuses, 
  initialIndex, 
  onClose, 
  onDelete, 
  onShare,
  onReplyToDM,
  onViewProfile,
  onMarkAsRead,
  currentUserUsername, 
  activeThemeClass,
  language
}) => {
  // 1. Group statuses by user
  const groupedStatuses = useMemo(() => {
    const groups: { username: string; items: UserStatus[] }[] = [];
    statuses.forEach(s => {
      const group = groups.find(g => g.username === s.username);
      if (group) {
        group.items.push(s);
      } else {
        groups.push({ username: s.username, items: [s] });
      }
    });
    return groups;
  }, [statuses]);

  // 2. Map global index to grouped indices
  const initialIndices = useMemo(() => {
    let count = 0;
    for (let uIdx = 0; uIdx < groupedStatuses.length; uIdx++) {
      for (let sIdx = 0; sIdx < groupedStatuses[uIdx].items.length; sIdx++) {
        if (count === initialIndex) return { uIdx, sIdx };
        count++;
      }
    }
    return { uIdx: 0, sIdx: 0 };
  }, [groupedStatuses, initialIndex]);

  const [userIndex, setUserIndex] = useState(initialIndices.uIdx);
  const [itemIndex, setItemIndex] = useState(initialIndices.sIdx);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const [replyText, setReplyText] = useState('');
  const [showSentFeedback, setShowSentFeedback] = useState(false);
  const [isReplyOpen, setIsReplyOpen] = useState(false);
  const [isViewersOpen, setIsViewersOpen] = useState(false);
  const [isDeleteConfirmOpen, setIsDeleteConfirmOpen] = useState(false);
  const [dragY, setDragY] = useState(0);
  const [direction, setDirection] = useState<'next' | 'prev' | null>(null);
  
  const touchStartPos = useRef<{ x: number, y: number } | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);
  
  const currentUserGroup = groupedStatuses[userIndex];
  const currentStatus = currentUserGroup?.items[itemIndex];
  const t = translations[language];

  const isMyStatus = currentUserUsername && currentStatus?.username === currentUserUsername;

  useEffect(() => {
    if (currentStatus && onMarkAsRead) {
      onMarkAsRead(currentStatus.id);
    }
  }, [currentStatus, onMarkAsRead]);

  useEffect(() => {
    if (isPaused || isReplyOpen || isViewersOpen || isDeleteConfirmOpen || !currentStatus) return;
    
    const timer = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          handleNextItem();
          return 0;
        }
        return prev + 1;
      });
    }, 50);

    return () => clearInterval(timer);
  }, [userIndex, itemIndex, isPaused, isReplyOpen, isViewersOpen, isDeleteConfirmOpen]);

  const handleNextUser = () => {
    if (userIndex >= groupedStatuses.length - 1) {
      onClose();
      return;
    }
    setDirection('next');
    setUserIndex(prev => prev + 1);
    setItemIndex(0);
    setProgress(0);
  };

  const handlePrevUser = () => {
    if (userIndex <= 0) return;
    setDirection('prev');
    setUserIndex(prev => prev - 1);
    setItemIndex(0);
    setProgress(0);
  };

  const handleNextItem = () => {
    if (itemIndex < currentUserGroup.items.length - 1) {
      setItemIndex(itemIndex + 1);
      setProgress(0);
    } else {
      handleNextUser();
    }
  };

  const handlePrevItem = () => {
    if (itemIndex > 0) {
      setItemIndex(itemIndex - 1);
      setProgress(0);
    } else {
      handlePrevUser();
    }
  };

  const renderTextWithMentions = (text: string) => {
    if (!text) return null;
    const parts = text.split(/(@\w+)/g);
    return parts.map((part, i) => {
      if (part.startsWith('@')) {
        const username = part.substring(1);
        return (
          <span 
            key={i} 
            onClick={(e) => { e.stopPropagation(); onViewProfile(username); }}
            className="text-purple-300 font-black cursor-pointer underline decoration-purple-500/50 hover:decoration-purple-500 transition-all"
          >
            {part}
          </span>
        );
      }
      return part;
    });
  };

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartPos.current = { x: e.touches[0].clientX, y: e.touches[0].clientY };
    setIsPaused(true);
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!touchStartPos.current) return;
    const currentX = e.touches[0].clientX;
    const currentY = e.touches[0].clientY;
    const deltaX = currentX - touchStartPos.current.x;
    const deltaY = currentY - touchStartPos.current.y;
    
    if (!isReplyOpen && !isViewersOpen && Math.abs(deltaY) > Math.abs(deltaX)) {
      setDragY(deltaY);
    }
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    if (!touchStartPos.current) return;
    const endX = e.changedTouches[0].clientX;
    const endY = e.changedTouches[0].clientY;
    const deltaX = endX - touchStartPos.current.x;
    const deltaY = endY - touchStartPos.current.y;

    if (!isReplyOpen && !isViewersOpen && deltaY < -60 && Math.abs(deltaY) > Math.abs(deltaX)) {
      if (isMyStatus) {
        setIsViewersOpen(true);
        setIsPaused(true);
      } else {
        openReply();
      }
    } else if (!isReplyOpen && !isViewersOpen && deltaY > 100 && Math.abs(deltaY) > Math.abs(deltaX)) {
      onClose();
    } else if (isReplyOpen && deltaY > 50) {
      closeReply();
    } else if (isViewersOpen && deltaY > 50) {
      setIsViewersOpen(false);
      setIsPaused(false);
    } else {
      if (Math.abs(deltaX) > 60 && Math.abs(deltaX) > Math.abs(deltaY)) {
        if (deltaX < 0) handleNextUser(); 
        else handlePrevUser(); 
      } else {
        if (!isReplyOpen && !isViewersOpen) setIsPaused(false);
      }
    }
    
    setDragY(0);
    touchStartPos.current = null;
  };

  const openReply = () => {
    setIsReplyOpen(true);
    setIsPaused(true);
    setTimeout(() => inputRef.current?.focus(), 100);
  };

  const closeReply = () => {
    setIsReplyOpen(false);
    setIsPaused(false);
    setReplyText('');
    inputRef.current?.blur();
  };

  const handleSendReply = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (replyText.trim()) {
      onReplyToDM(currentStatus.username, `Replied to Alpha: ${replyText}`);
      setShowSentFeedback(true);
      setTimeout(() => setShowSentFeedback(false), 2000);
      closeReply();
    }
  };

  if (!currentStatus) return null;

  const getAnimationClass = () => {
    if (!direction) return 'animate-in fade-in duration-300';
    return direction === 'next' ? 'flip-next-anim' : 'flip-prev-anim';
  };

  return (
    <div 
      className="fixed inset-0 z-[150] flex flex-col bg-black select-none overflow-hidden transition-transform duration-300 ease-out"
      style={{ 
        perspective: '2000px',
        transform: dragY > 0 && !isViewersOpen ? `translateY(${dragY}px)` : 'none' 
      }}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      <style>{`
        @keyframes flipNextIn {
          0% { transform: rotateY(90deg) translateZ(600px); opacity: 0; }
          100% { transform: rotateY(0) translateZ(0); opacity: 1; }
        }
        @keyframes flipPrevIn {
          0% { transform: rotateY(-90deg) translateZ(600px); opacity: 0; }
          100% { transform: rotateY(0) translateZ(0); opacity: 1; }
        }
        .flip-next-anim {
          animation: flipNextIn 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.2) forwards;
          transform-origin: center center;
          backface-visibility: hidden;
        }
        .flip-prev-anim {
          animation: flipPrevIn 0.6s cubic-bezier(0.175, 0.885, 0.32, 1.2) forwards;
          transform-origin: center center;
          backface-visibility: hidden;
        }
        .status-container {
           will-change: transform, opacity;
        }
      `}</style>

      <DeleteModal 
        isOpen={isDeleteConfirmOpen}
        onClose={() => { setIsDeleteConfirmOpen(false); setIsPaused(false); }}
        onConfirm={() => { onDelete(currentStatus.id); setIsDeleteConfirmOpen(false); }}
        language={language}
        customTitle={t.confirmTitle}
        customSub={t.confirmSub}
      />

      <div 
        key={userIndex}
        className={`status-container absolute inset-0 flex flex-col ${currentStatus.imageUrl ? 'bg-black' : currentStatus.bgColor} ${getAnimationClass()}`}
      >
        {currentStatus.imageUrl && (
          <img src={currentStatus.imageUrl} className="absolute inset-0 w-full h-full object-cover opacity-70" alt="BG" />
        )}
        
        <div className="flex gap-1.5 p-4 z-20">
          {currentUserGroup.items.map((_, idx) => (
            <div key={idx} className="h-1 flex-1 bg-white/20 rounded-full overflow-hidden">
              <div 
                className="h-full bg-white transition-all duration-100 ease-linear"
                style={{ width: idx < itemIndex ? '100%' : idx === itemIndex ? `${progress}%` : '0%' }}
              ></div>
            </div>
          ))}
        </div>

        <div className="flex items-center justify-between px-4 py-2 z-20">
          <div className="flex items-center gap-3">
            <img 
              src={currentStatus.avatar} 
              className="w-10 h-10 rounded-2xl border-2 border-white/20 object-cover cursor-pointer"
              onClick={() => onViewProfile(currentStatus.username)}
            />
            <div>
              <h3 className="text-white text-sm font-black uppercase italic tracking-tight cursor-pointer" onClick={() => onViewProfile(currentStatus.username)}>
                @{currentStatus.username}
              </h3>
              <span className="text-white/50 text-[10px] font-bold">
                {new Date(currentStatus.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-1.5">
            <button onClick={(e) => { e.stopPropagation(); onShare(currentStatus); }} className="p-2 bg-white/10 text-white rounded-xl border border-white/10 active:scale-90 transition-all">
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" />
              </svg>
            </button>
            {isMyStatus && (
              <button onClick={(e) => { e.stopPropagation(); setIsPaused(true); setIsDeleteConfirmOpen(true); }} className="p-2 bg-rose-500/20 text-rose-500 rounded-xl border border-rose-500/30 active:scale-90 transition-all">
                <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
              </button>
            )}
            <button onClick={onClose} className="text-white/80 hover:text-white p-2">
              <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}><path strokeLinecap="round" strokeLinejoin="round" d="M6 18L18 6M6 6l12 12" /></svg>
            </button>
          </div>
        </div>

        <div className="flex-1 flex flex-col items-center justify-center p-12 relative overflow-hidden">
          {!isReplyOpen && !isDeleteConfirmOpen && !isViewersOpen && (
            <div className="absolute inset-0 flex z-10">
              <div className="w-1/3 h-full cursor-pointer" onClick={handlePrevItem}></div>
              <div className="w-2/3 h-full cursor-pointer" onClick={handleNextItem}></div>
            </div>
          )}
          
          <p className={`text-white text-3xl font-black italic uppercase tracking-tighter text-center leading-tight drop-shadow-2xl z-20 transition-all duration-500 ${isReplyOpen || isViewersOpen ? 'scale-75 opacity-20 blur-sm' : 'animate-in zoom-in-95'}`}>
            "{renderTextWithMentions(currentStatus.text)}"
          </p>

          {showSentFeedback && (
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-[100] bg-purple-600 text-white px-6 py-3 rounded-full font-black uppercase italic tracking-widest text-sm animate-in zoom-in fade-in duration-300 shadow-2xl flex items-center gap-2">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" /></svg>
              {t.sent}
            </div>
          )}
        </div>

        {isMyStatus ? (
          <div className="relative z-30 pb-12 pt-4 px-6 flex flex-col">
            <div 
              onClick={() => { setIsViewersOpen(true); setIsPaused(true); }}
              className="bg-white/10 backdrop-blur-xl border border-white/10 rounded-[24px] p-4 cursor-pointer hover:bg-white/20 transition-colors animate-in slide-in-from-bottom-4 duration-500"
            >
               <div className="flex items-center justify-between mb-4">
                  <div className="flex flex-col">
                    <span className="text-[10px] font-black text-purple-400 uppercase tracking-widest">{t.seenBy}</span>
                    <span className="text-[8px] font-bold text-white/50 uppercase tracking-tight">{MOCK_VIEWERS.length} {t.viewers}</span>
                  </div>
                  <div className="flex -space-x-2">
                    {MOCK_VIEWERS.slice(0, 3).map((v, i) => (
                      <img key={i} src={v.avatar} className="w-6 h-6 rounded-full border border-zinc-950 object-cover" />
                    ))}
                    {MOCK_VIEWERS.length > 3 && (
                      <div className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-950 flex items-center justify-center text-[8px] font-black text-white">
                        +{MOCK_VIEWERS.length - 3}
                      </div>
                    )}
                  </div>
               </div>
               
               <div className="flex flex-col items-center gap-1 opacity-60">
                  <svg className="w-4 h-4 text-white animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" /></svg>
                  <span className="text-[7px] font-black text-white uppercase tracking-[0.3em]">{t.swipeUpDetails}</span>
               </div>
            </div>

            {/* FULL VIEWERS DRAWER */}
            <div 
              className={`absolute bottom-0 left-0 w-full bg-zinc-950/95 border-t border-white/10 backdrop-blur-2xl transition-all duration-500 ease-out flex flex-col z-50 ${isViewersOpen ? 'translate-y-0 h-[60vh]' : 'translate-y-full h-0'}`}
              style={{ transform: dragY < 0 && isViewersOpen ? `translateY(${dragY}px)` : '' }}
            >
               <div className="w-12 h-1 bg-white/20 rounded-full mx-auto mt-4 mb-2"></div>
               <div className="p-6 overflow-y-auto scrollbar-hide flex-1">
                  <div className="flex justify-between items-end mb-8">
                    <div>
                      <h2 className="text-xl font-black italic uppercase tracking-tighter text-white">{t.viewerTitle}</h2>
                      <p className="text-[9px] font-bold text-zinc-500 uppercase tracking-widest">{t.viewerSub}</p>
                    </div>
                    <button onClick={() => { setIsViewersOpen(false); setIsPaused(false); }} className="p-2 bg-white/5 rounded-xl border border-white/10 text-white/50">
                      <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2.5}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
                    </button>
                  </div>

                  <div className="space-y-4">
                    {MOCK_VIEWERS.map((v, i) => (
                      <div 
                        key={i} 
                        className="flex items-center justify-between group animate-in slide-in-from-bottom duration-300"
                        style={{ animationDelay: `${i * 50}ms` }}
                        onClick={() => { onViewProfile(v.username); setIsViewersOpen(false); }}
                      >
                        <div className="flex items-center gap-3">
                          <img src={v.avatar} className="w-12 h-12 rounded-2xl border-2 border-white/10 p-0.5 object-cover" alt={v.username} />
                          <div>
                            <span className="text-xs font-black uppercase text-white group-hover:text-purple-400 transition-colors">@{v.username}</span>
                            <span className="text-[8px] font-bold text-zinc-600 block uppercase tracking-widest">Active Trader</span>
                          </div>
                        </div>
                        <div className="text-right">
                          <span className="text-[9px] font-black text-white/30 uppercase">{v.time}</span>
                          <div className="flex items-center gap-1 justify-end mt-1">
                            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>
                            <span className="text-[7px] font-black text-emerald-500 uppercase tracking-tighter">Seen</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
               </div>
               <div className="p-4 bg-zinc-900/50 border-t border-white/5 text-center">
                  <span className="text-[7px] font-black text-zinc-600 uppercase tracking-[0.4em]">Synced with Street Protocol Hub</span>
               </div>
            </div>
          </div>
        ) : (
          <div className="relative z-30 pb-12 pt-4 px-4 flex flex-col items-center">
            <div 
              onClick={openReply}
              className={`w-full flex flex-col items-center gap-2 py-4 cursor-pointer transition-all duration-300 ${isReplyOpen ? 'opacity-0 translate-y-20' : 'opacity-100'}`}
              style={{ transform: `translateY(${dragY < 0 ? dragY : 0}px)` }}
            >
              <div className="bg-white/20 backdrop-blur-md rounded-full px-6 py-2 border border-white/10 shadow-lg flex flex-col items-center">
                 <svg className="w-4 h-4 text-purple-400 animate-bounce" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M5 15l7-7 7 7" /></svg>
                 <span className="text-[10px] font-black text-white uppercase tracking-[0.2em]">{t.swipeHint}</span>
              </div>
            </div>

            <div className={`absolute bottom-0 left-0 w-full bg-black/20 border-t border-white/10 backdrop-blur-3xl transition-all duration-500 ease-out flex flex-col ${isReplyOpen ? 'translate-y-0 h-48 opacity-100' : 'translate-y-full h-0 opacity-0'}`}>
              <div className="p-4 flex flex-col h-full">
                <div className="flex justify-between items-center mb-4">
                  <span className="text-[8px] font-black text-purple-400 uppercase tracking-[0.3em] drop-shadow-md">Direct Message Alpha</span>
                  <button onClick={closeReply} className="text-white/40 hover:text-white transition-colors">
                    <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={3}><path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" /></svg>
                  </button>
                </div>
                
                <form onSubmit={handleSendReply} className="flex gap-2">
                  <input 
                    ref={inputRef}
                    type="text"
                    value={replyText}
                    onChange={(e) => setReplyText(e.target.value)}
                    placeholder={t.reply}
                    className="flex-1 bg-white/10 border border-white/20 backdrop-blur-md rounded-2xl py-4 px-6 text-white text-sm font-bold focus:outline-none focus:border-purple-500 focus:bg-white/20 transition-all placeholder:text-white/40"
                  />
                  <button 
                    type="submit"
                    disabled={!replyText.trim()}
                    className="bg-purple-600/80 backdrop-blur-xl text-white px-8 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95 disabled:opacity-30 shadow-xl"
                  >
                    {t.post}
                  </button>
                </form>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default StatusViewer;
