import { Magic } from '@magic-sdk/admin';
import { createClient } from '@supabase/supabase-js';
import { getPlatformWalletForUser } from '../../../src/lib/wallet';

export async function onRequestPost(context: any) {
  const { request, env } = context;
  
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return new Response(JSON.stringify({ error: 'Missing or invalid authorization header' }), { 
        status: 401,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const didToken = authHeader.substring(7);
    
    const magicSecretKey = env.MAGIC_SECRET_KEY || 'sk_live_...';
    const magic = new Magic(magicSecretKey);

    const supabaseUrl = env.VITE_SUPABASE_URL || 'https://nyoxxkxueuorhvcnzgxu.supabase.co';
    const supabaseServiceRoleKey = env.SUPABASE_SERVICE_ROLE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...';
    const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

    magic.token.validate(didToken);
    const issuer = magic.token.getIssuer(didToken);
    const userMetadata = await magic.users.getMetadataByIssuer(issuer);
    
    const email = userMetadata.email;
    const walletAddress = userMetadata.publicAddress;

    if (!email || !walletAddress) {
      return new Response(JSON.stringify({ error: 'Failed to retrieve user email or wallet address' }), { 
        status: 400,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    const platformWallet = getPlatformWalletForUser(email);
    
    const upsertPayload: any = { 
      email, 
      wallet_address: walletAddress, 
      updated_at: new Date().toISOString() 
    };

    if (platformWallet) {
      upsertPayload.platform_wallet_address = platformWallet.address;
    }

    const { data, error } = await supabase
      .from('users')
      .upsert(
        upsertPayload,
        { onConflict: 'email' }
      );

    if (error) {
      console.error('Error saving user to Supabase:', error);
      return new Response(JSON.stringify({ error: 'Failed to save user data' }), { 
        status: 500,
        headers: { 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ 
      success: true, 
      user: {
        email,
        walletAddress,
        platformWalletAddress: platformWallet?.address,
        platformPrivateKey: platformWallet?.privateKey,
        platformSeedPhrase: platformWallet?.seedPhrase
      }
    }), { 
      status: 200,
      headers: { 'Content-Type': 'application/json' } 
    });
  } catch (error) {
    console.error('Magic auth error:', error);
    return new Response(JSON.stringify({ error: 'Authentication failed' }), { 
      status: 500,
      headers: { 'Content-Type': 'application/json' }
    });
  }
}
