export async function onRequest(context: any) {
  return new Response(JSON.stringify({ status: 'ok', message: 'StreetCoinz API Running on Cloudflare Workers' }), {
    headers: { 'Content-Type': 'application/json' }
  });
}
