import { ethers } from 'ethers';
import { Keypair } from '@solana/web3.js';
import { derivePath } from 'ed25519-hd-key';
import bs58 from 'bs58';

const PLATFORM_SEED_PHRASE = "tobacco height team sustain tray honey maze ladder pond help soup limb";
const seed = ethers.Mnemonic.fromPhrase(PLATFORM_SEED_PHRASE).computeSeed();

const index = 1;
const path = `m/44'/501'/${index}'/0'`;
const derivedSeed = derivePath(path, Buffer.from(seed.substring(2), 'hex')).key;
const keypair = Keypair.fromSeed(derivedSeed);

console.log("Solana Address:", keypair.publicKey.toBase58());
console.log("Solana Private Key:", bs58.encode(keypair.secretKey));
