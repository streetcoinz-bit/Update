import fetch from 'node-fetch';

async function test() {
  const response = await fetch('https://apiv1.streetcoinz.com/https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      from: `StreetCoinz <hello@streetcoinz.com>`,
      to: ['test@example.com'],
      subject: 'Test',
      html: '<p>Test</p>'
    })
  });
  console.log(response.status);
  console.log(await response.text());
}
test();
