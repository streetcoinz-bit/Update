import fetch from 'node-fetch';

async function test() {
  const response = await fetch('https://apiv1.streetcoinz.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({
      model: "google/gemini-2.5-flash", 
      messages: [
        { role: "user", content: "test" }
      ],
      temperature: 0.7,
      max_tokens: 50
    })
  });
  console.log(response.status);
  console.log(await response.text());
}
test();
