
import React, { useState, useEffect, useMemo } from 'react';
import { Magic } from 'magic-sdk';
import { AppTab, UserWallet, UserProfile, Language, AppTheme, UserStatus, ChatGroup, Comment, Notification, NotificationType, VideoPost, Transaction, Message } from './types';
import ChatList from './components/ChatList';
import PredictMarket from './components/PredictMarket';
import WalletDashboard from './components/WalletDashboard';
import BottomNav from './components/BottomNav';
import AuthModal from './components/AuthModal';
import WalletModal from './components/WalletModal';
import ProfileDetails from './components/ProfileDetails';
import PublicProfile from './components/PublicProfile';
import SquadProfile from './components/SquadProfile';
import CreateStatusModal from './components/CreateStatusModal';
import FollowListModal from './components/FollowListModal';
import CreateGroupModal from './components/CreateGroupModal';
import ShareModal from './components/ShareModal';
import NotificationModal from './components/NotificationModal';
import HomeFeed from './components/HomeFeed';
import PostOptionsModal from './components/PostOptionsModal';
import UploadModal from './components/UploadModal';
import DeleteModal from './components/DeleteModal';
import { authService } from './services/auth';
import { uploadFile } from './storage';

// Initialize Magic
const magic = new Magic('pk_live_F7B9E3F735A2C120');

const INITIAL_VIDEOS: VideoPost[] = [
  {
    id: 'v1',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-trading-monitor-with-charts-and-graphs-34487-large.mp4',
    username: 'crypto_whale_99',
    caption: 'Watching the charts like a hawk. BTC breakout incoming! 🚀 #crypto #trading',
    likes: 12500,
    comments: 450,
    tags: ['crypto', 'trading'],
    mediaType: 'video',
    commentsList: []
  },
  {
    id: 'v2',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-person-working-on-a-laptop-at-night-42514-large.mp4',
    username: 'scalp_queen',
    caption: 'Late night sessions are where the real gains are made. 📈 #scalping #forex',
    likes: 8900,
    comments: 230,
    tags: ['scalping', 'forex'],
    mediaType: 'video',
    commentsList: []
  },
  {
    id: 'v3',
    url: 'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=1000',
    username: 'street_trader_id',
    caption: 'Web3 is the future. Don\'t get left behind in the matrix. 💎 #web3 #decentralized',
    likes: 4200,
    comments: 112,
    tags: ['web3', 'future'],
    mediaType: 'image',
    commentsList: []
  },
  {
    id: 'v4',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-set-of-cryptocurrency-coins-9074-large.mp4',
    username: 'dex_demon',
    caption: 'Just found this gem on Solana. 100x or zero. 🔥 #solana #memecoin',
    likes: 5600,
    comments: 180,
    tags: ['solana', 'gem'],
    mediaType: 'video',
    commentsList: []
  },
  {
    id: 'v5',
    url: 'https://images.unsplash.com/photo-1642390210041-f6230f68449c?auto=format&fit=crop&q=80&w=1000',
    username: 'alpha_king',
    caption: 'My office for the day. High stakes, high rewards. 🏝️ #lifestyle #trader',
    likes: 15400,
    comments: 890,
    tags: ['lifestyle', 'alpha'],
    mediaType: 'image',
    commentsList: []
  },
  {
    id: 'v6',
    url: 'https://assets.mixkit.co/videos/preview/mixkit-man-working-on-a-desk-with-a-laptop-and-a-smartphone-42516-large.mp4',
    username: 'bull_runner',
    caption: 'Green candles only. Send it! 🕯️🚀 #bullmarket #sendit',
    likes: 7200,
    comments: 310,
    tags: ['bull', 'candles'],
    mediaType: 'video',
    commentsList: []
  },
  {
    id: 'v7',
    url: 'https://images.unsplash.com/photo-1621416894569-0f39ed31d247?auto=format&fit=crop&q=80&w=1000',
    username: 'bear_trap',
    caption: 'Everyone is greedy. Time to be fearful. 🐻 #bearish #shorting',
    likes: 3100,
    comments: 156,
    tags: ['bear', 'short'],
    mediaType: 'image',
    commentsList: []
  }
];

const INITIAL_STATUSES: UserStatus[] = [
  // Multi-status for crypto_whale_99 (Tap test)
  { id: 's1a', username: 'crypto_whale_99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto_whale_99', text: 'BTC at 100k is inevitable. 🚀', bgColor: 'bg-indigo-600', timestamp: new Date(Date.now() - 3600000), commentsList: [] },
  { id: 's1b', username: 'crypto_whale_99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto_whale_99', text: 'Just added 50 BTC to my bag.', bgColor: 'bg-indigo-700', timestamp: new Date(Date.now() - 3000000), commentsList: [] },
  
  // Multi-status for scalp_queen
  { id: 's2a', username: 'scalp_queen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=scalp_queen', text: 'Just caught a massive x! 📈', bgColor: 'bg-rose-600', timestamp: new Date(Date.now() - 7200000), commentsList: [] },
  { id: 's2b', username: 'scalp_queen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=scalp_queen', text: '5 mins candles are my yoga.', bgColor: 'bg-rose-800', timestamp: new Date(Date.now() - 6800000), commentsList: [] },

  { id: 's3', username: 'street_trader_id', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=street_trader_id', text: 'Street smarts > Book smarts.', bgColor: 'bg-zinc-800', timestamp: new Date(), commentsList: [] },
  { id: 's4', username: 'alpha_king', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alpha_king', text: 'VIP signals group dropping soon! 💎', bgColor: 'bg-amber-600', timestamp: new Date(), commentsList: [] },
  { id: 's5', username: 'dex_demon', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dex_demon', text: 'Solana is the new casino. 🎰', bgColor: 'bg-emerald-600', timestamp: new Date(), commentsList: [] },
  { id: 's6', username: 'moon_walker', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=moon_walker', text: 'Holding until 2030. Diamond hands. 💎🙌', bgColor: 'bg-blue-600', timestamp: new Date(), commentsList: [] }
];

const INITIAL_GROUPS: ChatGroup[] = [
  { id: 'g1', name: 'BTC Alpha Squad', description: 'Exclusive signals for BTC whales.', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=btc_alpha', memberCount: 1240, lastMsg: 'Wait for the 15m confirmation...', time: '2m', isGroup: true, owner: 'crypto_whale_99' },
  { id: 'g2', name: 'Degen Degenerates', description: 'Moon or zero. No stop losses.', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=degen_room', memberCount: 5620, lastMsg: 'LFG 🚀🚀🚀', time: '5m', isGroup: true, owner: 'alpha_king' },
  { id: 'g3', name: 'Solana Surfers', description: 'Surfing the SOL waves.', avatar: 'https://api.dicebear.com/7.x/identicon/svg?seed=solana', memberCount: 890, lastMsg: 'Raydium is lagging again...', time: '15m', isGroup: true, owner: 'dex_demon' }
];

const INITIAL_CHATS_LIST = [
  { id: 'c1', name: 'crypto_whale_99', lastMsg: 'Did you see that 15m candle? Insane!', time: '12m', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto_whale_99', online: true },
  { id: 'c2', name: 'scalp_queen', lastMsg: 'Thanks for the referral bonus! 🥂', time: '1h', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=scalp_queen', online: false },
  { id: 'c3', name: 'alpha_king', lastMsg: 'Yo, I have a private allocation...', time: '3h', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alpha_king', online: true },
  { id: 'c4', name: 'dex_demon', lastMsg: 'Which swap are you using?', time: '5h', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=dex_demon', online: true },
  { id: 'c5', name: 'moon_walker', lastMsg: 'HODL is the way.', time: '1d', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=moon_walker', online: false },
];

const MOCK_MESSAGES: Record<string, Message[]> = {
  'c1': [{ id: 'm1', text: 'Did you see that 15m candle? Insane!', sender: 'partner', timestamp: new Date(Date.now() - 720000), username: 'crypto_whale_99' }],
  'c2': [{ id: 'm2', text: 'Thanks for the referral bonus! 🥂', sender: 'partner', timestamp: new Date(Date.now() - 3600000), username: 'scalp_queen' }],
  'c3': [{ id: 'm3', text: 'Yo, I have a private allocation...', sender: 'partner', timestamp: new Date(Date.now() - 10800000), username: 'alpha_king' }],
  'c4': [{ id: 'm4', text: 'Which swap are you using?', sender: 'partner', timestamp: new Date(Date.now() - 18000000), username: 'dex_demon' }],
  'g1': [{ id: 'mg1', text: 'Wait for the 15m confirmation...', sender: 'partner', timestamp: new Date(Date.now() - 120000), username: 'crypto_whale_99' }],
  'g2': [{ id: 'mg2', text: 'LFG 🚀🚀🚀', sender: 'partner', timestamp: new Date(Date.now() - 300000), username: 'alpha_king' }]
};

const INITIAL_NOTIFICATIONS: Notification[] = [
  { id: 'n1', type: NotificationType.LIKE, username: 'crypto_whale_99', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=crypto_whale_99', content: '', timestamp: new Date(), isRead: false },
  { id: 'n2', type: NotificationType.REPLY, username: 'scalp_queen', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=scalp_queen', content: 'Nice trade! LFG 🚀', timestamp: new Date(Date.now() - 3600000), isRead: false },
  { id: 'n3', type: NotificationType.FOLLOW, username: 'street_trader_id', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=street_trader_id', content: '', timestamp: new Date(Date.now() - 7200000), isRead: true },
];

const MOCK_MY_FOLLOWERS = ['crypto_whale_99', 'scalp_queen', 'alpha_king', 'dex_demon', 'moon_walker', 'bull_runner', 'bear_trap', 'pump_master'];

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<AppTab>(AppTab.HOME);
  const [user, setUser] = useState<UserProfile | null>(null);
  const [viewingUser, setViewingUser] = useState<string | null>(null);
  const [viewingUserFeed, setViewingUserFeed] = useState<{ username: string; initialPostId: string } | null>(null);
  const [viewingSquadId, setViewingSquadId] = useState<string | null>(null);
  const [followingList, setFollowingList] = useState<Set<string>>(new Set(['crypto_whale_99', 'scalp_queen', 'alpha_king']));
  const [blockedUsers, setBlockedUsers] = useState<Set<string>>(new Set());
  const [mutedChatIds, setMutedChatIds] = useState<Set<string>>(new Set());
  const [viewedStatusIds, setViewedStatusIds] = useState<Set<string>>(new Set());
  const [language, setLanguage] = useState<Language>(Language.ID);
  const [theme, setTheme] = useState<AppTheme>(AppTheme.DARK);
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false);
  const [isWalletModalOpen, setIsWalletModalOpen] = useState(false);
  const [isCreateStatusOpen, setIsCreateStatusOpen] = useState(false);
  const [isCreateGroupOpen, setIsCreateGroupOpen] = useState(false);
  const [isFollowListOpen, setIsFollowListOpen] = useState(false);
  const [isNotificationOpen, setIsNotificationOpen] = useState(false);
  const [isPostOptionsOpen, setIsPostOptionsOpen] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [isDeleteModalOpen, setIsDeleteModalOpen] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [sharedPost, setSharedPost] = useState<VideoPost | null>(null);
  const [sharedStatus, setSharedStatus] = useState<UserStatus | null>(null);
  const [sharedProfileUsername, setSharedProfileUsername] = useState<string | null>(null);
  const [justUploadedId, setJustUploadedId] = useState<string | null>(null);
  
  const [statuses, setStatuses] = useState<UserStatus[]>(INITIAL_STATUSES);
  const [groups, setGroups] = useState<ChatGroup[]>(INITIAL_GROUPS);
  const [chatsList, setChatsList] = useState(INITIAL_CHATS_LIST);
  const [allMessages, setAllMessages] = useState<Record<string, Message[]>>(MOCK_MESSAGES);
  const [notifications, setNotifications] = useState<Notification[]>(INITIAL_NOTIFICATIONS);
  const [videos, setVideos] = useState<VideoPost[]>(INITIAL_VIDEOS);
  
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [isConnectingWallet, setIsConnectingWallet] = useState(false);
  const [isPosting, setIsPosting] = useState(false);
  const [authError, setAuthError] = useState<string | null>(null);
  
  const [wallet, setWallet] = useState<UserWallet>({
    address: null,
    balance: 1500.25,
    referralEarnings: 45.50,
    connected: false,
    history: [
      { id: '1', type: 'TOPUP', amount: 1000, timestamp: new Date(), status: 'COMPLETED' },
      { id: '2', type: 'BET', amount: -50, timestamp: new Date(Date.now() - 86400000), status: 'COMPLETED' },
    ]
  });

  const [isSystemDark, setIsSystemDark] = useState(window.matchMedia('(prefers-color-scheme: dark)').matches);

  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setIsSystemDark(e.matches);
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  const mutualFollows = MOCK_MY_FOLLOWERS
    .filter(username => followingList.has(username) && !blockedUsers.has(username))
    .map(username => ({
      username,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${username}`
    }));

  const handleLoginSuccess = (name: string, email: string, address: string | null) => {
    setUser({
      name: name,
      email: email,
      avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${name}`,
      bio: 'Street smart trader. Chasing alpha on StreetCoinz. 🚀',
      referralCode: 'STREET-' + Math.random().toString(36).substring(7).toUpperCase(),
      referralCount: 0,
      followerCount: 0,
      followingCount: 0,
      totalLikes: 0,
      links: []
    });
    
    setWallet(prev => ({
      ...prev,
      connected: true,
      address: address || `0x${Math.random().toString(16).substring(2, 6)}...`
    }));

    setIsAuthModalOpen(false);
    setIsWalletModalOpen(false);
    setIsAuthenticating(false);
    setIsConnectingWallet(false);
    setAuthError(null);
  };

  const handleEmailLogin = async (email: string, username: string, password?: string) => {
    setIsAuthenticating(true);
    setAuthError(null);
    const result = await authService.loginOrRegister(email, username, password);
    if (result.success && result.user) {
      handleLoginSuccess(result.user.name, result.user.email, result.user.address);
    } else {
      setIsAuthenticating(false);
      setAuthError(result.message);
    }
  };

  const handleWalletConnect = (providerName: string) => {
    setIsConnectingWallet(true);
    setTimeout(() => {
      const mockAddr = `0x${Math.random().toString(16).substring(2, 6)}...${Math.random().toString(16).substring(2, 10)}`;
      handleLoginSuccess(`${providerName}_Trader`, `${providerName}@street.eth`, mockAddr);
    }, 2000);
  };

  const handleLogout = () => {
    setUser(null);
    setWallet(prev => ({ ...prev, connected: false, address: null, balance: 1500.25 }));
    setActiveTab(AppTab.HOME);
    setViewingUser(null);
    setViewingUserFeed(null);
    setViewingSquadId(null);
    setBlockedUsers(new Set());
    setMutedChatIds(new Set());
    setViewedStatusIds(new Set());
  };

  const activeThemeClass = theme === AppTheme.SYSTEM 
    ? (isSystemDark ? 'theme-dark' : 'theme-clean')
    : (theme === AppTheme.CLEAN ? 'theme-clean' : 'theme-dark');

  const handleUpdateProfile = (updatedUser: UserProfile) => {
    setUser(updatedUser);
  };

  const handleCreateGroup = (data: { name: string; description: string; members: string[] }) => {
    const currentUsername = user?.name.toLowerCase().replace(/\s/g, '_') || 'anon';
    const newGroupId = 'g' + Date.now();
    const newGroup: ChatGroup = {
      id: newGroupId,
      name: data.name,
      description: data.description,
      avatar: `https://api.dicebear.com/7.x/identicon/svg?seed=${data.name}`,
      memberCount: data.members.length + 1,
      lastMsg: 'Squad formed! Let\'s cook. 🔥',
      time: 'Just now',
      isGroup: true,
      owner: currentUsername,
      isMuted: false
    };
    setGroups([newGroup, ...groups]);
    setAllMessages(prev => ({
      ...prev,
      [newGroupId]: [{
        id: 'msg-' + Date.now(),
        text: 'Squad formed! Let\'s cook. 🔥',
        sender: 'partner',
        timestamp: new Date(),
        username: 'System'
      }]
    }));
    setIsCreateGroupOpen(false);
  };

  const handleLeaveGroup = (groupId: string) => {
    setGroups(prev => prev.filter(g => g.id !== groupId));
    if (viewingSquadId === groupId) setViewingSquadId(null);
  };

  const handleDissolveGroup = (groupId: string) => {
    setGroups(prev => prev.filter(g => g.id !== groupId));
    if (viewingSquadId === groupId) setViewingSquadId(null);
  };

  const handleBlockUser = (username: string) => {
    setBlockedUsers(prev => new Set(prev).add(username));
    setFollowingList(prev => {
      const next = new Set(prev);
      next.delete(username);
      return next;
    });
    if (viewingUser === username) setViewingUser(null);
  };

  const handleUnblockUser = (username: string) => {
    setBlockedUsers(prev => {
      const next = new Set(prev);
      next.delete(username);
      return next;
    });
  };

  const handleToggleMuteChat = (chatId: string) => {
    setMutedChatIds(prev => {
      const next = new Set(prev);
      if (next.has(chatId)) next.delete(chatId);
      else next.add(chatId);
      return next;
    });
    if (chatId.startsWith('g')) {
      setGroups(prev => prev.map(g => g.id === chatId ? { ...g, isMuted: !g.isMuted } : g));
    }
  };

  const handleSendMessage = (targetId: string, msg: Partial<Message>) => {
    const newMessage: Message = {
      id: 'm' + Date.now() + Math.random(),
      timestamp: new Date(),
      sender: 'me',
      username: user?.name || 'Me',
      ...msg
    };

    setAllMessages(prev => ({
      ...prev,
      [targetId]: [...(prev[targetId] || []), newMessage]
    }));

    // Update last message in lists
    const lastTxt = msg.text || (msg.imageUrl ? '📷 Media' : msg.sharedPostId ? '🎬 Flex' : msg.sharedProfileUsername ? '👤 Profile' : msg.sharedStatusId ? '✨ Alpha' : 'Shared content');
    if (targetId.startsWith('g')) {
      setGroups(prev => prev.map(g => g.id === targetId ? { ...g, lastMsg: lastTxt, time: 'Just now' } : g));
    } else {
      setChatsList(prev => prev.map(c => c.id === targetId ? { ...c, lastMsg: lastTxt, time: 'Just now' } : c));
    }
  };

  const handleInternalShare = (usernames: string[]) => {
    if (!user || (!sharedPost && !sharedProfileUsername && !sharedStatus)) return;

    usernames.forEach(targetUsername => {
      // Find or Create Chat ID for this user
      let targetChat = chatsList.find(c => c.name === targetUsername);
      let targetChatId = targetChat?.id;

      if (!targetChatId) {
        targetChatId = 'c' + Date.now() + Math.random();
        const newChatEntry = {
          id: targetChatId,
          name: targetUsername,
          lastMsg: 'Shared content',
          time: 'Just now',
          avatar: `https://api.dicebear.com/7.x/avataaars/svg?seed=${targetUsername}`,
          online: true
        };
        setChatsList(prev => [newChatEntry, ...prev]);
      }

      // 1. Add to chat history
      const sharedMsg: Partial<Message> = {
        sender: 'me',
        timestamp: new Date(),
        username: user.name,
        sharedPostId: sharedPost?.id,
        sharedProfileUsername: sharedProfileUsername || undefined,
        sharedStatusId: sharedStatus?.id,
        text: sharedProfileUsername 
          ? `Check out @${sharedProfileUsername}'s profile!` 
          : sharedStatus 
            ? `Check out this Alpha by @${sharedStatus.username}: "${sharedStatus.text}"`
            : `Check out this flex: "${sharedPost?.caption}"`,
        imageUrl: sharedStatus ? sharedStatus.imageUrl : (sharedPost?.mediaType === 'image' ? sharedPost.url : (sharedPost?.mediaType === 'video' ? sharedPost.url : undefined))
      };
      
      handleSendMessage(targetChatId, sharedMsg);

      // 2. Trigger notification
      const newNotif: Notification = {
        id: 'n' + Date.now() + Math.random(),
        type: NotificationType.SHARE,
        username: user.name.toLowerCase().replace(/\s/g, '_'),
        avatar: user.avatar,
        content: sharedProfileUsername 
          ? `shared the trader @${sharedProfileUsername} with you.` 
          : sharedStatus
            ? `shared an Alpha status with you.`
            : `shared a flex with you: "${sharedPost?.caption}"`,
        timestamp: new Date(),
        postId: sharedPost?.id,
        sharedProfileUsername: sharedProfileUsername || undefined,
        isRead: false
      };
      setNotifications(prev => [newNotif, ...prev]);
    });
    
    setIsShareModalOpen(false);
    setSharedPost(null);
    setSharedProfileUsername(null);
    setSharedStatus(null);
  };

  const handleShareStatus = (status: UserStatus) => {
    setSharedStatus(status);
    setSharedPost(null);
    setSharedProfileUsername(null);
    setIsShareModalOpen(true);
  };

  const handleAddVideoComment = (postId: string, text: string, parentId?: string) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    const newComment: Comment = {
      id: Math.random().toString(36).substring(7),
      username: user.name.toLowerCase().replace(/\s/g, '_'),
      avatar: user.avatar,
      text,
      timestamp: new Date(),
      replies: []
    };

    setVideos(prev => prev.map(v => {
      if (v.id !== postId) return v;
      if (!parentId) {
        return { ...v, commentsList: [newComment, ...(v.commentsList || [])] };
      }
      return {
        ...v,
        commentsList: (v.commentsList || []).map(c => {
          if (c.id === parentId) {
            return { ...c, replies: [newComment, ...(c.replies || [])] };
          }
          return c;
        })
      };
    }));
  };

  const handleDeleteComment = (postId: string, commentId: string, parentId?: string) => {
    setVideos(prev => prev.map(v => {
      if (v.id !== postId) return v;
      if (!parentId) {
        return { ...v, commentsList: (v.commentsList || []).filter(c => c.id !== commentId) };
      }
      return {
        ...v,
        commentsList: (v.commentsList || []).map(c => {
          if (c.id === parentId) {
            return { ...c, replies: (c.replies || []).filter(r => r.id !== commentId) };
          }
          return c;
        })
      };
    }));
  };

  const handleUploadVideo = async (data: { file: File; caption: string; type: 'video' | 'image' }) => {
    if (!user) return;
    setIsPosting(true);
    try {
      const url = await uploadFile(data.file, user.name);
      const newId = 'v' + Date.now();
      const newPost: VideoPost = {
        id: newId,
        url: url,
        username: user.name.toLowerCase().replace(/\s/g, '_'),
        caption: data.caption,
        likes: 0,
        comments: 0,
        tags: [],
        mediaType: data.type,
        commentsList: []
      };
      setVideos([newPost, ...videos]);
      setIsUploadModalOpen(false);
      setJustUploadedId(newId);
      
      // Reset all sub-views to ensure we go to the primary home feed
      setViewingUser(null);
      setViewingUserFeed(null);
      setViewingSquadId(null);
      setActiveTab(AppTab.HOME);
    } catch (err) {
      console.error("Post Video Failed", err);
    } finally {
      setIsPosting(false);
    }
  };

  const handleDeletePost = (id: string) => {
    setDeleteId(id);
    setIsDeleteModalOpen(true);
  };

  const confirmDeletePost = () => {
    if (deleteId) {
      setVideos(videos.filter(v => v.id !== deleteId));
      setDeleteId(null);
      setIsDeleteModalOpen(false);
    }
  };

  const handleToggleFollow = (username: string) => {
    if (!user) {
      setIsAuthModalOpen(true);
      return;
    }
    if (blockedUsers.has(username)) return;
    setFollowingList(prev => {
      const next = new Set(prev);
      if (next.has(username)) next.delete(username);
      else next.add(username);
      return next;
    });
  };

  const handleViewProfile = (username: string) => {
    if (user && username === user.name.toLowerCase().replace(/\s/g, '_')) {
      setActiveTab(AppTab.PROFILE);
      setViewingUser(null);
      setViewingUserFeed(null);
      setViewingSquadId(null);
    } else {
      setViewingUser(username);
      setViewingUserFeed(null);
      setViewingSquadId(null);
    }
  };

  const handleViewSquad = (squadId: string) => {
    setViewingSquadId(squadId);
    setViewingUser(null);
    setViewingUserFeed(null);
  };

  const handleSharePost = (post: VideoPost) => {
    setSharedPost(post);
    setSharedProfileUsername(null);
    setSharedStatus(null);
    setIsShareModalOpen(true);
  };

  const handleShareProfile = (username: string) => {
    setSharedProfileUsername(username);
    setSharedPost(null);
    setSharedStatus(null);
    setIsShareModalOpen(true);
  };

  const handleDeposit = (amount: number) => {
    const newTx: Transaction = {
      id: Date.now().toString(),
      type: 'TOPUP',
      amount,
      timestamp: new Date(),
      status: 'COMPLETED'
    };
    setWallet(prev => ({
      ...prev,
      balance: prev.balance + amount,
      history: [newTx, ...prev.history]
    }));
  };

  const handleWithdraw = (amount: number) => {
    if (wallet.balance < amount) return;
    const newTx: Transaction = {
      id: Date.now().toString(),
      type: 'WITHDRAW',
      amount: -amount,
      timestamp: new Date(),
      status: 'COMPLETED'
    };
    setWallet(prev => ({
      ...prev,
      balance: prev.balance - amount,
      history: [newTx, ...prev.history]
    }));
  };

  const handleMarkStatusRead = (id: string) => {
    setViewedStatusIds(prev => new Set(prev).add(id));
  };

  // Group and Sort Statuses: Unread users first, fully-read users last
  const sortedStatuses = useMemo(() => {
    const grouped: Record<string, UserStatus[]> = {};
    statuses.forEach(s => {
      if (!grouped[s.username]) grouped[s.username] = [];
      grouped[s.username].push(s);
    });

    const usernames = Object.keys(grouped);
    const unreadUsers = usernames.filter(un => grouped[un].some(s => !viewedStatusIds.has(s.id)));
    const readUsers = usernames.filter(un => grouped[un].every(s => viewedStatusIds.has(s.id)));

    // Reconstruct the flattened list based on user groups sorted by unread state
    const result: UserStatus[] = [];
    [...unreadUsers, ...readUsers].forEach(un => {
      result.push(...grouped[un]);
    });
    return result;
  }, [statuses, viewedStatusIds]);

  const filteredVideos = videos.filter(v => !blockedUsers.has(v.username));
  const filteredStatuses = sortedStatuses.filter(s => !blockedUsers.has(s.username));

  const shouldShowNav = activeTab !== AppTab.PROFILE && !viewingUser && !viewingSquadId && !viewingUserFeed;

  const currentSquad = groups.find(g => g.id === viewingSquadId);

  return (
    <div className={`flex flex-col h-screen max-w-md mx-auto shadow-2xl overflow-hidden relative border-x transition-colors duration-300 ${activeThemeClass} ${activeThemeClass === 'theme-dark' ? 'bg-zinc-950 border-zinc-800' : 'bg-zinc-50 border-zinc-200'}`}>
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)} 
        onEmailLogin={handleEmailLogin}
        onOpenWallet={() => setIsWalletModalOpen(true)}
        language={language}
        isLoading={isAuthenticating}
        externalError={authError}
      />
      <WalletModal 
        isOpen={isWalletModalOpen} 
        onClose={() => setIsWalletModalOpen(false)} 
        onConnect={handleWalletConnect} 
        language={language}
        isConnecting={isConnectingWallet}
      />
      <PostOptionsModal
        isOpen={isPostOptionsOpen}
        onClose={() => setIsPostOptionsOpen(false)}
        onSelectVibez={() => setIsUploadModalOpen(true)}
        onSelectStatus={() => setIsCreateStatusOpen(true)}
        language={language}
      />
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        onUpload={handleUploadVideo}
        language={language}
        isPosting={isPosting}
      />
      <CreateStatusModal
        isOpen={isCreateStatusOpen}
        onClose={() => setIsCreateStatusOpen(false)}
        onPost={(data) => {
           const newStatus: UserStatus = {
             id: 's' + Date.now(),
             username: user?.name.toLowerCase().replace(/\s/g, '_') || 'anon',
             avatar: user?.avatar || '',
             text: data.text,
             bgColor: data.bgColor,
             imageUrl: data.imageUrl,
             timestamp: new Date(),
             commentsList: []
           };
           setStatuses([newStatus, ...statuses]);
           setIsCreateStatusOpen(false);
        }}
        language={language}
        user={user}
      />
      <CreateGroupModal
        isOpen={isCreateGroupOpen}
        onClose={() => setIsCreateGroupOpen(false)}
        onCreate={handleCreateGroup}
        language={language}
        mutualFollows={mutualFollows}
      />
      <DeleteModal
        isOpen={isDeleteModalOpen}
        onClose={() => setIsDeleteModalOpen(false)}
        onConfirm={confirmDeletePost}
        language={language}
      />
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        post={sharedPost}
        status={sharedStatus}
        profileUsername={sharedProfileUsername}
        language={language}
        onInternalShare={handleInternalShare}
      />
      <FollowListModal
        isOpen={isFollowListOpen}
        onClose={() => setIsFollowListOpen(false)}
        title="Traders"
        users={[]}
        onViewUser={handleViewProfile}
        language={language}
        activeThemeClass={activeThemeClass}
      />
      <NotificationModal
        isOpen={isNotificationOpen}
        onClose={() => setIsNotificationOpen(false)}
        notifications={notifications.filter(n => !blockedUsers.has(n.username))}
        onMarkRead={(id) => setNotifications(prev => prev.map(n => n.id === id ? { ...n, isRead: true } : n))}
        onClearAll={() => setNotifications([])}
        language={language}
        onViewProfile={(username) => {
          handleViewProfile(username);
          setIsNotificationOpen(false);
        }}
        activeThemeClass={activeThemeClass}
      />

      <header className={`p-4 flex justify-between items-center backdrop-blur-md z-50 border-b transition-colors duration-300 ${activeThemeClass === 'theme-dark' ? 'bg-zinc-950/70 border-zinc-900/50' : 'bg-white/70 border-zinc-200/50'}`}>
        <div 
          className="flex items-center gap-2 cursor-pointer group"
          onClick={() => { 
            setActiveTab(AppTab.HOME); 
            setViewingUser(null); 
            setViewingUserFeed(null); 
            setViewingSquadId(null); 
            setJustUploadedId(null);
          }}
        >
          <svg width="24" height="36" viewBox="0 0 46 70" fill="none" className="drop-shadow-[0_0_8px_rgba(168,85,247,0.6)] transition-transform group-hover:scale-110">
            <path d="M41.5 0L0 38.5H18.5L4.5 70L46 31.5H27.5L41.5 0Z" fill="#A855F7"/>
          </svg>
          <h1 className="text-xl font-black font-heading tracking-tighter italic">
            <span className="text-purple-500">STREET</span><span className={activeThemeClass === 'theme-dark' ? 'text-white' : 'text-zinc-900'}>COINZ</span>
          </h1>
        </div>
        
        <div className="flex items-center gap-2">
          {!user ? (
            <button 
              onClick={() => setIsAuthModalOpen(true)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-[10px] font-black hover:opacity-80 transition-all shadow-lg uppercase tracking-tight ${activeThemeClass === 'theme-dark' ? 'bg-white text-zinc-900' : 'bg-zinc-900 text-white'}`}
            >
              SIGN IN
            </button>
          ) : (
            <div className="flex items-center gap-3">
              <button 
                onClick={() => setIsNotificationOpen(true)}
                className="relative p-2 hover:bg-zinc-800/10 rounded-xl transition-all group"
              >
                <svg className={`w-5 h-5 ${activeThemeClass === 'theme-dark' ? 'text-zinc-400 group-hover:text-white' : 'text-zinc-500 group-hover:text-zinc-900'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                {notifications.some(n => !n.isRead && !blockedUsers.has(n.username)) && (
                  <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-rose-500 rounded-full border border-zinc-950 animate-pulse"></span>
                )}
              </button>

              <button 
                onClick={() => { setActiveTab(AppTab.PROFILE); setViewingUser(null); setViewingUserFeed(null); setViewingSquadId(null); setJustUploadedId(null); }}
                className={`relative rounded-xl p-0.5 transition-all ${activeTab === AppTab.PROFILE ? 'bg-gradient-to-r from-purple-500 to-pink-500 scale-110 shadow-[0_0_15px_rgba(168,85,247,0.5)]' : 'bg-zinc-800'}`}
              >
                <img src={user.avatar} alt="Profile" className={`w-8 h-8 rounded-lg border ${activeThemeClass === 'theme-dark' ? 'border-zinc-950' : 'border-white'}`} />
              </button>
            </div>
          )}
        </div>
      </header>

      <main className="flex-1 overflow-hidden relative">
        {viewingUserFeed ? (
          <HomeFeed
            posts={filteredVideos.filter(v => v.username === viewingUserFeed.username)}
            currentUser={user}
            language={language}
            followingList={followingList}
            onToggleFollow={handleToggleFollow}
            onDelete={handleDeletePost}
            onShare={handleSharePost}
            onViewProfile={handleViewProfile}
            onAddComment={handleAddVideoComment}
            onDeleteComment={handleDeleteComment}
            activeThemeClass={activeThemeClass}
            initialPostId={viewingUserFeed.initialPostId}
            onBack={() => setViewingUserFeed(null)}
          />
        ) : viewingUser ? (
          <PublicProfile 
            username={viewingUser} 
            posts={videos} 
            statuses={filteredStatuses}
            viewedStatusIds={viewedStatusIds}
            language={language} 
            activeThemeClass={activeThemeClass} 
            isFollowing={followingList.has(viewingUser)}
            isBlocked={blockedUsers.has(viewingUser)}
            onToggleFollow={() => handleToggleFollow(viewingUser)}
            onBlock={() => handleBlockUser(viewingUser)}
            onUnblock={() => handleUnblockUser(viewingUser)}
            onBack={() => setViewingUser(null)} 
            onShareProfile={() => handleShareProfile(viewingUser)}
            onOpenList={() => {}}
            onViewPost={(postId) => setViewingUserFeed({ username: viewingUser, initialPostId: postId })}
            onDeleteStatus={(id) => setStatuses(prev => prev.filter(s => s.id !== id))}
            onShareStatus={handleShareStatus}
            onSendMessage={(targetId, msg) => handleSendMessage(targetId, msg)}
            onMarkStatusRead={handleMarkStatusRead}
            currentUser={user}
          />
        ) : viewingSquadId && currentSquad ? (
          <SquadProfile
            squad={currentSquad}
            language={language}
            activeThemeClass={activeThemeClass}
            currentUserUsername={user?.name.toLowerCase().replace(/\s/g, '_') || 'anon'}
            onBack={() => setViewingSquadId(null)}
            onLeave={handleLeaveGroup}
            onDissolve={handleDissolveGroup}
            onToggleMute={handleToggleMuteChat}
            onViewMember={handleViewProfile}
          />
        ) : (
          <>
            {activeTab === AppTab.HOME && (
               <HomeFeed
                 posts={filteredVideos}
                 currentUser={user}
                 language={language}
                 followingList={followingList}
                 onToggleFollow={handleToggleFollow}
                 onDelete={handleDeletePost}
                 onShare={handleSharePost}
                 onViewProfile={handleViewProfile}
                 onAddComment={handleAddVideoComment}
                 onDeleteComment={handleDeleteComment}
                 activeThemeClass={activeThemeClass}
                 initialPostId={justUploadedId || undefined}
               />
            )}
            {activeTab === AppTab.PREDICT && <PredictMarket wallet={wallet} language={language} onBet={() => {}} activeThemeClass={activeThemeClass} />}
            {activeTab === AppTab.CHAT && (
              <ChatList 
                user={user} 
                statuses={filteredStatuses}
                viewedStatusIds={viewedStatusIds}
                groups={groups}
                chatsList={chatsList}
                allMessages={allMessages}
                onSendMessage={handleSendMessage}
                blockedUsers={blockedUsers}
                mutedChatIds={mutedChatIds}
                language={language} 
                activeThemeClass={activeThemeClass} 
                onViewProfile={handleViewProfile}
                onViewSquad={handleViewSquad}
                onLeaveGroup={handleLeaveGroup}
                onDissolveGroup={handleDissolveGroup}
                onBlockUser={handleBlockUser}
                onToggleMute={handleToggleMuteChat}
                onCreateStatus={() => { if(!user) setIsAuthModalOpen(true); else setIsCreateStatusOpen(true); }}
                onCreateGroup={() => { if(!user) setIsAuthModalOpen(true); else setIsCreateGroupOpen(true); }}
                onDeleteStatus={(id) => setStatuses(prev => prev.filter(s => s.id !== id))}
                onAddComment={(id, text) => {}}
                onShareStatus={handleShareStatus}
                onMarkStatusRead={handleMarkStatusRead}
              />
            )}
            {activeTab === AppTab.TOPUP && (
              <WalletDashboard 
                wallet={wallet} 
                user={user}
                language={language}
                activeThemeClass={activeThemeClass}
                onLogin={() => setIsAuthModalOpen(true)}
                onDeposit={handleDeposit} 
                onWithdraw={handleWithdraw}
              />
            )}
            {activeTab === AppTab.PROFILE && user && (
              <ProfileDetails 
                user={user} 
                wallet={wallet} 
                posts={videos} 
                statuses={filteredStatuses}
                viewedStatusIds={viewedStatusIds}
                language={language}
                setLanguage={setLanguage}
                theme={theme}
                setTheme={setTheme}
                activeThemeClass={activeThemeClass}
                onLogout={handleLogout} 
                onUpdateProfile={handleUpdateProfile}
                onOpenList={() => {}}
                onBack={() => setActiveTab(AppTab.HOME)}
                onViewPost={(postId) => setViewingUserFeed({ username: user.name.toLowerCase().replace(/\s/g, '_'), initialPostId: postId })}
                onShareProfile={() => handleShareProfile(user.name.toLowerCase().replace(/\s/g, '_'))}
                onDeleteStatus={(id) => setStatuses(prev => prev.filter(s => s.id !== id))}
                onShareStatus={handleShareStatus}
                onSendMessage={(targetId, msg) => handleSendMessage(targetId, msg)}
                onMarkStatusRead={handleMarkStatusRead}
              />
            )}
          </>
        )}
      </main>

      {shouldShowNav && (
        <BottomNav 
          activeTab={activeTab} 
          setActiveTab={(tTab) => {
            if (tTab === AppTab.POST) {
              if (!user) setIsAuthModalOpen(true);
              else setIsPostOptionsOpen(true);
            } else {
              setActiveTab(tTab);
              setViewingUser(null);
              setViewingUserFeed(null);
              setViewingSquadId(null);
              setJustUploadedId(null);
            }
          }} 
          language={language} 
          activeThemeClass={activeThemeClass} 
        />
      )}
    </div>
  );
};

export default App;
