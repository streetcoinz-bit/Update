
import { GoogleGenAI, Type } from "@google/genai";

/**
 * StreetCoinz AI Service
 * Powered by Google Gemini for street-smart market insights.
 */

// Initialize the Gemini API client. The API key is obtained from the environment variable.
const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Mengambil sentimen pasar untuk koin tertentu menggunakan Gemini API.
 */
export async function getMarketSentiment(coin: string = "Bitcoin") {
  try {
    const prompt = `Lakukan analisis sentimen sosial cepat untuk ${coin}. Gunakan getaran terbaru dari komunitas trading. 
                   Kembalikan objek JSON dengan 'sentiment' (Bullish/Bearish), 'confidence' (0-100), 'reasoning' (frasa pendek yang menarik).`;
    
    // Use gemini-3-flash-preview for basic text tasks and summarization.
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        systemInstruction: "Anda adalah bot sentimen crypto. Berikan respons HANYA dalam format objek JSON yang valid.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentiment: {
              type: Type.STRING,
              description: 'The market sentiment, either "Bullish" or "Bearish".',
            },
            confidence: {
              type: Type.NUMBER,
              description: 'Confidence level from 0 to 100.',
            },
            reasoning: {
              type: Type.STRING,
              description: 'A short, catchy phrase explaining the sentiment.',
            },
          },
          required: ["sentiment", "confidence", "reasoning"],
          propertyOrdering: ["sentiment", "confidence", "reasoning"],
        },
      },
    });

    // Access text property directly as per guidelines.
    const content = response.text?.trim();
    if (!content) throw new Error("Empty response from Gemini");
    
    return JSON.parse(content);
  } catch (err) {
    console.error("Analisis Sentimen Gemini Gagal:", err);
    return { 
      sentiment: 'Netral', 
      confidence: 50, 
      reasoning: 'Sinyal jalanan kabur. Kalibrasi getaran Gemini...',
      isFallback: true
    };
  }
}

/**
 * Berinteraksi dengan Street AI untuk saran pasar.
 */
export async function askMarketAI(userPrompt: string, currentPrice: number) {
  try {
    // Use gemini-3-pro-preview for complex reasoning and advanced market advice.
    const response = await ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: userPrompt,
      config: {
        systemInstruction: `Anda adalah StreetCoinz AI, pakar trading crypto yang cerdas. 
                      Harga BTC saat ini adalah $${currentPrice}. 
                      Jawab dalam 1-2 kalimat pendek dan lugas menggunakan bahasa gaul trader. Bantu mereka tapi ingatkan bahwa ini bukan saran keuangan.`,
      },
    });

    // Access text property directly as per guidelines.
    return response.text || "Street AI sedang istirahat. Coba lagi nanti, kawan.";
  } catch (err: any) {
    console.error("Chat Gemini Gagal:", err);
    return "Street AI sedang istirahat. Coba lagi nanti, kawan.";
  }
}
