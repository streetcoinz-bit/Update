export const games = [
  {
    id: '1',
    title: 'Neon Crash',
    provider: 'Street Originals',
    image: 'https://images.unsplash.com/photo-1551103782-8ab07afd45c1?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Originals',
    isHot: true,
  },
  {
    id: '2',
    title: 'Cyber Slots',
    provider: 'NetEnt',
    image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Slots',
  },
  {
    id: '3',
    title: 'Crypto Roulette',
    provider: 'Evolution',
    image: 'https://images.unsplash.com/photo-1606167668511-87303944271f?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Table Games',
    isHot: true,
  },
  {
    id: '4',
    title: 'Blackjack VIP',
    provider: 'Evolution',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Live Casino',
  },
  {
    id: '5',
    title: 'Street Dice',
    provider: 'Street Originals',
    image: 'https://images.unsplash.com/photo-1518133683791-0b9de5a055f0?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Originals',
  },
  {
    id: '6',
    title: 'Plinko Drop',
    provider: 'Street Originals',
    image: 'https://images.unsplash.com/photo-1611162617474-5b21e879e113?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Originals',
    isHot: true,
  },
  {
    id: '7',
    title: 'Baccarat Pro',
    provider: 'Pragmatic Play',
    image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Table Games',
  },
  {
    id: '8',
    title: 'Mega Wheel',
    provider: 'Pragmatic Play Live',
    image: 'https://images.unsplash.com/photo-1518133683791-0b9de5a055f0?auto=format&fit=crop&q=80&w=400&h=300',
    category: 'Live Casino',
  },
];

export const categories = [
  { id: 'all', name: 'Lobby' },
  { id: 'originals', name: 'Originals' },
  { id: 'slots', name: 'Slots' },
  { id: 'live', name: 'Live Casino' },
  { id: 'table', name: 'Table Games' },
];
