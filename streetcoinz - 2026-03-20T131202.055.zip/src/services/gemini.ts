import { GoogleGenAI } from "@google/genai";

export async function analyzeSpot(base64Image: string) {
  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [
      {
        parts: [
          { text: "Analyze this urban spot image. Identify if it's street art, a skate spot, or a hidden gem. Provide a short, cool description in a 'street' tone. Return JSON format with fields: 'type', 'style', 'description'." },
          { inlineData: { mimeType: "image/jpeg", data: base64Image.split(',')[1] } }
        ]
      }
    ],
    config: {
      responseMimeType: "application/json"
    }
  });

  return JSON.parse(response.text);
}
