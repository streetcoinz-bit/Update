export interface CryptoData {
  symbol: string;
  priceChange: string;
  priceChangePercent: string;
  lastPrice: string;
  volume: string;
  highPrice: string;
  lowPrice: string;
}

export async function fetchTopCryptos(): Promise<CryptoData[]> {
  try {
    const response = await fetch('https://api.binance.com/api/v3/ticker/24hr');
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data: any[] = await response.json();
    
    // Filter for some popular USDT pairs
    const targetSymbols = ['BTCUSDT', 'ETHUSDT', 'SOLUSDT', 'BNBUSDT', 'TRXUSDT', 'XRPUSDT', 'ADAUSDT', 'DOGEUSDT', 'AVAXUSDT', 'MATICUSDT', 'POLUSDT'];
    
    const filteredData = data
      .filter(item => targetSymbols.includes(item.symbol))
      .map(item => ({
        symbol: item.symbol.replace('USDT', ''),
        priceChange: parseFloat(item.priceChange).toFixed(2),
        priceChangePercent: parseFloat(item.priceChangePercent).toFixed(2),
        lastPrice: parseFloat(item.lastPrice).toFixed(2),
        volume: parseFloat(item.volume).toFixed(2),
        highPrice: parseFloat(item.highPrice).toFixed(2),
        lowPrice: parseFloat(item.lowPrice).toFixed(2),
      }))
      .sort((a, b) => targetSymbols.indexOf(a.symbol + 'USDT') - targetSymbols.indexOf(b.symbol + 'USDT'));
      
    return filteredData;
  } catch (error) {
    console.error("Error fetching crypto data:", error);
    return [];
  }
}

export async function fetchHistoricalData(symbol: string = 'BTCUSDT'): Promise<{time: string, price: number}[]> {
  try {
    const response = await fetch(`https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=1h&limit=24`);
    if (!response.ok) {
      throw new Error('Network response was not ok');
    }
    const data: any[] = await response.json();
    
    return data.map(candle => {
      const date = new Date(candle[0]);
      return {
        time: `${date.getHours()}:00`,
        price: parseFloat(candle[4]) // Close price
      };
    });
  } catch (error) {
    console.error("Error fetching historical data:", error);
    return [];
  }
}
