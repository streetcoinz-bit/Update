export const notifyDiscordLogin = async (userIdentifier: string, method: string) => {
  const webhookUrl = 'https://discord.com/api/webhooks/1481782382406140027/tr5MIH4DZySACY3VGoq60Azd20wwjiW68rpYQL8DJ28WV_UY99PB2_TKq4rDGiS8kqDc';
  
  try {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        content: `🚀 **New Login Detected!**\n**User:** \`${userIdentifier}\`\n**Method:** \`${method}\`\n**Time:** <t:${Math.floor(Date.now() / 1000)}:F>`,
      }),
    });
  } catch (error) {
    console.error('Failed to send Discord webhook:', error);
  }
};
