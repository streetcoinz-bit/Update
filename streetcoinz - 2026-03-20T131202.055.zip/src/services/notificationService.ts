export async function generateStreetCoinzNotification(eventType: string, data: any): Promise<string> {
  if (eventType === "Token Price Pump") {
    return `🚀 ${data.symbol} is pumping! Up ${data.changePercentage}% in 24h. Time to make your move! 💎`;
  } else if (eventType === "Token Price Dump") {
    return `🚨 ${data.symbol} is dumping! Down ${data.changePercentage}% in 24h. Buy the dip or short it? 🔥`;
  }
  
  return `StreetCoinz Alert: ${eventType}! 🚀`;
}

export async function checkAndSendPriceAlert(symbol: string, change24h: number) {
  // Only alert for significant changes, e.g., >= 5% or <= -5%
  const threshold = 5;
  const currentLevel = Math.floor(Math.abs(change24h) / threshold) * threshold;
  
  if (currentLevel >= threshold) {
    const key = `price_alert_${symbol}_${change24h > 0 ? 'up' : 'down'}_${currentLevel}`;
    
    // Check if we already notified for this level recently
    const lastNotifiedStr = localStorage.getItem(key);
    const lastNotified = lastNotifiedStr ? parseInt(lastNotifiedStr, 10) : 0;
    const now = Date.now();
    
    // Only notify once per 24 hours for the same threshold level
    if (!lastNotified || (now - lastNotified) > 24 * 60 * 60 * 1000) {
      localStorage.setItem(key, now.toString());
      
      const eventType = change24h > 0 ? "Token Price Pump" : "Token Price Dump";
      const body = await generateStreetCoinzNotification(eventType, {
        symbol,
        changePercentage: change24h.toFixed(2)
      });
      
      await sendPushNotification(
        `🚨 ${symbol} is ${change24h > 0 ? 'Pumping' : 'Dumping'}!`,
        body
      );
    }
  }
}

export async function sendPushNotification(title: string, body: string, data?: any) {
  try {
    const response = await fetch("https://pushnotif.streetcoinz.com/push", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        title,
        body,
        data,
      }),
    });

    if (!response.ok) {
      throw new Error(`Push API error: ${response.statusText}`);
    }

    console.log("Push notification sent successfully!");
  } catch (error) {
    console.error("Error sending push notification:", error);
  }
}

export async function subscribeToWebPush() {
  const publicVapidKey = import.meta.env.VITE_VAPID_PUBLIC_KEY || "BE-0rmaqkNckZYpO5Y_Px5T4mBl5AOqADA3j0wrM66A6nF6sRukOUlMUrlaadCi922D9ESyX9GQVhqTKXHSDFgE";
  
  if (!('serviceWorker' in navigator)) {
    console.warn('Service workers are not supported in this browser');
    return null;
  }

  try {
    const registration = await navigator.serviceWorker.register('/sw.js');
    console.log('Service Worker registered');

    const subscription = await registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: urlBase64ToUint8Array(publicVapidKey)
    });

    console.log('Push subscription successful:', subscription);
    // Here you would typically send the subscription to your backend (e.g., Supabase)
    return subscription;
  } catch (error) {
    console.error('Error subscribing to push notifications:', error);
    return null;
  }
}

function urlBase64ToUint8Array(base64String: string) {
  const padding = '='.repeat((4 - base64String.length % 4) % 4);
  const base64 = (base64String + padding)
    .replace(/\-/g, '+')
    .replace(/_/g, '/');

  const rawData = window.atob(base64);
  const outputArray = new Uint8Array(rawData.length);

  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray;
}
