import { fetchTopCryptos } from './cryptoService';

const RPC_URLS = {
  BNB: 'https://bnb-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6',
  ETH: 'https://eth-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6',
  POLYGON: 'https://polygon-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6'
};

const USDT_CONTRACTS = {
  ETH: '0xdAC17F958D2ee523a2206206994597C13D831ec7',
  BNB: '0x55d398326f99059fF775485246999027B3197955',
  POLYGON: '0xc2132D05D31c914a87C6611C10748AEb04B58e8F'
};

async function fetchEvmBalance(rpcUrl: string, address: string): Promise<number> {
  try {
    const res = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ jsonrpc: "2.0", method: "eth_getBalance", params: [address, "latest"], id: 1 })
    });
    const data = await res.json();
    const hexVal = data.result;
    if (!hexVal || hexVal === '0x') return 0;
    return Number(BigInt(hexVal)) / 1e18;
  } catch (e) {
    console.error('Error fetching EVM balance:', e);
    return 0;
  }
}

async function fetchEvmUsdtBalance(rpcUrl: string, contractAddress: string, walletAddress: string, decimals: number = 18): Promise<number> {
  try {
    const dataParam = "0x70a08231000000000000000000000000" + walletAddress.substring(2);
    const res = await fetch(rpcUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        jsonrpc: "2.0",
        method: "eth_call",
        params: [{ to: contractAddress, data: dataParam }, "latest"],
        id: 1
      })
    });
    const data = await res.json();
    const hexVal = data.result;
    if (!hexVal || hexVal === '0x') return 0;
    return Number(BigInt(hexVal)) / Math.pow(10, decimals);
  } catch (e) {
    console.error('Error fetching EVM USDT balance:', e);
    return 0;
  }
}

export async function getUserPlatformBalance(platformWallet: any): Promise<number> {
  if (!platformWallet) return 0;

  const { address: evmAddress } = platformWallet;
  if (!evmAddress) return 0;

  // Fetch all balances in parallel
  const [
    ethBal, bnbBal, maticBal,
    ethUsdt, bnbUsdt, maticUsdt,
    cryptoPrices
  ] = await Promise.all([
    fetchEvmBalance(RPC_URLS.ETH, evmAddress),
    fetchEvmBalance(RPC_URLS.BNB, evmAddress),
    fetchEvmBalance(RPC_URLS.POLYGON, evmAddress),
    fetchEvmUsdtBalance(RPC_URLS.ETH, USDT_CONTRACTS.ETH, evmAddress, 6), // ETH USDT has 6 decimals
    fetchEvmUsdtBalance(RPC_URLS.BNB, USDT_CONTRACTS.BNB, evmAddress, 18), // BNB USDT has 18 decimals
    fetchEvmUsdtBalance(RPC_URLS.POLYGON, USDT_CONTRACTS.POLYGON, evmAddress, 6), // POLYGON USDT has 6 decimals
    fetchTopCryptos()
  ]);

  // Get prices
  const getPrice = (symbol: string) => {
    const coin = cryptoPrices.find(c => c.symbol === symbol);
    return coin ? parseFloat(coin.lastPrice) : 0;
  };

  const ethPrice = getPrice('ETH');
  const bnbPrice = getPrice('BNB');
  const maticPrice = getPrice('MATIC') || getPrice('POL');

  // Calculate total USD value
  let totalUsd = 0;
  totalUsd += ethBal * ethPrice;
  totalUsd += bnbBal * bnbPrice;
  totalUsd += maticBal * maticPrice;

  totalUsd += ethUsdt;
  totalUsd += bnbUsdt;
  totalUsd += maticUsdt;

  return totalUsd;
}

export async function getUserPlatformAssets(platformWallet: any) {
  if (!platformWallet) return { eth: 0, bnb: 0, matic: 0, usdt: 0, ethUsd: 0, bnbUsd: 0, maticUsd: 0, usdtUsd: 0, totalUsd: 0 };

  const { address: evmAddress } = platformWallet;
  if (!evmAddress) return { eth: 0, bnb: 0, matic: 0, usdt: 0, ethUsd: 0, bnbUsd: 0, maticUsd: 0, usdtUsd: 0, totalUsd: 0 };

  const [
    ethBal, bnbBal, maticBal,
    ethUsdt, bnbUsdt, maticUsdt,
    cryptoPrices
  ] = await Promise.all([
    fetchEvmBalance(RPC_URLS.ETH, evmAddress),
    fetchEvmBalance(RPC_URLS.BNB, evmAddress),
    fetchEvmBalance(RPC_URLS.POLYGON, evmAddress),
    fetchEvmUsdtBalance(RPC_URLS.ETH, USDT_CONTRACTS.ETH, evmAddress, 6),
    fetchEvmUsdtBalance(RPC_URLS.BNB, USDT_CONTRACTS.BNB, evmAddress, 18),
    fetchEvmUsdtBalance(RPC_URLS.POLYGON, USDT_CONTRACTS.POLYGON, evmAddress, 6),
    fetchTopCryptos()
  ]);

  const getPrice = (symbol: string) => {
    const coin = cryptoPrices.find(c => c.symbol === symbol);
    return coin ? parseFloat(coin.lastPrice) : 0;
  };

  const ethPrice = getPrice('ETH');
  const bnbPrice = getPrice('BNB');
  const maticPrice = getPrice('MATIC') || getPrice('POL');

  const totalUsdt = ethUsdt + bnbUsdt + maticUsdt;

  let totalUsd = 0;
  totalUsd += ethBal * ethPrice;
  totalUsd += bnbBal * bnbPrice;
  totalUsd += maticBal * maticPrice;
  totalUsd += totalUsdt;

  return {
    eth: ethBal,
    bnb: bnbBal,
    matic: maticBal,
    usdt: totalUsdt,
    ethUsd: ethBal * ethPrice,
    bnbUsd: bnbBal * bnbPrice,
    maticUsd: maticBal * maticPrice,
    usdtUsd: totalUsdt,
    totalUsd
  };
}
