const PUSH_API_BASE_URL = 'https://pushnotif.streetcoinz.com';

export async function sendStreetCoinzEmail(toEmail: string, subject: string, htmlContent: string) {
  const fromEmail = "hello@streetcoinz.com";

  try {
    const response = await fetch(`${PUSH_API_BASE_URL}/email`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: `StreetCoinz <${fromEmail}>`,
        to: [toEmail],
        subject: subject,
        html: htmlContent,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`Email API error: ${JSON.stringify(errorData)}`);
    }

    console.log(`Email sent successfully to ${toEmail}!`);
  } catch (error) {
    console.error("Error sending email:", error);
  }
}

export async function sendWelcomeEmail(toEmail: string) {
  const subject = "Welcome to StreetCoinz! 🚀";
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #a252f0; text-align: center; font-size: 28px; margin-bottom: 10px;">Welcome to StreetCoinz! 💎</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Yo! Welcome to the ultimate crypto games arena. We're hyped to have you on board.
      </p>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Get ready to play original games, bet on market movements, climb the leaderboards, and earn rewards. The streets are watching, let's see what you've got!
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="https://streetcoinz.com" style="background-color: #a252f0; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Start Playing Now</a>
      </div>
      <p style="font-size: 14px; color: #9ca3af; text-align: center; margin-top: 40px;">
        Stay hyped,<br>The StreetCoinz Team
      </p>
    </div>
  `;
  
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}

export async function sendBetReceiptEmail(toEmail: string, pair: string, direction: string, amount: number) {
  const subject = `Bet Confirmed: ${pair} ${direction} 🚀`;
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #a252f0; text-align: center; font-size: 24px; margin-bottom: 10px;">Bet Locked In! 🔒</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Your bet has been successfully placed on the blockchain (simulated).
      </p>
      <div style="background-color: #1a1a1a; padding: 15px; border-radius: 8px; margin: 20px 0;">
        <p style="margin: 5px 0;"><strong>Market:</strong> ${pair}</p>
        <p style="margin: 5px 0;"><strong>Direction:</strong> <span style="color: ${direction === 'UP' ? '#22c55e' : '#ef4444'};">${direction}</span></p>
        <p style="margin: 5px 0;"><strong>Amount:</strong> ${amount} SCZ</p>
      </div>
      <p style="font-size: 14px; color: #9ca3af; text-align: center; margin-top: 30px;">
        Good luck! We'll notify you when the result is in.
      </p>
    </div>
  `;
  
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}

export async function sendCancelOrderEmail(toEmail: string, orderDetails: string) {
  const subject = "Order Cancelled - Need Help? 🤔";
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #ef4444; text-align: center; font-size: 24px; margin-bottom: 10px;">Order Cancelled</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        We noticed you just cancelled your order (${orderDetails}). 
      </p>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        If you experienced any issues or changed your mind, our support team is always here to help. Feel free to reach out or jump back into the action whenever you're ready!
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="https://streetcoinz.com" style="background-color: #a252f0; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Return to Arena</a>
      </div>
    </div>
  `;
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}

export async function sendDepositFollowUpEmail(toEmail: string, amount: number, currency: string) {
  const subject = "Deposit Successful! Let's Go! 💰";
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #22c55e; text-align: center; font-size: 24px; margin-bottom: 10px;">Funds Added Successfully!</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Your deposit of <strong>${amount} ${currency}</strong> has been credited to your StreetCoinz account.
      </p>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Your arsenal is loaded. The markets are moving fast—time to make your predictions and dominate the leaderboard!
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="https://streetcoinz.com" style="background-color: #a252f0; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Start Trading</a>
      </div>
    </div>
  `;
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}

export async function sendWithdrawFollowUpEmail(toEmail: string, amount: number, currency: string) {
  const subject = "Withdrawal Processed! 💸";
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #a252f0; text-align: center; font-size: 24px; margin-bottom: 10px;">Winnings Secured!</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Your withdrawal of <strong>${amount} ${currency}</strong> has been successfully processed and is on its way to your wallet.
      </p>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Great job securing those profits! When you're ready for the next big move, the arena will be waiting for you.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="https://streetcoinz.com" style="background-color: #2a2a2a; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block; border: 1px solid #444;">View Transaction History</a>
      </div>
    </div>
  `;
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}

export async function sendLowBalanceEmail(toEmail: string) {
  const subject = "Running Low on Ammo? ⛽";
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #f59e0b; text-align: center; font-size: 24px; margin-bottom: 10px;">Low Balance Alert</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        We noticed your StreetCoinz balance is getting a bit low. 
      </p>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Don't miss out on the next big market move! Top up your account now to keep your winning streak alive and stay in the game.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="https://streetcoinz.com" style="background-color: #a252f0; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Deposit Now</a>
      </div>
    </div>
  `;
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}

export async function sendInactiveUserEmail(toEmail: string) {
  const subject = "The Streets Miss You! 🏙️";
  const htmlContent = `
    <div style="font-family: 'Inter', sans-serif; max-width: 600px; margin: 0 auto; background-color: #131212; color: #ffffff; padding: 20px; border-radius: 12px; border: 1px solid #2a2a2a;">
      <h1 style="color: #a252f0; text-align: center; font-size: 24px; margin-bottom: 10px;">Where Have You Been?</h1>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        It's been a while since we saw you at StreetCoinz. The markets have been crazy lately, and there are plenty of opportunities waiting for you!
      </p>
      <p style="font-size: 16px; line-height: 1.5; color: #d1d5db;">
        Come back and check out our latest features, new prediction markets, and climb back up the leaderboard.
      </p>
      <div style="text-align: center; margin: 30px 0;">
        <a href="https://streetcoinz.com" style="background-color: #a252f0; color: #ffffff; padding: 12px 24px; text-decoration: none; border-radius: 8px; font-weight: bold; display: inline-block;">Jump Back In</a>
      </div>
    </div>
  `;
  await sendStreetCoinzEmail(toEmail, subject, htmlContent);
}
