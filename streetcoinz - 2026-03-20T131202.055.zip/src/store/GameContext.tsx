import React, { createContext, useContext, useState, ReactNode } from 'react';

interface GameContextType {
  balance: number;
  addBalance: (amount: number) => void;
  deductBalance: (amount: number) => boolean;
  username: string;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: ReactNode }) {
  const [balance, setBalance] = useState<number>(1000.00);
  const [username] = useState<string>('Player1');

  const addBalance = (amount: number) => {
    setBalance(prev => prev + amount);
  };

  const deductBalance = (amount: number) => {
    if (balance >= amount) {
      setBalance(prev => prev - amount);
      return true;
    }
    return false;
  };

  return (
    <GameContext.Provider value={{ balance, addBalance, deductBalance, username }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error('useGame must be used within a GameProvider');
  }
  return context;
}
