import { create } from 'zustand';

interface StoreState {
  balance: number;
  addBalance: (amount: number) => void;
  deductBalance: (amount: number) => void;
}

export const useStore = create<StoreState>((set) => ({
  balance: 1000,
  addBalance: (amount) => set((state) => ({ balance: state.balance + amount })),
  deductBalance: (amount) => set((state) => ({ balance: Math.max(0, state.balance - amount) })),
}));
