import { User, Shield, Bell, Key, Smartphone, Mail, Globe } from "lucide-react";

export function Settings() {
  return (
    <div className="max-w-4xl mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold mb-2">Settings</h1>
        <p className="text-zinc-400">
          Manage your account preferences and security settings.
        </p>
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Settings Sidebar */}
        <div className="w-full md:w-64 flex-shrink-0">
          <nav className="flex flex-col gap-2">
            {[
              { id: "profile", name: "Profile", icon: User, active: true },
              { id: "security", name: "Security", icon: Shield, active: false },
              {
                id: "notifications",
                name: "Notifications",
                icon: Bell,
                active: false,
              },
              {
                id: "preferences",
                name: "Preferences",
                icon: Globe,
                active: false,
              },
            ].map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.id}
                  className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-colors text-left ${
                    item.active
                      ? "bg-emerald-500/10 text-emerald-500 font-medium"
                      : "text-zinc-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  <Icon className="w-5 h-5" />
                  {item.name}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Settings Content */}
        <div className="flex-1 space-y-8">
          {/* Profile Section */}
          <section className="bg-[#18181b] border border-white/5 rounded-3xl p-8">
            <h2 className="text-xl font-bold mb-6">Profile Information</h2>

            <div className="flex items-center gap-6 mb-8">
              <div className="w-24 h-24 rounded-full bg-gradient-to-tr from-emerald-500 to-emerald-300 p-1">
                <div className="w-full h-full bg-[#09090b] rounded-full flex items-center justify-center">
                  <User className="w-10 h-10 text-zinc-400" />
                </div>
              </div>
              <div>
                <button className="bg-white/10 hover:bg-white/20 text-white font-semibold py-2 px-4 rounded-lg transition-colors mb-2">
                  Change Avatar
                </button>
                <p className="text-sm text-zinc-500">
                  JPG, GIF or PNG. Max size of 800K
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">
                  Username
                </label>
                <input
                  type="text"
                  defaultValue="minorityprotocol"
                  className="w-full bg-[#09090b] border border-white/10 rounded-xl px-4 py-3 text-white focus:outline-none focus:border-emerald-500 transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-zinc-400 mb-2">
                  Email Address
                </label>
                <div className="relative">
                  <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-zinc-500" />
                  <input
                    type="email"
                    defaultValue="minorityprotocol@gmail.com"
                    className="w-full bg-[#09090b] border border-white/10 rounded-xl pl-12 pr-4 py-3 text-white focus:outline-none focus:border-emerald-500 transition-colors"
                  />
                </div>
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button className="bg-emerald-500 hover:bg-emerald-600 text-black font-bold py-3 px-6 rounded-xl transition-colors">
                Save Changes
              </button>
            </div>
          </section>

          {/* Security Section (Preview) */}
          <section className="bg-[#18181b] border border-white/5 rounded-3xl p-8">
            <h2 className="text-xl font-bold mb-6">Security</h2>

            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 bg-[#09090b] border border-white/5 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-blue-500/10 flex items-center justify-center">
                    <Smartphone className="w-5 h-5 text-blue-500" />
                  </div>
                  <div>
                    <div className="font-semibold text-white">
                      Two-Factor Authentication
                    </div>
                    <div className="text-sm text-zinc-500">
                      Add an extra layer of security to your account.
                    </div>
                  </div>
                </div>
                <button className="bg-white/10 hover:bg-white/20 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
                  Enable
                </button>
              </div>

              <div className="flex items-center justify-between p-4 bg-[#09090b] border border-white/5 rounded-xl">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-purple-500/10 flex items-center justify-center">
                    <Key className="w-5 h-5 text-purple-500" />
                  </div>
                  <div>
                    <div className="font-semibold text-white">
                      Change Password
                    </div>
                    <div className="text-sm text-zinc-500">
                      Last changed 3 months ago.
                    </div>
                  </div>
                </div>
                <button className="bg-white/10 hover:bg-white/20 text-white font-semibold py-2 px-4 rounded-lg transition-colors">
                  Update
                </button>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
}
