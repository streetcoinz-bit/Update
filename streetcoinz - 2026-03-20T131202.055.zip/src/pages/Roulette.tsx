import { useState, useRef } from "react";
import { useWallet } from "../context/WalletContext";
import { CircleDollarSign, Play, RotateCw } from "lucide-react";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "motion/react";

const NUMBERS = [
  0, 32, 15, 19, 4, 21, 2, 25, 17, 34, 6, 27, 13, 36, 11, 30, 8, 23, 10, 5, 24,
  16, 33, 1, 20, 14, 31, 9, 22, 18, 29, 7, 28, 12, 35, 3, 26,
];

const getNumberColor = (num: number) => {
  if (num === 0) return "bg-casino-green text-black";
  return NUMBERS.indexOf(num) % 2 === 0
    ? "bg-black text-white border-white/20"
    : "bg-casino-accent text-white border-casino-accent/50";
};

export function Roulette() {
  const { balance, bet, win } = useWallet();
  const [betAmount, setBetAmount] = useState("10");
  const [selectedNumber, setSelectedNumber] = useState<number | null>(null);
  const [spinning, setSpinning] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [lastWin, setLastWin] = useState<number | null>(null);

  const wheelRef = useRef<HTMLDivElement>(null);

  const handleBet = (num: number) => {
    if (spinning) return;
    setSelectedNumber(num);
  };

  const spinWheel = () => {
    if (selectedNumber === null) {
      alert("Please select a number to bet on.");
      return;
    }

    const val = parseFloat(betAmount);
    if (isNaN(val) || val <= 0) return;

    if (!bet(val)) {
      alert("Insufficient balance");
      return;
    }

    setSpinning(true);
    setResult(null);
    setLastWin(null);

    // Simulate spin
    setTimeout(() => {
      const winningNumber = NUMBERS[Math.floor(Math.random() * NUMBERS.length)];
      setResult(winningNumber);
      setSpinning(false);

      if (winningNumber === selectedNumber) {
        const winnings = val * 36; // 35:1 payout + original bet
        win(winnings);
        setLastWin(winnings);
        confetti({
          particleCount: 150,
          spread: 80,
          origin: { y: 0.6 },
          colors: ["#ff2a5f", "#ffd700", "#00e676"],
        });
      }
    }, 3000);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-[0_0_20px_rgba(59,130,246,0.3)]">
          <CircleDollarSign className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-4xl font-display font-black tracking-tight text-white">
          Quantum Roulette
        </h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Wheel Area */}
        <div className="lg:col-span-1 bg-casino-surface p-8 rounded-3xl border border-white/5 flex flex-col items-center justify-center relative overflow-hidden">
          <div className="absolute inset-0 bg-gradient-to-b from-blue-500/5 to-transparent pointer-events-none" />

          <div className="relative w-64 h-64 flex items-center justify-center">
            {/* Outer Ring */}
            <div className="absolute inset-0 rounded-full border-8 border-white/5 shadow-[0_0_50px_rgba(0,0,0,0.5)]" />

            {/* Inner Wheel (Animated) */}
            <motion.div
              ref={wheelRef}
              animate={{ rotate: spinning ? 360 * 5 : 0 }}
              transition={{ duration: 3, ease: "circOut" }}
              className="absolute inset-4 rounded-full border-4 border-casino-surface-hover bg-black/80 flex items-center justify-center overflow-hidden"
            >
              {/* Simplified wheel segments for visual effect */}
              <div
                className="absolute inset-0"
                style={{
                  background:
                    "conic-gradient(from 0deg, #ff2a5f 0 180deg, #000 180deg 360deg)",
                  opacity: 0.2,
                }}
              />

              <AnimatePresence mode="wait">
                {result !== null && !spinning ? (
                  <motion.div
                    key="result"
                    initial={{ scale: 0, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className={`w-24 h-24 rounded-full flex items-center justify-center text-4xl font-black font-display shadow-[0_0_30px_rgba(255,255,255,0.2)] ${getNumberColor(result)}`}
                  >
                    {result}
                  </motion.div>
                ) : (
                  <motion.div
                    key="idle"
                    className="w-24 h-24 rounded-full bg-casino-surface-hover flex items-center justify-center border border-white/10"
                  >
                    <div className="w-4 h-4 rounded-full bg-white/20" />
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>

            {/* Pointer */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 w-4 h-8 bg-white rounded-b-full shadow-[0_0_10px_rgba(255,255,255,0.5)] z-10" />
          </div>

          {lastWin && (
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="mt-8 px-6 py-2 rounded-full bg-casino-gold/20 border border-casino-gold/50 text-casino-gold font-bold font-mono text-lg shadow-[0_0_20px_rgba(255,215,0,0.3)] neon-text-gold"
            >
              +{lastWin.toFixed(2)} USD
            </motion.div>
          )}
        </div>

        {/* Betting Board */}
        <div className="lg:col-span-2 bg-casino-surface p-8 rounded-3xl border border-white/5 space-y-8">
          <div className="flex items-center justify-between">
            <h3 className="text-xl font-display font-bold text-white">
              Place Your Bet
            </h3>
            <div className="text-sm font-mono text-gray-400">Payout: 36x</div>
          </div>

          {/* Number Grid */}
          <div className="grid grid-cols-12 gap-2">
            {/* Zero */}
            <button
              onClick={() => handleBet(0)}
              disabled={spinning}
              className={`col-span-12 py-3 rounded-lg font-bold font-mono text-lg border transition-all ${
                selectedNumber === 0
                  ? "bg-casino-green text-black border-casino-green shadow-[0_0_15px_rgba(0,230,118,0.4)] scale-105"
                  : "bg-casino-green/20 text-casino-green border-casino-green/30 hover:bg-casino-green/30"
              } disabled:opacity-50 disabled:cursor-not-allowed`}
            >
              0
            </button>

            {/* 1-36 */}
            {Array.from({ length: 36 }, (_, i) => i + 1).map((num) => {
              const isRed = NUMBERS.indexOf(num) % 2 !== 0;
              const isSelected = selectedNumber === num;

              return (
                <button
                  key={num}
                  onClick={() => handleBet(num)}
                  disabled={spinning}
                  className={`col-span-1 py-3 rounded-lg font-bold font-mono text-sm border transition-all ${
                    isSelected
                      ? "ring-2 ring-white ring-offset-2 ring-offset-casino-surface scale-110 z-10 shadow-[0_0_15px_rgba(255,255,255,0.3)]"
                      : "hover:scale-105"
                  } ${
                    isRed
                      ? "bg-casino-accent text-white border-casino-accent/50"
                      : "bg-black text-white border-white/20"
                  } disabled:opacity-50 disabled:cursor-not-allowed`}
                >
                  {num}
                </button>
              );
            })}
          </div>

          {/* Controls */}
          <div className="flex items-end gap-6 pt-4 border-t border-white/5">
            <div className="flex-1 space-y-2">
              <label className="text-xs font-mono text-gray-500 uppercase tracking-wider pl-2">
                Bet Amount
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-mono">
                  $
                </span>
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  disabled={spinning}
                  className="w-full bg-black/40 border border-white/10 rounded-xl py-4 pl-8 pr-4 text-xl font-mono text-white focus:border-casino-accent outline-none disabled:opacity-50 transition-colors"
                />
              </div>
            </div>

            <button
              onClick={spinWheel}
              disabled={spinning || selectedNumber === null}
              className="px-12 py-4 rounded-xl font-black text-xl tracking-wider flex items-center justify-center gap-3 bg-gradient-to-br from-blue-500 to-indigo-600 hover:from-blue-400 hover:to-indigo-500 text-white shadow-[0_0_30px_rgba(59,130,246,0.4)] disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:scale-[1.02] active:scale-[0.98]"
            >
              {spinning ? (
                <RotateCw className="w-6 h-6 animate-spin" />
              ) : (
                <>
                  SPIN
                  <Play className="w-5 h-5 fill-current" />
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
