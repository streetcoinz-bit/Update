import { useState } from 'react';
import { motion } from 'motion/react';
import { useOutletContext } from 'react-router-dom';
import { Dices, AlertCircle } from 'lucide-react';

export default function Dice() {
  const { balance } = useOutletContext<{ balance: number, fetchUser: () => void }>();
  const [betAmount, setBetAmount] = useState<number>(10);
  const [multiplier, setMultiplier] = useState<number>(2.0);
  const [rolling, setRolling] = useState(false);
  const [result, setResult] = useState<{ roll: number, won: boolean } | null>(null);
  const [error, setError] = useState('');

  const winChance = (98 / multiplier).toFixed(2);

  const handleRoll = async () => {
    if (betAmount > balance) {
      setError('Insufficient balance');
      return;
    }
    if (multiplier < 1.01 || multiplier > 100) {
      setError('Multiplier must be between 1.01 and 100');
      return;
    }
    setError('');
    setRolling(true);
    setResult(null);

    try {
      const res = await fetch('/api/play/dice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ betAmount, multiplier })
      });
      const data = await res.json();

      if (res.ok) {
        setTimeout(() => {
          setResult(data);
          setRolling(false);
          window.dispatchEvent(new Event('balance-update'));
        }, 600); // Fake delay for suspense
      } else {
        setError(data.error);
        setRolling(false);
      }
    } catch (err) {
      setError('Network error');
      setRolling(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold text-white flex items-center gap-3">
          <Dices className="w-8 h-8 text-violet-500" />
          Street Dice
        </h1>
        <p className="text-zinc-400 mt-2">Provably fair dice game. Set your multiplier and roll.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls */}
        <div className="bg-[#18181b] p-6 rounded-2xl border border-white/5 flex flex-col gap-6">
          <div>
            <label className="text-sm font-medium text-zinc-400 mb-2 block">Bet Amount</label>
            <div className="relative">
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full bg-[#09090b] border border-white/10 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-violet-500 transition-colors"
              />
              <div className="absolute right-3 top-1/2 -translate-y-1/2 flex gap-2">
                <button onClick={() => setBetAmount(b => b / 2)} className="bg-zinc-800 hover:bg-zinc-700 text-xs px-2 py-1 rounded text-zinc-300">1/2</button>
                <button onClick={() => setBetAmount(b => b * 2)} className="bg-zinc-800 hover:bg-zinc-700 text-xs px-2 py-1 rounded text-zinc-300">2x</button>
              </div>
            </div>
          </div>

          <div>
            <label className="text-sm font-medium text-zinc-400 mb-2 block">Multiplier</label>
            <div className="relative">
              <input
                type="number"
                step="0.01"
                value={multiplier}
                onChange={(e) => setMultiplier(Number(e.target.value))}
                className="w-full bg-[#09090b] border border-white/10 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-violet-500 transition-colors"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 text-zinc-500 font-mono">x</span>
            </div>
          </div>

          <div className="bg-[#09090b] rounded-xl p-4 border border-white/5 flex justify-between items-center">
            <span className="text-zinc-400 text-sm">Win Chance</span>
            <span className="text-emerald-400 font-mono font-medium">{winChance}%</span>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 p-3 rounded-lg">
              <AlertCircle className="w-4 h-4" />
              {error}
            </div>
          )}

          <button
            onClick={handleRoll}
            disabled={rolling}
            className="w-full bg-violet-600 hover:bg-violet-700 disabled:opacity-50 disabled:cursor-not-allowed text-white font-bold py-4 rounded-xl transition-all active:scale-[0.98] mt-auto"
          >
            {rolling ? 'Rolling...' : 'Roll Dice'}
          </button>
        </div>

        {/* Game Area */}
        <div className="lg:col-span-2 bg-[#18181b] p-8 rounded-2xl border border-white/5 flex flex-col items-center justify-center min-h-[400px] relative overflow-hidden">
          {/* Background decoration */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(139,92,246,0.1)_0%,transparent_70%)] pointer-events-none" />

          <div className="relative z-10 flex flex-col items-center">
            {rolling ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 0.5, ease: "linear" }}
              >
                <Dices className="w-24 h-24 text-violet-500 opacity-50" />
              </motion.div>
            ) : result ? (
              <motion.div
                initial={{ scale: 0.8, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className="flex flex-col items-center"
              >
                <div className={`text-7xl font-display font-bold mb-4 ${result.won ? 'text-emerald-400' : 'text-red-500'}`}>
                  {result.roll.toFixed(2)}
                </div>
                <div className={`text-xl font-medium px-6 py-2 rounded-full ${result.won ? 'bg-emerald-500/20 text-emerald-400' : 'bg-red-500/20 text-red-400'}`}>
                  {result.won ? `You won $${((betAmount * multiplier) - betAmount).toFixed(2)}!` : 'You lost'}
                </div>
              </motion.div>
            ) : (
              <div className="text-center">
                <Dices className="w-24 h-24 text-zinc-700 mx-auto mb-6" />
                <p className="text-zinc-500 font-medium text-lg">Waiting for your roll...</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
