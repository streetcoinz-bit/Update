import React from 'react';
import { GameCard } from '../components/GameCard';
import { Flame, Trophy, Clock, ChevronRight } from 'lucide-react';

export function Dashboard() {
  const featuredGames = [
    { title: 'Neon Roulette', provider: 'Evolution', imageSeed: 'roulette', isHot: true, players: 1240 },
    { title: 'Golden Slots', provider: 'Pragmatic Play', imageSeed: 'slots', isNew: true, players: 850 },
    { title: 'Cyber Blackjack', provider: 'NetEnt', imageSeed: 'blackjack', players: 420 },
    { title: 'Crash Street', provider: 'StreetCoinz Games', image: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Crash.jpg', isHot: true, players: 3100 },
  ];

  const liveGames = [
    { title: 'Live Baccarat VIP', provider: 'Evolution', imageSeed: 'baccarat', players: 150 },
    { title: 'Lightning Dice', provider: 'StreetCoinz Games', image: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Dice.jpg', isHot: true, players: 890 },
    { title: 'Monopoly Live', provider: 'Evolution', imageSeed: 'monopoly', players: 2100 },
    { title: 'Crazy Time', provider: 'Evolution', imageSeed: 'crazytime', isHot: true, players: 4500 },
  ];

  return (
    <div className="space-y-12 pb-12">
      {/* Hero Section */}
      <section className="relative rounded-3xl overflow-hidden h-[400px] flex items-center">
        <div className="absolute inset-0">
          <img
            src="https://picsum.photos/seed/casino-hero/1920/1080?blur=2"
            alt="Hero Background"
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent"></div>
        </div>
        
        <div className="relative z-10 p-12 max-w-2xl">
          <span className="inline-block px-3 py-1 mb-4 text-xs font-bold uppercase tracking-widest text-[var(--color-brand-gold)] border border-[var(--color-brand-gold)]/30 rounded-full bg-black/50 backdrop-blur-md">
            Welcome Bonus
          </span>
          <h1 className="text-5xl font-serif font-bold text-white mb-4 leading-tight">
            Claim Your <span className="gold-gradient-text">200% Match</span><br />
            Up To 5,000 SCZ
          </h1>
          <p className="text-lg text-[var(--color-text-secondary)] mb-8 max-w-lg">
            Experience the ultimate premium casino platform. High stakes, instant payouts, and exclusive VIP rewards.
          </p>
          <div className="flex items-center gap-4">
            <button className="px-8 py-4 bg-gradient-to-r from-[var(--color-brand-gold)] to-[var(--color-brand-gold-dark)] text-black font-bold rounded-xl hover:scale-105 transition-transform shadow-[0_0_20px_rgba(212,175,55,0.3)]">
              Deposit Now
            </button>
            <button className="px-8 py-4 bg-white/5 hover:bg-white/10 text-white font-medium rounded-xl border border-white/10 backdrop-blur-md transition-colors">
              Read Terms
            </button>
          </div>
        </div>
      </section>

      {/* Featured Games */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-red-500/20 flex items-center justify-center">
              <Flame className="w-5 h-5 text-red-500" />
            </div>
            <h2 className="text-2xl font-serif font-bold text-white">Trending Now</h2>
          </div>
          <button className="flex items-center gap-1 text-sm font-medium text-[var(--color-brand-gold)] hover:text-[var(--color-brand-gold-light)] transition-colors">
            View All <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {featuredGames.map((game, index) => (
            <GameCard key={index} {...game} />
          ))}
        </div>
      </section>

      {/* Live Casino */}
      <section>
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[var(--color-brand-neon-dim)] flex items-center justify-center">
              <Trophy className="w-5 h-5 text-[var(--color-brand-neon)]" />
            </div>
            <h2 className="text-2xl font-serif font-bold text-white">Live Dealers</h2>
          </div>
          <button className="flex items-center gap-1 text-sm font-medium text-[var(--color-brand-gold)] hover:text-[var(--color-brand-gold-light)] transition-colors">
            View All <ChevronRight className="w-4 h-4" />
          </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {liveGames.map((game, index) => (
            <GameCard key={index} {...game} />
          ))}
        </div>
      </section>
    </div>
  );
}
