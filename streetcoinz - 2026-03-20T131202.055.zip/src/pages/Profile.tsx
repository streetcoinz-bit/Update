import React from 'react';
import { Shield, Mail, Lock, Smartphone, CheckCircle2 } from 'lucide-react';

export function Profile() {
  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-4xl font-serif font-bold text-white mb-2">Profile Settings</h1>
        <p className="text-[var(--color-text-secondary)]">Manage your account details and security</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Sidebar / Nav */}
        <div className="space-y-2">
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl bg-[var(--color-bg-panel)] border border-[var(--color-brand-gold)]/30 text-[var(--color-brand-gold)] font-medium">
            <Shield className="w-5 h-5" /> Security
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-panel)] hover:text-white transition-colors font-medium">
            <Mail className="w-5 h-5" /> Preferences
          </button>
          <button className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-[var(--color-text-secondary)] hover:bg-[var(--color-bg-panel)] hover:text-white transition-colors font-medium">
            <CheckCircle2 className="w-5 h-5" /> Verification (KYC)
          </button>
        </div>

        {/* Main Content */}
        <div className="md:col-span-2 space-y-6">
          {/* Personal Info */}
          <div className="glass-panel rounded-3xl p-8 border border-white/5">
            <h3 className="text-xl font-bold text-white mb-6">Personal Information</h3>
            
            <div className="flex items-center gap-6 mb-8">
              <img
                src="https://picsum.photos/seed/avatar1/150/150"
                alt="Avatar"
                className="w-24 h-24 rounded-full border-4 border-[var(--color-bg-dark)] shadow-[0_0_0_2px_var(--color-brand-gold)] object-cover"
                referrerPolicy="no-referrer"
              />
              <div>
                <button className="px-4 py-2 bg-[var(--color-bg-panel)] border border-white/10 rounded-lg text-sm font-medium text-white hover:bg-white/5 transition-colors mb-2">
                  Change Avatar
                </button>
                <p className="text-xs text-[var(--color-text-secondary)]">JPG, GIF or PNG. Max size of 2MB.</p>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">First Name</label>
                <input 
                  type="text" 
                  defaultValue="Alex"
                  className="w-full bg-[var(--color-bg-dark)] border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-[var(--color-brand-gold)]/50 transition-colors"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">Last Name</label>
                <input 
                  type="text" 
                  defaultValue="Player"
                  className="w-full bg-[var(--color-bg-dark)] border border-white/10 rounded-xl py-3 px-4 text-white focus:outline-none focus:border-[var(--color-brand-gold)]/50 transition-colors"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-sm font-medium text-[var(--color-text-secondary)] mb-2">Email Address</label>
                <div className="relative">
                  <input 
                    type="email" 
                    defaultValue="alex.player@example.com"
                    disabled
                    className="w-full bg-[var(--color-bg-dark)] border border-white/5 rounded-xl py-3 px-4 text-[var(--color-text-secondary)] opacity-70 cursor-not-allowed"
                  />
                  <span className="absolute right-4 top-1/2 -translate-y-1/2 text-xs font-bold uppercase text-[var(--color-brand-neon)] flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Verified
                  </span>
                </div>
              </div>
            </div>
            
            <div className="mt-8 flex justify-end">
              <button className="px-6 py-3 bg-white text-black font-bold rounded-xl hover:bg-gray-200 transition-colors">
                Save Changes
              </button>
            </div>
          </div>

          {/* Security */}
          <div className="glass-panel rounded-3xl p-8 border border-white/5">
            <h3 className="text-xl font-bold text-white mb-6">Security Settings</h3>
            
            <div className="space-y-6">
              <div className="flex items-center justify-between p-4 rounded-xl bg-[var(--color-bg-dark)] border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center">
                    <Lock className="w-5 h-5 text-[var(--color-text-secondary)]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Password</p>
                    <p className="text-xs text-[var(--color-text-secondary)]">Last changed 3 months ago</p>
                  </div>
                </div>
                <button className="px-4 py-2 bg-[var(--color-bg-panel)] border border-white/10 rounded-lg text-sm font-medium text-white hover:bg-white/5 transition-colors">
                  Update
                </button>
              </div>

              <div className="flex items-center justify-between p-4 rounded-xl bg-[var(--color-bg-dark)] border border-white/5">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 rounded-full bg-[var(--color-brand-neon)]/10 flex items-center justify-center">
                    <Smartphone className="w-5 h-5 text-[var(--color-brand-neon)]" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-white">Two-Factor Authentication (2FA)</p>
                    <p className="text-xs text-[var(--color-brand-neon)]">Currently Enabled</p>
                  </div>
                </div>
                <button className="px-4 py-2 bg-[var(--color-bg-panel)] border border-white/10 rounded-lg text-sm font-medium text-white hover:bg-white/5 transition-colors">
                  Manage
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
