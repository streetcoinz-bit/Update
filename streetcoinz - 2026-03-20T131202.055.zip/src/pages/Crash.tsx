import { useState, useEffect } from "react";
import { motion } from "motion/react";
import { Flame, Rocket, TrendingUp } from "lucide-react";

export function Crash() {
  const [multiplier, setMultiplier] = useState(1.0);
  const [gameState, setGameState] = useState<"betting" | "playing" | "crashed">(
    "betting",
  );
  const [betAmount, setBetAmount] = useState(10);

  // Simulated game loop
  useEffect(() => {
    let interval: NodeJS.Timeout;

    if (gameState === "playing") {
      interval = setInterval(() => {
        setMultiplier((prev) => {
          const next = prev + prev * 0.01 + 0.01;
          // Random crash logic
          if (Math.random() < 0.02 && next > 1.2) {
            setGameState("crashed");
            return prev;
          }
          return next;
        });
      }, 50);
    } else if (gameState === "crashed") {
      setTimeout(() => {
        setGameState("betting");
        setMultiplier(1.0);
      }, 5000);
    }

    return () => clearInterval(interval);
  }, [gameState]);

  const handleBet = () => {
    if (gameState === "betting") {
      setGameState("playing");
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6 pb-12">
      <div className="flex items-center gap-3 mb-6">
        <div className="w-10 h-10 rounded-xl bg-orange-500/20 text-orange-400 flex items-center justify-center border border-orange-500/30">
          <Rocket className="w-5 h-5" />
        </div>
        <h1 className="text-3xl font-black text-white">Street Crash</h1>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Game Area */}
        <div className="lg:col-span-3 bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden flex flex-col relative min-h-[500px]">
          {/* Chart Area */}
          <div className="flex-1 relative flex items-center justify-center p-8">
            {/* Grid Background */}
            <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>

            {/* Multiplier Display */}
            <div className="relative z-10 text-center">
              <motion.div
                animate={{
                  scale: gameState === "playing" ? [1, 1.05, 1] : 1,
                  color:
                    gameState === "crashed"
                      ? "#ef4444"
                      : gameState === "playing"
                        ? "#10b981"
                        : "#ffffff",
                }}
                transition={{
                  duration: 0.5,
                  repeat: gameState === "playing" ? Infinity : 0,
                }}
                className={`text-7xl md:text-9xl font-black tracking-tighter ${gameState === "crashed" ? "text-red-500" : "text-emerald-400"}`}
              >
                {multiplier.toFixed(2)}x
              </motion.div>

              <div className="mt-4 text-xl font-bold text-zinc-400 uppercase tracking-widest">
                {gameState === "betting" && "Place your bets"}
                {gameState === "playing" && "Flying..."}
                {gameState === "crashed" && "Crashed!"}
              </div>
            </div>

            {/* Rocket Animation (Simplified) */}
            {gameState === "playing" && (
              <motion.div
                className="absolute bottom-10 left-10 text-orange-500"
                animate={{
                  x: [0, 100, 200, 300, 400],
                  y: [0, -50, -150, -250, -350],
                  rotate: [45, 45, 45, 45, 45],
                }}
                transition={{ duration: 10, ease: "linear" }}
              >
                <Rocket className="w-12 h-12 fill-orange-500 drop-shadow-[0_0_15px_rgba(249,115,22,0.8)]" />
              </motion.div>
            )}
          </div>

          {/* Controls */}
          <div className="bg-zinc-950 p-6 border-t border-zinc-800 flex flex-col md:flex-row gap-4 items-center justify-between">
            <div className="flex-1 w-full max-w-md bg-zinc-900 rounded-xl p-2 flex items-center border border-zinc-800">
              <div className="px-4 text-zinc-400 font-bold">$</div>
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="bg-transparent border-none outline-none text-white font-bold w-full"
                disabled={gameState !== "betting"}
              />
              <div className="flex gap-1 px-2">
                <button className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold text-zinc-300 transition-colors">
                  1/2
                </button>
                <button className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold text-zinc-300 transition-colors">
                  2x
                </button>
                <button className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold text-zinc-300 transition-colors">
                  Max
                </button>
              </div>
            </div>

            <button
              onClick={handleBet}
              disabled={gameState === "crashed"}
              className={`w-full md:w-auto px-12 py-4 rounded-xl font-black text-xl transition-all ${
                gameState === "betting"
                  ? "bg-emerald-500 hover:bg-emerald-400 text-zinc-950 shadow-[0_0_20px_rgba(52,211,153,0.4)]"
                  : gameState === "playing"
                    ? "bg-orange-500 hover:bg-orange-400 text-zinc-950 shadow-[0_0_20px_rgba(249,115,22,0.4)]"
                    : "bg-zinc-800 text-zinc-500 cursor-not-allowed"
              }`}
            >
              {gameState === "betting"
                ? "BET"
                : gameState === "playing"
                  ? "CASHOUT"
                  : "WAIT"}
            </button>
          </div>
        </div>

        {/* Sidebar / Players */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 flex flex-col h-[500px]">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              Live Bets
            </h3>
            <span className="text-xs text-zinc-500 font-medium">
              142 Players
            </span>
          </div>

          <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
            <PlayerRow
              name="CryptoWhale"
              bet="$500"
              multiplier="-"
              profit="-"
              playing={gameState === "playing"}
            />
            <PlayerRow
              name="Alex99"
              bet="$50"
              multiplier="2.50x"
              profit="+$125"
              playing={false}
            />
            <PlayerRow
              name="LuckyStar"
              bet="$10"
              multiplier="-"
              profit="-"
              playing={gameState === "playing"}
            />
            <PlayerRow
              name="NeonRider"
              bet="$100"
              multiplier="1.50x"
              profit="+$150"
              playing={false}
            />
            <PlayerRow
              name="StreetKing"
              bet="$250"
              multiplier="-"
              profit="-"
              playing={gameState === "playing"}
            />
            <PlayerRow
              name="Gamer123"
              bet="$5"
              multiplier="5.00x"
              profit="+$25"
              playing={false}
            />
            <PlayerRow
              name="HighRoller"
              bet="$1000"
              multiplier="-"
              profit="-"
              playing={gameState === "playing"}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

function PlayerRow({
  name,
  bet,
  multiplier,
  profit,
  playing,
}: {
  name: string;
  bet: string;
  multiplier: string;
  profit: string;
  playing: boolean;
}) {
  return (
    <div
      className={`flex items-center justify-between p-2 rounded-lg text-sm ${playing ? "bg-zinc-800/50" : "bg-emerald-500/10"}`}
    >
      <div className="font-medium text-zinc-300 truncate w-24">{name}</div>
      <div className="text-zinc-400 font-mono">{bet}</div>
      <div
        className={`font-mono font-bold ${playing ? "text-zinc-500" : "text-emerald-400"}`}
      >
        {multiplier}
      </div>
      <div
        className={`font-bold ${playing ? "text-zinc-500" : "text-emerald-400"}`}
      >
        {profit}
      </div>
    </div>
  );
}
