import { useState, useEffect } from "react";
import { useParams, Link } from "react-router-dom";
import {
  ArrowLeft,
  Maximize2,
  Settings,
  Volume2,
  History,
  Info,
  TrendingUp,
  TrendingDown,
  Activity,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { TickChart } from "../components/TickChart";
import { MobileBetControls } from "../components/MobileBetControls";

export function Game() {
  const { id } = useParams();
  const [ticks, setTicks] = useState<{ time: string; price: number }[]>([]);
  const [currentPrice, setCurrentPrice] = useState(100);
  const [isPositive, setIsPositive] = useState(true);
  const [balance] = useState(1243.50);

  // Mock game data based on ID
  const gameName = id ? id.charAt(0).toUpperCase() + id.slice(1) : "Game";

  // Simulate real-time ticks
  useEffect(() => {
    const initialTicks = Array.from({ length: 20 }).map((_, i) => ({
      time: new Date(Date.now() - (20 - i) * 1000).toLocaleTimeString(),
      price: 100 + Math.random() * 10 - 5,
    }));
    setTicks(initialTicks);
    setCurrentPrice(initialTicks[initialTicks.length - 1].price);

    const interval = setInterval(() => {
      setTicks((prev) => {
        const lastTick = prev[prev.length - 1];
        const newPrice = lastTick.price + (Math.random() * 2 - 1);
        const newTick = {
          time: new Date().toLocaleTimeString(),
          price: newPrice,
        };
        setCurrentPrice(newPrice);
        setIsPositive(newPrice > lastTick.price);
        return [...prev.slice(1), newTick];
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [currentPrice]);

  const handlePlaceBet = (amount: number, direction: 'UP' | 'DOWN') => {
    console.log(`Placed bet: ${amount} SC on ${direction}`);
    // Handle bet logic here
  };

  return (
    <div className="min-h-screen bg-[#09090b] flex flex-col">
      {/* Top Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/5 bg-[#131212] shrink-0">
        <Link
          to="/"
          className="p-2 -ml-2 text-zinc-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </Link>

        <div className="flex flex-col items-center">
          <h1 className="text-lg font-display font-bold text-white leading-tight">
            {gameName}
          </h1>
          <div className="flex items-center gap-1.5">
            <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">
              Live // 1,243 Active
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button className="p-2 text-zinc-400 hover:text-white transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Game Area (Tick Chart) */}
        <div className="flex-1 relative bg-[#09090b] flex flex-col min-h-0">
          {/* Price Overlay */}
          <div className="absolute top-6 left-6 z-10 pointer-events-none">
            <div className="flex flex-col">
              <span className="text-xs text-zinc-500 font-mono uppercase tracking-widest mb-1">
                Current Price
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-4xl font-mono font-bold text-white tracking-tighter">
                  ${currentPrice.toFixed(2)}
                </span>
                <div className={`flex items-center gap-0.5 text-sm font-bold ${isPositive ? 'text-emerald-500' : 'text-red-500'}`}>
                  {isPositive ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
                  <span>{isPositive ? '+' : '-'}{(Math.random() * 0.5).toFixed(2)}%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Real-time Chart */}
          <div className="flex-1 pt-24 pb-8 px-4">
            <TickChart data={ticks} isPositive={isPositive} />
          </div>

          {/* Game Status Overlay */}
          <div className="absolute bottom-6 left-1/2 -translate-x-1/2 z-10">
            <div className="bg-black/40 backdrop-blur-md border border-white/10 px-4 py-2 rounded-full flex items-center gap-3">
              <Activity className="w-4 h-4 text-emerald-500" />
              <span className="text-xs font-bold text-white/80 uppercase tracking-widest">
                Round starting in 5s...
              </span>
            </div>
          </div>
        </div>

        {/* Mobile Betting Controls */}
        <MobileBetControls 
          balance={balance} 
          onPlaceBet={handlePlaceBet} 
        />
      </div>

      {/* Secondary Info (Desktop only or expandable on mobile) */}
      <div className="hidden lg:block bg-[#18181b] border-t border-white/5 p-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-center gap-6 border-b border-white/5 pb-4 mb-6">
            <button className="flex items-center gap-2 text-emerald-500 font-semibold border-b-2 border-emerald-500 pb-4 -mb-[18px]">
              <History className="w-4 h-4" /> My Bets
            </button>
            <button className="flex items-center gap-2 text-zinc-500 hover:text-zinc-300 font-semibold pb-4 -mb-[18px] transition-colors">
              <Info className="w-4 h-4" /> Game Info
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="text-xs text-zinc-500 uppercase tracking-wider border-b border-white/5">
                  <th className="pb-3 font-medium">Time</th>
                  <th className="pb-3 font-medium">Bet</th>
                  <th className="pb-3 font-medium">Multiplier</th>
                  <th className="pb-3 font-medium text-right">Payout</th>
                </tr>
              </thead>
              <tbody className="text-sm font-mono">
                {[1, 2, 3, 4, 5].map((i) => (
                  <tr
                    key={i}
                    className="border-b border-white/5/50 hover:bg-white/5 transition-colors"
                  >
                    <td className="py-3 text-zinc-400">14:2{i}:05</td>
                    <td className="py-3 text-white">10.00 SC</td>
                    <td className="py-3 text-emerald-500">2.4{i}x</td>
                    <td className="py-3 text-emerald-500 text-right font-bold">
                      +24.{i}0 SC
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
