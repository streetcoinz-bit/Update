import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { useCasino } from '../context/CasinoContext';
import { Settings, Info, History } from 'lucide-react';

export default function DiceGame() {
  const { balance, updateBalance, addHistory, history } = useCasino();
  
  const [betAmount, setBetAmount] = useState<number>(10);
  const [target, setTarget] = useState<number>(50.5);
  const [condition, setCondition] = useState<'over' | 'under'>('over');
  
  const [isRolling, setIsRolling] = useState(false);
  const [lastRoll, setLastRoll] = useState<number | null>(null);
  const [winStatus, setWinStatus] = useState<'win' | 'loss' | null>(null);

  // Derived values
  const winChance = condition === 'over' ? 99.99 - target : target;
  const multiplier = 99 / winChance;
  const payoutOnWin = betAmount * multiplier;

  const handleRoll = () => {
    if (betAmount > balance || betAmount <= 0) return;
    
    setIsRolling(true);
    setWinStatus(null);
    
    // Deduct bet immediately
    updateBalance(-betAmount);

    // Simulate network/rolling delay
    setTimeout(() => {
      // Generate random number between 0.00 and 100.00
      const roll = Number((Math.random() * 100).toFixed(2));
      setLastRoll(roll);
      
      const isWin = condition === 'over' ? roll > target : roll < target;
      
      if (isWin) {
        setWinStatus('win');
        const profit = payoutOnWin - betAmount;
        updateBalance(payoutOnWin);
        addHistory({
          id: Math.random().toString(36).substr(2, 9),
          game: 'Dice',
          betAmount,
          payout: payoutOnWin,
          profit,
          time: new Date(),
          won: true
        });
      } else {
        setWinStatus('loss');
        addHistory({
          id: Math.random().toString(36).substr(2, 9),
          game: 'Dice',
          betAmount,
          payout: 0,
          profit: -betAmount,
          time: new Date(),
          won: false
        });
      }
      
      setIsRolling(false);
    }, 600);
  };

  return (
    <div className="max-w-5xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-display font-bold text-white">Original Dice</h1>
        <div className="flex gap-2">
          <button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 transition-colors">
            <History className="w-5 h-5" />
          </button>
          <button className="p-2 bg-slate-800 hover:bg-slate-700 rounded-lg text-slate-400 transition-colors">
            <Settings className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Controls Panel */}
        <div className="lg:col-span-1 bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col gap-6">
          {/* Bet Amount */}
          <div>
            <div className="flex justify-between mb-2">
              <label className="text-sm font-medium text-slate-400">Bet Amount</label>
              <span className="text-sm font-medium text-slate-300">${betAmount.toFixed(2)}</span>
            </div>
            <div className="flex bg-slate-950 rounded-xl border border-slate-800 p-1 focus-within:border-amber-500/50 transition-colors">
              <div className="pl-3 flex items-center justify-center text-amber-500 font-bold">
                SCZ
              </div>
              <input 
                type="number" 
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full bg-transparent border-none outline-none text-white font-mono text-right pr-3 py-2"
                min="0.01"
                step="1"
              />
              <div className="flex gap-1 pr-1">
                <button 
                  onClick={() => setBetAmount(prev => Math.max(0.01, prev / 2))}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold text-slate-300 transition-colors"
                >
                  ½
                </button>
                <button 
                  onClick={() => setBetAmount(prev => prev * 2)}
                  className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 rounded-lg text-xs font-bold text-slate-300 transition-colors"
                >
                  2x
                </button>
              </div>
            </div>
          </div>

          {/* Profit on Win */}
          <div>
            <div className="flex justify-between mb-2">
              <label className="text-sm font-medium text-slate-400">Profit on Win</label>
            </div>
            <div className="flex bg-slate-950 rounded-xl border border-slate-800 p-1 opacity-70">
              <div className="pl-3 flex items-center justify-center text-emerald-500 font-bold">
                SCZ
              </div>
              <input 
                type="text" 
                value={(payoutOnWin - betAmount).toFixed(2)}
                readOnly
                className="w-full bg-transparent border-none outline-none text-emerald-400 font-mono text-right pr-3 py-2"
              />
            </div>
          </div>

          <button 
            onClick={handleRoll}
            disabled={isRolling || betAmount > balance || betAmount <= 0}
            className="w-full py-4 rounded-xl font-display font-bold text-lg uppercase tracking-wider transition-all
              disabled:opacity-50 disabled:cursor-not-allowed
              bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-[0_0_20px_rgba(245,158,11,0.2)] hover:shadow-[0_0_30px_rgba(245,158,11,0.4)]"
          >
            {isRolling ? 'Rolling...' : 'Bet'}
          </button>
        </div>

        {/* Game Area */}
        <div className="lg:col-span-2 bg-slate-900 border border-slate-800 rounded-2xl p-6 flex flex-col">
          
          {/* Main Display */}
          <div className="flex-1 flex flex-col items-center justify-center py-12 relative">
            <div className="absolute top-0 right-0 flex gap-2">
              <button 
                onClick={() => setCondition('under')}
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${condition === 'under' ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
              >
                Roll Under
              </button>
              <button 
                onClick={() => setCondition('over')}
                className={`px-4 py-2 rounded-lg text-sm font-bold transition-colors ${condition === 'over' ? 'bg-slate-700 text-white' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}
              >
                Roll Over
              </button>
            </div>

            <div className="text-center mt-8">
              <AnimatePresence mode="wait">
                <motion.div
                  key={lastRoll !== null ? lastRoll : 'empty'}
                  initial={{ scale: 0.8, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className={`text-8xl font-display font-black tracking-tighter ${
                    winStatus === 'win' ? 'text-emerald-500 drop-shadow-[0_0_30px_rgba(16,185,129,0.5)]' : 
                    winStatus === 'loss' ? 'text-rose-500 drop-shadow-[0_0_30px_rgba(244,63,94,0.5)]' : 
                    'text-white'
                  }`}
                >
                  {lastRoll !== null ? lastRoll.toFixed(2) : '00.00'}
                </motion.div>
              </AnimatePresence>
              <p className="text-slate-400 mt-4 font-medium">
                Target: {condition === 'over' ? '>' : '<'} {target.toFixed(2)}
              </p>
            </div>
          </div>

          {/* Slider Area */}
          <div className="mt-auto pt-8 border-t border-slate-800">
            <div className="mb-8 relative">
              {/* Custom Slider Track */}
              <div className="h-4 bg-slate-950 rounded-full relative overflow-hidden border border-slate-800">
                <div 
                  className={`absolute h-full transition-all duration-300 ${condition === 'under' ? 'bg-emerald-500/20' : 'bg-rose-500/20'}`}
                  style={{ width: `${target}%`, left: 0 }}
                />
                <div 
                  className={`absolute h-full transition-all duration-300 ${condition === 'over' ? 'bg-emerald-500/20' : 'bg-rose-500/20'}`}
                  style={{ width: `${100 - target}%`, left: `${target}%` }}
                />
              </div>
              <input 
                type="range" 
                min="2" 
                max="98" 
                step="0.01"
                value={target}
                onChange={(e) => setTarget(Number(e.target.value))}
                className="absolute top-0 w-full h-4 opacity-0 cursor-pointer"
              />
              {/* Custom Thumb Indicator */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 w-6 h-6 bg-white rounded-full shadow-lg border-4 border-slate-900 pointer-events-none transition-all duration-75"
                style={{ left: `calc(${target}% - 12px)` }}
              />
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 bg-slate-950 rounded-xl p-2 border border-slate-800">
              <div className="bg-slate-900 rounded-lg p-3 text-center">
                <p className="text-xs text-slate-500 font-semibold uppercase mb-1">Multiplier</p>
                <p className="text-lg font-mono font-bold text-white">{multiplier.toFixed(4)}x</p>
              </div>
              <div className="bg-slate-900 rounded-lg p-3 text-center">
                <p className="text-xs text-slate-500 font-semibold uppercase mb-1">Roll {condition}</p>
                <p className="text-lg font-mono font-bold text-white">{target.toFixed(2)}</p>
              </div>
              <div className="bg-slate-900 rounded-lg p-3 text-center">
                <p className="text-xs text-slate-500 font-semibold uppercase mb-1">Win Chance</p>
                <p className="text-lg font-mono font-bold text-white">{winChance.toFixed(2)}%</p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* Live Bets Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl overflow-hidden">
        <div className="p-4 border-b border-slate-800 flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></div>
          <h3 className="font-display font-bold text-white">My Bets</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-950 text-slate-400 font-medium">
              <tr>
                <th className="px-6 py-4">Game</th>
                <th className="px-6 py-4">Time</th>
                <th className="px-6 py-4 text-right">Bet Amount</th>
                <th className="px-6 py-4 text-right">Multiplier</th>
                <th className="px-6 py-4 text-right">Payout</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/50">
              {history.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-8 text-center text-slate-500">
                    No bets placed yet.
                  </td>
                </tr>
              ) : (
                history.map((bet) => (
                  <tr key={bet.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="px-6 py-4 font-medium text-white">{bet.game}</td>
                    <td className="px-6 py-4 text-slate-400">
                      {new Date(bet.time).toLocaleTimeString()}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-slate-300">
                      {bet.betAmount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 text-right font-mono text-slate-400">
                      {bet.won ? (bet.payout / bet.betAmount).toFixed(2) + 'x' : '0.00x'}
                    </td>
                    <td className={`px-6 py-4 text-right font-mono font-bold ${bet.won ? 'text-emerald-500' : 'text-slate-500'}`}>
                      {bet.won ? '+' + bet.payout.toFixed(2) : '0.00'}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
