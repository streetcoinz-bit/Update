import {
  ArrowDownLeft,
  ArrowUpRight,
  Copy,
  CreditCard,
  History,
  Wallet as WalletIcon,
} from "lucide-react";
import { motion } from "motion/react";

export function Wallet() {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-12">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
          <WalletIcon className="w-5 h-5" />
        </div>
        <h1 className="text-3xl font-black text-white">Wallet</h1>
      </div>

      {/* Balance Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute top-0 right-0 p-4 opacity-10">
            <WalletIcon className="w-32 h-32 text-white" />
          </div>
          <div className="relative z-10">
            <div className="text-sm text-zinc-400 mb-2 font-medium">
              Total Balance
            </div>
            <div className="text-4xl font-black text-white mb-6">$2,450.00</div>

            <div className="flex gap-3">
              <button className="flex-1 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold py-3 rounded-xl transition-colors shadow-[0_0_15px_rgba(52,211,153,0.3)] flex items-center justify-center gap-2">
                <ArrowDownLeft className="w-5 h-5" />
                Deposit
              </button>
              <button className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-white font-bold py-3 rounded-xl transition-colors border border-zinc-700 flex items-center justify-center gap-2">
                <ArrowUpRight className="w-5 h-5" />
                Withdraw
              </button>
            </div>
          </div>
        </div>

        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col justify-between">
          <div>
            <div className="text-sm text-zinc-400 mb-4 font-medium">
              Quick Deposit Address (USDT TRC20)
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 flex items-center justify-between group">
              <code className="text-sm text-emerald-400 font-mono truncate mr-4">
                T9yD14Nj9j7xAB4dbGeiX9h8unkK...
              </code>
              <button className="p-2 bg-zinc-800 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-700 transition-colors">
                <Copy className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="mt-6 flex items-center gap-4 text-sm text-zinc-500">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 rounded-full bg-emerald-500"></div>
              Network Active
            </div>
            <div className="flex items-center gap-2">
              <CreditCard className="w-4 h-4" />
              Buy Crypto with Card
            </div>
          </div>
        </div>
      </div>

      {/* Transaction History */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden">
        <div className="p-6 border-b border-zinc-800 flex items-center justify-between">
          <h2 className="text-xl font-bold text-white flex items-center gap-2">
            <History className="w-5 h-5 text-zinc-400" />
            Recent Transactions
          </h2>
          <button className="text-sm text-emerald-400 hover:text-emerald-300 font-medium">
            View All
          </button>
        </div>

        <div className="divide-y divide-zinc-800/50">
          <TransactionRow
            type="deposit"
            amount="+$500.00"
            status="Completed"
            date="Today, 14:30"
            method="USDT"
          />
          <TransactionRow
            type="withdraw"
            amount="-$1,200.00"
            status="Completed"
            date="Yesterday, 09:15"
            method="BTC"
          />
          <TransactionRow
            type="deposit"
            amount="+$250.00"
            status="Completed"
            date="Mar 4, 18:45"
            method="ETH"
          />
          <TransactionRow
            type="withdraw"
            amount="-$50.00"
            status="Failed"
            date="Mar 2, 11:20"
            method="LTC"
          />
        </div>
      </div>
    </div>
  );
}

function TransactionRow({
  type,
  amount,
  status,
  date,
  method,
}: {
  type: "deposit" | "withdraw";
  amount: string;
  status: string;
  date: string;
  method: string;
}) {
  const isDeposit = type === "deposit";

  return (
    <div className="p-4 flex items-center justify-between hover:bg-zinc-800/30 transition-colors">
      <div className="flex items-center gap-4">
        <div
          className={`w-10 h-10 rounded-full flex items-center justify-center ${isDeposit ? "bg-emerald-500/10 text-emerald-400" : "bg-red-500/10 text-red-400"}`}
        >
          {isDeposit ? (
            <ArrowDownLeft className="w-5 h-5" />
          ) : (
            <ArrowUpRight className="w-5 h-5" />
          )}
        </div>
        <div>
          <div className="font-bold text-white">
            {isDeposit ? "Deposit" : "Withdrawal"}
          </div>
          <div className="text-xs text-zinc-500">
            {date} • {method}
          </div>
        </div>
      </div>

      <div className="text-right">
        <div
          className={`font-bold ${isDeposit ? "text-emerald-400" : "text-white"}`}
        >
          {amount}
        </div>
        <div
          className={`text-xs font-medium ${status === "Completed" ? "text-emerald-500" : status === "Failed" ? "text-red-500" : "text-yellow-500"}`}
        >
          {status}
        </div>
      </div>
    </div>
  );
}
