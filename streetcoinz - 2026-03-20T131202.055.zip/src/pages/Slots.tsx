import { useState, useRef } from "react";
import { useWallet } from "../context/WalletContext";
import { Gamepad2, Play, RotateCw } from "lucide-react";
import confetti from "canvas-confetti";
import { motion, AnimatePresence } from "motion/react";

const SYMBOLS = ["🍒", "🍋", "🍊", "🍉", "⭐", "7️⃣", "💎"];
const PAYOUTS: Record<string, number> = {
  "🍒": 2,
  "🍋": 3,
  "🍊": 5,
  "🍉": 10,
  "⭐": 20,
  "7️⃣": 50,
  "💎": 100,
};

export function Slots() {
  const { balance, bet, win } = useWallet();
  const [betAmount, setBetAmount] = useState("10");
  const [reels, setReels] = useState<string[]>(["💎", "💎", "💎"]);
  const [spinning, setSpinning] = useState(false);
  const [lastWin, setLastWin] = useState<number | null>(null);
  const [spinId, setSpinId] = useState(0);

  const spinReels = () => {
    const val = parseFloat(betAmount);
    if (isNaN(val) || val <= 0) return;

    if (!bet(val)) {
      alert("Insufficient balance");
      return;
    }

    setSpinId(prev => prev + 1);
    setSpinning(true);
    setLastWin(null);

    // Simulate spinning
    let spins = 0;
    const interval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
      spins++;

      if (spins > 20) {
        clearInterval(interval);
        setSpinning(false);
        checkWin(val);
      }
    }, 100);
  };

  const checkWin = (betVal: number) => {
    // Generate final result
    const r1 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const r2 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
    const r3 = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];

    // Force win for demo purposes occasionally
    const isForcedWin = Math.random() > 0.7;
    const finalReels = isForcedWin ? [r1, r1, r1] : [r1, r2, r3];

    setReels(finalReels);

    if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
      const multiplier = PAYOUTS[finalReels[0]];
      const winnings = betVal * multiplier;
      win(winnings);
      setLastWin(winnings);

      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 },
        colors: ["#ff2a5f", "#ffd700", "#00e676"],
      });
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-3">
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-pink-500 to-rose-600 flex items-center justify-center shadow-[0_0_20px_rgba(236,72,153,0.3)]">
          <Gamepad2 className="w-6 h-6 text-white" />
        </div>
        <h1 className="text-4xl font-display font-black tracking-tight text-white">
          Neon Slots
        </h1>
      </div>

      <div className="bg-casino-surface p-8 rounded-3xl border border-white/5 relative overflow-hidden">
        {/* Slot Machine Body */}
        <div className="bg-black/60 p-8 rounded-2xl border-4 border-casino-surface-hover shadow-[inset_0_0_50px_rgba(0,0,0,0.8)] relative">
          {/* Paytable hint */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 text-[10px] font-mono text-gray-500 uppercase tracking-widest flex gap-4">
            <span>🍒 2x</span>
            <span>⭐ 20x</span>
            <span>💎 100x</span>
          </div>

          <div className="flex justify-center gap-4 mt-6">
            {reels.map((symbol, i) => (
              <div
                key={i}
                className="w-32 h-40 bg-gradient-to-b from-gray-900 via-gray-800 to-gray-900 rounded-xl border-2 border-white/10 flex items-center justify-center text-7xl shadow-[inset_0_0_20px_rgba(0,0,0,0.5)] overflow-hidden relative"
              >
                <AnimatePresence mode="popLayout">
                  <motion.div
                    key={`${i}-${symbol}-${spinId}`}
                    initial={spinning ? { y: -100, opacity: 0 } : false}
                    animate={{ y: 0, opacity: 1 }}
                    exit={spinning ? { y: 100, opacity: 0 } : undefined}
                    transition={{ type: "spring", stiffness: 300, damping: 20 }}
                    className="absolute"
                  >
                    {symbol}
                  </motion.div>
                </AnimatePresence>

                {/* Glass reflection */}
                <div className="absolute inset-0 bg-gradient-to-b from-white/10 to-transparent h-1/2 pointer-events-none" />
              </div>
            ))}
          </div>

          {/* Win Display */}
          <div className="mt-8 h-16 flex items-center justify-center">
            <AnimatePresence>
              {lastWin && (
                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  exit={{ scale: 0.5, opacity: 0 }}
                  className="px-8 py-3 rounded-full bg-casino-gold/20 border border-casino-gold/50 text-casino-gold font-black font-display text-2xl tracking-wider shadow-[0_0_30px_rgba(255,215,0,0.3)] neon-text-gold"
                >
                  WIN ${lastWin.toFixed(2)}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Controls */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="col-span-2 flex items-center gap-4 bg-black/40 p-4 rounded-2xl border border-white/5">
            <div className="flex-1 space-y-2">
              <label className="text-xs font-mono text-gray-500 uppercase tracking-wider pl-2">
                Bet Amount
              </label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-mono">
                  $
                </span>
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  disabled={spinning}
                  className="w-full bg-casino-surface border border-white/10 rounded-xl py-3 pl-8 pr-4 text-xl font-mono text-white focus:border-casino-accent outline-none disabled:opacity-50 transition-colors"
                />
              </div>
            </div>
            <div className="flex flex-col gap-2 pt-6">
              <button
                disabled={spinning}
                onClick={() =>
                  setBetAmount((parseFloat(betAmount) / 2).toFixed(2))
                }
                className="px-4 py-1.5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-xs font-mono text-gray-300 disabled:opacity-50 transition-colors"
              >
                1/2
              </button>
              <button
                disabled={spinning}
                onClick={() =>
                  setBetAmount((parseFloat(betAmount) * 2).toFixed(2))
                }
                className="px-4 py-1.5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-lg text-xs font-mono text-gray-300 disabled:opacity-50 transition-colors"
              >
                2x
              </button>
            </div>
          </div>

          <button
            onClick={spinReels}
            disabled={spinning}
            className="col-span-1 py-4 rounded-2xl font-black text-2xl tracking-wider flex items-center justify-center gap-3 bg-gradient-to-br from-casino-accent to-rose-600 hover:from-casino-accent-hover hover:to-rose-500 text-white shadow-[0_0_30px_rgba(255,42,95,0.4)] disabled:opacity-50 disabled:cursor-not-allowed transition-all hover:scale-[1.02] active:scale-[0.98]"
          >
            {spinning ? (
              <RotateCw className="w-8 h-8 animate-spin" />
            ) : (
              <>
                SPIN
                <Play className="w-6 h-6 fill-current" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
