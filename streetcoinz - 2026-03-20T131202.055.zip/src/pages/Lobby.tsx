import React from 'react';
import { Link } from 'react-router-dom';
import { TrendingUp, Coins, Flame, Star } from 'lucide-react';

const GAMES = [
  {
    id: 'crash',
    name: 'Street Crash',
    path: '/crash',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?auto=format&fit=crop&q=80&w=800',
    icon: TrendingUp,
    color: 'from-purple-500/80 to-purple-900/80',
    tag: 'Hot'
  },
  {
    id: 'slots',
    name: 'Neon Slots',
    path: '/slots',
    image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?auto=format&fit=crop&q=80&w=800',
    icon: Coins,
    color: 'from-yellow-500/80 to-yellow-900/80',
    tag: 'New'
  },
  {
    id: 'roulette',
    name: 'Cyber Roulette',
    path: '/',
    image: 'https://images.unsplash.com/photo-1605870445919-838d190e8e1b?auto=format&fit=crop&q=80&w=800',
    icon: Star,
    color: 'from-emerald-500/80 to-emerald-900/80',
  }
];

export function Lobby() {
  return (
    <div className="max-w-6xl mx-auto">
      {/* Hero Banner */}
      <div className="relative w-full h-64 md:h-80 rounded-3xl overflow-hidden mb-12 group">
        <img 
          src="https://images.unsplash.com/photo-1511512578047-dfb367046420?auto=format&fit=crop&q=80&w=2000" 
          alt="Casino Banner" 
          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-950/80 to-transparent flex flex-col justify-center p-8 md:p-12">
          <div className="flex items-center gap-2 text-yellow-500 mb-4">
            <Flame className="w-5 h-5" />
            <span className="font-bold uppercase tracking-wider text-sm">Welcome to the Underground</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-white mb-4 tracking-tighter uppercase italic">
            Rule the <br/><span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-600">Streets</span>
          </h1>
          <p className="text-zinc-400 max-w-md mb-8">
            The most authentic crypto casino experience. Play Crash, Slots, and more to multiply your SCZ.
          </p>
          <Link to="/crash" className="bg-yellow-500 hover:bg-yellow-400 text-zinc-950 px-8 py-3 rounded-full font-bold w-max transition-colors">
            Play Crash Now
          </Link>
        </div>
      </div>

      {/* Games Grid */}
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold flex items-center gap-2">
          <Star className="w-6 h-6 text-yellow-500" />
          Featured Games
        </h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {GAMES.map((game) => (
          <Link 
            key={game.id} 
            to={game.path}
            className="group relative h-64 rounded-2xl overflow-hidden block"
          >
            <img 
              src={game.image} 
              alt={game.name} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            <div className={`absolute inset-0 bg-gradient-to-t ${game.color} mix-blend-multiply opacity-80 transition-opacity group-hover:opacity-60`} />
            <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/40 to-transparent p-6 flex flex-col justify-end">
              {game.tag && (
                <span className="absolute top-4 right-4 bg-zinc-950/80 backdrop-blur-sm text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider border border-white/10">
                  {game.tag}
                </span>
              )}
              <game.icon className="w-8 h-8 mb-3 text-white/80" />
              <h3 className="text-2xl font-black uppercase italic tracking-tight">{game.name}</h3>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
