import { Gift, Zap, Trophy, Calendar, ArrowRight } from "lucide-react";
import { motion } from "motion/react";

export function Promotions() {
  return (
    <div className="max-w-5xl mx-auto space-y-8 pb-12">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-pink-500/20 text-pink-400 flex items-center justify-center border border-pink-500/30">
          <Gift className="w-5 h-5" />
        </div>
        <h1 className="text-3xl font-black text-white">Promotions</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Welcome Bonus */}
        <motion.div
          whileHover={{ y: -5 }}
          className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="h-48 relative overflow-hidden">
            <img
              src="https://picsum.photos/seed/promo1/800/400"
              alt="Welcome Bonus"
              className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-emerald-500 text-zinc-950 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
              <Zap className="w-3 h-3" />
              NEW PLAYERS
            </div>
          </div>
          <div className="p-6 relative z-10">
            <h2 className="text-2xl font-black text-white mb-2">
              200% Welcome Match
            </h2>
            <p className="text-zinc-400 mb-6 line-clamp-2">
              Double your first deposit up to $1,000 and get 50 free spins on
              Neon Rush. Start your StreetCoinz journey with a massive boost!
            </p>
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-zinc-500">
                Min. deposit: $20
              </div>
              <button className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-xl font-bold transition-colors flex items-center gap-2">
                Claim Now <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Weekly Cashback */}
        <motion.div
          whileHover={{ y: -5 }}
          className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="h-48 relative overflow-hidden">
            <img
              src="https://picsum.photos/seed/promo2/800/400"
              alt="Weekly Cashback"
              className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-purple-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              WEEKLY
            </div>
          </div>
          <div className="p-6 relative z-10">
            <h2 className="text-2xl font-black text-white mb-2">
              15% Weekly Cashback
            </h2>
            <p className="text-zinc-400 mb-6 line-clamp-2">
              Didn't have a lucky week? Don't worry! We've got your back with up
              to 15% cashback on your net losses every Monday.
            </p>
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-zinc-500">
                Wagering: 1x
              </div>
              <button className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-xl font-bold transition-colors flex items-center gap-2">
                Read More <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>

        {/* Weekend Reload */}
        <motion.div
          whileHover={{ y: -5 }}
          className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-blue-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="h-48 relative overflow-hidden">
            <img
              src="https://picsum.photos/seed/promo3/800/400"
              alt="Weekend Reload"
              className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-blue-500 text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
              <Calendar className="w-3 h-3" />
              WEEKEND
            </div>
          </div>
          <div className="p-6 relative z-10">
            <h2 className="text-2xl font-black text-white mb-2">
              50% Weekend Reload
            </h2>
            <p className="text-zinc-400 mb-6 line-clamp-2">
              Boost your weekend bankroll with a 50% match bonus up to $500.
              Available every Friday to Sunday.
            </p>
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-zinc-500">
                Code: WEEKEND50
              </div>
              <button className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-xl font-bold transition-colors flex items-center gap-2">
                Deposit Now <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>

        {/* VIP Tournament */}
        <motion.div
          whileHover={{ y: -5 }}
          className="bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative group"
        >
          <div className="absolute inset-0 bg-gradient-to-br from-yellow-500/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
          <div className="h-48 relative overflow-hidden">
            <img
              src="https://picsum.photos/seed/promo4/800/400"
              alt="VIP Tournament"
              className="w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-500"
              referrerPolicy="no-referrer"
            />
            <div className="absolute top-4 left-4 bg-yellow-500 text-zinc-950 text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
              <Trophy className="w-3 h-3" />
              TOURNAMENT
            </div>
          </div>
          <div className="p-6 relative z-10">
            <h2 className="text-2xl font-black text-white mb-2">
              $50,000 Street Race
            </h2>
            <p className="text-zinc-400 mb-6 line-clamp-2">
              Compete against other players in our monthly leaderboard. Top 100
              players share a massive $50,000 prize pool!
            </p>
            <div className="flex items-center justify-between">
              <div className="text-sm font-medium text-zinc-500">
                Ends in: 5d 12h
              </div>
              <button className="bg-zinc-800 hover:bg-zinc-700 text-white px-4 py-2 rounded-xl font-bold transition-colors flex items-center gap-2">
                Join Race <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
