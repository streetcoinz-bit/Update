import { useState, useEffect, useRef } from 'react';
import { useStore } from '../store/useStore';
import { TrendingUp, AlertCircle, Play } from 'lucide-react';

export default function CrashGame() {
  const { balance, addBalance, deductBalance } = useStore();
  const [betAmount, setBetAmount] = useState(10);
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'crashed'>('idle');
  const [multiplier, setMultiplier] = useState(1.00);
  const [crashPoint, setCrashPoint] = useState(1.00);
  const [cashoutMultiplier, setCashoutMultiplier] = useState<number | null>(null);
  const [profit, setProfit] = useState<number | null>(null);

  const requestRef = useRef<number>();
  const startTimeRef = useRef<number>();

  // Generate a random crash point (weighted towards lower numbers)
  const generateCrashPoint = () => {
    const e = 2 ** 32;
    const h = crypto.getRandomValues(new Uint32Array(1))[0];
    const crash = Math.floor((100 * e - h) / (e - h)) / 100;
    return Math.max(1.00, crash);
  };

  const startGame = () => {
    if (betAmount > balance || betAmount <= 0) return;
    
    deductBalance(betAmount);
    const newCrashPoint = generateCrashPoint();
    setCrashPoint(newCrashPoint);
    setGameState('playing');
    setMultiplier(1.00);
    setCashoutMultiplier(null);
    setProfit(null);
    startTimeRef.current = performance.now();
    
    const updateMultiplier = (time: number) => {
      if (!startTimeRef.current) return;
      
      const elapsed = time - startTimeRef.current;
      // Exponential growth: multiplier = e^(rt)
      const currentMult = Math.pow(Math.E, 0.00006 * elapsed);
      
      if (currentMult >= newCrashPoint) {
        setMultiplier(newCrashPoint);
        setGameState('crashed');
        return;
      }
      
      setMultiplier(currentMult);
      requestRef.current = requestAnimationFrame(updateMultiplier);
    };
    
    requestRef.current = requestAnimationFrame(updateMultiplier);
  };

  const cashOut = () => {
    if (gameState !== 'playing') return;
    
    if (requestRef.current) {
      cancelAnimationFrame(requestRef.current);
    }
    
    const wonAmount = betAmount * multiplier;
    addBalance(wonAmount);
    setCashoutMultiplier(multiplier);
    setProfit(wonAmount - betAmount);
    setGameState('crashed'); // End game for this user
  };

  useEffect(() => {
    return () => {
      if (requestRef.current) {
        cancelAnimationFrame(requestRef.current);
      }
    };
  }, []);

  return (
    <div className="max-w-6xl mx-auto grid grid-cols-1 lg:grid-cols-4 gap-6">
      {/* Controls Sidebar */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col gap-6">
        <div>
          <label className="block text-sm font-medium text-zinc-400 mb-2">Bet Amount</label>
          <div className="relative">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <span className="text-zinc-500">$</span>
            </div>
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Number(e.target.value))}
              disabled={gameState === 'playing'}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-8 pr-4 text-white focus:outline-none focus:border-emerald-500 transition-colors disabled:opacity-50"
            />
            <div className="absolute inset-y-0 right-0 flex items-center pr-2 gap-1">
              <button 
                onClick={() => setBetAmount(Math.max(1, betAmount / 2))}
                disabled={gameState === 'playing'}
                className="px-2 py-1 text-xs font-medium bg-zinc-800 hover:bg-zinc-700 rounded text-zinc-300 transition-colors disabled:opacity-50"
              >
                1/2
              </button>
              <button 
                onClick={() => setBetAmount(betAmount * 2)}
                disabled={gameState === 'playing'}
                className="px-2 py-1 text-xs font-medium bg-zinc-800 hover:bg-zinc-700 rounded text-zinc-300 transition-colors disabled:opacity-50"
              >
                2x
              </button>
            </div>
          </div>
        </div>

        {gameState === 'idle' || gameState === 'crashed' ? (
          <button
            onClick={startGame}
            disabled={betAmount > balance || betAmount <= 0}
            className="w-full bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-950 font-bold py-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <Play className="w-5 h-5 fill-current" />
            Place Bet
          </button>
        ) : (
          <button
            onClick={cashOut}
            className="w-full bg-amber-500 hover:bg-amber-600 text-zinc-950 font-bold py-4 rounded-xl transition-colors flex flex-col items-center justify-center"
          >
            <span>Cash Out</span>
            <span className="text-sm opacity-80">${(betAmount * multiplier).toFixed(2)}</span>
          </button>
        )}

        {betAmount > balance && (
          <div className="flex items-center gap-2 text-red-400 text-sm bg-red-400/10 p-3 rounded-lg border border-red-400/20">
            <AlertCircle className="w-4 h-4" />
            Insufficient balance
          </div>
        )}
      </div>

      {/* Game Area */}
      <div className="lg:col-span-3 bg-zinc-900 border border-zinc-800 rounded-2xl p-8 relative overflow-hidden min-h-[400px] flex flex-col items-center justify-center">
        {/* Background Grid */}
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyNTUsIDI1NSwgMjU1LCAwLjAzKSIgc3Ryb2tlLXdpZHRoPSIxIi8+PC9wYXR0ZXJuPjwvZGVmcz48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSJ1cmwoI2dyaWQpIi8+PC9zdmc+')] opacity-50" />
        
        {/* Main Display */}
        <div className="relative z-10 text-center">
          <div className={`text-7xl md:text-9xl font-black font-mono tracking-tighter transition-colors duration-300 ${
            gameState === 'crashed' ? 'text-red-500' : 'text-emerald-400'
          }`}>
            {multiplier.toFixed(2)}x
          </div>
          
          <div className="h-8 mt-4">
            {gameState === 'crashed' && (
              <div className="text-red-400 font-bold text-xl uppercase tracking-widest animate-pulse">
                Crashed
              </div>
            )}
            {cashoutMultiplier && (
              <div className="text-emerald-400 font-bold text-xl">
                Cashed out at {cashoutMultiplier.toFixed(2)}x
                <span className="block text-sm text-emerald-500/80 mt-1">
                  +${profit?.toFixed(2)}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Visual Graph (Simplified) */}
        <div className="absolute bottom-0 left-0 w-full h-1/2 pointer-events-none">
          <svg className="w-full h-full" preserveAspectRatio="none">
            <path
              d={`M 0,${100} Q ${50},${100 - (multiplier * 5)} ${100},${100 - (multiplier * 10)}`}
              fill="none"
              stroke={gameState === 'crashed' ? '#ef4444' : '#34d399'}
              strokeWidth="4"
              className="transition-all duration-75"
              vectorEffect="non-scaling-stroke"
            />
            <path
              d={`M 0,${100} Q ${50},${100 - (multiplier * 5)} ${100},${100 - (multiplier * 10)} L 100,100 L 0,100 Z`}
              fill={gameState === 'crashed' ? 'rgba(239, 68, 68, 0.1)' : 'rgba(52, 211, 153, 0.1)'}
              className="transition-all duration-75"
            />
          </svg>
        </div>
      </div>
    </div>
  );
}
