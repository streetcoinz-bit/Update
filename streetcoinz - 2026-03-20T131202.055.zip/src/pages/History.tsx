import { useState, useEffect } from "react";
import { History as HistoryIcon, TrendingUp, TrendingDown } from "lucide-react";

export default function History() {
  // Mock history for now since we didn't add a GET /api/history endpoint
  const [history, setHistory] = useState([
    {
      id: 1,
      game: "Crash",
      amount: 10,
      multiplier: 2.5,
      payout: 25,
      timestamp: new Date().toISOString(),
    },
    {
      id: 2,
      game: "Coin Flip",
      amount: 20,
      multiplier: 0,
      payout: 0,
      timestamp: new Date(Date.now() - 3600000).toISOString(),
    },
    {
      id: 3,
      game: "Crash",
      amount: 50,
      multiplier: 1.5,
      payout: 75,
      timestamp: new Date(Date.now() - 7200000).toISOString(),
    },
  ]);

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-display font-bold flex items-center gap-3">
          <HistoryIcon className="text-[#00FFFF]" size={32} />
          Bet History
        </h1>
        <p className="text-gray-400 mt-2">View your recent gaming activity.</p>
      </div>

      <div className="bg-[#141416] border border-[#232326] rounded-2xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#232326] bg-[#0A0A0B]">
                <th className="p-4 text-sm font-medium text-gray-400">Game</th>
                <th className="p-4 text-sm font-medium text-gray-400">Time</th>
                <th className="p-4 text-sm font-medium text-gray-400">
                  Bet Amount
                </th>
                <th className="p-4 text-sm font-medium text-gray-400">
                  Multiplier
                </th>
                <th className="p-4 text-sm font-medium text-gray-400">
                  Payout
                </th>
              </tr>
            </thead>
            <tbody>
              {history.map((bet) => (
                <tr
                  key={bet.id}
                  className="border-b border-[#232326] hover:bg-[#232326]/30 transition-colors"
                >
                  <td className="p-4 font-medium">{bet.game}</td>
                  <td className="p-4 text-sm text-gray-400">
                    {new Date(bet.timestamp).toLocaleString()}
                  </td>
                  <td className="p-4 font-mono">${bet.amount.toFixed(2)}</td>
                  <td className="p-4 font-mono">
                    {bet.multiplier.toFixed(2)}x
                  </td>
                  <td className="p-4">
                    <div
                      className={`flex items-center gap-2 font-mono font-bold ${bet.payout > 0 ? "text-[#CCFF00]" : "text-red-500"}`}
                    >
                      {bet.payout > 0 ? (
                        <TrendingUp size={16} />
                      ) : (
                        <TrendingDown size={16} />
                      )}
                      ${bet.payout.toFixed(2)}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
