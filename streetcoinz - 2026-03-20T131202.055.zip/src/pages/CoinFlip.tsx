import { useState } from "react";
import { Coins, AlertCircle } from "lucide-react";
import { useUser } from "../context/UserContext";
import { cn } from "../lib/utils";

type Side = "heads" | "tails";

export function CoinFlip() {
  const { balance, addBalance, subtractBalance } = useUser();
  const [betAmount, setBetAmount] = useState<number>(10);
  const [selectedSide, setSelectedSide] = useState<Side>("heads");
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<Side | null>(null);
  const [winAmount, setWinAmount] = useState<number | null>(null);

  const handleFlip = () => {
    if (betAmount <= 0 || betAmount > balance || isFlipping) return;

    setIsFlipping(true);
    setResult(null);
    setWinAmount(null);
    subtractBalance(betAmount);

    // Simulate flip
    setTimeout(() => {
      const outcome: Side = Math.random() > 0.5 ? "heads" : "tails";
      setResult(outcome);
      setIsFlipping(false);

      if (outcome === selectedSide) {
        const win = betAmount * 1.98;
        addBalance(win);
        setWinAmount(win);
      } else {
        setWinAmount(0);
      }
    }, 2000);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-xl bg-emerald-500/10 text-emerald-400">
          <Coins className="w-8 h-8" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-black tracking-tight">Coin Flip</h1>
          <p className="text-zinc-400">Guess the side, double your money.</p>
        </div>
      </div>

      <div className="grid lg:grid-cols-[1fr_350px] gap-8">
        {/* Game Area */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 flex flex-col items-center justify-center min-h-[400px] relative overflow-hidden">
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.05)_0%,transparent_70%)]" />
          
          <div className="relative z-10 flex flex-col items-center">
            {/* Coin */}
            <div className={cn(
              "w-48 h-48 rounded-full border-4 flex items-center justify-center text-4xl font-display font-black shadow-[0_0_50px_rgba(0,0,0,0.5)] transition-all duration-500",
              isFlipping ? "animate-spin border-emerald-500 text-emerald-500 shadow-[0_0_50px_rgba(16,185,129,0.5)]" : 
              result === "heads" ? "border-amber-400 text-amber-400 bg-amber-400/10 shadow-[0_0_50px_rgba(251,191,36,0.3)]" :
              result === "tails" ? "border-zinc-300 text-zinc-300 bg-zinc-300/10 shadow-[0_0_50px_rgba(212,212,216,0.3)]" :
              "border-zinc-700 text-zinc-600 bg-zinc-800"
            )}>
              {isFlipping ? "?" : result === "heads" ? "H" : result === "tails" ? "T" : "?"}
            </div>

            {/* Result Message */}
            <div className="h-16 mt-8 flex items-center justify-center">
              {result && !isFlipping && (
                <div className={cn(
                  "text-2xl font-display font-black tracking-tight animate-in fade-in slide-in-from-bottom-4",
                  winAmount && winAmount > 0 ? "text-emerald-400" : "text-red-400"
                )}>
                  {winAmount && winAmount > 0 ? `+ $${winAmount.toFixed(2)}` : "You lost!"}
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Controls */}
        <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-6 space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Bet Amount</label>
            <div className="relative">
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-mono">$</span>
              <input 
                type="number" 
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-8 pr-4 font-mono text-lg focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
                min="0.01"
                step="0.01"
                disabled={isFlipping}
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                <button 
                  onClick={() => setBetAmount(prev => prev / 2)}
                  className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold transition-colors disabled:opacity-50"
                  disabled={isFlipping}
                >
                  1/2
                </button>
                <button 
                  onClick={() => setBetAmount(prev => prev * 2)}
                  className="px-2 py-1 bg-zinc-800 hover:bg-zinc-700 rounded text-xs font-bold transition-colors disabled:opacity-50"
                  disabled={isFlipping}
                >
                  2x
                </button>
              </div>
            </div>
            {betAmount > balance && (
              <div className="flex items-center gap-1 text-red-400 text-xs mt-1">
                <AlertCircle className="w-3 h-3" />
                <span>Insufficient balance</span>
              </div>
            )}
          </div>

          <div className="space-y-2">
            <label className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Select Side</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setSelectedSide("heads")}
                disabled={isFlipping}
                className={cn(
                  "py-3 rounded-xl font-bold transition-all border",
                  selectedSide === "heads" 
                    ? "bg-amber-400/10 border-amber-400/50 text-amber-400" 
                    : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-800"
                )}
              >
                Heads
              </button>
              <button
                onClick={() => setSelectedSide("tails")}
                disabled={isFlipping}
                className={cn(
                  "py-3 rounded-xl font-bold transition-all border",
                  selectedSide === "tails" 
                    ? "bg-zinc-300/10 border-zinc-300/50 text-zinc-300" 
                    : "bg-zinc-950 border-zinc-800 text-zinc-400 hover:bg-zinc-800"
                )}
              >
                Tails
              </button>
            </div>
          </div>

          <div className="pt-4 border-t border-zinc-800">
            <div className="flex justify-between text-sm mb-4">
              <span className="text-zinc-400">Payout on Win</span>
              <span className="font-mono text-emerald-400 font-bold">${(betAmount * 1.98).toFixed(2)}</span>
            </div>
            <button
              onClick={handleFlip}
              disabled={isFlipping || betAmount <= 0 || betAmount > balance}
              className="w-full bg-emerald-500 hover:bg-emerald-400 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-950 py-4 rounded-xl font-black text-lg transition-all hover:scale-[1.02] active:scale-[0.98] disabled:hover:scale-100 disabled:cursor-not-allowed"
            >
              {isFlipping ? "Flipping..." : "Place Bet"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
