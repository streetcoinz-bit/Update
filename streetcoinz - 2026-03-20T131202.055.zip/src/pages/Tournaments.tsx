import { Trophy, Clock, Users, ChevronRight } from 'lucide-react';

const tournaments = [
  {
    id: 1,
    title: 'Neon Nights Slots Race',
    prizePool: '50,000 SCZ',
    status: 'active',
    endsIn: '2d 14h 30m',
    participants: 1245,
    image: 'https://picsum.photos/seed/neon-race/800/400?blur=1',
    color: 'from-[var(--color-accent-primary)] to-emerald-500'
  },
  {
    id: 2,
    title: 'Weekend Blackjack Master',
    prizePool: '10,000 SCZ',
    status: 'upcoming',
    startsIn: '1d 05h 00m',
    participants: 342,
    image: 'https://picsum.photos/seed/blackjack/800/400?blur=1',
    color: 'from-[var(--color-accent-secondary)] to-purple-500'
  },
  {
    id: 3,
    title: 'Crash Kings Monthly',
    prizePool: '100,000 SCZ',
    status: 'active',
    endsIn: '14d 22h 15m',
    participants: 5621,
    image: 'https://picsum.photos/seed/crash/800/400?blur=1',
    color: 'from-orange-500 to-red-500'
  }
];

export default function Tournaments() {
  return (
    <div className="space-y-12 pb-12">
      <div className="max-w-3xl">
        <h1 className="text-4xl md:text-5xl font-black tracking-tight mb-4 flex items-center gap-4">
          <Trophy className="w-12 h-12 text-yellow-500" />
          Tournaments
        </h1>
        <p className="text-lg text-gray-400">
          Compete against other players for massive prize pools. Climb the leaderboard and claim your victory.
        </p>
      </div>

      <div className="space-y-6">
        {tournaments.map((tournament) => (
          <div key={tournament.id} className="group relative rounded-3xl overflow-hidden bg-[var(--color-bg-elevated)] border border-white/5 hover:border-white/20 transition-all duration-500 flex flex-col md:flex-row">
            <div className="w-full md:w-1/3 relative min-h-[200px] md:min-h-full">
              <img 
                src={tournament.image} 
                alt={tournament.title} 
                className="absolute inset-0 w-full h-full object-cover opacity-60 group-hover:scale-105 transition-transform duration-700"
                referrerPolicy="no-referrer"
              />
              <div className={`absolute inset-0 bg-gradient-to-r ${tournament.color} opacity-40 mix-blend-overlay`}></div>
              <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-[var(--color-bg-elevated)] via-transparent to-transparent"></div>
              
              <div className="absolute top-4 left-4">
                {tournament.status === 'active' ? (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-[var(--color-accent-primary)]/20 border border-[var(--color-accent-primary)]/30 text-[var(--color-accent-primary)] text-xs font-bold uppercase tracking-wider">
                    <span className="w-2 h-2 rounded-full bg-[var(--color-accent-primary)] animate-pulse"></span>
                    Live Now
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-wider">
                    Upcoming
                  </span>
                )}
              </div>
            </div>
            
            <div className="relative z-10 p-6 md:p-8 flex-1 flex flex-col justify-center">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                <div>
                  <h2 className="text-2xl font-black text-white mb-2">{tournament.title}</h2>
                  <div className="flex items-center gap-4 text-sm text-gray-400">
                    <div className="flex items-center gap-1.5">
                      <Users className="w-4 h-4" />
                      {tournament.participants} Players
                    </div>
                    <div className="flex items-center gap-1.5">
                      <Clock className="w-4 h-4" />
                      {tournament.status === 'active' ? `Ends in ${tournament.endsIn}` : `Starts in ${tournament.startsIn}`}
                    </div>
                  </div>
                </div>
                
                <div className="text-left md:text-right">
                  <p className="text-sm text-gray-400 font-medium mb-1">Prize Pool</p>
                  <p className="text-3xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-200">
                    {tournament.prizePool}
                  </p>
                </div>
              </div>
              
              <div className="flex items-center gap-4 mt-auto">
                <button className="px-6 py-3 rounded-xl bg-white text-black font-bold hover:bg-gray-200 transition-colors flex items-center gap-2">
                  {tournament.status === 'active' ? 'Join Tournament' : 'Opt-in Now'}
                  <ChevronRight className="w-4 h-4" />
                </button>
                <button className="px-6 py-3 rounded-xl bg-white/5 text-white font-bold hover:bg-white/10 border border-white/10 transition-colors">
                  Leaderboard
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
