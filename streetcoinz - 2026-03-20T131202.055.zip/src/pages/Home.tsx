import { Play, Star, TrendingUp, Zap, User, Flame } from "lucide-react";
import { motion } from "motion/react";
import { ReactNode, useMemo } from "react";

export function Home() {
  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      {/* Hero Banner */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative rounded-3xl overflow-hidden bg-zinc-900 border border-zinc-800"
      >
        <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-900/80 to-transparent z-10"></div>
        <img
          src="https://picsum.photos/seed/casino-neon/1200/400"
          alt="Casino Banner"
          className="absolute inset-0 w-full h-full object-cover opacity-50 mix-blend-overlay"
          referrerPolicy="no-referrer"
        />

        <div className="relative z-20 p-8 md:p-12 flex flex-col items-start max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-400 text-xs font-bold uppercase tracking-wider mb-4 border border-emerald-500/30">
            <Zap className="w-3 h-3" />
            Welcome Bonus
          </div>
          <h1 className="text-4xl md:text-6xl font-black tracking-tight text-white mb-4 leading-tight">
            200% MATCH <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-cyan-400">
              UP TO $1,000
            </span>
          </h1>
          <p className="text-zinc-400 text-lg mb-8 max-w-md">
            Join StreetCoinz today and double your first deposit. Plus get 50
            free spins on selected slots.
          </p>
          <button className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-lg px-8 py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(52,211,153,0.4)] hover:shadow-[0_0_30px_rgba(52,211,153,0.6)] hover:-translate-y-1">
            Claim Bonus Now
          </button>
        </div>
      </motion.div>

      {/* Categories */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <CategoryCard
          title="Slots"
          icon={<Zap className="w-6 h-6 text-yellow-400" />}
          count="2,451"
          color="from-yellow-500/20 to-orange-500/5"
          border="border-yellow-500/20"
        />
        <CategoryCard
          title="Live Casino"
          icon={<Star className="w-6 h-6 text-purple-400" />}
          count="128"
          color="from-purple-500/20 to-pink-500/5"
          border="border-purple-500/20"
        />
        <CategoryCard
          title="Crash Games"
          icon={<TrendingUp className="w-6 h-6 text-emerald-400" />}
          count="15"
          color="from-emerald-500/20 to-cyan-500/5"
          border="border-emerald-500/20"
        />
        <CategoryCard
          title="Table Games"
          icon={<Play className="w-6 h-6 text-blue-400" />}
          count="84"
          color="from-blue-500/20 to-indigo-500/5"
          border="border-blue-500/20"
        />
      </div>

      {/* Popular Games */}
      <div>
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-white flex items-center gap-2">
            <Flame className="w-6 h-6 text-emerald-400" />
            Trending Now
          </h2>
          <button className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
            View All
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          <GameCard
            title="Neon Rush"
            provider="StreetGaming"
            image="https://picsum.photos/seed/slot1/400/500"
            rtp="96.5%"
          />
          <GameCard
            title="Cyber Crash"
            provider="StreetCoinz Games"
            image="https://is3.cloudhost.id/streetcoinzstorage/GAMES/Crash.jpg"
            rtp="99.0%"
          />
          <GameCard
            title="Midnight Blackjack"
            provider="LiveDealer"
            image="https://picsum.photos/seed/cards1/400/500"
            rtp="99.5%"
          />
          <GameCard
            title="Street Dice"
            provider="StreetCoinz Games"
            image="https://is3.cloudhost.id/streetcoinzstorage/GAMES/Dice.jpg"
            rtp="98.0%"
          />
          <GameCard
            title="Golden Vault"
            provider="SpinMaster"
            image="https://picsum.photos/seed/slot2/400/500"
            rtp="95.8%"
          />
        </div>
      </div>

      {/* Recent Big Wins */}
      <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-2xl p-6">
        <h3 className="text-lg font-bold text-white mb-4">Live Activity</h3>
        <div className="space-y-3">
          <WinRow
            user="Alex99"
            game="Neon Rush"
            amount="$1,250.00"
            multiplier="250x"
            time="2 min ago"
          />
          <WinRow
            user="CryptoKing"
            game="Cyber Crash"
            amount="$4,500.00"
            multiplier="15x"
            time="5 min ago"
          />
          <WinRow
            user="LuckyStar"
            game="Street Dice"
            amount="$850.00"
            multiplier="2x"
            time="12 min ago"
          />
        </div>
      </div>
    </div>
  );
}

function CategoryCard({
  title,
  icon,
  count,
  color,
  border,
}: {
  title: string;
  icon: ReactNode;
  count: string;
  color: string;
  border: string;
}) {
  return (
    <button
      className={`flex flex-col items-start p-5 rounded-2xl bg-gradient-to-br ${color} border ${border} hover:bg-zinc-800 transition-all group`}
    >
      <div className="bg-zinc-950/50 p-3 rounded-xl mb-4 group-hover:scale-110 transition-transform">
        {icon}
      </div>
      <h3 className="text-lg font-bold text-white mb-1">{title}</h3>
      <p className="text-sm text-zinc-500 font-medium">{count} Games</p>
    </button>
  );
}

function GameCard({
  title,
  provider,
  image,
  rtp,
}: {
  title: string;
  provider: string;
  image: string;
  rtp: string;
}) {
  const activePlayers = useMemo(() => {
    const today = new Date();
    const dateString = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
    let hash = 0;
    const str = title + dateString;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % 900 + 50;
  }, [title]);

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="group relative rounded-xl overflow-hidden bg-zinc-900 border border-zinc-800 cursor-pointer"
    >
      <div className="aspect-[3/4] overflow-hidden relative">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-md flex items-center gap-1 z-10">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] font-medium text-white">{activePlayers}</span>
          <User className="w-3 h-3 text-white" />
        </div>
        <div className="absolute top-2 right-2 bg-red-500/20 border border-red-500/50 backdrop-blur-sm px-2 py-1 rounded-md flex items-center gap-1 z-10 shadow-[0_0_10px_rgba(239,68,68,0.3)]">
          <Flame className="w-3 h-3 text-red-500" fill="currentColor" />
          <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider">Hot</span>
        </div>
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-zinc-950/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
        <button className="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center text-zinc-950 transform scale-50 group-hover:scale-100 transition-transform duration-300">
          <Play className="w-5 h-5 ml-1" fill="currentColor" />
        </button>
      </div>

      <div className="p-3">
        <div className="flex justify-between items-start mb-1">
          <h4 className="text-sm font-bold text-white truncate pr-2">
            {title}
          </h4>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
            {rtp}
          </span>
        </div>
        <p className="text-xs">
          {provider === 'StreetCoinz Games' ? (
            <span className="text-[#a252f0] font-bold">{provider}</span>
          ) : (
            <span className="text-zinc-500">{provider}</span>
          )}
        </p>
      </div>
    </motion.div>
  );
}



function WinRow({
  user,
  game,
  amount,
  multiplier,
  time,
}: {
  user: string;
  game: string;
  amount: string;
  multiplier: string;
  time: string;
}) {
  return (
    <div className="flex items-center justify-between p-3 rounded-xl hover:bg-zinc-800/50 transition-colors border border-transparent hover:border-zinc-800">
      <div className="flex items-center gap-4">
        <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center">
          <User className="w-4 h-4 text-zinc-400" />
        </div>
        <div>
          <div className="text-sm font-medium text-white">{user}</div>
          <div className="text-xs text-zinc-500">{game}</div>
        </div>
      </div>
      <div className="text-right">
        <div className="text-sm font-bold text-emerald-400">{amount}</div>
        <div className="flex items-center gap-2 justify-end">
          <span className="text-xs font-mono text-zinc-400 bg-zinc-800 px-1.5 py-0.5 rounded">
            {multiplier}
          </span>
          <span className="text-xs text-zinc-600">{time}</span>
        </div>
      </div>
    </div>
  );
}
