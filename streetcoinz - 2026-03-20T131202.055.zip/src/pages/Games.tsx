import { Play, Search, Filter, User, Flame } from "lucide-react";
import { motion } from "motion/react";
import { ReactNode, FC, useMemo } from "react";

export function Games({
  title,
  icon,
  color,
}: {
  title: string;
  icon: ReactNode;
  color: string;
}) {
  return (
    <div className="max-w-7xl mx-auto space-y-8 pb-12">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl ${color} flex items-center justify-center`}
          >
            {icon}
          </div>
          <h1 className="text-3xl font-black text-white">{title}</h1>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden md:flex items-center bg-zinc-900 border border-zinc-800 rounded-xl px-4 py-2 focus-within:border-emerald-500/50 transition-all">
            <Search className="w-4 h-4 text-zinc-500 mr-2" />
            <input
              type="text"
              placeholder="Search games..."
              className="bg-transparent border-none outline-none text-sm w-48 text-zinc-200 placeholder-zinc-500"
            />
          </div>
          <button className="bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 text-zinc-300 px-4 py-2 rounded-xl flex items-center gap-2 transition-colors text-sm font-medium">
            <Filter className="w-4 h-4" />
            Providers
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {Array.from({ length: 24 }).map((_, i) => (
          <GameCard
            key={i}
            title={`${title} Game ${i + 1}`}
            provider={
              ["StreetGaming", "SpinMaster", "LiveDealer", "StreetCoinz Games"][i % 4]
            }
            image={`https://picsum.photos/seed/${title.toLowerCase().replace(" ", "")}${i}/400/500`}
            rtp={`${(95 + Math.random() * 4).toFixed(1)}%`}
          />
        ))}
      </div>
    </div>
  );
}

const GameCard: FC<{
  title: string;
  provider: string;
  image: string;
  rtp: string;
}> = ({ title, provider, image, rtp }) => {
  const activePlayers = useMemo(() => {
    const today = new Date();
    const dateString = `${today.getFullYear()}-${today.getMonth()}-${today.getDate()}`;
    let hash = 0;
    const str = title + dateString;
    for (let i = 0; i < str.length; i++) {
      hash = ((hash << 5) - hash) + str.charCodeAt(i);
      hash |= 0;
    }
    return Math.abs(hash) % 900 + 50;
  }, [title]);

  return (
    <motion.div
      whileHover={{ y: -5 }}
      className="group relative rounded-xl overflow-hidden bg-zinc-900 border border-zinc-800 cursor-pointer"
    >
      <div className="aspect-[3/4] overflow-hidden relative">
        <img
          src={image}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-2 left-2 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-md flex items-center gap-1 z-10">
          <div className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span className="text-[10px] font-medium text-white">{activePlayers}</span>
          <User className="w-3 h-3 text-white" />
        </div>
        <div className="absolute top-2 right-2 bg-red-500/20 border border-red-500/50 backdrop-blur-sm px-2 py-1 rounded-md flex items-center gap-1 z-10 shadow-[0_0_10px_rgba(239,68,68,0.3)]">
          <Flame className="w-3 h-3 text-red-500" fill="currentColor" />
          <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider">Hot</span>
        </div>
      </div>

      {/* Overlay */}
      <div className="absolute inset-0 bg-zinc-950/80 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center backdrop-blur-sm">
        <button className="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center text-zinc-950 transform scale-50 group-hover:scale-100 transition-transform duration-300">
          <Play className="w-5 h-5 ml-1" fill="currentColor" />
        </button>
      </div>

      <div className="p-3">
        <div className="flex justify-between items-start mb-1">
          <h4 className="text-sm font-bold text-white truncate pr-2">
            {title}
          </h4>
          <span className="text-[10px] font-mono text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded">
            {rtp}
          </span>
        </div>
        <p className="text-xs">
          {provider === 'StreetCoinz Games' ? (
            <span className="text-[#a252f0] font-bold">{provider}</span>
          ) : (
            <span className="text-zinc-500">{provider}</span>
          )}
        </p>
      </div>
    </motion.div>
  );
};
