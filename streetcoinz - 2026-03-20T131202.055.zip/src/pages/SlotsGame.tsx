import { useState, useEffect } from 'react';
import { useStore } from '../store/useStore';
import { Gamepad2, AlertCircle } from 'lucide-react';

const SYMBOLS = ['🍒', '🍋', '🍇', '🍉', '⭐', '💎', '7️⃣'];
const MULTIPLIERS: Record<string, number> = {
  '🍒': 2,
  '🍋': 3,
  '🍇': 5,
  '🍉': 10,
  '⭐': 20,
  '💎': 50,
  '7️⃣': 100,
};

export default function SlotsGame() {
  const { balance, addBalance, deductBalance } = useStore();
  const [betAmount, setBetAmount] = useState(10);
  const [reels, setReels] = useState<string[]>(['🍒', '🍒', '🍒']);
  const [isSpinning, setIsSpinning] = useState(false);
  const [winAmount, setWinAmount] = useState<number | null>(null);

  const spin = () => {
    if (betAmount > balance || betAmount <= 0 || isSpinning) return;
    
    deductBalance(betAmount);
    setIsSpinning(true);
    setWinAmount(null);

    // Simulate spinning animation
    let spins = 0;
    const maxSpins = 20;
    
    const spinInterval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
      
      spins++;
      if (spins >= maxSpins) {
        clearInterval(spinInterval);
        
        // Final result
        const finalReels = [
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        ];
        
        // Force a win sometimes for demo purposes (10% chance)
        if (Math.random() < 0.1) {
          const winSymbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
          finalReels[0] = winSymbol;
          finalReels[1] = winSymbol;
          finalReels[2] = winSymbol;
        }

        setReels(finalReels);
        setIsSpinning(false);
        
        checkWin(finalReels);
      }
    }, 100);
  };

  const checkWin = (finalReels: string[]) => {
    if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
      const symbol = finalReels[0];
      const won = betAmount * MULTIPLIERS[symbol];
      setWinAmount(won);
      addBalance(won);
    } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2] || finalReels[0] === finalReels[2]) {
      // Small win for 2 matching
      const won = betAmount * 0.5;
      setWinAmount(won);
      addBalance(won);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 lg:p-12 shadow-2xl relative overflow-hidden">
        {/* Decorative background */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-purple-900/20 via-zinc-900 to-zinc-900 pointer-events-none" />
        
        <div className="relative z-10 flex flex-col items-center">
          <div className="flex items-center gap-3 mb-8">
            <Gamepad2 className="w-8 h-8 text-purple-400" />
            <h1 className="text-3xl font-black text-white tracking-tight uppercase italic">Neon Slots</h1>
          </div>

          {/* Slot Machine Display */}
          <div className="bg-zinc-950 border-4 border-zinc-800 rounded-2xl p-6 mb-8 w-full max-w-2xl shadow-inner relative">
            {/* Win Overlay */}
            {winAmount !== null && winAmount > 0 && (
              <div className="absolute inset-0 z-20 flex items-center justify-center bg-black/60 backdrop-blur-sm rounded-xl animate-in fade-in duration-300">
                <div className="text-center transform animate-bounce">
                  <div className="text-4xl font-black text-yellow-400 drop-shadow-[0_0_15px_rgba(250,204,21,0.5)] mb-2">
                    YOU WIN!
                  </div>
                  <div className="text-2xl font-bold text-emerald-400">
                    +${winAmount.toFixed(2)}
                  </div>
                </div>
              </div>
            )}

            <div className="grid grid-cols-3 gap-4">
              {reels.map((symbol, i) => (
                <div 
                  key={i} 
                  className="bg-zinc-900 border border-zinc-800 rounded-xl h-32 lg:h-40 flex items-center justify-center text-6xl lg:text-7xl shadow-inner overflow-hidden relative"
                >
                  <div className={`transition-transform duration-100 ${isSpinning ? 'animate-pulse blur-[2px]' : ''}`}>
                    {symbol}
                  </div>
                  {/* Glass reflection */}
                  <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none" />
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="w-full max-w-2xl bg-zinc-950/50 rounded-2xl p-6 border border-zinc-800/50 flex flex-col md:flex-row items-center gap-6 justify-between">
            <div className="w-full md:w-auto flex-1">
              <label className="block text-sm font-medium text-zinc-400 mb-2">Bet Amount</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <span className="text-zinc-500">$</span>
                </div>
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(Number(e.target.value))}
                  disabled={isSpinning}
                  className="w-full bg-zinc-900 border border-zinc-800 rounded-xl py-3 pl-8 pr-4 text-white focus:outline-none focus:border-purple-500 transition-colors disabled:opacity-50"
                />
              </div>
              {betAmount > balance && (
                <div className="flex items-center gap-1 text-red-400 text-xs mt-2">
                  <AlertCircle className="w-3 h-3" />
                  Insufficient balance
                </div>
              )}
            </div>

            <button
              onClick={spin}
              disabled={isSpinning || betAmount > balance || betAmount <= 0}
              className="w-full md:w-auto px-12 py-4 bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 disabled:from-zinc-800 disabled:to-zinc-800 disabled:text-zinc-500 text-white font-black text-xl rounded-xl transition-all transform hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(168,85,247,0.4)] disabled:shadow-none uppercase tracking-wider"
            >
              {isSpinning ? 'Spinning...' : 'SPIN'}
            </button>
          </div>

          {/* Paytable Info */}
          <div className="mt-8 text-center text-zinc-500 text-sm">
            <p>Match 3 symbols to win big! Match 2 for a small prize.</p>
            <div className="flex flex-wrap justify-center gap-4 mt-4 opacity-70">
              {Object.entries(MULTIPLIERS).map(([sym, mult]) => (
                <span key={sym} className="bg-zinc-950 px-3 py-1 rounded-full border border-zinc-800">
                  {sym} {mult}x
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
