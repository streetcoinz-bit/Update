import { Trophy, Star, Crown, Shield, Zap, Gift } from "lucide-react";
import { motion } from "motion/react";
import { ReactNode } from "react";

export function VIP() {
  return (
    <div className="max-w-5xl mx-auto space-y-12 pb-12">
      {/* Header */}
      <div className="text-center space-y-4 pt-8">
        <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-yellow-500/20 text-yellow-400 border border-yellow-500/30 mb-4">
          <Crown className="w-8 h-8" />
        </div>
        <h1 className="text-4xl md:text-5xl font-black text-white tracking-tight">
          StreetCoinz{" "}
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-600">
            VIP Club
          </span>
        </h1>
        <p className="text-zinc-400 text-lg max-w-2xl mx-auto">
          Experience the ultimate casino luxury. Earn points, level up, and
          unlock exclusive rewards, higher limits, and a personal account
          manager.
        </p>
      </div>

      {/* Current Status */}
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-5">
          <Trophy className="w-48 h-48 text-white" />
        </div>

        <div className="relative z-10 flex flex-col md:flex-row gap-8 items-center justify-between">
          <div>
            <div className="text-sm font-bold text-zinc-500 uppercase tracking-wider mb-2">
              Current Tier
            </div>
            <div className="text-4xl font-black text-white flex items-center gap-3">
              Silver
              <span className="text-sm font-bold bg-zinc-800 text-zinc-300 px-3 py-1 rounded-full">
                Level 12
              </span>
            </div>
          </div>

          <div className="flex-1 w-full max-w-md">
            <div className="flex justify-between text-sm font-bold mb-2">
              <span className="text-zinc-400">12,450 XP</span>
              <span className="text-yellow-400">Gold (20,000 XP)</span>
            </div>
            <div className="h-3 bg-zinc-950 rounded-full overflow-hidden border border-zinc-800">
              <motion.div
                initial={{ width: 0 }}
                animate={{ width: "62%" }}
                transition={{ duration: 1, ease: "easeOut" }}
                className="h-full bg-gradient-to-r from-zinc-500 to-zinc-300 rounded-full"
              ></motion.div>
            </div>
            <div className="text-xs text-zinc-500 mt-2 text-right">
              7,550 XP to next tier
            </div>
          </div>
        </div>
      </div>

      {/* Tiers */}
      <div>
        <h2 className="text-2xl font-bold text-white mb-6 text-center">
          VIP Tiers & Benefits
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <TierCard
            name="Bronze"
            xp="0 - 5,000"
            color="from-orange-700 to-orange-900"
            borderColor="border-orange-800"
            textColor="text-orange-400"
            benefits={[
              "5% Weekly Cashback",
              "Standard Support",
              "Birthday Bonus",
            ]}
          />
          <TierCard
            name="Silver"
            xp="5,000 - 20,000"
            color="from-zinc-400 to-zinc-600"
            borderColor="border-zinc-500"
            textColor="text-zinc-300"
            benefits={[
              "10% Weekly Cashback",
              "Priority Support",
              "Higher Withdrawals",
              "Monthly Reload",
            ]}
            active
          />
          <TierCard
            name="Gold"
            xp="20,000 - 100,000"
            color="from-yellow-400 to-yellow-600"
            borderColor="border-yellow-500"
            textColor="text-yellow-400"
            benefits={[
              "15% Weekly Cashback",
              "VIP Host",
              "Instant Withdrawals",
              "Exclusive Tournaments",
            ]}
          />
          <TierCard
            name="Diamond"
            xp="100,000+"
            color="from-cyan-400 to-blue-600"
            borderColor="border-cyan-500"
            textColor="text-cyan-400"
            benefits={[
              "20% Weekly Cashback",
              "Dedicated Host",
              "No Limits",
              "Luxury Gifts & Events",
            ]}
          />
        </div>
      </div>

      {/* Features */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-8">
        <FeatureCard
          icon={<Shield className="w-6 h-6 text-emerald-400" />}
          title="Priority Withdrawals"
          desc="Skip the queue. VIP members get their winnings processed instantly."
        />
        <FeatureCard
          icon={<Star className="w-6 h-6 text-yellow-400" />}
          title="Dedicated VIP Host"
          desc="A personal account manager available 24/7 for all your needs."
        />
        <FeatureCard
          icon={<Gift className="w-6 h-6 text-purple-400" />}
          title="Exclusive Bonuses"
          desc="Custom tailored promotions and bonuses with lower wagering requirements."
        />
      </div>
    </div>
  );
}

function TierCard({
  name,
  xp,
  color,
  borderColor,
  textColor,
  benefits,
  active = false,
}: {
  name: string;
  xp: string;
  color: string;
  borderColor: string;
  textColor: string;
  benefits: string[];
  active?: boolean;
}) {
  return (
    <div
      className={`bg-zinc-900 rounded-3xl p-6 border ${active ? borderColor : "border-zinc-800"} relative overflow-hidden flex flex-col h-full`}
    >
      {active && (
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white to-transparent opacity-50"></div>
      )}

      <div className="mb-6">
        <h3 className={`text-2xl font-black ${textColor} mb-1`}>{name}</h3>
        <div className="text-xs font-bold text-zinc-500">{xp} XP</div>
      </div>

      <ul className="space-y-3 flex-1">
        {benefits.map((benefit, i) => (
          <li key={i} className="flex items-start gap-2 text-sm text-zinc-300">
            <Zap className={`w-4 h-4 mt-0.5 ${textColor}`} />
            <span>{benefit}</span>
          </li>
        ))}
      </ul>

      {active && (
        <div className="mt-6 pt-4 border-t border-zinc-800 text-center text-xs font-bold text-zinc-500 uppercase tracking-wider">
          Current Tier
        </div>
      )}
    </div>
  );
}

function FeatureCard({
  icon,
  title,
  desc,
}: {
  icon: ReactNode;
  title: string;
  desc: string;
}) {
  return (
    <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-2xl p-6 text-center flex flex-col items-center">
      <div className="w-12 h-12 rounded-full bg-zinc-800 flex items-center justify-center mb-4">
        {icon}
      </div>
      <h4 className="text-lg font-bold text-white mb-2">{title}</h4>
      <p className="text-sm text-zinc-400">{desc}</p>
    </div>
  );
}
