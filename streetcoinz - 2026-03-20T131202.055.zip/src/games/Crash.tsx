import { useState, useEffect, useRef } from 'react';
import type { Dispatch, SetStateAction } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { TrendingUp, AlertTriangle } from 'lucide-react';

interface CrashProps {
  balance: number;
  setBalance: Dispatch<SetStateAction<number>>;
}

type GameState = 'idle' | 'playing' | 'crashed' | 'cashed_out';

export function Crash({ balance, setBalance }: CrashProps) {
  const [gameState, setGameState] = useState<GameState>('idle');
  const [multiplier, setMultiplier] = useState(1.00);
  const [bet, setBet] = useState(10);
  const [winAmount, setWinAmount] = useState(0);
  const [crashPoint, setCrashPoint] = useState(0);
  
  const multiplierRef = useRef(1.00);
  const betRef = useRef(bet);

  useEffect(() => {
    betRef.current = bet;
  }, [bet]);

  useEffect(() => {
    multiplierRef.current = multiplier;
  }, [multiplier]);

  const startGame = () => {
    if (balance < bet) return;
    
    setBalance(prev => prev - bet);
    setGameState('playing');
    setMultiplier(1.00);
    setWinAmount(0);
    
    // Determine crash point using a simple house edge algorithm
    // e = 100, h = 4 (4% house edge)
    // crash = (100 * E) / (E - h) where E is random between 0 and 100
    // Simplified:
    const r = Math.random();
    // 1% chance of instant crash
    if (r < 0.01) {
      setCrashPoint(1.00);
    } else {
      const maxMultiplier = 100;
      // Logarithmic distribution for realistic crash curve
      const calculatedCrash = Math.max(1.01, Math.min(maxMultiplier, 0.99 / (1 - r)));
      setCrashPoint(calculatedCrash);
    }
  };

  useEffect(() => {
    let animationFrame: number;
    let startTime: number;

    const updateMultiplier = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const elapsed = timestamp - startTime;
      
      // Exponential growth curve
      // multiplier = e^(rt)
      const rate = 0.00005; // Growth rate
      const currentMult = Math.exp(rate * elapsed);
      
      if (currentMult >= crashPoint) {
        setMultiplier(crashPoint);
        setGameState('crashed');
        return;
      }

      setMultiplier(currentMult);
      animationFrame = requestAnimationFrame(updateMultiplier);
    };

    if (gameState === 'playing') {
      animationFrame = requestAnimationFrame(updateMultiplier);
    }

    return () => {
      if (animationFrame) cancelAnimationFrame(animationFrame);
    };
  }, [gameState, crashPoint]);

  const cashOut = () => {
    if (gameState !== 'playing') return;
    
    const currentMult = multiplierRef.current;
    const currentBet = betRef.current;
    const won = currentBet * currentMult;
    
    setWinAmount(won);
    setBalance(prev => prev + won);
    setGameState('cashed_out');
  };

  return (
    <div className="w-full max-w-4xl mx-auto flex flex-col items-center justify-center p-8 bg-zinc-900/50 rounded-3xl border border-zinc-800 shadow-2xl relative overflow-hidden">
      {/* Background Glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/10 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="relative z-10 w-full flex flex-col items-center">
        <div className="flex items-center gap-4 mb-8">
          <TrendingUp size={32} className="text-emerald-500" />
          <h2 className="text-4xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-600 uppercase">
            Crypto Crash
          </h2>
        </div>

        {/* Game Display */}
        <div className="w-full aspect-video max-h-[400px] bg-zinc-950 rounded-2xl border border-zinc-800 shadow-inner relative overflow-hidden mb-8 flex items-center justify-center">
          {/* Grid Background */}
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.05)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.05)_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_100%)]"></div>
          
          {/* Chart Line Simulation */}
          {gameState !== 'idle' && (
            <svg className="absolute inset-0 w-full h-full" preserveAspectRatio="none">
              <motion.path
                d={`M 0 ${400} Q ${Math.min(100, multiplier * 10)} ${400 - Math.min(300, multiplier * 20)} ${Math.min(1000, multiplier * 50)} ${400 - Math.min(380, multiplier * 30)}`}
                fill="none"
                stroke={gameState === 'crashed' ? '#ef4444' : '#10b981'}
                strokeWidth="4"
                className="drop-shadow-[0_0_10px_rgba(16,185,129,0.5)]"
                initial={{ pathLength: 0 }}
                animate={{ pathLength: 1 }}
                transition={{ duration: 0.1 }}
              />
            </svg>
          )}

          {/* Multiplier Display */}
          <div className="relative z-20 flex flex-col items-center">
            <AnimatePresence mode="wait">
              {gameState === 'crashed' ? (
                <motion.div
                  key="crashed"
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex flex-col items-center"
                >
                  <div className="flex items-center gap-3 text-red-500 mb-2">
                    <AlertTriangle size={32} />
                    <span className="text-2xl font-bold uppercase tracking-widest">Crashed</span>
                  </div>
                  <span className="text-7xl font-black text-red-500 drop-shadow-[0_0_20px_rgba(239,68,68,0.5)]">
                    {multiplier.toFixed(2)}x
                  </span>
                </motion.div>
              ) : gameState === 'cashed_out' ? (
                <motion.div
                  key="cashed_out"
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex flex-col items-center"
                >
                  <span className="text-2xl font-bold text-emerald-400 mb-2 uppercase tracking-widest">Cashed Out!</span>
                  <span className="text-7xl font-black text-emerald-500 drop-shadow-[0_0_20px_rgba(16,185,129,0.5)]">
                    {multiplier.toFixed(2)}x
                  </span>
                  <span className="text-xl font-bold text-yellow-400 mt-4">
                    +${winAmount.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </span>
                </motion.div>
              ) : (
                <motion.span
                  key="playing"
                  className={`text-8xl font-black tabular-nums ${
                    gameState === 'idle' ? 'text-zinc-700' : 'text-white drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]'
                  }`}
                >
                  {multiplier.toFixed(2)}x
                </motion.span>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Controls */}
        <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 bg-zinc-950 p-2 rounded-xl border border-zinc-800 w-full md:w-auto">
            <button 
              onClick={() => setBet(Math.max(10, bet - 10))}
              disabled={gameState === 'playing'}
              className="w-10 h-10 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center font-bold text-xl disabled:opacity-50 transition-colors"
            >-</button>
            <div className="flex flex-col items-center justify-center min-w-[80px]">
              <span className="text-[10px] text-zinc-500 font-bold uppercase tracking-wider">Bet Amount</span>
              <span className="text-xl font-bold text-white">${bet}</span>
            </div>
            <button 
              onClick={() => setBet(Math.min(1000, bet + 10))}
              disabled={gameState === 'playing'}
              className="w-10 h-10 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center justify-center font-bold text-xl disabled:opacity-50 transition-colors"
            >+</button>
          </div>

          {gameState === 'playing' ? (
            <button
              onClick={cashOut}
              className="w-full md:w-auto px-12 py-4 rounded-xl font-black text-xl uppercase tracking-widest transition-all bg-emerald-500 text-zinc-950 hover:bg-emerald-400 hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] hover:scale-105 active:scale-95"
            >
              Cash Out
            </button>
          ) : (
            <button
              onClick={startGame}
              disabled={balance < bet}
              className={`w-full md:w-auto px-12 py-4 rounded-xl font-black text-xl uppercase tracking-widest transition-all ${
                balance < bet
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                  : 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] hover:scale-105 active:scale-95'
              }`}
            >
              {gameState === 'crashed' || gameState === 'cashed_out' ? 'Play Again' : 'Place Bet'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
