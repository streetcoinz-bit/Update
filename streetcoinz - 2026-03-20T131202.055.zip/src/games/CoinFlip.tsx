import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coins, AlertCircle } from 'lucide-react';

interface CoinFlipProps {
  balance: number;
  onWin: (amount: number) => void;
  onBet: (amount: number) => boolean;
}

export function CoinFlip({ balance, onWin, onBet }: CoinFlipProps) {
  const [betAmount, setBetAmount] = useState(10);
  const [side, setSide] = useState<'heads' | 'tails'>('heads');
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<'heads' | 'tails' | null>(null);
  const [error, setError] = useState('');
  const [lastWin, setLastWin] = useState(0);

  const flip = () => {
    if (isFlipping) return;
    if (betAmount <= 0) {
      setError('Bet must be greater than 0');
      return;
    }
    if (!onBet(betAmount)) {
      setError('Insufficient balance');
      return;
    }

    setError('');
    setResult(null);
    setLastWin(0);
    setIsFlipping(true);

    setTimeout(() => {
      const outcome = Math.random() > 0.5 ? 'heads' : 'tails';
      setResult(outcome);
      setIsFlipping(false);

      if (outcome === side) {
        const winAmount = betAmount * 2;
        setLastWin(winAmount);
        onWin(winAmount);
      }
    }, 2000);
  };

  return (
    <div className="flex flex-col items-center justify-center h-full max-w-2xl mx-auto">
      <div className="w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-yellow-500 shadow-[0_0_20px_rgba(234,179,8,1)]"></div>
        
        <div className="text-center mb-8">
          <h2 className="text-4xl font-black tracking-tighter text-white flex items-center justify-center gap-3">
            <Coins className="w-8 h-8 text-yellow-500" />
            STREET <span className="text-yellow-500">FLIP</span>
          </h2>
          <p className="text-zinc-400 mt-2 font-mono">Double your money with a 50/50 chance.</p>
        </div>

        {/* Coin Area */}
        <div className="flex flex-col items-center justify-center py-12 mb-8 bg-zinc-950 rounded-2xl border border-zinc-800/50 relative">
          <motion.div
            animate={
              isFlipping 
                ? { rotateY: [0, 360, 720, 1080, 1440, 1800], y: [0, -150, 0] } 
                : result 
                  ? { rotateY: result === 'heads' ? 0 : 180 } 
                  : { rotateY: side === 'heads' ? 0 : 180 }
            }
            transition={{ duration: 2, ease: "easeInOut" }}
            className="w-40 h-40 relative preserve-3d"
            style={{ transformStyle: 'preserve-3d' }}
          >
            {/* Heads */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-yellow-300 to-yellow-600 border-4 border-yellow-200 flex items-center justify-center backface-hidden shadow-[0_0_30px_rgba(234,179,8,0.3)]" style={{ backfaceVisibility: 'hidden' }}>
              <div className="w-32 h-32 rounded-full border-2 border-yellow-700/30 flex items-center justify-center">
                <span className="text-4xl font-black text-yellow-800">H</span>
              </div>
            </div>
            {/* Tails */}
            <div className="absolute inset-0 rounded-full bg-gradient-to-br from-zinc-300 to-zinc-500 border-4 border-zinc-200 flex items-center justify-center backface-hidden shadow-[0_0_30px_rgba(161,161,170,0.3)]" style={{ backfaceVisibility: 'hidden', transform: 'rotateY(180deg)' }}>
              <div className="w-32 h-32 rounded-full border-2 border-zinc-600/30 flex items-center justify-center">
                <span className="text-4xl font-black text-zinc-700">T</span>
              </div>
            </div>
          </motion.div>

          <AnimatePresence>
            {result && !isFlipping && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className={`absolute bottom-4 font-black text-2xl tracking-wider ${result === side ? 'text-emerald-400' : 'text-red-400'}`}
              >
                {result === side ? `YOU WON $${lastWin.toFixed(2)}!` : 'YOU LOST!'}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Controls */}
        <div className="space-y-6">
          <div className="flex gap-4 p-1 bg-zinc-950 rounded-xl border border-zinc-800">
            <button
              onClick={() => setSide('heads')}
              disabled={isFlipping}
              className={`flex-1 py-3 rounded-lg font-bold transition-all ${
                side === 'heads' 
                  ? 'bg-zinc-800 text-yellow-500 shadow-md' 
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              HEADS
            </button>
            <button
              onClick={() => setSide('tails')}
              disabled={isFlipping}
              className={`flex-1 py-3 rounded-lg font-bold transition-all ${
                side === 'tails' 
                  ? 'bg-zinc-800 text-zinc-300 shadow-md' 
                  : 'text-zinc-500 hover:text-zinc-300'
              }`}
            >
              TAILS
            </button>
          </div>

          <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800/50">
            <div className="flex flex-col w-full md:w-auto">
              <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Bet Amount</label>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setBetAmount(Math.max(1, betAmount / 2))}
                  className="w-10 h-10 rounded-lg bg-zinc-800 hover:bg-zinc-700 font-mono font-bold transition-colors"
                  disabled={isFlipping}
                >
                  /2
                </button>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-mono">$</span>
                  <input
                    type="number"
                    value={betAmount}
                    onChange={(e) => setBetAmount(Number(e.target.value))}
                    className="w-24 h-10 bg-zinc-900 border border-zinc-700 rounded-lg pl-7 pr-3 font-mono font-bold focus:outline-none focus:border-yellow-500 transition-colors"
                    disabled={isFlipping}
                  />
                </div>
                <button 
                  onClick={() => setBetAmount(betAmount * 2)}
                  className="w-10 h-10 rounded-lg bg-zinc-800 hover:bg-zinc-700 font-mono font-bold transition-colors"
                  disabled={isFlipping}
                >
                  x2
                </button>
              </div>
              {error && <div className="text-red-400 text-xs mt-2 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> {error}</div>}
            </div>

            <button
              onClick={flip}
              disabled={isFlipping}
              className={`w-full md:w-auto px-12 py-4 rounded-xl font-black text-xl tracking-wider uppercase transition-all duration-200 ${
                isFlipping 
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
                  : 'bg-yellow-500 hover:bg-yellow-400 text-zinc-950 shadow-[0_0_20px_rgba(234,179,8,0.4)] hover:shadow-[0_0_30px_rgba(234,179,8,0.6)] hover:-translate-y-1'
              }`}
            >
              {isFlipping ? 'Flipping...' : 'FLIP COIN'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
