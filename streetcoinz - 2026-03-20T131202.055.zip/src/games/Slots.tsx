import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Zap, AlertCircle } from 'lucide-react';

const SYMBOLS = ['🍒', '🍋', '🍉', '💎', '7️⃣', '🔔'];
const MULTIPLIERS: Record<string, number> = {
  '🍒': 2,
  '🍋': 3,
  '🍉': 5,
  '🔔': 10,
  '💎': 25,
  '7️⃣': 50,
};

interface SlotsProps {
  balance: number;
  onWin: (amount: number) => void;
  onBet: (amount: number) => boolean;
}

export function Slots({ balance, onWin, onBet }: SlotsProps) {
  const [reels, setReels] = useState(['7️⃣', '7️⃣', '7️⃣']);
  const [isSpinning, setIsSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState(10);
  const [lastWin, setLastWin] = useState(0);
  const [error, setError] = useState('');

  const spin = () => {
    if (isSpinning) return;
    if (betAmount <= 0) {
      setError('Bet must be greater than 0');
      return;
    }
    if (!onBet(betAmount)) {
      setError('Insufficient balance');
      return;
    }

    setError('');
    setLastWin(0);
    setIsSpinning(true);

    // Simulate spinning
    let spins = 0;
    const interval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
      spins++;

      if (spins > 20) {
        clearInterval(interval);
        const finalReels = [
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        ];
        
        // Force a win sometimes for demo purposes (20% chance if not naturally winning)
        if (Math.random() > 0.8 && new Set(finalReels).size !== 1) {
            const forcedSymbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
            finalReels[0] = forcedSymbol;
            finalReels[1] = forcedSymbol;
            finalReels[2] = forcedSymbol;
        }

        setReels(finalReels);
        setIsSpinning(false);
        checkWin(finalReels);
      }
    }, 100);
  };

  const checkWin = (finalReels: string[]) => {
    if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
      const symbol = finalReels[0];
      const multiplier = MULTIPLIERS[symbol];
      const winAmount = betAmount * multiplier;
      setLastWin(winAmount);
      onWin(winAmount);
    }
  };

  return (
    <div className="flex flex-col items-center justify-center h-full max-w-3xl mx-auto">
      <div className="w-full bg-zinc-900 border border-zinc-800 rounded-3xl p-8 shadow-2xl relative overflow-hidden">
        {/* Decorative neon effects */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-3/4 h-1 bg-emerald-500 shadow-[0_0_20px_rgba(16,185,129,1)]"></div>
        
        <div className="text-center mb-8">
          <h2 className="text-4xl font-black tracking-tighter text-white flex items-center justify-center gap-3">
            <Zap className="w-8 h-8 text-emerald-500" />
            NEON <span className="text-emerald-500">SLOTS</span>
          </h2>
          <p className="text-zinc-400 mt-2 font-mono">Match 3 symbols to win up to 50x!</p>
        </div>

        {/* Slot Machine Display */}
        <div className="bg-zinc-950 border-4 border-zinc-800 rounded-2xl p-6 mb-8 relative shadow-inner">
          <div className="flex justify-center gap-4 md:gap-8">
            {reels.map((symbol, i) => (
              <div key={i} className="w-24 h-32 md:w-32 md:h-40 bg-zinc-900 rounded-xl border-2 border-zinc-800 flex items-center justify-center text-6xl md:text-8xl shadow-inner relative overflow-hidden">
                <motion.div
                  animate={isSpinning ? { y: [0, -100, 100, 0] } : { y: 0 }}
                  transition={isSpinning ? { repeat: Infinity, duration: 0.2, ease: "linear" } : { type: "spring" }}
                >
                  {symbol}
                </motion.div>
                {/* Glass reflection */}
                <div className="absolute inset-0 bg-gradient-to-b from-white/5 to-transparent pointer-events-none"></div>
              </div>
            ))}
          </div>

          {/* Win Overlay */}
          <AnimatePresence>
            {lastWin > 0 && !isSpinning && (
              <motion.div
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center bg-black/80 backdrop-blur-sm rounded-xl z-10"
              >
                <div className="text-center">
                  <div className="text-6xl font-black text-emerald-400 drop-shadow-[0_0_15px_rgba(16,185,129,0.8)] mb-2">
                    BIG WIN!
                  </div>
                  <div className="text-3xl font-mono text-white">
                    +${lastWin.toFixed(2)}
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Controls */}
        <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-zinc-950/50 p-6 rounded-2xl border border-zinc-800/50">
          <div className="flex flex-col w-full md:w-auto">
            <label className="text-xs font-bold text-zinc-500 uppercase tracking-wider mb-2">Bet Amount</label>
            <div className="flex items-center gap-2">
              <button 
                onClick={() => setBetAmount(Math.max(1, betAmount / 2))}
                className="w-10 h-10 rounded-lg bg-zinc-800 hover:bg-zinc-700 font-mono font-bold transition-colors"
                disabled={isSpinning}
              >
                /2
              </button>
              <div className="relative">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400 font-mono">$</span>
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(Number(e.target.value))}
                  className="w-24 h-10 bg-zinc-900 border border-zinc-700 rounded-lg pl-7 pr-3 font-mono font-bold focus:outline-none focus:border-emerald-500 transition-colors"
                  disabled={isSpinning}
                />
              </div>
              <button 
                onClick={() => setBetAmount(betAmount * 2)}
                className="w-10 h-10 rounded-lg bg-zinc-800 hover:bg-zinc-700 font-mono font-bold transition-colors"
                disabled={isSpinning}
              >
                x2
              </button>
            </div>
            {error && <div className="text-red-400 text-xs mt-2 flex items-center gap-1"><AlertCircle className="w-3 h-3"/> {error}</div>}
          </div>

          <button
            onClick={spin}
            disabled={isSpinning}
            className={`w-full md:w-auto px-12 py-4 rounded-xl font-black text-xl tracking-wider uppercase transition-all duration-200 ${
              isSpinning 
                ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
                : 'bg-emerald-500 hover:bg-emerald-400 text-zinc-950 shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:shadow-[0_0_30px_rgba(16,185,129,0.6)] hover:-translate-y-1'
            }`}
          >
            {isSpinning ? 'Spinning...' : 'SPIN'}
          </button>
        </div>
      </div>
    </div>
  );
}
