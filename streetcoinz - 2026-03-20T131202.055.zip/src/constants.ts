import { Coin } from './types';

export const INITIAL_COINS: Coin[] = [
  {
    id: '1',
    name: 'Graffiti',
    symbol: 'TAG',
    price: 420.69,
    change24h: 12.5,
    volume: '2.4M',
    trending: true,
  },
  {
    id: '2',
    name: 'Concrete',
    symbol: 'CRTE',
    price: 15.30,
    change24h: -2.1,
    volume: '850K',
    trending: false,
  },
  {
    id: '3',
    name: 'Neon',
    symbol: 'GLOW',
    price: 0.08,
    change24h: 45.2,
    volume: '12M',
    trending: true,
  },
  {
    id: '4',
    name: 'Subway',
    symbol: 'METRO',
    price: 2.50,
    change24h: 0.5,
    volume: '500K',
    trending: false,
  },
  {
    id: '5',
    name: 'Hype',
    symbol: 'HYPE',
    price: 1337.00,
    change24h: 8.8,
    volume: '5.1M',
    trending: true,
  }
];
