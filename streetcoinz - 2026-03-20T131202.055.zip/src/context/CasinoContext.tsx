import React, { createContext, useContext, useState, useEffect } from 'react';

interface CasinoContextType {
  balance: number;
  updateBalance: (amount: number) => void;
  history: BetHistory[];
  addHistory: (bet: BetHistory) => void;
}

export interface BetHistory {
  id: string;
  game: string;
  betAmount: number;
  payout: number;
  profit: number;
  time: Date;
  won: boolean;
}

const CasinoContext = createContext<CasinoContextType | undefined>(undefined);

export const CasinoProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [balance, setBalance] = useState(() => {
    const saved = localStorage.getItem('streetcoinz_balance');
    return saved ? parseFloat(saved) : 10000; // Starting balance $10,000
  });

  const [history, setHistory] = useState<BetHistory[]>(() => {
    const saved = localStorage.getItem('streetcoinz_history');
    return saved ? JSON.parse(saved) : [];
  });

  useEffect(() => {
    localStorage.setItem('streetcoinz_balance', balance.toString());
  }, [balance]);

  useEffect(() => {
    localStorage.setItem('streetcoinz_history', JSON.stringify(history));
  }, [history]);

  const updateBalance = (amount: number) => {
    setBalance(prev => prev + amount);
  };

  const addHistory = (bet: BetHistory) => {
    setHistory(prev => [bet, ...prev].slice(0, 50)); // Keep last 50 bets
  };

  return (
    <CasinoContext.Provider value={{ balance, updateBalance, history, addHistory }}>
      {children}
    </CasinoContext.Provider>
  );
};

export const useCasino = () => {
  const context = useContext(CasinoContext);
  if (!context) throw new Error('useCasino must be used within CasinoProvider');
  return context;
};
