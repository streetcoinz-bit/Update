import { createContext, useContext, useState, ReactNode } from "react";

interface WalletContextType {
  balance: number;
  deposit: (amount: number) => void;
  withdraw: (amount: number) => void;
  bet: (amount: number) => boolean; // Returns true if successful
  win: (amount: number) => void;
}

const WalletContext = createContext<WalletContextType | undefined>(undefined);

export function WalletProvider({ children }: { children: ReactNode }) {
  const [balance, setBalance] = useState(1000); // Start with 1000 coins

  const deposit = (amount: number) => setBalance((b) => b + amount);
  const withdraw = (amount: number) =>
    setBalance((b) => Math.max(0, b - amount));

  const bet = (amount: number) => {
    if (balance >= amount) {
      setBalance((b) => b - amount);
      return true;
    }
    return false;
  };

  const win = (amount: number) => setBalance((b) => b + amount);

  return (
    <WalletContext.Provider value={{ balance, deposit, withdraw, bet, win }}>
      {children}
    </WalletContext.Provider>
  );
}

export function useWallet() {
  const context = useContext(WalletContext);
  if (context === undefined) {
    throw new Error("useWallet must be used within a WalletProvider");
  }
  return context;
}
