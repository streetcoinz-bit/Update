import { createContext, useContext, useState, ReactNode } from "react";

interface UserContextType {
  balance: number;
  setBalance: (balance: number) => void;
  addBalance: (amount: number) => void;
  subtractBalance: (amount: number) => void;
}

const UserContext = createContext<UserContextType | undefined>(undefined);

export function UserProvider({ children }: { children: ReactNode }) {
  const [balance, setBalance] = useState(1450.25);

  const addBalance = (amount: number) => setBalance((prev) => prev + amount);
  const subtractBalance = (amount: number) => setBalance((prev) => prev - amount);

  return (
    <UserContext.Provider value={{ balance, setBalance, addBalance, subtractBalance }}>
      {children}
    </UserContext.Provider>
  );
}

export function useUser() {
  const context = useContext(UserContext);
  if (context === undefined) {
    throw new Error("useUser must be used within a UserProvider");
  }
  return context;
}
