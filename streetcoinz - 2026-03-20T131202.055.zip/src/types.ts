import { LucideIcon } from 'lucide-react';

export interface Coin {
  id: string;
  name: string;
  symbol: string;
  price: number;
  change24h: number;
  volume: string;
  trending: boolean;
}

export interface UserPortfolio {
  balance: number;
  holdings: {
    [coinId: string]: number;
  };
}

export interface HistoryData {
  timestamp: number;
  price: number;
}

export interface Game {
  id: string;
  title: string;
  provider: string;
  imageUrl: string;
  category: string;
  isHot?: boolean;
  isNew?: boolean;
}

export interface User {
  id: string;
  email: string;
  displayName: string;
  avatarUrl?: string;
  balance: number;
}

export interface Spot {
  id: string;
  name: string;
  location: string;
  imageUrl: string;
  description: string;
}
