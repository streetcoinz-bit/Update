import { Bell, Menu, Search, User, Wallet } from "lucide-react";

export function Navbar({ toggleSidebar }: { toggleSidebar: () => void }) {
  return (
    <nav className="sticky top-0 z-50 flex h-16 items-center justify-between border-b border-white/5 bg-[#0B0F19]/80 px-4 backdrop-blur-md lg:px-8">
      <div className="flex items-center gap-4">
        <button
          onClick={toggleSidebar}
          className="rounded-lg p-2 text-gray-400 hover:bg-white/5 hover:text-white lg:hidden"
        >
          <Menu className="h-6 w-6" />
        </button>
        <div className="hidden items-center gap-2 lg:flex">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500 font-bold text-white">
            S
          </div>
          <span className="text-xl font-bold tracking-tight text-white">
            Street<span className="text-emerald-500">Coinz</span>
          </span>
        </div>
      </div>

      <div className="hidden max-w-md flex-1 items-center px-8 lg:flex">
        <div className="relative w-full">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-400" />
          <input
            type="text"
            placeholder="Search games..."
            className="w-full rounded-full border border-white/10 bg-white/5 py-2 pl-10 pr-4 text-sm text-white placeholder-gray-400 focus:border-emerald-500 focus:outline-none focus:ring-1 focus:ring-emerald-500"
          />
        </div>
      </div>

      <div className="flex items-center gap-2 sm:gap-4">
        <div className="hidden flex-col items-end sm:flex">
          <span className="text-xs text-gray-400">Balance</span>
          <span className="font-mono text-sm font-bold text-emerald-400">
            $12,450.00
          </span>
        </div>
        <button className="flex items-center gap-2 rounded-full bg-emerald-500 px-4 py-2 text-sm font-bold text-white transition-colors hover:bg-emerald-600">
          <Wallet className="h-4 w-4" />
          <span className="hidden sm:inline">Deposit</span>
        </button>
        <button className="relative rounded-full p-2 text-gray-400 hover:bg-white/5 hover:text-white">
          <Bell className="h-5 w-5" />
          <span className="absolute right-1 top-1 h-2 w-2 rounded-full bg-red-500"></span>
        </button>
        <button className="rounded-full bg-white/10 p-2 text-white hover:bg-white/20">
          <User className="h-5 w-5" />
        </button>
      </div>
    </nav>
  );
}
