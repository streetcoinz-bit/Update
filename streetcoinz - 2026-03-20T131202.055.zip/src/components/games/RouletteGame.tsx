import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CircleDashed, DollarSign, ChevronLeft } from 'lucide-react';
import { toast } from '../../lib/toast';

export const RouletteGame = ({ onBack, onGameBet }: { onBack?: () => void, onGameBet?: (game: string, amount: number, won: boolean, multiplier: number) => void }) => {
  const [betAmount, setBetAmount] = useState<number | ''>('');
  const [selectedColor, setSelectedColor] = useState<'red' | 'black' | 'green' | null>(null);
  const [isSpinning, setIsSpinning] = useState(false);
  const [result, setResult] = useState<'red' | 'black' | 'green' | null>(null);

  const handleSpin = () => {
    if (!betAmount || betAmount <= 0) {
      toast.error('Enter a valid bet amount');
      return;
    }
    if (!selectedColor) {
      toast.error('Select a color to bet on');
      return;
    }

    setIsSpinning(true);
    setResult(null);

    setTimeout(() => {
      const roll = Math.random();
      let outcome: 'red' | 'black' | 'green';
      if (roll < 0.05) outcome = 'green';
      else if (roll < 0.525) outcome = 'red';
      else outcome = 'black';

      setResult(outcome);
      setIsSpinning(false);

      const won = outcome === selectedColor;
      const multiplier = outcome === 'green' ? 14 : 2;

      if (won) {
        toast.success(`You won! Multiplier: ${multiplier}x`);
      } else {
        toast.error('You lost!');
      }

      if (onGameBet) {
        onGameBet('Roulette', betAmount, won, won ? multiplier : 0);
      }
    }, 2000);
  };

  return (
    <div className="flex flex-col h-full bg-[#131212] text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#131212] shrink-0">
        <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <CircleDashed className="w-5 h-5 text-[#a252f0]" />
          <h1 className="text-xl font-bold">Roulette</h1>
        </div>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center">
        <div className="w-full max-w-md bg-[#1e1e1e] rounded-2xl p-6 border border-white/5 text-center">
          <div className="relative w-48 h-48 mx-auto mb-8">
            <motion.div 
              animate={{ rotate: isSpinning ? 360 * 5 : 0 }} 
              transition={{ duration: 2, ease: "circOut" }}
              className="w-full h-full rounded-full border-8 border-white/10 flex items-center justify-center relative"
              style={{
                background: 'conic-gradient(#ef4444 0% 47.5%, #22c55e 47.5% 52.5%, #1f2937 52.5% 100%)'
              }}
            >
              <div className="w-32 h-32 bg-[#1e1e1e] rounded-full flex items-center justify-center shadow-inner">
                {result && !isSpinning && (
                  <div className={`w-16 h-16 rounded-full ${
                    result === 'red' ? 'bg-red-500' : result === 'black' ? 'bg-gray-800' : 'bg-green-500'
                  }`} />
                )}
              </div>
            </motion.div>
            <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-2 w-4 h-6 bg-white rounded-b-full z-10" />
          </div>

          <div className="flex gap-2 mb-6">
            <button 
              onClick={() => setSelectedColor('red')}
              className={`flex-1 py-4 rounded-xl font-bold transition-all ${selectedColor === 'red' ? 'bg-red-500 text-white scale-105' : 'bg-red-500/20 text-red-500 hover:bg-red-500/30'}`}
            >
              2x
            </button>
            <button 
              onClick={() => setSelectedColor('green')}
              className={`w-20 py-4 rounded-xl font-bold transition-all ${selectedColor === 'green' ? 'bg-green-500 text-white scale-105' : 'bg-green-500/20 text-green-500 hover:bg-green-500/30'}`}
            >
              14x
            </button>
            <button 
              onClick={() => setSelectedColor('black')}
              className={`flex-1 py-4 rounded-xl font-bold transition-all ${selectedColor === 'black' ? 'bg-gray-800 text-white scale-105' : 'bg-gray-800/50 text-gray-400 hover:bg-gray-800'}`}
            >
              2x
            </button>
          </div>

          <div className="relative mb-6">
            <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(parseInt(e.target.value) || '')}
              placeholder="Bet Amount"
              className="w-full bg-black/20 border border-white/10 rounded-xl py-4 pl-12 pr-4 font-mono text-lg focus:outline-none focus:border-[#a252f0]"
            />
          </div>

          <button 
            onClick={handleSpin}
            disabled={isSpinning}
            className="w-full bg-[#a252f0] text-white font-bold py-4 rounded-xl hover:bg-[#8e44d6] transition-colors disabled:opacity-50"
          >
            {isSpinning ? 'Spinning...' : 'Place Bet'}
          </button>
        </div>
      </div>
    </div>
  );
};
