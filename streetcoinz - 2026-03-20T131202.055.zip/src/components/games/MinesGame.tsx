import React, { useState } from 'react';
import { Bomb, Diamond, DollarSign, ChevronLeft } from 'lucide-react';
import { toast } from '../../lib/toast';

export const MinesGame = ({ onBack, onGameBet }: { onBack?: () => void, onGameBet?: (game: string, amount: number, won: boolean, multiplier: number) => void }) => {
  const [betAmount, setBetAmount] = useState<number | ''>('');
  const [minesCount, setMinesCount] = useState(3);
  const [isPlaying, setIsPlaying] = useState(false);
  const [grid, setGrid] = useState<{isMine: boolean, revealed: boolean}[]>(Array(25).fill({isMine: false, revealed: false}));
  const [gameOver, setGameOver] = useState(false);
  const [revealedCount, setRevealedCount] = useState(0);

  const startGame = () => {
    if (!betAmount || betAmount <= 0) {
      toast.error('Enter a valid bet amount');
      return;
    }
    const newGrid = Array(25).fill({isMine: false, revealed: false});
    let minesPlaced = 0;
    while (minesPlaced < minesCount) {
      const idx = Math.floor(Math.random() * 25);
      if (!newGrid[idx].isMine) {
        newGrid[idx] = { isMine: true, revealed: false };
        minesPlaced++;
      }
    }
    setGrid(newGrid);
    setIsPlaying(true);
    setGameOver(false);
    setRevealedCount(0);
  };

  const handleTileClick = (index: number) => {
    if (!isPlaying || gameOver || grid[index].revealed) return;

    const newGrid = [...grid];
    newGrid[index] = { ...newGrid[index], revealed: true };
    setGrid(newGrid);

    if (newGrid[index].isMine) {
      setGameOver(true);
      setIsPlaying(false);
      // Reveal all mines
      setGrid(newGrid.map(cell => cell.isMine ? { ...cell, revealed: true } : cell));
      toast.error('BOOM! You hit a mine.');
      if (onGameBet) {
        onGameBet('Mines', Number(betAmount), false, 0);
      }
    } else {
      setRevealedCount(prev => prev + 1);
    }
  };

  const cashout = () => {
    if (!isPlaying || revealedCount === 0) return;
    setGameOver(true);
    setIsPlaying(false);
    toast.success(`Cashed out!`);
    if (onGameBet) {
      const currentMultiplier = 1 + (revealedCount * (minesCount / 25));
      onGameBet('Mines', Number(betAmount), true, currentMultiplier);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#131212] text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#131212] shrink-0">
        <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <Bomb className="w-5 h-5 text-[#a252f0]" />
          <h1 className="text-xl font-bold">Mines</h1>
        </div>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center">
        <div className="w-full max-w-md bg-[#1e1e1e] rounded-2xl p-6 border border-white/5">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold flex items-center gap-2"><Bomb className="text-[#a252f0]" /> Mines</h2>
            {isPlaying && <span className="text-green-500 font-mono font-bold">Safe: {revealedCount}</span>}
          </div>

          <div className="grid grid-cols-5 gap-2 mb-8 aspect-square max-w-sm mx-auto">
            {grid.map((cell, idx) => (
              <button
                key={idx}
                onClick={() => handleTileClick(idx)}
                disabled={!isPlaying || gameOver || cell.revealed}
                className={`rounded-lg flex items-center justify-center transition-all duration-300 ${
                  cell.revealed 
                    ? cell.isMine 
                      ? 'bg-red-500/20 border-2 border-red-500' 
                      : 'bg-green-500/20 border-2 border-green-500'
                    : 'bg-white/5 hover:bg-white/10 border-2 border-transparent'
                }`}
              >
                {cell.revealed && cell.isMine && <Bomb className="w-6 h-6 text-red-500" />}
                {cell.revealed && !cell.isMine && <Diamond className="w-6 h-6 text-green-500" />}
              </button>
            ))}
          </div>

          {!isPlaying && !gameOver && (
            <div className="space-y-4 mb-6">
              <div>
                <label className="text-xs text-gray-500 uppercase mb-2 block">Mines</label>
                <select 
                  value={minesCount} 
                  onChange={(e) => setMinesCount(parseInt(e.target.value))}
                  className="w-full bg-black/20 border border-white/10 rounded-xl p-4 text-white focus:outline-none focus:border-[#a252f0]"
                >
                  {[1,3,5,10,24].map(n => <option key={n} value={n}>{n} Mines</option>)}
                </select>
              </div>
              <div className="relative">
                <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
                <input
                  type="number"
                  value={betAmount}
                  onChange={(e) => setBetAmount(parseInt(e.target.value) || '')}
                  placeholder="Bet Amount"
                  className="w-full bg-black/20 border border-white/10 rounded-xl py-4 pl-12 pr-4 font-mono text-lg focus:outline-none focus:border-[#a252f0]"
                />
              </div>
            </div>
          )}

          {isPlaying ? (
            <button 
              onClick={cashout}
              className="w-full bg-green-500 text-white font-bold py-4 rounded-xl hover:bg-green-600 transition-colors"
            >
              Cashout
            </button>
          ) : (
            <button 
              onClick={startGame}
              className="w-full bg-[#a252f0] text-white font-bold py-4 rounded-xl hover:bg-[#8e44d6] transition-colors"
            >
              {gameOver ? 'Play Again' : 'Bet'}
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
