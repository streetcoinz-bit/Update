import { useState } from "react";
import { motion } from "motion/react";
import { Coins, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface CoinFlipProps {
  userId: string;
  onBalanceUpdate: (newBalance: number) => void;
}

export default function CoinFlip({ userId, onBalanceUpdate }: CoinFlipProps) {
  const [amount, setAmount] = useState<number>(10);
  const [guess, setGuess] = useState<"heads" | "tails">("heads");
  const [isFlipping, setIsFlipping] = useState(false);
  const [result, setResult] = useState<{
    win: boolean;
    payout: number;
    result: string;
  } | null>(null);

  const handleFlip = async () => {
    setIsFlipping(true);
    setResult(null);

    try {
      const response = await fetch("/api/play/coinflip", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, amount, guess }),
      });

      const data = await response.json();

      if (response.ok) {
        // Simulate flip animation time
        setTimeout(() => {
          setResult(data);
          onBalanceUpdate(data.newBalance);
          setIsFlipping(false);
        }, 1500);
      } else {
        alert(data.error);
        setIsFlipping(false);
      }
    } catch (error) {
      console.error("Error flipping coin:", error);
      setIsFlipping(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto border-zinc-800 bg-zinc-950/50 backdrop-blur-xl">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-emerald-400 flex items-center justify-center gap-2">
          <Coins className="w-6 h-6" />
          Street Coin Toss
        </CardTitle>
        <CardDescription>Double your money or lose it all.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Coin Animation Area */}
        <div className="flex justify-center py-8">
          <motion.div
            animate={
              isFlipping
                ? { rotateY: [0, 360, 720, 1080], scale: [1, 1.2, 1] }
                : {}
            }
            transition={{ duration: 1.5, ease: "easeInOut" }}
            className="w-32 h-32 rounded-full border-4 border-yellow-500 bg-yellow-400 flex items-center justify-center shadow-[0_0_30px_rgba(234,179,8,0.5)]"
          >
            {isFlipping ? (
              <Coins className="w-16 h-16 text-yellow-700 animate-pulse" />
            ) : result ? (
              <span className="text-4xl font-black text-yellow-800 uppercase">
                {result.result[0]}
              </span>
            ) : (
              <span className="text-4xl font-black text-yellow-800">?</span>
            )}
          </motion.div>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-zinc-900 p-2 rounded-lg">
            <span className="text-zinc-400 text-sm px-2">Bet Amount</span>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="bg-transparent text-right text-white font-mono outline-none w-24"
              min="1"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button
              variant={guess === "heads" ? "neon" : "outline"}
              className={
                guess === "heads" ? "" : "border-zinc-700 text-zinc-400"
              }
              onClick={() => setGuess("heads")}
              disabled={isFlipping}
            >
              HEADS
            </Button>
            <Button
              variant={guess === "tails" ? "neon" : "outline"}
              className={
                guess === "tails" ? "" : "border-zinc-700 text-zinc-400"
              }
              onClick={() => setGuess("tails")}
              disabled={isFlipping}
            >
              TAILS
            </Button>
          </div>

          <Button
            variant="neon"
            className="w-full h-14 text-lg mt-4"
            onClick={handleFlip}
            disabled={isFlipping || amount <= 0}
          >
            {isFlipping ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              "FLIP COIN"
            )}
          </Button>
        </div>

        {/* Result Display */}
        {result && !isFlipping && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center p-4 rounded-lg ${result.win ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}
          >
            <p className="font-bold text-lg">
              {result.win ? "YOU WON!" : "YOU LOST!"}
            </p>
            {result.win && (
              <p className="font-mono">+{result.payout.toFixed(2)}</p>
            )}
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
