import { useState } from "react";
import { motion } from "motion/react";
import { Dices, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

interface DiceRollProps {
  userId: string;
  onBalanceUpdate: (newBalance: number) => void;
}

export default function DiceRoll({ userId, onBalanceUpdate }: DiceRollProps) {
  const [amount, setAmount] = useState<number>(10);
  const [target, setTarget] = useState<number>(50);
  const [condition, setCondition] = useState<"over" | "under">("over");
  const [isRolling, setIsRolling] = useState(false);
  const [result, setResult] = useState<{
    win: boolean;
    payout: number;
    roll: number;
    multiplier: number;
  } | null>(null);

  const handleRoll = async () => {
    setIsRolling(true);
    setResult(null);

    try {
      const response = await fetch("/api/play/dice", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, amount, target, condition }),
      });

      const data = await response.json();

      if (response.ok) {
        setTimeout(() => {
          setResult(data);
          onBalanceUpdate(data.newBalance);
          setIsRolling(false);
        }, 1000);
      } else {
        alert(data.error);
        setIsRolling(false);
      }
    } catch (error) {
      console.error("Error rolling dice:", error);
      setIsRolling(false);
    }
  };

  const calculateMultiplier = () => {
    let mult = 0;
    if (condition === "over") {
      mult = 99 / (100 - target);
    } else {
      mult = 99 / (target - 1);
    }
    return (mult * 0.98).toFixed(2); // 2% house edge
  };

  const calculateWinChance = () => {
    if (condition === "over") return 100 - target;
    return target - 1;
  };

  return (
    <Card className="w-full max-w-md mx-auto border-zinc-800 bg-zinc-950/50 backdrop-blur-xl">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-purple-400 flex items-center justify-center gap-2">
          <Dices className="w-6 h-6" />
          Street Dice
        </CardTitle>
        <CardDescription>Roll the dice, beat the odds.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Roll Display */}
        <div className="flex justify-center py-6">
          <motion.div
            animate={
              isRolling
                ? { scale: [1, 1.1, 1], rotate: [0, -10, 10, -10, 0] }
                : {}
            }
            transition={{ duration: 0.5, repeat: isRolling ? Infinity : 0 }}
            className="w-32 h-32 rounded-2xl border-2 border-purple-500/50 bg-zinc-900 flex items-center justify-center shadow-[0_0_20px_rgba(168,85,247,0.2)]"
          >
            {isRolling ? (
              <Dices className="w-16 h-16 text-purple-500 animate-pulse" />
            ) : result ? (
              <span
                className={`text-5xl font-black ${result.win ? "text-emerald-400" : "text-red-400"}`}
              >
                {result.roll}
              </span>
            ) : (
              <span className="text-5xl font-black text-zinc-700">00</span>
            )}
          </motion.div>
        </div>

        {/* Controls */}
        <div className="space-y-4">
          <div className="flex justify-between items-center bg-zinc-900 p-2 rounded-lg">
            <span className="text-zinc-400 text-sm px-2">Bet Amount</span>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="bg-transparent text-right text-white font-mono outline-none w-24"
              min="1"
            />
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm text-zinc-400">
              <span>Target: {target}</span>
              <span>Win Chance: {calculateWinChance()}%</span>
            </div>
            <input
              type="range"
              min="2"
              max="98"
              value={target}
              onChange={(e) => setTarget(Number(e.target.value))}
              className="w-full accent-purple-500"
              disabled={isRolling}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Button
              variant={condition === "under" ? "neon" : "outline"}
              className={
                condition === "under"
                  ? "!bg-purple-500 hover:!bg-purple-400 !shadow-[0_0_15px_rgba(168,85,247,0.5)]"
                  : "border-zinc-700 text-zinc-400"
              }
              onClick={() => setCondition("under")}
              disabled={isRolling}
            >
              ROLL UNDER
            </Button>
            <Button
              variant={condition === "over" ? "neon" : "outline"}
              className={
                condition === "over"
                  ? "!bg-purple-500 hover:!bg-purple-400 !shadow-[0_0_15px_rgba(168,85,247,0.5)]"
                  : "border-zinc-700 text-zinc-400"
              }
              onClick={() => setCondition("over")}
              disabled={isRolling}
            >
              ROLL OVER
            </Button>
          </div>

          <div className="text-center text-sm text-zinc-500 font-mono">
            Multiplier: {calculateMultiplier()}x
          </div>

          <Button
            variant="neon"
            className="w-full h-14 text-lg !bg-purple-500 hover:!bg-purple-400 !shadow-[0_0_15px_rgba(168,85,247,0.5)]"
            onClick={handleRoll}
            disabled={isRolling || amount <= 0}
          >
            {isRolling ? (
              <Loader2 className="w-6 h-6 animate-spin" />
            ) : (
              "ROLL DICE"
            )}
          </Button>
        </div>

        {/* Result Display */}
        {result && !isRolling && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className={`text-center p-4 rounded-lg ${result.win ? "bg-emerald-500/20 text-emerald-400" : "bg-red-500/20 text-red-400"}`}
          >
            <p className="font-bold text-lg">
              {result.win ? "YOU WON!" : "YOU LOST!"}
            </p>
            {result.win && (
              <p className="font-mono">+{result.payout.toFixed(2)}</p>
            )}
          </motion.div>
        )}
      </CardContent>
    </Card>
  );
}
