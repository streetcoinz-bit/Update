import React, { useState } from 'react';
import { motion } from 'motion/react';
import { AlignEndHorizontal, DollarSign, ChevronLeft } from 'lucide-react';
import { toast } from '../../lib/toast';

export const PlinkoGame = ({ onBack, onGameBet }: { onBack?: () => void, onGameBet?: (game: string, amount: number, won: boolean, multiplier: number) => void }) => {
  const [betAmount, setBetAmount] = useState<number | ''>('');
  const [isDropping, setIsDropping] = useState(false);
  const [resultMultiplier, setResultMultiplier] = useState<number | null>(null);
  const [ballPath, setBallPath] = useState<{x: number, y: number}[]>([]);

  const multipliers = [16, 9, 2, 1.4, 1.4, 1.2, 1.1, 1, 0.5, 1, 1.1, 1.2, 1.4, 1.4, 2, 9, 16];

  const handleDrop = () => {
    if (!betAmount || betAmount <= 0) {
      toast.error('Enter a valid bet amount');
      return;
    }

    setIsDropping(true);
    setResultMultiplier(null);
    setBallPath([]);

    // Simulate path
    const rows = 16;
    let currentPos = 8; // Start in middle of 17 slots
    const path = [{x: currentPos, y: 0}];

    for (let i = 1; i <= rows; i++) {
      const dir = Math.random() > 0.5 ? 0.5 : -0.5;
      currentPos += dir;
      path.push({x: currentPos, y: i});
    }

    setBallPath(path);

    setTimeout(() => {
      const finalIndex = Math.round(currentPos);
      const mult = multipliers[Math.min(Math.max(finalIndex, 0), multipliers.length - 1)];
      setResultMultiplier(mult);
      setIsDropping(false);
      if (mult > 1) {
        toast.success(`Won ${mult}x!`);
      } else {
        toast.error(`Got ${mult}x`);
      }
      if (onGameBet) {
        onGameBet('Plinko', betAmount, mult > 1, mult);
      }
    }, rows * 200);
  };

  return (
    <div className="flex flex-col h-full bg-[#131212] text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#131212] shrink-0">
        <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <AlignEndHorizontal className="w-5 h-5 text-[#a252f0]" />
          <h1 className="text-xl font-bold">Plinko</h1>
        </div>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center">
        <div className="w-full max-w-md bg-[#1e1e1e] rounded-2xl p-6 border border-white/5 text-center">
          <div className="relative w-full max-w-sm mx-auto aspect-square bg-black/20 rounded-xl border border-white/5 mb-8 overflow-hidden p-4 flex flex-col justify-between">
            {/* Pegs representation */}
            <div className="flex-1 flex flex-col justify-between py-4">
              {Array.from({length: 8}).map((_, row) => (
                <div key={row} className="flex justify-center gap-4">
                  {Array.from({length: row + 3}).map((_, col) => (
                    <div key={col} className="w-2 h-2 rounded-full bg-white/20" />
                  ))}
                </div>
              ))}
            </div>

            {/* Ball Animation */}
            {isDropping && ballPath.length > 0 && (
              <motion.div
                className="absolute w-4 h-4 bg-[#a252f0] rounded-full shadow-[0_0_10px_#a252f0]"
                initial={{ top: '10%', left: '50%', x: '-50%' }}
                animate={{ 
                  top: '85%', 
                  left: `${(ballPath[ballPath.length-1].x / 16) * 100}%`,
                  x: '-50%'
                }}
                transition={{ duration: 3, ease: "linear" }}
              />
            )}

            {/* Multipliers */}
            <div className="flex justify-between gap-1 mt-auto">
              {[16, 2, 1.2, 0.5, 1.2, 2, 16].map((m, i) => (
                <div key={i} className={`flex-1 text-[10px] font-bold py-2 rounded ${
                  m >= 2 ? 'bg-green-500/20 text-green-500' : 
                  m < 1 ? 'bg-red-500/20 text-red-500' : 'bg-yellow-500/20 text-yellow-500'
                }`}>
                  {m}x
                </div>
              ))}
            </div>
          </div>

          <div className="relative mb-6">
            <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(parseInt(e.target.value) || '')}
              placeholder="Bet Amount"
              className="w-full bg-black/20 border border-white/10 rounded-xl py-4 pl-12 pr-4 font-mono text-lg focus:outline-none focus:border-[#a252f0]"
            />
          </div>

          <button 
            onClick={handleDrop}
            disabled={isDropping}
            className="w-full bg-[#a252f0] text-white font-bold py-4 rounded-xl hover:bg-[#8e44d6] transition-colors disabled:opacity-50"
          >
            {isDropping ? 'Dropping...' : 'Drop Ball'}
          </button>
        </div>
      </div>
    </div>
  );
};
