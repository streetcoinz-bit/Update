import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Dices, DollarSign, ChevronLeft } from 'lucide-react';
import { toast } from '../../lib/toast';

export const DiceGame = ({ onBack, onGameBet }: { onBack?: () => void, onGameBet?: (game: string, amount: number, won: boolean, multiplier: number) => void }) => {
  const [betAmount, setBetAmount] = useState<number | ''>('');
  const [target, setTarget] = useState(50);
  const [condition, setCondition] = useState<'under' | 'over'>('under');
  const [result, setResult] = useState<number | null>(null);
  const [isRolling, setIsRolling] = useState(false);

  const multiplier = condition === 'under' ? 99 / target : 99 / (100 - target);

  const handleRoll = () => {
    if (!betAmount || betAmount <= 0) {
      toast.error('Enter a valid bet amount');
      return;
    }
    setIsRolling(true);
    setResult(null);
    setTimeout(() => {
      const roll = Math.floor(Math.random() * 100) + 1;
      setResult(roll);
      setIsRolling(false);
      const won = condition === 'under' ? roll < target : roll > target;
      if (won) {
        toast.success(`You won! Rolled ${roll}`);
      } else {
        toast.error(`You lost. Rolled ${roll}`);
      }
      if (onGameBet) {
        onGameBet('Dice', betAmount, won, multiplier);
      }
    }, 1000);
  };

  return (
    <div className="flex flex-col h-full bg-[#131212] text-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b border-white/10 bg-[#131212] shrink-0">
        <button onClick={onBack} className="p-2 hover:bg-white/5 rounded-full transition-colors">
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div className="flex items-center gap-2">
          <Dices className="w-5 h-5 text-[#a252f0]" />
          <h1 className="text-xl font-bold">Dice</h1>
        </div>
        <div className="w-10" />
      </div>

      <div className="flex-1 overflow-y-auto p-4 flex flex-col items-center justify-center">
        <div className="w-full max-w-md bg-[#1e1e1e] rounded-2xl p-6 border border-white/5 text-center">
          <div className="text-6xl font-mono font-bold text-white my-8 h-20 flex items-center justify-center">
            {isRolling ? (
              <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 0.5 }}>
                <Dices className="w-16 h-16 text-gray-500" />
              </motion.div>
            ) : result !== null ? (
              <span className={(condition === 'under' ? result < target : result > target) ? 'text-green-500' : 'text-red-500'}>
                {result}
              </span>
            ) : (
              <span className="text-gray-500">00</span>
            )}
          </div>

          <div className="mb-8">
            <div className="flex justify-between text-sm text-gray-400 mb-2">
              <span>0</span>
              <span>Target: {target}</span>
              <span>100</span>
            </div>
            <input 
              type="range" 
              min="2" 
              max="98" 
              value={target} 
              onChange={(e) => setTarget(parseInt(e.target.value))}
              className="w-full accent-[#a252f0]"
            />
          </div>

          <div className="flex gap-2 mb-6">
            <button 
              onClick={() => setCondition('under')}
              className={`flex-1 py-3 rounded-xl font-bold transition-colors ${condition === 'under' ? 'bg-[#a252f0] text-white' : 'bg-white/5 text-gray-400'}`}
            >
              Roll Under {target}
            </button>
            <button 
              onClick={() => setCondition('over')}
              className={`flex-1 py-3 rounded-xl font-bold transition-colors ${condition === 'over' ? 'bg-[#a252f0] text-white' : 'bg-white/5 text-gray-400'}`}
            >
              Roll Over {target}
            </button>
          </div>

          <div className="flex justify-between bg-black/20 p-4 rounded-xl mb-6">
            <div>
              <p className="text-xs text-gray-500 uppercase">Multiplier</p>
              <p className="font-mono font-bold">{multiplier.toFixed(2)}x</p>
            </div>
            <div className="text-right">
              <p className="text-xs text-gray-500 uppercase">Win Chance</p>
              <p className="font-mono font-bold">{condition === 'under' ? target - 1 : 100 - target}%</p>
            </div>
          </div>

          <div className="relative mb-6">
            <DollarSign className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-500" />
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(parseInt(e.target.value) || '')}
              placeholder="Bet Amount"
              className="w-full bg-black/20 border border-white/10 rounded-xl py-4 pl-12 pr-4 font-mono text-lg focus:outline-none focus:border-[#a252f0] transition-colors"
            />
          </div>

          <button 
            onClick={handleRoll}
            disabled={isRolling}
            className="w-full bg-[#a252f0] text-white font-bold py-4 rounded-xl hover:bg-[#8e44d6] transition-colors disabled:opacity-50"
          >
            {isRolling ? 'Rolling...' : 'Place Bet'}
          </button>
        </div>
      </div>
    </div>
  );
};
