import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

// Mock data for portfolio since we can't easily fetch historical portfolio data without auth
const data = [
  { time: "00:00", value: 12400 },
  { time: "04:00", value: 12800 },
  { time: "08:00", value: 12100 },
  { time: "12:00", value: 13500 },
  { time: "16:00", value: 13200 },
  { time: "20:00", value: 14800 },
  { time: "24:00", value: 15240 },
];

const CustomTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    return (
      <div className="bg-brutal-black border-2 border-neon-green p-3 font-mono">
        <p className="text-brutal-white/70 text-xs mb-1">{label}</p>
        <p className="text-neon-green font-bold text-lg">
          ${payload[0].value.toLocaleString()}
        </p>
      </div>
    );
  }
  return null;
};

export function PortfolioChart() {
  return (
    <div className="w-full h-[300px] sm:h-[400px] bg-brutal-gray border-2 border-brutal-white relative overflow-hidden group">
      <div className="absolute top-4 left-4 z-10">
        <div className="font-display text-4xl sm:text-6xl tracking-tight leading-none">
          $15,240<span className="text-neon-green">.00</span>
        </div>
        <div className="font-mono text-neon-green text-sm mt-2 flex items-center gap-2">
          <span className="bg-neon-green text-brutal-black px-1 py-0.5 font-bold">
            +22.9%
          </span>
          <span>PAST 24H</span>
        </div>
      </div>

      <div className="absolute inset-0 pt-24">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart
            data={data}
            margin={{ top: 0, right: 0, left: 0, bottom: 0 }}
          >
            <defs>
              <linearGradient id="colorValue" x1="0" y1="0" x2="0" y2="1">
                <stop
                  offset="5%"
                  stopColor="var(--color-neon-green)"
                  stopOpacity={0.3}
                />
                <stop
                  offset="95%"
                  stopColor="var(--color-neon-green)"
                  stopOpacity={0}
                />
              </linearGradient>
            </defs>
            <CartesianGrid
              strokeDasharray="3 3"
              stroke="var(--color-brutal-white)"
              opacity={0.1}
              vertical={false}
            />
            <Tooltip content={<CustomTooltip />} />
            <Area
              type="monotone"
              dataKey="value"
              stroke="var(--color-neon-green)"
              strokeWidth={3}
              fillOpacity={1}
              fill="url(#colorValue)"
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      {/* Decorative elements */}
      <div className="absolute bottom-4 right-4 font-mono text-xs text-brutal-white/30 uppercase tracking-widest">
        LIVE FEED // SECURE
      </div>
      <div className="absolute top-4 right-4 w-3 h-3 bg-neon-green rounded-full animate-pulse"></div>
    </div>
  );
}
