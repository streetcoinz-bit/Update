import { Play, ArrowRight, Zap } from 'lucide-react';
import { motion } from 'motion/react';

export function HeroBanner() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className="relative overflow-hidden rounded-3xl bg-zinc-900 border border-zinc-800 p-8 md:p-12 lg:p-16 mb-12 group"
    >
      {/* Background Effects */}
      <div className="absolute inset-0 bg-gradient-to-r from-zinc-950 via-zinc-900/80 to-transparent z-10" />
      <div className="absolute -right-20 -top-20 w-96 h-96 bg-emerald-500/20 rounded-full blur-[100px] group-hover:bg-emerald-500/30 transition-colors duration-700" />
      <div className="absolute right-40 bottom-0 w-64 h-64 bg-yellow-500/10 rounded-full blur-[80px]" />
      
      {/* Content */}
      <div className="relative z-20 max-w-2xl">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-zinc-800/80 border border-zinc-700 text-xs font-semibold text-emerald-400 mb-6 uppercase tracking-wider backdrop-blur-sm">
          <Zap size={14} className="fill-emerald-400" />
          Welcome Bonus
        </div>
        
        <h1 className="text-4xl md:text-5xl lg:text-7xl font-display font-black text-white leading-[1.1] mb-6 tracking-tight">
          DOUBLE YOUR <br />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-amber-600">
            FIRST DEPOSIT
          </span>
        </h1>
        
        <p className="text-lg md:text-xl text-zinc-400 mb-8 max-w-lg font-medium">
          Get a 100% match bonus up to 1 BTC + 50 Free Spins on StreetCoinz exclusive slots.
        </p>
        
        <div className="flex flex-wrap items-center gap-4">
          <button className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold px-8 py-4 rounded-full text-lg transition-all shadow-[0_0_20px_rgba(16,185,129,0.4)] hover:shadow-[0_0_30px_rgba(16,185,129,0.6)] flex items-center gap-2">
            Claim Bonus <ArrowRight size={20} />
          </button>
          <button className="bg-zinc-800 hover:bg-zinc-700 text-white font-semibold px-8 py-4 rounded-full text-lg transition-colors border border-zinc-700 flex items-center gap-2">
            <Play size={20} className="fill-white" /> Play Now
          </button>
        </div>
      </div>

      {/* Decorative Image */}
      <div className="absolute right-0 top-0 bottom-0 w-1/2 hidden lg:block z-0">
        <img 
          src="https://images.unsplash.com/photo-1596838132731-3301c3fd4317?q=80&w=2070&auto=format&fit=crop" 
          alt="Casino Chips" 
          className="w-full h-full object-cover opacity-40 mix-blend-luminosity"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-l from-transparent to-zinc-900" />
      </div>
    </motion.div>
  );
}
