import React, { useState } from 'react';
import { Camera, Upload, Loader2, CheckCircle2 } from 'lucide-react';
import { analyzeSpot } from '../services/gemini';

interface SpotUploaderProps {
  onUpload: (data: any) => void;
}

export const SpotUploader: React.FC<SpotUploaderProps> = ({ onUpload }) => {
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setLoading(true);
    setSuccess(false);

    const reader = new FileReader();
    reader.onloadend = async () => {
      const base64 = reader.result as string;
      try {
        const analysis = await analyzeSpot(base64);
        onUpload({ ...analysis, image: base64 });
        setSuccess(true);
        setTimeout(() => setSuccess(false), 3000);
      } catch (error) {
        console.error('Analysis failed', error);
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="brutal-border bg-black text-white p-6 relative overflow-hidden">
      <div className="relative z-10">
        <h2 className="font-display text-3xl uppercase mb-2">Drop a Spot</h2>
        <p className="font-mono text-xs text-gray-400 mb-6">Upload a photo to earn cred. Gemini AI will analyze your find.</p>
        
        <label className="brutal-btn bg-neon-green text-black flex items-center justify-center gap-2 cursor-pointer">
          {loading ? (
            <Loader2 className="animate-spin" />
          ) : success ? (
            <CheckCircle2 />
          ) : (
            <Camera />
          )}
          <span className="font-display">
            {loading ? 'Analyzing...' : success ? 'Spot Dropped!' : 'Capture Spot'}
          </span>
          <input 
            type="file" 
            accept="image/*" 
            className="hidden" 
            onChange={handleFileChange}
            disabled={loading}
          />
        </label>
      </div>
      
      {/* Decorative elements */}
      <div className="absolute -bottom-4 -right-4 opacity-20">
        <Upload size={120} />
      </div>
    </div>
  );
};
