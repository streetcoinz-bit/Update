import { motion } from 'motion/react';
import { TICKER_DATA } from '../data';

export default function LiveTicker() {
  return (
    <div className="w-full bg-surface border border-white/5 rounded-2xl overflow-hidden flex items-center h-14 relative">
      <div className="absolute left-0 top-0 bottom-0 w-24 bg-gradient-to-r from-surface to-transparent z-10 flex items-center pl-4">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-brand animate-pulse" />
          <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Live</span>
        </div>
      </div>

      <div className="flex-1 overflow-hidden relative">
        <motion.div
          animate={{ x: [0, -1035] }}
          transition={{
            x: {
              repeat: Infinity,
              repeatType: "loop",
              duration: 20,
              ease: "linear",
            },
          }}
          className="flex whitespace-nowrap items-center h-full pl-32"
        >
          {/* Double the data for seamless looping */}
          {[...TICKER_DATA, ...TICKER_DATA].map((item, i) => (
            <div key={`${item.id}-${i}`} className="flex items-center gap-3 mx-6">
              <span className="text-sm text-gray-400">{item.user}</span>
              <span className="text-sm text-white font-medium">{item.game}</span>
              <span className="text-sm font-bold text-brand">{item.payout}</span>
              <span className="text-xs px-2 py-0.5 rounded-md bg-white/10 text-white font-mono">
                {item.multiplier}
              </span>
            </div>
          ))}
        </motion.div>
      </div>

      <div className="absolute right-0 top-0 bottom-0 w-12 bg-gradient-to-l from-surface to-transparent z-10" />
    </div>
  );
}
