import React, { useState, useEffect } from 'react';
import { Crown, Activity, RefreshCw, DollarSign, TrendingUp } from 'lucide-react';
import { toast } from '../lib/toast';

export function OwnerDashboard({ userEmail }: { userEmail?: string }) {
  const [isIDR, setIsIDR] = useState(() => {
    const saved = localStorage.getItem('admin_currency_idr');
    return saved === 'true';
  });

  const [ownerStats, setOwnerStats] = useState<any>({
    totalRevenue: 0,
    totalPayouts: 0,
    netProfit: 0,
    activeAdmins: 0,
    totalPlatformFees: 0,
    totalReferralPayouts: 0,
    totalCashbackPayouts: 0,
  });
  const [ledgerEntries, setLedgerEntries] = useState<any[]>([]);

  useEffect(() => {
    localStorage.setItem('admin_currency_idr', String(isIDR));
  }, [isIDR]);

  const EXCHANGE_RATE = 15500;

  const formatCurrency = (amount: number) => {
    if (isIDR) {
      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount * EXCHANGE_RATE);
    }
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  const injectFakeData = () => {
    setOwnerStats({
      totalRevenue: 45000000.00 * 0.025, // Assuming 2.5% edge
      totalPayouts: 4200000.00,
      netProfit: (45000000.00 * 0.025) - 250000.00 - 150000.00,
      activeAdmins: 3,
      totalPlatformFees: 45000000.00 * 0.025,
      totalReferralPayouts: 150000.00,
      totalCashbackPayouts: 250000.00,
    });

    const fakeLedger = Array.from({ length: 15 }).map((_, i) => {
      const type = ['Deposit', 'Withdrawal', 'Bet Won', 'Bet Lost'][Math.floor(Math.random() * 4)];
      const amount = Math.random() * 1000;
      let profit = 0;
      if (type === 'Deposit') profit = amount * 0.025;
      if (type === 'Bet Lost') profit = amount;
      if (type === 'Bet Won') profit = -amount * 0.025;
      
      return {
        id: `fake-ledger-${i}`,
        date: new Date(Date.now() - Math.random() * 10000000).toISOString(),
        type: type,
        amount: amount,
        profit: profit
      };
    }).sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    setLedgerEntries(fakeLedger);

    toast.success('Fake owner data injected for testing logic');
  };

  if (userEmail !== 'streetcoinz@gmail.com') {
    return <div className="pt-20 px-4 text-center text-red-500">Access Denied</div>;
  }

  return (
    <div className="pt-20 px-4 pb-24 min-h-screen">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-purple-500/20 flex items-center justify-center border border-purple-500/30">
            <Crown className="w-5 h-5 text-purple-500" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Owner Dashboard</h2>
            <p className="text-sm text-gray-400">Executive Overview & Controls</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={injectFakeData}
            className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 border border-purple-500/30 rounded-lg text-sm font-bold text-purple-400 hover:bg-purple-500/30 transition-colors"
            title="Inject Fake Data"
          >
            <Activity className="w-4 h-4" />
            Test Logic
          </button>
          <button
            onClick={() => setIsIDR(!isIDR)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#1e1e1e] border border-white/10 rounded-lg text-sm font-bold hover:bg-white/5 transition-colors"
            title="Toggle Currency (USD/IDR)"
          >
            <RefreshCw className={`w-4 h-4 text-gray-400 transition-transform ${isIDR ? 'rotate-180' : ''}`} />
            {isIDR ? 'IDR' : 'USD'}
          </button>
        </div>
      </div>

      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Total Revenue (Fees)</div>
            <div className="text-2xl font-mono font-bold text-green-400">{formatCurrency(ownerStats.totalRevenue)}</div>
          </div>
          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Net Profit</div>
            <div className="text-2xl font-mono font-bold text-purple-400">{formatCurrency(ownerStats.netProfit)}</div>
          </div>
          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Active Admins</div>
            <div className="text-2xl font-mono font-bold text-white">{ownerStats.activeAdmins}</div>
          </div>
          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Total Referral Payouts</div>
            <div className="text-2xl font-mono font-bold text-red-400">{formatCurrency(ownerStats.totalReferralPayouts)}</div>
          </div>
          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Total Cashback Payouts</div>
            <div className="text-2xl font-mono font-bold text-red-400">{formatCurrency(ownerStats.totalCashbackPayouts)}</div>
          </div>
        </div>

        <div className="grid gap-6">
          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Global Platform Controls</h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-[#1e1e1e] rounded-xl border border-white/5">
                <div>
                  <div className="font-bold text-white">Platform Fee Percentage</div>
                  <div className="text-xs text-gray-400">Current fee taken from winning bets</div>
                </div>
                <div className="flex items-center gap-2">
                  <input type="number" defaultValue="2.5" className="w-20 bg-black/40 text-white px-3 py-1.5 rounded-lg border border-white/10 text-center font-mono" />
                  <span className="text-gray-400">%</span>
                  <button className="px-3 py-1.5 bg-purple-500 text-white rounded-lg text-sm font-bold hover:bg-purple-600">Save</button>
                </div>
              </div>
              
              <div className="flex items-center justify-between p-4 bg-[#1e1e1e] rounded-xl border border-white/5">
                <div>
                  <div className="font-bold text-white">Admin Management</div>
                  <div className="text-xs text-gray-400">Manage admin accounts and permissions</div>
                </div>
                <button className="px-4 py-2 bg-white/10 text-white rounded-lg text-sm font-bold hover:bg-white/20">Manage Admins</button>
              </div>
            </div>
          </div>

          <div className="bg-black/20 p-5 rounded-xl border border-white/5">
            <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-4">Global Financial Ledger</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-white/10 text-xs text-gray-400 uppercase tracking-wider">
                    <th className="p-3 font-medium">Date</th>
                    <th className="p-3 font-medium">Type</th>
                    <th className="p-3 font-medium text-right">Amount</th>
                    <th className="p-3 font-medium text-right">Platform Profit</th>
                  </tr>
                </thead>
                <tbody className="text-sm">
                  {ledgerEntries.length > 0 ? (
                    ledgerEntries.map((entry) => (
                      <tr key={entry.id} className="border-b border-white/5 hover:bg-white/5 transition-colors">
                        <td className="p-3 text-gray-300">{new Date(entry.date).toLocaleString()}</td>
                        <td className={`p-3 font-bold ${entry.type === 'Deposit' || entry.type === 'Bet Lost' ? 'text-green-400' : 'text-red-400'}`}>{entry.type}</td>
                        <td className="p-3 text-right font-mono text-white">{formatCurrency(entry.amount)}</td>
                        <td className={`p-3 text-right font-mono ${entry.profit > 0 ? 'text-green-500' : entry.profit < 0 ? 'text-red-500' : 'text-gray-500'}`}>
                          {entry.profit > 0 ? '+' : ''}{formatCurrency(entry.profit)}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr className="border-b border-white/5 hover:bg-white/5 transition-colors">
                      <td className="p-3 text-gray-300">No data</td>
                      <td className="p-3 text-gray-500">-</td>
                      <td className="p-3 text-right font-mono text-gray-500">-</td>
                      <td className="p-3 text-right font-mono text-gray-500">-</td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
