import { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { Dices, Sparkles } from 'lucide-react';

const SYMBOLS = ['🍒', '🍋', '🍇', '🍉', '⭐', '💎', '7️⃣'];
const MULTIPLIERS: Record<string, number> = {
  '🍒': 2,
  '🍋': 3,
  '🍇': 5,
  '🍉': 10,
  '⭐': 20,
  '💎': 50,
  '7️⃣': 100,
};

export default function SlotsGame() {
  const [balance, setBalance] = useState(1000);
  const updateBalance = async (amount: number, isAdding: boolean) => setBalance(prev => isAdding ? prev + amount : prev - amount);
  const [reels, setReels] = useState(['🍒', '🍒', '🍒']);
  const [spinning, setSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState(10);
  const [winAmount, setWinAmount] = useState(0);

  const spin = async () => {
    if (betAmount > balance || betAmount <= 0 || spinning) return;
    
    await updateBalance(betAmount, false);
    setSpinning(true);
    setWinAmount(0);

    // Simulate spinning delay
    const spinDuration = 2000;
    const interval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
    }, 100);

    setTimeout(async () => {
      clearInterval(interval);
      
      // Final result
      const result = [
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ];
      
      // Force win for demo purposes occasionally (1 in 5 chance)
      if (Math.random() < 0.2) {
        const winSymbol = SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)];
        result[0] = winSymbol;
        result[1] = winSymbol;
        result[2] = winSymbol;
      }

      setReels(result);
      setSpinning(false);

      // Check win
      if (result[0] === result[1] && result[1] === result[2]) {
        const multiplier = MULTIPLIERS[result[0]];
        const win = betAmount * multiplier;
        setWinAmount(win);
        await updateBalance(win, true);
      }
    }, spinDuration);
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-8 max-w-4xl mx-auto"
    >
      <div className="bg-dark-surface border border-dark-border rounded-3xl p-8 md:p-12 shadow-2xl relative overflow-hidden">
        {/* Decorative background elements */}
        <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-neon-purple via-neon-blue to-neon-green" />
        <div className="absolute -top-24 -right-24 w-64 h-64 bg-neon-purple/10 rounded-full blur-3xl" />
        <div className="absolute -bottom-24 -left-24 w-64 h-64 bg-neon-blue/10 rounded-full blur-3xl" />

        <div className="relative z-10 flex flex-col items-center">
          <h2 className="text-3xl font-black mb-12 flex items-center gap-3 uppercase tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white to-gray-400">
            <Dices className="text-neon-blue w-8 h-8" /> Cyber Slots
          </h2>

          {/* Slot Machine Display */}
          <div className="bg-dark-bg border-4 border-dark-border rounded-2xl p-6 mb-12 w-full max-w-2xl relative shadow-[inset_0_0_50px_rgba(0,0,0,0.8)]">
            {/* Win Overlay */}
            {winAmount > 0 && (
              <motion.div 
                initial={{ opacity: 0, scale: 0.5 }}
                animate={{ opacity: 1, scale: 1 }}
                className="absolute inset-0 z-20 flex items-center justify-center bg-black/80 rounded-xl backdrop-blur-sm"
              >
                <div className="text-center">
                  <div className="text-neon-green text-5xl font-black mb-2 flex items-center justify-center gap-2">
                    <Sparkles /> BIG WIN! <Sparkles />
                  </div>
                  <div className="text-white text-3xl font-mono">+${winAmount.toFixed(2)}</div>
                </div>
              </motion.div>
            )}

            <div className="flex justify-between gap-4">
              {reels.map((symbol, i) => (
                <div key={i} className="flex-1 bg-dark-surface border-2 border-dark-border rounded-xl h-48 flex items-center justify-center overflow-hidden relative">
                  <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/50 z-10 pointer-events-none" />
                  <motion.div 
                    animate={spinning ? { y: [0, -100, 100, 0] } : { y: 0 }}
                    transition={spinning ? { repeat: Infinity, duration: 0.2, ease: "linear" } : {}}
                    className="text-7xl filter drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]"
                  >
                    {symbol}
                  </motion.div>
                </div>
              ))}
            </div>
          </div>

          {/* Controls */}
          <div className="flex flex-col md:flex-row items-center gap-6 w-full max-w-2xl bg-dark-bg p-6 rounded-2xl border border-dark-border">
            <div className="flex-1 w-full">
              <label className="text-xs text-gray-400 mb-2 block font-medium uppercase tracking-wider">Bet Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                <input 
                  type="number" 
                  value={betAmount}
                  onChange={(e) => setBetAmount(Number(e.target.value))}
                  disabled={spinning}
                  className="w-full bg-dark-surface border border-dark-border rounded-xl py-4 pl-8 pr-4 text-white font-mono text-lg focus:outline-none focus:border-neon-blue/50 transition-colors disabled:opacity-50"
                />
              </div>
            </div>

            <button 
              onClick={spin}
              disabled={spinning || betAmount > balance || betAmount <= 0}
              className="w-full md:w-auto px-12 py-4 bg-gradient-to-r from-neon-blue to-neon-purple hover:from-neon-blue/80 hover:to-neon-purple/80 text-white font-black text-xl rounded-xl transition-all shadow-[0_0_30px_rgba(0,240,255,0.3)] disabled:opacity-50 disabled:shadow-none uppercase tracking-widest"
            >
              {spinning ? 'Spinning...' : 'SPIN'}
            </button>
          </div>
          
          {/* Paytable */}
          <div className="mt-12 w-full max-w-2xl">
            <h3 className="text-sm text-gray-400 uppercase tracking-widest mb-4 text-center">Paytable (3 of a kind)</h3>
            <div className="grid grid-cols-4 md:grid-cols-7 gap-2">
              {Object.entries(MULTIPLIERS).map(([sym, mult]) => (
                <div key={sym} className="bg-dark-bg border border-dark-border rounded-lg p-2 text-center">
                  <div className="text-2xl mb-1">{sym}</div>
                  <div className="text-xs font-mono text-neon-green">{mult}x</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}
