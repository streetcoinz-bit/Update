import { Activity } from 'lucide-react';
import { motion } from 'motion/react';

const EthIcon = ({ className = "w-4 h-4" }: { className?: string }) => (
  <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1027.png" alt="ETH" className={`${className} rounded-full`} referrerPolicy="no-referrer" />
);

const BnbIcon = ({ className = "w-4 h-4" }: { className?: string }) => (
  <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/1839.png" alt="BNB" className={`${className} rounded-full`} referrerPolicy="no-referrer" />
);

const PolygonIcon = ({ className = "w-4 h-4" }: { className?: string }) => (
  <img src="https://s2.coinmarketcap.com/static/img/coins/64x64/3890.png" alt="POLYGON" className={`${className} rounded-full`} referrerPolicy="no-referrer" />
);

const getCoinIcon = (coin: string) => {
  switch (coin) {
    case 'ETH': return <EthIcon />;
    case 'BNB': return <BnbIcon />;
    case 'MATIC': return <PolygonIcon />;
    default: return <EthIcon />;
  }
};

const BETS = [
  { id: 1, game: 'Crash', user: 'Anonim', time: '12:45', bet: 0.05, multiplier: 2.45, payout: 0.1225, win: true, coin: 'ETH' },
  { id: 2, game: 'Roulette', user: 'Anonim', time: '12:44', bet: 1.5, multiplier: 0, payout: 0, win: false, coin: 'BNB' },
  { id: 3, game: 'Sweet Bonanza', user: 'Anonim', time: '12:44', bet: 45.00, multiplier: 15.2, payout: 684.00, win: true, coin: 'MATIC' },
  { id: 4, game: 'Blackjack', user: 'Anonim', time: '12:43', bet: 0.15, multiplier: 2.0, payout: 0.3, win: true, coin: 'ETH' },
  { id: 5, game: 'Mega Moolah', user: 'Anonim', time: '12:42', bet: 120.00, multiplier: 0, payout: 0, win: false, coin: 'MATIC' },
  { id: 6, game: 'Baccarat', user: 'Anonim', time: '12:41', bet: 2.5, multiplier: 1.95, payout: 4.875, win: true, coin: 'BNB' },
];

export function LiveBets() {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
      className="bg-zinc-900/50 border border-zinc-800 rounded-3xl p-6 md:p-8 mb-16"
    >
      <div className="flex items-center justify-between mb-8">
        <h2 className="text-2xl font-display font-bold text-white flex items-center gap-2">
          <Activity className="text-emerald-400" /> Live Bets
        </h2>
        <div className="flex items-center gap-2 text-sm">
          <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-zinc-400">Updating live...</span>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="text-zinc-500 text-xs uppercase tracking-wider border-b border-zinc-800/80">
              <th className="pb-4 font-semibold px-4">Game</th>
              <th className="pb-4 font-semibold px-4">User</th>
              <th className="pb-4 font-semibold px-4">Time</th>
              <th className="pb-4 font-semibold px-4 text-right">Bet Amount</th>
              <th className="pb-4 font-semibold px-4 text-right">Multiplier</th>
              <th className="pb-4 font-semibold px-4 text-right">Payout</th>
            </tr>
          </thead>
          <tbody className="text-sm">
            {BETS.map((bet) => (
              <tr key={bet.id} className="border-b border-zinc-800/30 hover:bg-zinc-800/20 transition-colors">
                <td className="py-4 px-4 font-medium text-zinc-300">{bet.game}</td>
                <td className="py-4 px-4 text-zinc-400">{bet.user}</td>
                <td className="py-4 px-4 text-zinc-500 font-mono text-xs">{bet.time}</td>
                <td className="py-4 px-4 text-right font-mono text-zinc-300">
                  <div className="flex items-center justify-end gap-2">
                    {getCoinIcon(bet.coin)}
                    {bet.coin === 'ETH' ? bet.bet.toFixed(4) : bet.coin === 'BNB' ? bet.bet.toFixed(3) : bet.bet.toFixed(2)}
                  </div>
                </td>
                <td className="py-4 px-4 text-right font-mono">
                  <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-md text-xs font-bold ${bet.win ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                    {bet.multiplier.toFixed(2)}x
                  </span>
                </td>
                <td className={`py-4 px-4 text-right font-mono font-bold ${bet.win ? 'text-emerald-400' : 'text-zinc-500'}`}>
                  <div className="flex items-center justify-end gap-2">
                    {bet.win && getCoinIcon(bet.coin)}
                    {bet.coin === 'ETH' ? bet.payout.toFixed(4) : bet.coin === 'BNB' ? bet.payout.toFixed(3) : bet.payout.toFixed(2)}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}
