import { ReactNode } from "react";
import { NavLink } from "react-router-dom";
import {
  Home,
  Gamepad2,
  Trophy,
  Gift,
  Wallet,
  User,
  Search,
  Bell,
  Menu,
  Coins,
  Flame,
} from "lucide-react";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  return (
    <div className="flex h-screen bg-zinc-950 text-zinc-50 font-sans overflow-hidden">
      {/* Sidebar */}
      <aside className="w-64 border-r border-zinc-800/50 bg-zinc-950/50 backdrop-blur-xl flex flex-col hidden md:flex">
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center shadow-[0_0_15px_rgba(52,211,153,0.5)]">
            <Coins className="w-5 h-5 text-zinc-950" />
          </div>
          <span className="text-xl font-bold tracking-tight text-white">
            Street<span className="text-emerald-400">Coinz</span>
          </span>
        </div>

        <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
          <div className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4 mt-2 px-2">
            Casino
          </div>
          <NavItem to="/" icon={<Home className="w-5 h-5" />} label="Lobby" />
          <NavItem
            to="/slots"
            icon={<Gamepad2 className="w-5 h-5" />}
            label="Slots"
          />
          <NavItem
            to="/live"
            icon={<User className="w-5 h-5" />}
            label="Live Casino"
          />
          <NavItem
            to="/crash"
            icon={<Flame className="w-5 h-5" />}
            label="Crash Games"
          />

          <div className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4 mt-8 px-2">
            Account
          </div>
          <NavItem
            to="/promotions"
            icon={<Gift className="w-5 h-5" />}
            label="Promotions"
          />
          <NavItem
            to="/vip"
            icon={<Trophy className="w-5 h-5" />}
            label="VIP Club"
          />
          <NavItem
            to="/wallet"
            icon={<Wallet className="w-5 h-5" />}
            label="Wallet"
          />
        </nav>

        <div className="p-4 border-t border-zinc-800/50">
          <div className="bg-zinc-900 rounded-xl p-4 border border-zinc-800">
            <div className="text-sm text-zinc-400 mb-1">VIP Progress</div>
            <div className="flex justify-between text-xs font-medium mb-2">
              <span className="text-emerald-400">Silver</span>
              <span>Gold</span>
            </div>
            <div className="h-1.5 bg-zinc-800 rounded-full overflow-hidden">
              <div className="h-full bg-gradient-to-r from-emerald-500 to-emerald-400 w-3/4 rounded-full"></div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 border-b border-zinc-800/50 bg-zinc-950/80 backdrop-blur-md flex items-center justify-between px-4 md:px-8 z-10">
          <div className="flex items-center gap-4">
            <button className="md:hidden p-2 text-zinc-400 hover:text-white">
              <Menu className="w-6 h-6" />
            </button>
            <div className="hidden md:flex items-center bg-zinc-900 border border-zinc-800 rounded-full px-4 py-1.5 w-64 focus-within:border-emerald-500/50 focus-within:ring-1 focus-within:ring-emerald-500/50 transition-all">
              <Search className="w-4 h-4 text-zinc-500 mr-2" />
              <input
                type="text"
                placeholder="Search games..."
                className="bg-transparent border-none outline-none text-sm w-full text-zinc-200 placeholder-zinc-500"
              />
            </div>
          </div>

          <div className="flex items-center gap-4 md:gap-6">
            <div className="flex items-center bg-zinc-900 rounded-full p-1 border border-zinc-800">
              <div className="px-3 py-1 text-sm font-mono font-medium text-white">
                $2,450.00
              </div>
              <button className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-sm font-bold px-4 py-1.5 rounded-full transition-colors shadow-[0_0_10px_rgba(52,211,153,0.3)]">
                Deposit
              </button>
            </div>

            <button className="relative p-2 text-zinc-400 hover:text-white transition-colors">
              <Bell className="w-5 h-5" />
              <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full border-2 border-zinc-950"></span>
            </button>

            <button className="w-9 h-9 rounded-full bg-zinc-800 border border-zinc-700 overflow-hidden">
              <img
                src="https://picsum.photos/seed/avatar/100/100"
                alt="User"
                className="w-full h-full object-cover"
                referrerPolicy="no-referrer"
              />
            </button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-y-auto p-4 md:p-8">{children}</main>
      </div>
    </div>
  );
}

function NavItem({
  to,
  icon,
  label,
}: {
  to: string;
  icon: ReactNode;
  label: string;
}) {
  return (
    <NavLink
      to={to}
      className={({ isActive }) =>
        `flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 ${
          isActive
            ? "bg-zinc-800/80 text-emerald-400 font-medium shadow-sm"
            : "text-zinc-400 hover:bg-zinc-900 hover:text-zinc-200"
        }`
      }
    >
      {icon}
      <span className="text-sm">{label}</span>
    </NavLink>
  );
}
