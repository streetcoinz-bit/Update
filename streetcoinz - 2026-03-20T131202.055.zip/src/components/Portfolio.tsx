import React from "react";
import { Wallet, Plus, ArrowUpRight, ArrowDownRight, History } from "lucide-react";
import { formatCurrency, cn } from "../lib/utils";

// Mock portfolio data for demonstration
const portfolioAssets = [
  { id: "bitcoin", symbol: "BTC", name: "Bitcoin", balance: 0.245, price: 64230.50, change: 2.4, color: "#F7931A" },
  { id: "ethereum", symbol: "ETH", name: "Ethereum", balance: 4.5, price: 3450.20, change: -1.2, color: "#627EEA" },
  { id: "chainlink", symbol: "LINK", name: "Chainlink", balance: 450, price: 18.40, change: 0.8, color: "#2A5ADA" },
];

const recentTransactions = [
  { id: 1, type: "buy", asset: "BTC", amount: 0.05, price: 65100.00, date: "2024-03-08T09:15:00Z" },
  { id: 2, type: "buy", asset: "ETH", amount: 1.5, price: 3200.50, date: "2024-03-05T16:45:00Z" },
];

export default function Portfolio() {
  const totalValue = portfolioAssets.reduce((acc, asset) => acc + (asset.balance * asset.price), 0);
  const totalChange24h = 1245.50; // Mock 24h change value
  const totalChangePercent = 2.4;

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-2xl font-bold tracking-tight mb-1">Your Portfolio</h1>
          <p className="text-text-muted text-sm">Manage your assets and track performance.</p>
        </div>
        <button className="flex items-center gap-2 bg-primary text-black px-4 py-2 rounded-lg font-medium hover:bg-primary-hover transition-colors">
          <Plus className="w-4 h-4" />
          Add Asset
        </button>
      </div>

      {/* Main Balance Card */}
      <div className="bg-gradient-to-br from-surface to-surface-hover border border-border rounded-2xl p-6 md:p-8 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/3"></div>
        
        <div className="relative z-10">
          <div className="flex items-center gap-2 text-text-muted mb-2">
            <Wallet className="w-5 h-5" />
            <span className="font-medium">Total Balance</span>
          </div>
          <h2 className="text-4xl md:text-5xl font-bold font-mono mb-4">
            {formatCurrency(totalValue)}
          </h2>
          
          <div className="flex items-center gap-3">
            <div className={cn(
              "inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-sm font-medium",
              totalChangePercent >= 0 ? "bg-success/10 text-success" : "bg-danger/10 text-danger"
            )}>
              {totalChangePercent >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              {formatCurrency(totalChange24h)} ({Math.abs(totalChangePercent)}%)
            </div>
            <span className="text-text-muted text-sm">Past 24 Hours</span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Assets List */}
        <div className="lg:col-span-2 space-y-4">
          <h3 className="text-lg font-semibold">Your Assets</h3>
          <div className="bg-surface border border-border rounded-xl overflow-hidden">
            <div className="divide-y divide-border">
              {portfolioAssets.map((asset) => {
                const value = asset.balance * asset.price;
                return (
                  <div key={asset.id} className="p-4 flex items-center justify-between hover:bg-surface-hover/50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center font-bold text-white" style={{ backgroundColor: asset.color }}>
                        {asset.symbol[0]}
                      </div>
                      <div>
                        <div className="font-medium">{asset.name}</div>
                        <div className="text-sm text-text-muted">{asset.balance} {asset.symbol}</div>
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="font-mono font-medium">{formatCurrency(value)}</div>
                      <div className={cn(
                        "text-sm flex items-center justify-end gap-1",
                        asset.change >= 0 ? "text-success" : "text-danger"
                      )}>
                        {asset.change >= 0 ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
                        {Math.abs(asset.change)}%
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Recent Transactions */}
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">Recent Activity</h3>
          <div className="bg-surface border border-border rounded-xl p-4">
            <div className="space-y-4">
              {recentTransactions.map((tx) => (
                <div key={tx.id} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className={cn(
                      "w-8 h-8 rounded-full flex items-center justify-center",
                      tx.type === 'buy' ? "bg-success/10 text-success" : "bg-danger/10 text-danger"
                    )}>
                      {tx.type === 'buy' ? <ArrowDownRight className="w-4 h-4" /> : <ArrowUpRight className="w-4 h-4" />}
                    </div>
                    <div>
                      <div className="font-medium capitalize">{tx.type} {tx.asset}</div>
                      <div className="text-xs text-text-muted">
                        {new Date(tx.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono text-sm">{tx.type === 'buy' ? '+' : '-'}{tx.amount}</div>
                    <div className="text-xs text-text-muted">{formatCurrency(tx.price)}</div>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-4 py-2 text-sm text-text-muted hover:text-text-main transition-colors flex items-center justify-center gap-2 border-t border-border pt-4">
              <History className="w-4 h-4" />
              View All History
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
