import React from 'react';
import { Menu, Search, Bell, User, Wallet, Plus, ChevronDown } from 'lucide-react';

interface HeaderProps {
  onMenuClick: () => void;
}

export function Header({ onMenuClick }: HeaderProps) {
  return (
    <header className="h-16 bg-[var(--color-bg-surface)]/80 backdrop-blur-md border-b border-white/5 flex items-center justify-between px-4 sm:px-6 lg:px-8 sticky top-0 z-30">
      
      {/* Left side */}
      <div className="flex items-center gap-4">
        <button 
          onClick={onMenuClick} 
          className="lg:hidden p-2 -ml-2 text-zinc-400 hover:text-white rounded-lg hover:bg-white/5 transition-colors"
        >
          <Menu className="w-6 h-6" />
        </button>

        {/* Search Bar - Hidden on mobile */}
        <div className="hidden md:flex items-center relative group">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3 group-focus-within:text-emerald-500 transition-colors" />
          <input 
            type="text" 
            placeholder="Search games..." 
            className="bg-[var(--color-bg-elevated)] border border-white/5 rounded-full py-2 pl-10 pr-4 text-sm text-zinc-100 placeholder:text-zinc-500 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500/50 w-64 transition-all"
          />
        </div>
      </div>

      {/* Right side */}
      <div className="flex items-center gap-3 sm:gap-4">
        
        {/* Mobile Search Icon */}
        <button className="md:hidden p-2 text-zinc-400 hover:text-white rounded-full hover:bg-white/5 transition-colors">
          <Search className="w-5 h-5" />
        </button>

        {/* Notifications */}
        <button className="relative p-2 text-zinc-400 hover:text-white rounded-full hover:bg-white/5 transition-colors">
          <Bell className="w-5 h-5" />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-emerald-500 rounded-full border-2 border-[var(--color-bg-surface)]"></span>
        </button>

        {/* Balance Area */}
        <div className="flex items-center bg-[var(--color-bg-elevated)] border border-white/5 rounded-full p-1 pl-3 sm:pl-4 transition-colors hover:border-white/10">
          <div className="flex flex-col mr-3">
            <span className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider leading-none mb-0.5">Balance</span>
            <div className="flex items-center gap-1.5">
              <span className="text-emerald-500 font-bold text-sm leading-none">$</span>
              <span className="text-white font-bold text-sm leading-none">1,245.50</span>
            </div>
          </div>
          <button className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 p-1.5 sm:p-2 rounded-full transition-colors shadow-[0_0_15px_rgba(16,185,129,0.3)]">
            <Plus className="w-4 h-4 sm:w-5 sm:w-5" />
          </button>
        </div>

        {/* User Profile */}
        <button className="flex items-center gap-2 p-1 pr-2 rounded-full hover:bg-white/5 transition-colors border border-transparent hover:border-white/5">
          <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-indigo-500 to-purple-500 flex items-center justify-center border border-white/10">
            <User className="w-4 h-4 text-white" />
          </div>
          <ChevronDown className="w-4 h-4 text-zinc-500 hidden sm:block" />
        </button>

      </div>
    </header>
  );
}
