import React from 'react';
import { Spot } from '../types';
import { MapPin, User, Clock, Coins } from 'lucide-react';
import { motion } from 'motion/react';

interface SpotCardProps {
  spot: Spot;
  onCheckIn: (id: string) => void;
}

export const SpotCard: React.FC<SpotCardProps> = ({ spot, onCheckIn }) => {
  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="brutal-border bg-white overflow-hidden flex flex-col"
    >
      <div className="relative h-48">
        <img 
          src={spot.image} 
          alt={spot.name} 
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
        <div className="absolute top-2 right-2 bg-neon-green brutal-border px-2 py-1 text-xs font-mono font-bold">
          {spot.type.toUpperCase()}
        </div>
      </div>
      
      <div className="p-4 flex-1 flex flex-col">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-display text-xl uppercase leading-tight">{spot.name}</h3>
          <div className="flex items-center gap-1 font-mono text-sm font-bold">
            <Coins size={14} className="text-neon-green" />
            {spot.reward}
          </div>
        </div>
        
        <p className="text-sm text-gray-600 mb-4 line-clamp-2">{spot.description}</p>
        
        <div className="mt-auto space-y-2">
          <div className="flex items-center gap-2 text-xs font-mono text-gray-500">
            <MapPin size={12} />
            {spot.location.address}
          </div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-xs font-mono text-gray-500">
              <User size={12} />
              {spot.author}
            </div>
            <div className="flex items-center gap-2 text-xs font-mono text-gray-500">
              <Clock size={12} />
              {new Date(spot.timestamp).toLocaleDateString()}
            </div>
          </div>
        </div>
        
        <button 
          onClick={() => onCheckIn(spot.id)}
          className="brutal-btn mt-4 w-full bg-neon-green text-black"
        >
          Check In
        </button>
      </div>
    </motion.div>
  );
};
