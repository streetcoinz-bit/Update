import { motion } from 'motion/react';
import { Trophy } from 'lucide-react';

const wins = [
  { id: 1, user: 'CryptoKing', game: 'Neon Nights', amount: '0.15 BTC', multiplier: 'x150' },
  { id: 2, user: 'Satoshi99', game: 'Cyberpunk Roulette', amount: '2.5 ETH', multiplier: 'x35' },
  { id: 3, user: 'Whale_Alert', game: 'Crypto Crash', amount: '150 SOL', multiplier: 'x10' },
  { id: 4, user: 'DogeFather', game: 'Dogecoin Dice', amount: '5000 DOGE', multiplier: 'x2' },
  { id: 5, user: 'LuckyStrike', game: 'Ethereum Slots', amount: '0.8 ETH', multiplier: 'x800' },
];

export function RecentWins() {
  return (
    <section className="w-full mt-24">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-xl bg-street-surface border border-street-border flex items-center justify-center text-yellow-500">
          <Trophy size={20} />
        </div>
        <h2 className="text-2xl font-display font-bold">Recent Big Wins</h2>
      </div>

      <div className="w-full overflow-x-auto scrollbar-hide">
        <div className="min-w-[800px] bg-street-surface rounded-2xl border border-street-border overflow-hidden">
          {/* Header */}
          <div className="grid grid-cols-4 gap-4 p-4 border-b border-street-border bg-street-surface-hover text-sm font-medium text-zinc-400">
            <div>Game</div>
            <div>Player</div>
            <div>Multiplier</div>
            <div className="text-right">Payout</div>
          </div>

          {/* Rows */}
          <div className="divide-y divide-street-border">
            {wins.map((win, i) => (
              <motion.div 
                key={win.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: i * 0.1 }}
                className="grid grid-cols-4 gap-4 p-4 items-center hover:bg-street-surface-hover/50 transition-colors"
              >
                <div className="font-medium text-white">{win.game}</div>
                <div className="text-zinc-400 flex items-center gap-2">
                  <div className="w-6 h-6 rounded-full bg-zinc-800 overflow-hidden">
                    <img src={`https://picsum.photos/seed/${win.user}/100/100`} alt={win.user} referrerPolicy="no-referrer" />
                  </div>
                  {win.user}
                </div>
                <div className="text-street-accent font-bold">{win.multiplier}</div>
                <div className="text-right text-street-primary font-bold font-display">{win.amount}</div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
