import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';

export function GameSplash({ children }: { children: React.ReactNode }) {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <>
      <AnimatePresence>
        {showSplash && (
          <motion.div
            initial={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5 }}
            className="fixed inset-0 z-[100] bg-[#131212] flex flex-col items-center justify-center"
          >
            <motion.img
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
              src="https://is3.cloudhost.id/streetcoinzstorage/STREETCOINZLOGOV2/streetcoinzlogo&name.png"
              alt="StreetCoinz Logo"
              className="w-64 h-auto object-contain mb-8"
            />
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="w-10 h-10 border-4 border-[#a252f0] border-t-transparent rounded-full animate-spin"
            />
          </motion.div>
        )}
      </AnimatePresence>
      <div style={{ display: showSplash ? 'none' : 'block', height: '100%' }}>
        {children}
      </div>
    </>
  );
}
