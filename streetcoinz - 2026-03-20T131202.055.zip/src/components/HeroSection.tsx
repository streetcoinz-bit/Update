import { motion } from 'motion/react';

export function HeroSection() {
  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
      className="relative w-full h-[320px] rounded-3xl overflow-hidden mb-10 border border-white/10"
    >
      <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent z-10" />
      
      <img 
        src="https://images.unsplash.com/photo-1596838132731-3301c3fd4317?q=80&w=2070&auto=format&fit=crop" 
        alt="Casino background" 
        className="absolute inset-0 w-full h-full object-cover object-center opacity-60"
        referrerPolicy="no-referrer"
      />

      <div className="relative z-20 h-full flex flex-col justify-center p-8 lg:p-12 max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.5 }}
        >
          <span className="inline-block py-1 px-3 rounded-full bg-yellow-500/20 border border-yellow-500/30 text-yellow-500 text-xs font-bold uppercase tracking-widest mb-4">
            Welcome Bonus
          </span>
          <h1 className="text-4xl lg:text-6xl font-display font-bold text-white leading-tight mb-4">
            200% Match <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 to-yellow-600">
              Up to $5,000
            </span>
          </h1>
          <p className="text-zinc-300 text-lg mb-8 max-w-md">
            Join StreetCoinz today and double your first deposit. Plus 50 free spins on selected slots.
          </p>
          <button className="bg-yellow-500 hover:bg-yellow-400 text-black font-bold text-lg px-8 py-4 rounded-xl transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(250,204,21,0.3)]">
            Claim Bonus Now
          </button>
        </motion.div>
      </div>
    </motion.div>
  );
}
