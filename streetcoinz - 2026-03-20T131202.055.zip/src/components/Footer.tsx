import { Coins, Twitter, MessageCircle, Send } from 'lucide-react';

export function Footer() {
  return (
    <footer className="border-t border-zinc-800/50 bg-zinc-950 pt-16 pb-8 px-4 lg:px-8">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
        <div>
          <div className="flex items-center gap-2 text-2xl font-display font-black tracking-tight text-white mb-6">
            <Coins className="text-yellow-400" size={28} />
            <span>STREET<span className="text-yellow-400">COINZ</span></span>
          </div>
          <p className="text-zinc-400 text-sm leading-relaxed mb-6">
            The premier street-style crypto casino. Experience the thrill of the game with instant payouts, provably fair algorithms, and a vibrant community.
          </p>
          <div className="flex items-center gap-4">
            <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-600 transition-colors">
              <Twitter size={18} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-600 transition-colors">
              <MessageCircle size={18} />
            </a>
            <a href="#" className="w-10 h-10 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center text-zinc-400 hover:text-white hover:border-zinc-600 transition-colors">
              <Send size={18} />
            </a>
          </div>
        </div>

        <div>
          <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Casino</h3>
          <ul className="space-y-3 text-sm text-zinc-400">
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Casino Home</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Live Casino</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">New Releases</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Table Games</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Street Originals</a></li>
          </ul>
        </div>

        <div>
          <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Support</h3>
          <ul className="space-y-3 text-sm text-zinc-400">
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Fairness</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Privacy Policy</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Terms of Service</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Responsible Gambling</a></li>
            <li><a href="#" className="hover:text-emerald-400 transition-colors">Live Support 24/7</a></li>
          </ul>
        </div>

        <div>
          <h3 className="text-white font-bold mb-6 uppercase tracking-wider text-sm">Accepted Crypto</h3>
          <div className="flex flex-wrap gap-2">
            {['BTC', 'ETH', 'USDT', 'LTC', 'DOGE', 'TRX'].map((coin) => (
              <span key={coin} className="px-3 py-1.5 rounded-md bg-zinc-900 border border-zinc-800 text-xs font-bold text-zinc-300">
                {coin}
              </span>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto pt-8 border-t border-zinc-800/50 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-zinc-500">
        <p>&copy; 2026 StreetCoinz Casino. All rights reserved.</p>
        <p>18+ Play Responsibly.</p>
      </div>
    </footer>
  );
}
