import { Bell, Search, User, Wallet } from 'lucide-react';

export function TopNav() {
  return (
    <header className="h-20 border-b border-white/5 bg-[#0a0a0c]/80 backdrop-blur-md sticky top-0 z-30 flex items-center justify-between px-6 lg:px-10">
      <div className="flex-1 flex items-center gap-4">
        <div className="hidden md:flex items-center gap-2 bg-[#141417] border border-white/5 rounded-full px-4 py-2 w-64 focus-within:border-yellow-500/50 transition-colors">
          <Search size={18} className="text-zinc-500" />
          <input 
            type="text" 
            placeholder="Search games..." 
            className="bg-transparent border-none outline-none text-sm text-white placeholder:text-zinc-500 w-full"
          />
        </div>
      </div>

      <div className="flex items-center gap-4 lg:gap-6">
        <div className="flex items-center gap-3 bg-[#141417] border border-white/5 rounded-full p-1 pr-4">
          <div className="bg-yellow-500/20 p-2 rounded-full">
            <Wallet size={16} className="text-yellow-500" />
          </div>
          <div className="flex flex-col">
            <span className="text-[10px] text-zinc-500 font-semibold uppercase tracking-wider leading-none">Balance</span>
            <span className="text-sm font-bold font-mono text-white leading-tight">$12,450.00</span>
          </div>
          <button className="ml-2 bg-yellow-500 hover:bg-yellow-400 text-black text-xs font-bold px-3 py-1.5 rounded-full transition-colors">
            Deposit
          </button>
        </div>

        <button className="relative p-2 text-zinc-400 hover:text-white transition-colors">
          <Bell size={20} />
          <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full border-2 border-[#0a0a0c]"></span>
        </button>

        <button className="w-10 h-10 rounded-full bg-gradient-to-tr from-zinc-800 to-zinc-700 border border-white/10 flex items-center justify-center overflow-hidden hover:border-yellow-500/50 transition-colors">
          <User size={20} className="text-zinc-300" />
        </button>
      </div>
    </header>
  );
}
