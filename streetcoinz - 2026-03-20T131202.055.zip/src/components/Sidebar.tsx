import React from 'react';
import { 
  Home, 
  Gamepad2, 
  Trophy, 
  Gift, 
  Flame, 
  Spade, 
  MonitorPlay, 
  Coins, 
  Dice1, 
  X,
  HelpCircle,
  MessageSquare
} from 'lucide-react';

interface SidebarProps {
  onClose: () => void;
}

export function Sidebar({ onClose }: SidebarProps) {
  const navItems = [
    { icon: Home, label: 'Home', active: true },
    { icon: Flame, label: 'Hot Games', badge: 'New' },
    { icon: Gamepad2, label: 'Slots' },
    { icon: MonitorPlay, label: 'Live Casino' },
    { icon: Spade, label: 'Table Games' },
    { icon: Dice1, label: 'Crash Games' },
  ];

  const promoItems = [
    { icon: Gift, label: 'Promotions', badge: '3' },
    { icon: Trophy, label: 'Tournaments' },
    { icon: Coins, label: 'VIP Club' },
  ];

  const supportItems = [
    { icon: MessageSquare, label: 'Live Support' },
    { icon: HelpCircle, label: 'FAQ' },
  ];

  return (
    <div className="h-full w-64 bg-[var(--color-bg-surface)] border-r border-white/5 flex flex-col">
      {/* Logo Area */}
      <div className="h-16 flex items-center justify-between px-6 border-b border-white/5 shrink-0">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
            <Coins className="w-5 h-5 text-zinc-950" />
          </div>
          <span className="font-display font-bold text-xl tracking-tight text-white">
            Street<span className="text-emerald-500">Coinz</span>
          </span>
        </div>
        <button onClick={onClose} className="lg:hidden text-zinc-400 hover:text-white">
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* Navigation Links */}
      <div className="flex-1 overflow-y-auto py-6 px-4 space-y-8">
        
        {/* Main Nav */}
        <div className="space-y-1">
          <p className="px-3 text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">Casino</p>
          {navItems.map((item, i) => (
            <a 
              key={i} 
              href="#" 
              className={`flex items-center justify-between px-3 py-2.5 rounded-xl transition-colors ${
                item.active 
                  ? 'bg-emerald-500/10 text-emerald-500' 
                  : 'text-zinc-400 hover:bg-white/5 hover:text-zinc-100'
              }`}
            >
              <div className="flex items-center gap-3">
                <item.icon className="w-5 h-5" />
                <span className="font-medium text-sm">{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-400">
                  {item.badge}
                </span>
              )}
            </a>
          ))}
        </div>

        {/* Promos */}
        <div className="space-y-1">
          <p className="px-3 text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">Rewards</p>
          {promoItems.map((item, i) => (
            <a 
              key={i} 
              href="#" 
              className="flex items-center justify-between px-3 py-2.5 rounded-xl text-zinc-400 hover:bg-white/5 hover:text-zinc-100 transition-colors"
            >
              <div className="flex items-center gap-3">
                <item.icon className="w-5 h-5" />
                <span className="font-medium text-sm">{item.label}</span>
              </div>
              {item.badge && (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/20 text-amber-400">
                  {item.badge}
                </span>
              )}
            </a>
          ))}
        </div>

        {/* Support */}
        <div className="space-y-1">
          <p className="px-3 text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-2">Support</p>
          {supportItems.map((item, i) => (
            <a 
              key={i} 
              href="#" 
              className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-zinc-400 hover:bg-white/5 hover:text-zinc-100 transition-colors"
            >
              <item.icon className="w-5 h-5" />
              <span className="font-medium text-sm">{item.label}</span>
            </a>
          ))}
        </div>

      </div>

      {/* Language / Theme Toggle Area */}
      <div className="p-4 border-t border-white/5 shrink-0">
        <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-[var(--color-bg-elevated)] border border-white/5">
          <span className="text-xs font-medium text-zinc-400">EN / USD</span>
          <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.8)]"></div>
        </div>
      </div>
    </div>
  );
}
