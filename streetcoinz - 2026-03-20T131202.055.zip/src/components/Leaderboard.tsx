import React from 'react';
import { User } from '../types';
import { Trophy } from 'lucide-react';

interface LeaderboardProps {
  users: User[];
}

export const Leaderboard: React.FC<LeaderboardProps> = ({ users }) => {
  return (
    <div className="brutal-border bg-white p-4">
      <div className="flex items-center gap-2 mb-4">
        <Trophy className="text-neon-green" />
        <h2 className="font-display text-2xl uppercase">Street Cred</h2>
      </div>
      
      <div className="space-y-3">
        {users.sort((a, b) => b.cred - a.cred).map((user, index) => (
          <div 
            key={user.id} 
            className={`flex items-center gap-3 p-2 border-b border-black last:border-0 ${index === 0 ? 'bg-neon-green/10' : ''}`}
          >
            <div className="font-display text-xl w-6 text-center">0{index + 1}</div>
            <img 
              src={user.avatar} 
              alt={user.username} 
              className="w-10 h-10 brutal-border bg-white"
              referrerPolicy="no-referrer"
            />
            <div className="flex-1">
              <div className="font-bold text-sm">{user.username}</div>
              <div className="font-mono text-[10px] uppercase text-gray-500">{user.cred} Cred</div>
            </div>
            <div className="font-mono font-bold text-sm">
              {user.coinz} <span className="text-[10px]">SC</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
