import React from 'react';
import { ResponsiveContainer, AreaChart, Area, XAxis, YAxis, Tooltip } from 'recharts';

interface TickData {
  time: string;
  price: number;
}

interface TickChartProps {
  data: TickData[];
  isPositive?: boolean;
}

export const TickChart: React.FC<TickChartProps> = ({ data, isPositive = true }) => {
  const color = isPositive ? '#10b981' : '#ef4444'; // emerald-500 or red-500

  return (
    <div className="w-full h-full min-h-[200px]">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data}>
          <defs>
            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={color} stopOpacity={0.3} />
              <stop offset="95%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-[#18181b] border border-white/10 p-2 rounded shadow-xl">
                    <p className="text-white font-mono text-xs">${payload[0].value?.toLocaleString()}</p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area
            type="monotone"
            dataKey="price"
            stroke={color}
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorPrice)"
            isAnimationActive={false}
          />
          <XAxis dataKey="time" hide />
          <YAxis hide domain={['auto', 'auto']} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
};
