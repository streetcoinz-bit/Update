import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Camera, Car, AlertCircle, DollarSign, Trophy } from 'lucide-react';
import { toast } from '../lib/toast';

export const TrafficCameraGame = ({ onGameBet }: { onGameBet?: (game: string, amount: number, won: boolean, multiplier: number) => void }) => {
  const [guess, setGuess] = useState<number | ''>('');
  const [betAmount, setBetAmount] = useState<string>('');
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'result'>('idle');
  const [actualCars, setActualCars] = useState<number>(0);
  const [countdown, setCountdown] = useState(5);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const finishGame = () => {
    // Generate a random number of cars between 1 and 20
    const result = Math.floor(Math.random() * 20) + 1;
    setActualCars(result);
    setGameState('result');
    
    if (onGameBet) {
      const won = guess === result;
      onGameBet('Traffic Camera', parseFloat(betAmount) || 0, won, won ? 10 : 0);
    }
  };

  const BET_RECIPIENT_ADDRESS = '0x11f5c694bde30f985f37c4efbb82b29bfd6409ad';

  const startGame = () => {
    setGameState('playing');
    setCountdown(5);
    
    // Simulate the traffic camera watching for 5 seconds
    timerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          if (timerRef.current) clearInterval(timerRef.current);
          finishGame();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const handleBet = async () => {
    if (!guess || guess <= 0) {
      toast.error('Please enter a valid guess');
      return;
    }
    
    const parsedBet = parseFloat(betAmount);
    if (isNaN(parsedBet) || parsedBet <= 0) {
      toast.error('Please enter a valid bet amount');
      return;
    }

    if (typeof window !== 'undefined' && (window as any).ethereum) {
      try {
        const ethereum = (window as any).ethereum;
        const accounts = await ethereum.request({ method: 'eth_requestAccounts' });
        const account = accounts[0];

        // Convert betAmount to Wei (assuming betAmount is in ETH/BNB/MATIC)
        const betAmountInWei = BigInt(Math.floor(parsedBet * 1e18)).toString(16);

        toast.loading('Waiting for transaction approval...', { id: 'tx-toast' });

        await ethereum.request({
          method: 'eth_sendTransaction',
          params: [
            {
              from: account,
              to: BET_RECIPIENT_ADDRESS,
              value: `0x${betAmountInWei}`,
            },
          ],
        });

        toast.success(`Transaction sent!`, { id: 'tx-toast' });
        startGame();
      } catch (error: any) {
        console.error(error);
        toast.error(error.message || 'Transaction failed or rejected', { id: 'tx-toast' });
        return;
      }
    } else {
      toast.error('No Web3 wallet detected. Please install MetaMask!');
      return;
    }
  };

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const resetGame = () => {
    setGameState('idle');
    setGuess('');
    setBetAmount('');
    setActualCars(0);
  };

  const isWin = guess === actualCars;
  const isClose = Math.abs((guess as number) - actualCars) <= 2;

  return (
    <div className="space-y-6">
      <div className="bg-[#1C1C1E] rounded-2xl overflow-hidden border border-white/5">
        {/* Camera Feed Simulation */}
        <div className="relative aspect-video bg-black flex items-center justify-center overflow-hidden">
          {/* Static noise overlay */}
          <div className="absolute inset-0 opacity-10 mix-blend-screen pointer-events-none" style={{ backgroundImage: 'url("https://www.transparenttextures.com/patterns/stardust.png")' }}></div>
          
          {/* Camera UI overlay */}
          <div className="absolute top-4 left-4 flex items-center gap-2">
            <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
            <span className="text-red-500 font-mono text-xs font-bold tracking-widest">REC</span>
          </div>
          <div className="absolute top-4 right-4 text-white/50 font-mono text-xs">
            CAM-04 // HIGHWAY 99
          </div>
          <div className="absolute bottom-4 left-4 text-white/50 font-mono text-xs">
            {new Date().toISOString().replace('T', ' ').substring(0, 19)}
          </div>

          {/* Main Content */}
          <AnimatePresence mode="wait">
            {gameState === 'idle' && (
              <motion.div 
                key="idle"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="text-center z-10"
              >
                <Camera className="w-12 h-12 text-white/20 mx-auto mb-2" />
                <p className="text-white/50 font-mono text-sm">Awaiting Prediction...</p>
              </motion.div>
            )}

            {gameState === 'playing' && (
              <motion.div 
                key="playing"
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 1.1 }}
                className="text-center z-10"
              >
                <div className="text-6xl font-display text-white mb-2">{countdown}</div>
                <p className="text-[#14F195] font-mono text-sm animate-pulse">Analyzing traffic flow...</p>
              </motion.div>
            )}

            {gameState === 'result' && (
              <motion.div 
                key="result"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center z-10 bg-black/80 backdrop-blur-md p-6 rounded-2xl border border-white/10"
              >
                <div className="flex items-center justify-center gap-4 mb-4">
                  <div className="text-center">
                    <p className="text-gray-400 text-xs uppercase tracking-wider mb-1">Your Guess</p>
                    <p className="text-3xl font-mono text-white">{guess}</p>
                  </div>
                  <div className="w-px h-12 bg-white/20"></div>
                  <div className="text-center">
                    <p className="text-gray-400 text-xs uppercase tracking-wider mb-1">Actual Cars</p>
                    <p className="text-3xl font-mono text-[#14F195]">{actualCars}</p>
                  </div>
                </div>

                {isWin ? (
                  <div className="text-[#14F195] flex items-center justify-center gap-2 font-bold text-xl">
                    <Trophy className="w-6 h-6" />
                    JACKPOT! x10 Payout
                  </div>
                ) : isClose ? (
                  <div className="text-yellow-500 flex items-center justify-center gap-2 font-bold text-lg">
                    <AlertCircle className="w-5 h-5" />
                    Close! x2 Payout
                  </div>
                ) : (
                  <div className="text-red-500 font-bold text-lg">
                    Busted! Better luck next time.
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Controls */}
        <div className="p-6 bg-[#131212]">
          <div className="mb-6">
            <h3 className="text-white font-bold text-lg mb-1 flex items-center gap-2">
              <Car className="w-5 h-5 text-[#14F195]" />
              Traffic Predictor
            </h3>
            <p className="text-gray-400 text-sm">Guess how many cars will pass by the camera in the next 5 seconds.</p>
          </div>

          <div className="grid grid-cols-2 gap-4 mb-6">
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Your Guess (1-20)</label>
              <input
                type="number"
                min="1"
                max="20"
                value={guess}
                onChange={(e) => setGuess(parseInt(e.target.value) || '')}
                disabled={gameState !== 'idle'}
                className="w-full bg-black border border-white/10 rounded-xl px-4 py-3 text-white font-mono focus:outline-none focus:border-[#14F195] transition-colors disabled:opacity-50"
                placeholder="e.g. 7"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-2">Bet Amount</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="number"
                  min="0.001"
                  step="0.001"
                  value={betAmount}
                  onChange={(e) => setBetAmount(e.target.value)}
                  disabled={gameState !== 'idle'}
                  className="w-full bg-black border border-white/10 rounded-xl pl-10 pr-4 py-3 text-white font-mono focus:outline-none focus:border-[#14F195] transition-colors disabled:opacity-50"
                  placeholder="0.00"
                />
              </div>
            </div>
          </div>

          {gameState === 'idle' ? (
            <button
              onClick={handleBet}
              className="w-full bg-[#14F195] text-black font-bold py-4 rounded-xl hover:bg-[#14F195]/90 transition-colors shadow-[0_0_20px_rgba(20,241,149,0.2)]"
            >
              Place Prediction
            </button>
          ) : gameState === 'result' ? (
            <button
              onClick={resetGame}
              className="w-full bg-white/10 text-white font-bold py-4 rounded-xl hover:bg-white/20 transition-colors"
            >
              Play Again
            </button>
          ) : (
            <button
              disabled
              className="w-full bg-gray-800 text-gray-500 font-bold py-4 rounded-xl cursor-not-allowed"
            >
              Analyzing...
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
