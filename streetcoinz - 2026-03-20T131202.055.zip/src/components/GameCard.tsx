import React from 'react';
import { Play, Flame } from 'lucide-react';

interface GameCardProps {
  title: string;
  provider: string;
  imageSeed?: string;
  image?: string;
  isHot?: boolean;
  isNew?: boolean;
  players?: number;
  key?: React.Key;
}

export function GameCard({ title, provider, imageSeed, image, isHot, isNew, players }: GameCardProps) {
  return (
    <div className="group relative rounded-2xl overflow-hidden bg-[var(--color-bg-panel)] border border-white/5 hover:border-[var(--color-brand-gold)]/30 transition-all duration-300 cursor-pointer">
      {/* Badges */}
      <div className="absolute top-3 left-3 z-20 flex gap-2">
        {isNew && (
          <span className="px-2 py-1 text-[10px] font-bold uppercase tracking-wider bg-[var(--color-brand-neon)] text-black rounded-md">
            New
          </span>
        )}
      </div>
      
      {isHot && (
        <div className="absolute top-3 right-3 bg-red-500/20 border border-red-500/50 backdrop-blur-sm px-2 py-1 rounded-md flex items-center gap-1 z-20 shadow-[0_0_10px_rgba(239,68,68,0.3)]">
          <Flame className="w-3 h-3 text-red-500" fill="currentColor" />
          <span className="text-[10px] font-bold text-red-500 uppercase tracking-wider">Hot</span>
        </div>
      )}

      {/* Image Container */}
      <div className="relative aspect-[4/3] overflow-hidden">
        <img
          src={image || `https://picsum.photos/seed/${imageSeed}/400/300`}
          alt={title}
          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-80"></div>
        
        {/* Play Button Overlay */}
        <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300 bg-black/40 backdrop-blur-sm">
          <button className="w-14 h-14 rounded-full bg-[var(--color-brand-gold)] flex items-center justify-center text-black hover:scale-110 transition-transform">
            <Play className="w-6 h-6 ml-1" fill="currentColor" />
          </button>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 relative z-10">
        <h3 className="text-lg font-bold text-white mb-1 truncate">{title}</h3>
        <div className="flex items-center justify-between">
          <p className="text-xs uppercase tracking-wider">
            {provider === 'StreetCoinz Games' ? (
              <span className="text-[#a252f0] font-bold">{provider}</span>
            ) : (
              <span className="text-[var(--color-text-secondary)]">{provider}</span>
            )}
          </p>
          {players && (
            <p className="text-xs font-mono text-[var(--color-brand-neon)] flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-[var(--color-brand-neon)] animate-pulse"></span>
              {players} playing
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
