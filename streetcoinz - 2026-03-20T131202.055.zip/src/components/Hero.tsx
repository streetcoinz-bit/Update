import React from 'react';
import { Play, ArrowRight, Sparkles } from 'lucide-react';

export function Hero() {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-emerald-900/40 to-zinc-900 border border-white/5 shadow-2xl">
      
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1596838132731-3301c3fd4317?q=80&w=2070&auto=format&fit=crop')] bg-cover bg-center opacity-20 mix-blend-overlay"></div>
      <div className="absolute inset-0 bg-gradient-to-r from-[var(--color-bg-base)] via-transparent to-transparent"></div>
      <div className="absolute -top-24 -right-24 w-96 h-96 bg-emerald-500/20 rounded-full blur-3xl"></div>

      <div className="relative z-10 px-6 py-12 sm:px-12 sm:py-16 lg:py-20 lg:px-16 flex flex-col lg:flex-row items-center justify-between gap-8">
        
        {/* Content */}
        <div className="max-w-xl space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-medium">
            <Sparkles className="w-4 h-4" />
            <span>Welcome Bonus</span>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-display font-bold tracking-tight text-white leading-[1.1]">
            Double Your <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-emerald-600">
              First Deposit
            </span>
          </h1>
          
          <p className="text-lg text-zinc-400 max-w-md leading-relaxed">
            Join StreetCoinz today and get a 100% match bonus up to $500 + 50 Free Spins on CyberPunk Slots.
          </p>
          
          <div className="flex flex-wrap items-center gap-4 pt-4">
            <button className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 px-8 py-4 rounded-xl font-bold transition-all hover:scale-105 active:scale-95 shadow-[0_0_20px_rgba(16,185,129,0.4)]">
              Claim Bonus
              <ArrowRight className="w-5 h-5" />
            </button>
            <button className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-white px-8 py-4 rounded-xl font-medium transition-all border border-white/10">
              Read Terms
            </button>
          </div>
        </div>

        {/* Featured Game Preview (Optional visual element) */}
        <div className="hidden lg:block relative w-72 h-72 shrink-0 group cursor-pointer">
          <div className="absolute inset-0 bg-gradient-to-tr from-purple-600 to-blue-600 rounded-2xl rotate-6 opacity-50 blur-xl group-hover:rotate-12 transition-transform duration-500"></div>
          <div className="relative h-full w-full rounded-2xl overflow-hidden border-2 border-white/10 shadow-2xl transform group-hover:-translate-y-2 transition-transform duration-500">
            <img 
              src="https://images.unsplash.com/photo-1605806616949-1e87b487cb2a?q=80&w=1000&auto=format&fit=crop" 
              alt="Featured Game" 
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
              <div className="w-16 h-16 rounded-full bg-emerald-500/90 flex items-center justify-center text-zinc-950 transform scale-50 group-hover:scale-100 transition-transform duration-500 delay-100">
                <Play className="w-8 h-8 ml-1" fill="currentColor" />
              </div>
            </div>
            <div className="absolute bottom-0 inset-x-0 p-4 bg-gradient-to-t from-black/90 to-transparent">
              <p className="font-display font-bold text-white text-lg">CyberPunk 2077 Slots</p>
              <p className="text-emerald-400 text-sm font-medium">RTP 96.5%</p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
