import { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Coins } from 'lucide-react';

export default function CoinFlip({ balance, setBalance }: any) {
  const [betAmount, setBetAmount] = useState(10);
  const [side, setSide] = useState<'heads' | 'tails'>('heads');
  const [flipping, setFlipping] = useState(false);
  const [result, setResult] = useState<'heads' | 'tails' | null>(null);
  const [win, setWin] = useState<boolean | null>(null);

  const handleFlip = () => {
    if (betAmount > balance || betAmount <= 0) return;
    
    setBalance((b: number) => b - betAmount);
    setFlipping(true);
    setResult(null);
    setWin(null);

    setTimeout(() => {
      const outcome = Math.random() > 0.5 ? 'heads' : 'tails';
      setResult(outcome);
      const isWin = outcome === side;
      setWin(isWin);
      if (isWin) {
        setBalance((b: number) => b + betAmount * 2);
      }
      setFlipping(false);
    }, 2000);
  };

  return (
    <div className="max-w-5xl mx-auto flex flex-col lg:flex-row gap-8">
      {/* Game Area */}
      <div className="flex-1 bg-zinc-900 border border-zinc-800 rounded-3xl p-8 md:p-12 flex flex-col items-center justify-center min-h-[400px] md:min-h-[500px] relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.05)_0%,transparent_70%)]" />
        
        <div className="relative z-10 flex flex-col items-center">
          <AnimatePresence mode="wait">
            {flipping ? (
              <motion.div
                key="flipping"
                animate={{ rotateY: 360 * 5 }}
                transition={{ duration: 2, ease: "easeInOut" }}
                className="w-40 h-40 md:w-48 md:h-48 rounded-full bg-gradient-to-br from-yellow-400 to-yellow-600 flex items-center justify-center shadow-[0_0_50px_rgba(234,179,8,0.3)] border-4 border-yellow-300"
              >
                <Coins size={64} className="text-yellow-100" />
              </motion.div>
            ) : result ? (
              <motion.div
                key="result"
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className={`w-40 h-40 md:w-48 md:h-48 rounded-full flex items-center justify-center border-4 shadow-2xl ${
                  result === 'heads' 
                    ? 'bg-gradient-to-br from-blue-500 to-blue-700 border-blue-400 shadow-blue-500/30' 
                    : 'bg-gradient-to-br from-purple-500 to-purple-700 border-purple-400 shadow-purple-500/30'
                }`}
              >
                <span className="text-3xl md:text-4xl font-display font-bold text-white uppercase tracking-wider">{result}</span>
              </motion.div>
            ) : (
              <motion.div
                key="idle"
                className="w-40 h-40 md:w-48 md:h-48 rounded-full bg-zinc-800 border-4 border-zinc-700 flex items-center justify-center"
              >
                <Coins size={64} className="text-zinc-600" />
              </motion.div>
            )}
          </AnimatePresence>

          {win !== null && !flipping && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`mt-8 text-xl md:text-2xl font-display font-bold ${win ? 'text-emerald-400' : 'text-rose-400'}`}
            >
              {win ? `You won ${(betAmount * 2).toFixed(2)} SCZ!` : `You lost ${betAmount.toFixed(2)} SCZ`}
            </motion.div>
          )}
        </div>
      </div>

      {/* Controls Area */}
      <div className="w-full lg:w-96 bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 flex flex-col">
        <h3 className="text-xl font-display font-bold mb-6">Bet Slip</h3>
        
        <div className="space-y-6 flex-1">
          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-2">Bet Amount</label>
            <div className="relative">
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex space-x-1">
                <button onClick={() => setBetAmount(b => b / 2)} className="px-2 py-1 bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-700">1/2</button>
                <button onClick={() => setBetAmount(b => b * 2)} className="px-2 py-1 bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-700">2x</button>
                <button onClick={() => setBetAmount(balance)} className="px-2 py-1 bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-700">Max</button>
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-2">Side</label>
            <div className="grid grid-cols-2 gap-4">
              <button
                onClick={() => setSide('heads')}
                className={`py-3 rounded-xl font-bold transition-all ${side === 'heads' ? 'bg-blue-500 text-white shadow-[0_0_20px_rgba(59,130,246,0.3)]' : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:bg-zinc-800'}`}
              >
                HEADS
              </button>
              <button
                onClick={() => setSide('tails')}
                className={`py-3 rounded-xl font-bold transition-all ${side === 'tails' ? 'bg-purple-500 text-white shadow-[0_0_20px_rgba(168,85,247,0.3)]' : 'bg-zinc-950 border border-zinc-800 text-zinc-400 hover:bg-zinc-800'}`}
              >
                TAILS
              </button>
            </div>
          </div>
        </div>

        <button
          onClick={handleFlip}
          disabled={flipping || betAmount > balance || betAmount <= 0}
          className="w-full mt-8 bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-950 font-bold py-4 rounded-xl transition-colors text-lg"
        >
          {flipping ? 'Flipping...' : 'Place Bet'}
        </button>
      </div>
    </div>
  )
}
