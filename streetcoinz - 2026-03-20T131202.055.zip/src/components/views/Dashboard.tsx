import { motion } from 'motion/react';
import { Coins, Dices, Flame, TrendingUp } from 'lucide-react';

export default function Dashboard({ setCurrentView }: any) {
  const games = [
    { id: 'coinflip', name: 'Coin Flip', icon: Coins, color: 'from-yellow-500 to-orange-500', desc: 'Double or nothing. 50/50 chance.' },
    { id: 'dice', name: 'Dice Roll', icon: Dices, color: 'from-emerald-500 to-teal-500', desc: 'Roll the dice. Set your own odds.' },
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 p-8 md:p-12">
        <div className="relative z-10 max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-display font-bold mb-4">Welcome to <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-400">StreetCoinz</span></h1>
          <p className="text-zinc-400 text-lg mb-8">The most provably fair crypto casino on the streets. Play games, win big, and flex your balance.</p>
          <button onClick={() => setCurrentView('coinflip')} className="bg-white text-zinc-950 font-bold py-3 px-8 rounded-full hover:bg-zinc-200 transition-colors">
            Start Playing
          </button>
        </div>
        {/* Abstract shapes */}
        <div className="absolute right-0 top-0 w-96 h-96 bg-emerald-500/10 blur-3xl rounded-full translate-x-1/3 -translate-y-1/3" />
        <div className="absolute right-40 bottom-0 w-64 h-64 bg-purple-500/10 blur-3xl rounded-full translate-x-1/3 translate-y-1/3" />
      </section>

      <section>
        <div className="flex items-center space-x-2 mb-6">
          <Flame className="text-orange-500" />
          <h2 className="text-2xl font-display font-semibold">Featured Games</h2>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {games.map((game, i) => {
            const Icon = game.icon;
            return (
              <motion.button
                key={game.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                onClick={() => setCurrentView(game.id)}
                className="group relative text-left bg-zinc-900 border border-zinc-800 rounded-2xl p-6 hover:border-zinc-700 transition-all overflow-hidden"
              >
                <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${game.color} flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <Icon size={28} className="text-white" />
                </div>
                <h3 className="text-xl font-display font-bold mb-2">{game.name}</h3>
                <p className="text-zinc-400">{game.desc}</p>
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-900/90 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-6">
                  <span className="text-emerald-400 font-medium flex items-center">Play Now <TrendingUp size={16} className="ml-2" /></span>
                </div>
              </motion.button>
            )
          })}
        </div>
      </section>
    </div>
  )
}
