import { useState } from 'react';
import { motion } from 'motion/react';

export default function Dice({ balance, setBalance }: any) {
  const [betAmount, setBetAmount] = useState(10);
  const [target, setTarget] = useState(50);
  const [condition, setCondition] = useState<'under' | 'over'>('under');
  const [rolling, setRolling] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [win, setWin] = useState<boolean | null>(null);

  const winChance = condition === 'under' ? target : 100 - target;
  const multiplier = 99 / winChance;
  const potentialWin = betAmount * multiplier;

  const handleRoll = () => {
    if (betAmount > balance || betAmount <= 0 || winChance <= 0 || winChance >= 100) return;
    
    setBalance((b: number) => b - betAmount);
    setRolling(true);
    setResult(null);
    setWin(null);

    // Simulate roll animation
    let rolls = 0;
    const interval = setInterval(() => {
      setResult(Math.floor(Math.random() * 101));
      rolls++;
      if (rolls > 20) {
        clearInterval(interval);
        const finalResult = Math.floor(Math.random() * 101);
        setResult(finalResult);
        
        const isWin = condition === 'under' ? finalResult < target : finalResult > target;
        setWin(isWin);
        if (isWin) {
          setBalance((b: number) => b + potentialWin);
        }
        setRolling(false);
      }
    }, 50);
  };

  return (
    <div className="max-w-5xl mx-auto flex flex-col lg:flex-row gap-8">
      {/* Game Area */}
      <div className="flex-1 bg-zinc-900 border border-zinc-800 rounded-3xl p-8 md:p-12 flex flex-col items-center justify-center min-h-[400px] md:min-h-[500px] relative overflow-hidden">
        <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(16,185,129,0.05)_0%,transparent_70%)]" />
        
        <div className="relative z-10 w-full max-w-md flex flex-col items-center">
          <div className="text-8xl md:text-9xl font-display font-black tracking-tighter mb-12 tabular-nums bg-clip-text text-transparent bg-gradient-to-b from-white to-zinc-500">
            {result !== null ? result.toString().padStart(2, '0') : '00'}
          </div>

          {/* Slider Visualization */}
          <div className="w-full relative h-4 bg-zinc-800 rounded-full overflow-hidden mb-8">
            <div 
              className={`absolute top-0 bottom-0 ${condition === 'under' ? 'left-0 bg-emerald-500/50' : 'right-0 bg-emerald-500/50'}`}
              style={{ width: condition === 'under' ? `${target}%` : `${100 - target}%` }}
            />
            {result !== null && !rolling && (
              <motion.div 
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                className={`absolute top-1/2 -translate-y-1/2 w-3 h-3 rounded-full ${win ? 'bg-emerald-400 shadow-[0_0_10px_#34d399]' : 'bg-rose-400 shadow-[0_0_10px_#fb7185]'}`}
                style={{ left: `calc(${result}% - 6px)` }}
              />
            )}
          </div>

          {win !== null && !rolling && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`text-xl md:text-2xl font-display font-bold ${win ? 'text-emerald-400' : 'text-rose-400'}`}
            >
              {win ? `You won ${potentialWin.toFixed(2)} SCZ!` : `You lost ${betAmount.toFixed(2)} SCZ`}
            </motion.div>
          )}
        </div>
      </div>

      {/* Controls Area */}
      <div className="w-full lg:w-96 bg-zinc-900 border border-zinc-800 rounded-3xl p-6 md:p-8 flex flex-col">
        <h3 className="text-xl font-display font-bold mb-6">Bet Slip</h3>
        
        <div className="space-y-6 flex-1">
          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-2">Bet Amount</label>
            <div className="relative">
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-emerald-500 transition-colors"
              />
              <div className="absolute right-2 top-1/2 -translate-y-1/2 flex space-x-1">
                <button onClick={() => setBetAmount(b => b / 2)} className="px-2 py-1 bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-700">1/2</button>
                <button onClick={() => setBetAmount(b => b * 2)} className="px-2 py-1 bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-700">2x</button>
                <button onClick={() => setBetAmount(balance)} className="px-2 py-1 bg-zinc-800 rounded text-xs font-medium hover:bg-zinc-700">Max</button>
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4">
              <div className="text-sm text-zinc-400 mb-1">Multiplier</div>
              <div className="text-xl font-mono font-bold text-white">{multiplier.toFixed(2)}x</div>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4">
              <div className="text-sm text-zinc-400 mb-1">Win Chance</div>
              <div className="text-xl font-mono font-bold text-emerald-400">{winChance.toFixed(2)}%</div>
            </div>
          </div>

          <div>
            <div className="flex justify-between text-sm font-medium text-zinc-400 mb-2">
              <label>Target</label>
              <span>{condition === 'under' ? `< ${target}` : `> ${target}`}</span>
            </div>
            <input
              type="range"
              min="1"
              max="99"
              value={target}
              onChange={(e) => setTarget(Number(e.target.value))}
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />
            <div className="flex justify-between mt-4">
              <button
                onClick={() => setCondition('under')}
                className={`flex-1 py-2 rounded-l-xl font-bold transition-all ${condition === 'under' ? 'bg-emerald-500 text-zinc-950' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'}`}
              >
                Roll Under
              </button>
              <button
                onClick={() => setCondition('over')}
                className={`flex-1 py-2 rounded-r-xl font-bold transition-all ${condition === 'over' ? 'bg-emerald-500 text-zinc-950' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'}`}
              >
                Roll Over
              </button>
            </div>
          </div>
        </div>

        <button
          onClick={handleRoll}
          disabled={rolling || betAmount > balance || betAmount <= 0}
          className="w-full mt-8 bg-emerald-500 hover:bg-emerald-600 disabled:bg-zinc-800 disabled:text-zinc-500 text-zinc-950 font-bold py-4 rounded-xl transition-colors text-lg"
        >
          {rolling ? 'Rolling...' : 'Place Bet'}
        </button>
      </div>
    </div>
  )
}
