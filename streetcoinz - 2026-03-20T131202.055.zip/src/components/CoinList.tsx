import { useEffect, useState } from "react";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";

interface Coin {
  id: string;
  symbol: string;
  name: string;
  image: string;
  current_price: number;
  price_change_percentage_24h: number;
  market_cap: number;
  total_volume: number;
}

export function CoinList() {
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=20&page=1&sparkline=false",
    )
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setCoins(data);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error("Failed to fetch coin list", err);
        setLoading(false);
      });
  }, []);

  if (loading) {
    return (
      <div className="p-6 font-mono text-neon-green animate-pulse">
        FETCHING THE LATEST DROP...
      </div>
    );
  }

  return (
    <div className="w-full">
      <div className="grid grid-cols-[40px_1.5fr_1fr_1fr_1fr] gap-4 p-4 border-b-2 border-brutal-white font-display text-xl tracking-wide uppercase text-brutal-white/50">
        <div>#</div>
        <div>ASSET</div>
        <div className="text-right">PRICE</div>
        <div className="text-right">24H</div>
        <div className="text-right hidden sm:block">VOLUME</div>
      </div>

      <div className="flex flex-col">
        {coins.map((coin, index) => {
          const isPositive = coin.price_change_percentage_24h >= 0;
          return (
            <div
              key={coin.id}
              className="grid grid-cols-[40px_1.5fr_1fr_1fr_1fr] gap-4 p-4 border-b border-brutal-white/20 hover:bg-neon-green hover:text-brutal-black transition-colors cursor-pointer group items-center"
            >
              <div className="font-mono text-sm opacity-50 group-hover:opacity-100">
                {(index + 1).toString().padStart(2, "0")}
              </div>
              <div className="flex items-center gap-3">
                <img
                  src={coin.image}
                  alt={coin.name}
                  className="w-8 h-8 rounded-full grayscale group-hover:grayscale-0 transition-all"
                />
                <div className="flex flex-col">
                  <span className="font-bold text-lg leading-none uppercase">
                    {coin.symbol}
                  </span>
                  <span className="text-xs font-mono opacity-60 group-hover:opacity-100">
                    {coin.name}
                  </span>
                </div>
              </div>
              <div className="text-right font-mono font-bold">
                $
                {coin.current_price.toLocaleString(undefined, {
                  minimumFractionDigits: 2,
                  maximumFractionDigits: 6,
                })}
              </div>
              <div
                className={`text-right font-mono font-bold flex items-center justify-end gap-1 ${isPositive ? "text-neon-green group-hover:text-brutal-black" : "text-red-500 group-hover:text-red-900"}`}
              >
                {isPositive ? (
                  <ArrowUpRight size={16} strokeWidth={3} />
                ) : (
                  <ArrowDownRight size={16} strokeWidth={3} />
                )}
                {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
              </div>
              <div className="text-right font-mono text-sm opacity-70 group-hover:opacity-100 hidden sm:block">
                ${(coin.total_volume / 1000000).toFixed(1)}M
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
