import React from 'react';
import { Trophy, ArrowUpRight } from 'lucide-react';

export function RecentWinners() {
  const winners = [
    { user: 'Anonim', game: 'Cyber City', amount: '$4,250.00', multiplier: 'x125' },
    { user: 'Anonim', game: 'Neon Nights', amount: '$1,120.50', multiplier: 'x50' },
    { user: 'Anonim', game: 'Crypto Crash', amount: '$8,900.00', multiplier: 'x890' },
    { user: 'Anonim', game: 'Street Dice', amount: '$550.00', multiplier: 'x10' },
    { user: 'Anonim', game: 'Cyber City', amount: '$2,100.00', multiplier: 'x75' },
  ];

  return (
    <div className="h-14 bg-[var(--color-bg-surface)] border-t border-white/5 flex items-center shrink-0 overflow-hidden relative z-20">
      
      {/* Label */}
      <div className="flex items-center gap-2 px-4 sm:px-6 h-full bg-[var(--color-bg-elevated)] border-r border-white/5 shrink-0 z-10 shadow-[10px_0_20px_rgba(0,0,0,0.5)]">
        <Trophy className="w-4 h-4 text-amber-500" />
        <span className="text-xs font-bold text-white uppercase tracking-wider hidden sm:block">Recent Winners</span>
      </div>

      {/* Ticker */}
      <div className="flex-1 overflow-hidden relative">
        <div className="flex items-center gap-6 animate-[marquee_20s_linear_infinite] whitespace-nowrap px-4">
          {[...winners, ...winners].map((winner, i) => (
            <div key={i} className="flex items-center gap-3 bg-white/5 rounded-full px-3 py-1.5 border border-white/5 hover:border-emerald-500/30 transition-colors cursor-pointer group">
              <div className="flex flex-col">
                <span className="text-[10px] text-zinc-500 font-medium leading-none mb-0.5">{winner.game}</span>
                <span className="text-xs text-zinc-300 font-semibold leading-none">{winner.user}</span>
              </div>
              <div className="h-6 w-px bg-white/10 mx-1"></div>
              <div className="flex flex-col items-end">
                <span className="text-xs font-bold text-emerald-400 leading-none mb-0.5 flex items-center gap-0.5">
                  {winner.amount}
                  <ArrowUpRight className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
                </span>
                <span className="text-[10px] text-amber-500 font-bold leading-none">{winner.multiplier}</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes marquee {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
      `}} />
    </div>
  );
}
