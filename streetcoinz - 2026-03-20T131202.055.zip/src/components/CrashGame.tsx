import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { cn } from '../lib/utils';
import { Flame, TrendingUp, AlertCircle } from 'lucide-react';

export default function CrashGame() {
  const [balance, setBalance] = useState(1000);
  const updateBalance = async (amount: number, isAdding: boolean) => setBalance(prev => isAdding ? prev + amount : prev - amount);
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'crashed'>('idle');
  const [multiplier, setMultiplier] = useState(1.00);
  const [betAmount, setBetAmount] = useState(10);
  const [crashPoint, setCrashPoint] = useState(0);
  const [cashedOut, setCashedOut] = useState(false);
  
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animationRef = useRef<number>(null);
  const startTimeRef = useRef<number>(0);

  // Generate a random crash point (weighted towards lower numbers)
  const generateCrashPoint = () => {
    const e = 2 ** 32;
    const h = crypto.getRandomValues(new Uint32Array(1))[0];
    const p = h / e;
    return Math.max(1.00, (100 / (100 - p * 99)) * 0.99);
  };

  const startGame = async () => {
    if (betAmount > balance || betAmount <= 0) return;
    
    await updateBalance(betAmount, false); // Deduct bet
    
    setCrashPoint(generateCrashPoint());
    setGameState('playing');
    setMultiplier(1.00);
    setCashedOut(false);
    startTimeRef.current = performance.now();
    
    if (animationRef.current) cancelAnimationFrame(animationRef.current);
    animationRef.current = requestAnimationFrame(updateGame);
  };

  const cashOut = async () => {
    if (gameState !== 'playing' || cashedOut) return;
    
    setCashedOut(true);
    const winAmount = betAmount * multiplier;
    await updateBalance(winAmount, true);
  };

  const updateGame = (timestamp: number) => {
    if (gameState !== 'playing') return;

    const elapsed = timestamp - startTimeRef.current;
    // Multiplier increases exponentially
    const currentMultiplier = Math.max(1.00, Math.pow(Math.E, 0.00006 * elapsed));
    
    if (currentMultiplier >= crashPoint) {
      setMultiplier(crashPoint);
      setGameState('crashed');
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
      return;
    }

    setMultiplier(currentMultiplier);
    drawGraph(currentMultiplier);
    
    animationRef.current = requestAnimationFrame(updateGame);
  };

  const drawGraph = (currentMult: number) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const width = canvas.width;
    const height = canvas.height;
    
    ctx.clearRect(0, 0, width, height);
    
    // Draw grid
    ctx.strokeStyle = '#2A2A35';
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let i = 0; i < width; i += 50) {
      ctx.moveTo(i, 0);
      ctx.lineTo(i, height);
    }
    for (let i = 0; i < height; i += 50) {
      ctx.moveTo(0, i);
      ctx.lineTo(width, i);
    }
    ctx.stroke();

    // Draw curve
    ctx.beginPath();
    ctx.moveTo(0, height);
    
    // Simple curve calculation for visual effect
    const points = 100;
    for (let i = 0; i <= points; i++) {
      const x = (i / points) * width;
      // Exponential curve visual
      const normalizedMult = Math.min(currentMult, 10) / 10; // Cap visual at 10x
      const y = height - (Math.pow(i / points, 2) * height * normalizedMult);
      ctx.lineTo(x, y);
    }
    
    ctx.strokeStyle = gameState === 'crashed' ? '#FF4444' : '#00FF00';
    ctx.lineWidth = 4;
    ctx.stroke();
    
    // Fill under curve
    ctx.lineTo(width, height);
    ctx.lineTo(0, height);
    const gradient = ctx.createLinearGradient(0, 0, 0, height);
    if (gameState === 'crashed') {
      gradient.addColorStop(0, 'rgba(255, 68, 68, 0.2)');
      gradient.addColorStop(1, 'rgba(255, 68, 68, 0)');
    } else {
      gradient.addColorStop(0, 'rgba(0, 255, 0, 0.2)');
      gradient.addColorStop(1, 'rgba(0, 255, 0, 0)');
    }
    ctx.fillStyle = gradient;
    ctx.fill();
  };

  useEffect(() => {
    // Initial draw
    drawGraph(1.00);
    return () => {
      if (animationRef.current) cancelAnimationFrame(animationRef.current);
    };
  }, []);

  // Redraw when game state changes to crashed
  useEffect(() => {
    if (gameState === 'crashed') {
      drawGraph(multiplier);
    }
  }, [gameState]);

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-8 max-w-6xl mx-auto flex flex-col lg:flex-row gap-8"
    >
      {/* Controls Panel */}
      <div className="w-full lg:w-80 bg-dark-surface border border-dark-border rounded-2xl p-6 flex flex-col gap-6">
        <div>
          <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
            <TrendingUp className="text-neon-purple" /> Crash
          </h2>
          
          <div className="space-y-4">
            <div>
              <label className="text-sm text-gray-400 mb-2 block font-medium uppercase tracking-wider">Bet Amount</label>
              <div className="relative">
                <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">$</span>
                <input 
                  type="number" 
                  value={betAmount}
                  onChange={(e) => setBetAmount(Number(e.target.value))}
                  disabled={gameState === 'playing'}
                  className="w-full bg-dark-bg border border-dark-border rounded-xl py-3 pl-8 pr-4 text-white font-mono focus:outline-none focus:border-neon-purple/50 transition-colors disabled:opacity-50"
                />
                <div className="absolute right-2 top-1/2 -translate-y-1/2 flex gap-1">
                  <button onClick={() => setBetAmount(b => b / 2)} disabled={gameState === 'playing'} className="bg-dark-surface px-2 py-1 rounded text-xs text-gray-400 hover:text-white transition-colors">1/2</button>
                  <button onClick={() => setBetAmount(b => b * 2)} disabled={gameState === 'playing'} className="bg-dark-surface px-2 py-1 rounded text-xs text-gray-400 hover:text-white transition-colors">2x</button>
                </div>
              </div>
            </div>

            <div className="pt-4">
              {gameState === 'idle' || gameState === 'crashed' ? (
                <button 
                  onClick={startGame}
                  disabled={betAmount > balance || betAmount <= 0}
                  className="w-full bg-neon-purple hover:bg-neon-purple/80 text-white font-bold py-4 rounded-xl transition-all shadow-[0_0_20px_rgba(176,38,255,0.3)] disabled:opacity-50 disabled:shadow-none uppercase tracking-widest"
                >
                  Place Bet
                </button>
              ) : (
                <button 
                  onClick={cashOut}
                  disabled={cashedOut}
                  className={cn(
                    "w-full font-bold py-4 rounded-xl transition-all uppercase tracking-widest",
                    cashedOut 
                      ? "bg-dark-border text-gray-400 cursor-not-allowed" 
                      : "bg-neon-green hover:bg-neon-green/80 text-black shadow-[0_0_20px_rgba(0,255,0,0.3)]"
                  )}
                >
                  {cashedOut ? 'Cashed Out' : `Cash Out (${(betAmount * multiplier).toFixed(2)})`}
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Game Info */}
        <div className="mt-auto pt-6 border-t border-dark-border">
          <div className="flex justify-between text-sm mb-2">
            <span className="text-gray-400">Previous Crashes</span>
          </div>
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
            {[2.45, 1.12, 5.67, 1.01, 12.4].map((m, i) => (
              <span key={i} className={cn(
                "px-2 py-1 rounded text-xs font-mono font-bold",
                m >= 2 ? "text-neon-green bg-neon-green/10" : "text-red-500 bg-red-500/10"
              )}>
                {m.toFixed(2)}x
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Game Canvas */}
      <div className="flex-1 bg-dark-surface border border-dark-border rounded-2xl relative overflow-hidden min-h-[400px] flex items-center justify-center">
        <canvas 
          ref={canvasRef} 
          width={800} 
          height={500} 
          className="w-full h-full absolute inset-0 object-cover opacity-50"
        />
        
        <div className="relative z-10 text-center">
          <div className={cn(
            "text-7xl md:text-9xl font-black font-mono tracking-tighter transition-colors duration-300",
            gameState === 'crashed' ? "text-red-500" : 
            cashedOut ? "text-neon-green" : "text-white"
          )}>
            {multiplier.toFixed(2)}x
          </div>
          
          {gameState === 'crashed' && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className="mt-4 text-red-500 font-bold text-xl flex items-center justify-center gap-2 uppercase tracking-widest"
            >
              <AlertCircle /> Crashed
            </motion.div>
          )}
          
          {cashedOut && gameState === 'playing' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 text-neon-green font-bold text-xl uppercase tracking-widest"
            >
              You won ${(betAmount * multiplier).toFixed(2)}!
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
