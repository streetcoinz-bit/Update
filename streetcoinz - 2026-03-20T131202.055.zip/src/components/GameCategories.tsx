import { motion } from 'motion/react';
import { Cherry, Dice5, Gamepad2, Spade, Trophy, Zap } from 'lucide-react';

const categories = [
  { name: 'Slots', icon: Cherry, color: 'text-pink-500', bg: 'bg-pink-500/10' },
  { name: 'Live Casino', icon: Spade, color: 'text-neon-green', bg: 'bg-neon-green/10' },
  { name: 'Originals', icon: Zap, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
  { name: 'Table Games', icon: Dice5, color: 'text-neon-blue', bg: 'bg-neon-blue/10' },
  { name: 'Crash', icon: Gamepad2, color: 'text-neon-purple', bg: 'bg-neon-purple/10' },
  { name: 'Sports', icon: Trophy, color: 'text-orange-500', bg: 'bg-orange-500/10' },
];

export default function GameCategories() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {categories.map((category, index) => {
          const Icon = category.icon;
          return (
            <motion.a
              key={category.name}
              href="#"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className={`flex flex-col items-center justify-center gap-3 rounded-2xl border border-white/5 bg-street-gray p-6 text-center hover:bg-street-light transition-colors`}
            >
              <div className={`flex h-12 w-12 items-center justify-center rounded-xl ${category.bg}`}>
                <Icon className={`h-6 w-6 ${category.color}`} />
              </div>
              <span className="font-display text-sm font-semibold text-gray-300">
                {category.name}
              </span>
            </motion.a>
          );
        })}
      </div>
    </div>
  );
}
