import { Search, Bell, User } from "lucide-react";

export function TopBar() {
  return (
    <header className="sticky top-0 z-30 flex h-16 w-full items-center justify-between border-b border-white/5 bg-dark-900/80 px-4 backdrop-blur-md sm:px-6 lg:px-8">
      <div className="flex flex-1 items-center gap-4">
        <div className="relative hidden w-full max-w-md sm:block">
          <div className="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
            <Search className="h-4 w-4 text-gray-500" />
          </div>
          <input
            type="text"
            className="block w-full rounded-full border-0 bg-dark-800 py-2 pl-10 pr-3 text-sm text-white placeholder:text-gray-500 focus:bg-dark-700 focus:outline-none focus:ring-1 focus:ring-brand-500 sm:text-sm sm:leading-6"
            placeholder="Search games..."
          />
        </div>
      </div>

      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2 rounded-full bg-dark-800 py-1 pl-4 pr-1">
          <span className="font-mono text-sm font-medium text-brand-500">
            1,250.50 STC
          </span>
          <button className="rounded-full bg-brand-500 px-4 py-1.5 text-sm font-semibold text-dark-900 transition-colors hover:bg-brand-600">
            Deposit
          </button>
        </div>

        <button className="relative rounded-full p-2 text-gray-400 hover:bg-white/5 hover:text-white">
          <Bell className="h-5 w-5" />
          <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-brand-500" />
        </button>

        <button className="flex h-9 w-9 items-center justify-center rounded-full bg-dark-700 text-gray-400 hover:text-white">
          <User className="h-5 w-5" />
        </button>
      </div>
    </header>
  );
}
