import { Link } from 'react-router-dom';
import { Twitter, Instagram, Send, ShieldCheck, HelpCircle } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="border-t border-white/5 bg-[var(--color-bg-base)] mt-auto">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 lg:gap-12">
          <div className="col-span-1 md:col-span-1">
            <Link to="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 rounded bg-[var(--color-accent-primary)] flex items-center justify-center">
                <span className="font-bold text-black text-lg">S</span>
              </div>
              <span className="font-bold text-xl tracking-tight">
                Street<span className="text-[var(--color-accent-primary)]">Coinz</span>
              </span>
            </Link>
            <p className="text-sm text-gray-400 mb-6">
              The ultimate crypto casino experience. Provably fair games, instant payouts, and massive rewards.
            </p>
            <div className="flex items-center gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors">
                <Send className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Casino</h3>
            <ul className="space-y-3">
              <li><Link to="/games" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">All Games</Link></li>
              <li><Link to="/games?category=slots" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Slots</Link></li>
              <li><Link to="/games?category=live" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Live Casino</Link></li>
              <li><Link to="/promotions" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Promotions</Link></li>
              <li><Link to="/vip" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">VIP Club</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Support</h3>
            <ul className="space-y-3">
              <li><Link to="/faq" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">FAQ</Link></li>
              <li><Link to="/support" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Live Support</Link></li>
              <li><Link to="/fairness" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Provably Fair</Link></li>
              <li><Link to="/responsible" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Responsible Gaming</Link></li>
            </ul>
          </div>

          <div>
            <h3 className="text-sm font-bold text-white uppercase tracking-wider mb-4">Legal</h3>
            <ul className="space-y-3">
              <li><Link to="/terms" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Terms of Service</Link></li>
              <li><Link to="/privacy" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">Privacy Policy</Link></li>
              <li><Link to="/aml" className="text-sm text-gray-400 hover:text-[var(--color-accent-primary)] transition-colors">AML Policy</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-gray-400">
              <ShieldCheck className="w-5 h-5 text-green-500" />
              <span className="text-sm font-medium">100% Secure</span>
            </div>
            <div className="flex items-center gap-2 text-gray-400">
              <HelpCircle className="w-5 h-5 text-blue-500" />
              <span className="text-sm font-medium">24/7 Support</span>
            </div>
          </div>
          <p className="text-sm text-gray-500">
            &copy; {new Date().getFullYear()} StreetCoinz. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
}
