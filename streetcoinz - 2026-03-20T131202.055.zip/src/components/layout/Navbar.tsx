import { Menu, Search, Wallet, Bell, User } from 'lucide-react';
import { Link } from 'react-router-dom';

interface NavbarProps {
  onMenuClick: () => void;
}

export default function Navbar({ onMenuClick }: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 w-full glass-panel border-b border-white/5">
      <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
        <div className="flex items-center gap-4">
          <button
            onClick={onMenuClick}
            className="p-2 -ml-2 text-gray-400 hover:text-white lg:hidden transition-colors"
          >
            <span className="sr-only">Open sidebar</span>
            <Menu className="h-6 w-6" />
          </button>
          
          <Link to="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded bg-[var(--color-accent-primary)] flex items-center justify-center">
              <span className="font-bold text-black text-lg">S</span>
            </div>
            <span className="font-bold text-xl tracking-tight hidden sm:block">
              Street<span className="text-[var(--color-accent-primary)]">Coinz</span>
            </span>
          </Link>
        </div>

        <div className="flex-1 max-w-md px-4 hidden md:block">
          <div className="relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-gray-400 group-focus-within:text-[var(--color-accent-primary)] transition-colors" />
            </div>
            <input
              type="text"
              className="block w-full pl-10 pr-3 py-2 border border-white/10 rounded-lg leading-5 bg-[var(--color-bg-elevated)] text-gray-300 placeholder-gray-500 focus:outline-none focus:ring-1 focus:ring-[var(--color-accent-primary)] focus:border-[var(--color-accent-primary)] sm:text-sm transition-all"
              placeholder="Search games..."
            />
          </div>
        </div>

        <div className="flex items-center gap-3 sm:gap-4">
          <div className="hidden sm:flex items-center bg-[var(--color-bg-elevated)] rounded-lg p-1 border border-white/5">
            <div className="px-3 py-1 flex items-center gap-2">
              <span className="text-sm font-mono text-gray-300">1,245.50</span>
              <span className="text-xs font-bold text-[var(--color-accent-primary)]">SCZ</span>
            </div>
            <button className="bg-[var(--color-accent-primary)] text-black px-3 py-1 rounded-md text-sm font-bold hover:bg-[#00e65c] transition-colors flex items-center gap-1">
              <Wallet className="w-4 h-4" />
              Deposit
            </button>
          </div>

          <button className="p-2 text-gray-400 hover:text-white transition-colors relative">
            <Bell className="h-5 w-5" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-[var(--color-accent-primary)] rounded-full"></span>
          </button>
          
          <button className="w-8 h-8 rounded-full bg-gradient-to-tr from-[var(--color-accent-secondary)] to-purple-400 flex items-center justify-center border border-white/10 overflow-hidden">
            <User className="h-4 w-4 text-white" />
          </button>
        </div>
      </div>
    </header>
  );
}
