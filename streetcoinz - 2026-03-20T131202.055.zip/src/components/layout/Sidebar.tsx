import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Gamepad2, 
  Trophy, 
  Gift, 
  Flame, 
  Coins, 
  Users, 
  Settings,
  LogOut,
  X
} from 'lucide-react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

interface SidebarProps {
  isOpen: boolean;
  setIsOpen: (isOpen: boolean) => void;
}

const navItems = [
  { name: 'Home', href: '/', icon: Home },
  { name: 'All Games', href: '/games', icon: Gamepad2 },
  { name: 'Tournaments', href: '/tournaments', icon: Trophy },
  { name: 'Promotions', href: '/promotions', icon: Gift },
  { name: 'Hot Drops', href: '/hot-drops', icon: Flame },
  { name: 'VIP Club', href: '/vip', icon: Coins },
  { name: 'Affiliates', href: '/affiliates', icon: Users },
];

export default function Sidebar({ isOpen, setIsOpen }: SidebarProps) {
  const location = useLocation();

  return (
    <>
      {/* Mobile backdrop */}
      {isOpen && (
        <div 
          className="fixed inset-0 z-40 bg-black/80 backdrop-blur-sm lg:hidden transition-opacity"
          onClick={() => setIsOpen(false)}
        />
      )}

      {/* Sidebar component */}
      <div
        className={twMerge(
          "fixed inset-y-0 left-0 z-50 w-64 glass-panel border-r border-white/5 transform transition-transform duration-300 ease-in-out lg:static lg:translate-x-0 flex flex-col",
          isOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="flex items-center justify-between h-16 px-6 border-b border-white/5 lg:hidden">
          <Link to="/" className="flex items-center gap-2" onClick={() => setIsOpen(false)}>
            <div className="w-8 h-8 rounded bg-[var(--color-accent-primary)] flex items-center justify-center">
              <span className="font-bold text-black text-lg">S</span>
            </div>
            <span className="font-bold text-xl tracking-tight">
              Street<span className="text-[var(--color-accent-primary)]">Coinz</span>
            </span>
          </Link>
          <button 
            onClick={() => setIsOpen(false)}
            className="text-gray-400 hover:text-white transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto py-6 px-4 space-y-8">
          <nav className="space-y-1">
            {navItems.map((item) => {
              const isActive = location.pathname === item.href;
              return (
                <Link
                  key={item.name}
                  to={item.href}
                  onClick={() => setIsOpen(false)}
                  className={twMerge(
                    "group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg transition-all duration-200",
                    isActive 
                      ? "bg-[var(--color-accent-primary)]/10 text-[var(--color-accent-primary)] border border-[var(--color-accent-primary)]/20 shadow-[0_0_15px_rgba(0,255,102,0.1)]" 
                      : "text-gray-400 hover:bg-white/5 hover:text-white"
                  )}
                >
                  <item.icon
                    className={twMerge(
                      "flex-shrink-0 -ml-1 mr-3 h-5 w-5 transition-colors duration-200",
                      isActive ? "text-[var(--color-accent-primary)]" : "text-gray-500 group-hover:text-gray-300"
                    )}
                    aria-hidden="true"
                  />
                  <span className="truncate">{item.name}</span>
                  {isActive && (
                    <span className="ml-auto w-1.5 h-1.5 rounded-full bg-[var(--color-accent-primary)] neon-glow"></span>
                  )}
                </Link>
              );
            })}
          </nav>

          <div>
            <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Account
            </h3>
            <nav className="space-y-1">
              <Link
                to="/settings"
                className="group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg text-gray-400 hover:bg-white/5 hover:text-white transition-all"
              >
                <Settings className="flex-shrink-0 -ml-1 mr-3 h-5 w-5 text-gray-500 group-hover:text-gray-300" />
                Settings
              </Link>
              <button
                className="w-full group flex items-center px-3 py-2.5 text-sm font-medium rounded-lg text-red-400 hover:bg-red-400/10 hover:text-red-300 transition-all"
              >
                <LogOut className="flex-shrink-0 -ml-1 mr-3 h-5 w-5 text-red-500/70 group-hover:text-red-400" />
                Logout
              </button>
            </nav>
          </div>
        </div>

        <div className="p-4 border-t border-white/5">
          <div className="bg-[var(--color-bg-elevated)] rounded-xl p-4 border border-white/5 relative overflow-hidden group cursor-pointer">
            <div className="absolute inset-0 bg-gradient-to-br from-[var(--color-accent-secondary)]/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="relative z-10 flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-[var(--color-accent-secondary)] flex items-center justify-center">
                <Trophy className="w-5 h-5 text-white" />
              </div>
              <div>
                <p className="text-sm font-bold text-white">VIP Level 4</p>
                <div className="w-full bg-black rounded-full h-1.5 mt-2">
                  <div className="bg-[var(--color-accent-secondary)] h-1.5 rounded-full" style={{ width: '65%' }}></div>
                </div>
                <p className="text-xs text-gray-400 mt-1">65% to Level 5</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
