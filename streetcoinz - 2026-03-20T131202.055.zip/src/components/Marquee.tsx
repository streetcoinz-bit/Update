import { useEffect, useState } from "react";

interface Coin {
  id: string;
  symbol: string;
  name: string;
  current_price: number;
  price_change_percentage_24h: number;
}

export function Marquee() {
  const [coins, setCoins] = useState<Coin[]>([]);

  useEffect(() => {
    fetch(
      "https://api.coingecko.com/api/v3/coins/markets?vs_currency=usd&order=market_cap_desc&per_page=10&page=1&sparkline=false",
    )
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setCoins(data);
        }
      })
      .catch((err) => console.error("Failed to fetch marquee data", err));
  }, []);

  const displayCoins = coins.length > 0 ? [...coins, ...coins] : []; // Duplicate for seamless loop

  return (
    <div className="w-full bg-neon-green text-brutal-black border-b-2 border-brutal-white overflow-hidden flex whitespace-nowrap py-2 font-mono text-sm font-bold uppercase tracking-wider">
      <div className="flex animate-marquee">
        {displayCoins.map((coin, i) => (
          <div key={`${coin.id}-${i}`} className="flex items-center mx-6">
            <span>{coin.symbol}</span>
            <span className="mx-2">${coin.current_price.toLocaleString()}</span>
            <span
              className={
                coin.price_change_percentage_24h >= 0
                  ? "text-brutal-black"
                  : "text-red-700"
              }
            >
              {coin.price_change_percentage_24h >= 0 ? "+" : ""}
              {coin.price_change_percentage_24h?.toFixed(2)}%
            </span>
          </div>
        ))}
        {displayCoins.length === 0 && (
          <div className="mx-6">
            LOADING STREET DATA... LOADING STREET DATA... LOADING STREET DATA...
          </div>
        )}
      </div>
    </div>
  );
}
