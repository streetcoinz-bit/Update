import React, { useState, useEffect } from 'react';
import { Users, Activity, DollarSign, Settings, Shield, AlertTriangle, TrendingUp, TrendingDown, Search, UserCheck, UserMinus, ArrowUpRight, ArrowDownLeft, Check, X, RefreshCw, ArrowDownToLine, ArrowUpFromLine, BarChart3, Copy, Mail, Send, Crown } from 'lucide-react';
import { toast } from '../lib/toast';
import { supabase } from '../lib/supabase';

import { sendDepositFollowUpEmail, sendWithdrawFollowUpEmail, sendCancelOrderEmail } from '../services/emailService';

export function AdminDashboard({ userEmail }: { userEmail?: string }) {
  const [activeTab, setActiveTab] = useState<'overview' | 'alerts' | 'daily' | 'monthly' | 'yearly' | 'users' | 'top_users' | 'bets' | 'deposits' | 'withdrawals' | 'emails' | 'settings'>('overview');
  const [searchQuery, setSearchQuery] = useState('');
  const [isIDR, setIsIDR] = useState(() => {
    const saved = localStorage.getItem('admin_currency_idr');
    return saved === 'true';
  });
  const [isMaintenanceMode, setIsMaintenanceMode] = useState(() => {
    const saved = localStorage.getItem('admin_maintenance_mode');
    return saved === 'true';
  });
  const [isTradingHalted, setIsTradingHalted] = useState(() => {
    const saved = localStorage.getItem('admin_trading_halted');
    return saved === 'true';
  });
  
  // Email form state
  const [emailRecipient, setEmailRecipient] = useState('');
  const [emailSubject, setEmailSubject] = useState('');
  const [emailMessage, setEmailMessage] = useState('');
  const [showEmailPreview, setShowEmailPreview] = useState(false);

  // Data state
  const [users, setUsers] = useState<any[]>([]);
  const [bets, setBets] = useState<any[]>([]);
  const [deposits, setDeposits] = useState<any[]>([]);
  const [withdrawals, setWithdrawals] = useState<any[]>([]);
  const [logs, setLogs] = useState<any[]>([]);
  
  // User Adjustment Modal State
  const [showAdjustmentModal, setShowAdjustmentModal] = useState(false);
  const [selectedUserForAdjustment, setSelectedUserForAdjustment] = useState<any>(null);
  const [adjustmentType, setAdjustmentType] = useState<'win' | 'loss'>('win');
  const [adjustmentAmount, setAdjustmentAmount] = useState('');
  const [isAdjusting, setIsAdjusting] = useState(false);

  // Game Settings Modal State
  const [showGameSettingsModal, setShowGameSettingsModal] = useState(false);
  const [selectedUserForGameSettings, setSelectedUserForGameSettings] = useState<any>(null);
  const [forcedOutcome, setForcedOutcome] = useState<'normal' | 'win' | 'lose'>('normal');
  const [targetWinAmount, setTargetWinAmount] = useState('');
  const [targetLossAmount, setTargetLossAmount] = useState('');
  const [isSavingGameSettings, setIsSavingGameSettings] = useState(false);
  const [riggedUsers, setRiggedUsers] = useState<Record<string, any>>({});

  const [stats, setStats] = useState<any>({
    totalUsers: 0,
    totalDeposits: 0,
    totalWithdrawals: 0,
    totalVolume: 0,
    platformProfit: 0,
    activeBets: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    localStorage.setItem('admin_currency_idr', String(isIDR));
  }, [isIDR]);

  useEffect(() => {
    localStorage.setItem('admin_maintenance_mode', String(isMaintenanceMode));
    window.dispatchEvent(new Event('admin_settings_changed'));
  }, [isMaintenanceMode]);

  useEffect(() => {
    localStorage.setItem('admin_trading_halted', String(isTradingHalted));
    window.dispatchEvent(new Event('admin_settings_changed'));
  }, [isTradingHalted]);

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      
      // Fetch users
      const { data: usersData, error: usersError } = await supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });
        
      if (usersError) throw usersError;

      // Fetch users_wallets
      const { data: walletsData } = await supabase
        .from('users_wallets')
        .select('email, balance');

      // Calculate referral counts and merge wallet balance
      const usersWithReferrals = usersData?.map(user => {
        const referralCount = usersData.filter(u => u.referred_by === user.id).length;
        const wallet = walletsData?.find(w => w.email === user.email);
        return { 
          ...user, 
          referral_users: referralCount,
          balance: wallet ? wallet.balance : user.balance
        };
      }) || [];
      
      // Fetch bets
      const { data: betsData, error: betsError } = await supabase
        .from('bets')
        .select('*, users(email)')
        .order('created_at', { ascending: false })
        .limit(50);
        
      if (betsError) throw betsError;
      
      // Fetch external API data
      let apiStats: any = { total_balance: 0, total_deposits: 0, total_withdrawals: 0 };
      let apiDeposits: any[] = [];
      let apiWithdrawals: any[] = [];
      let apiUsersOnline: any = { online_users: 0 };

      try {
        const [statsRes, depositsRes, withdrawalsRes, usersOnlineRes] = await Promise.all([
          fetch('https://apiv1.streetcoinz.com/admin/stats').catch(() => null),
          fetch('https://apiv1.streetcoinz.com/admin/deposits').catch(() => null),
          fetch('https://apiv1.streetcoinz.com/admin/withdrawals').catch(() => null),
          fetch('https://apiv1.streetcoinz.com/admin/users-online').catch(() => null),
        ]);

        if (statsRes?.ok) apiStats = await statsRes.json().catch(() => apiStats);
        if (depositsRes?.ok) {
          const d = await depositsRes.json().catch(() => []);
          if (Array.isArray(d)) apiDeposits = d;
          else if (d && typeof d === 'object' && Array.isArray(d.data)) apiDeposits = d.data;
        }
        if (withdrawalsRes?.ok) {
          const w = await withdrawalsRes.json().catch(() => []);
          if (Array.isArray(w)) apiWithdrawals = w;
          else if (w && typeof w === 'object' && Array.isArray(w.data)) apiWithdrawals = w.data;
        }
        if (usersOnlineRes?.ok) apiUsersOnline = await usersOnlineRes.json().catch(() => apiUsersOnline);
      } catch (e) {
        console.error('Error fetching external API data:', e);
      }

      const depositsData = apiDeposits;
      const withdrawalsData = apiWithdrawals;

      // Calculate dates
      const now = new Date();
      
      const today = new Date(now);
      today.setHours(0, 0, 0, 0);
      const todayIso = today.toISOString();

      const thisMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const monthIso = thisMonth.toISOString();

      const thisYear = new Date(now.getFullYear(), 0, 1);
      const yearIso = thisYear.toISOString();

      // Fetch yearly data
      const { data: yearlyUsers } = await supabase
        .from('users')
        .select('id, joined_at')
        .gte('joined_at', yearIso);

      const { data: yearlyDeposits } = await supabase
        .from('deposits')
        .select('amount, created_at')
        .gte('created_at', yearIso)
        .eq('status', 'completed');

      const { data: yearlyWithdrawals } = await supabase
        .from('withdrawals')
        .select('amount, created_at')
        .gte('created_at', yearIso)
        .in('status', ['approved', 'sent']);

      const { data: yearlyBets } = await supabase
        .from('bets')
        .select('amount, created_at')
        .gte('created_at', yearIso);
        
      const { data: yearlyCashback } = await supabase
        .from('cashback_rewards')
        .select('amount, created_at')
        .gte('created_at', yearIso);

      const { data: yearlyReferral } = await supabase
        .from('referral_rewards')
        .select('amount, created_at')
        .gte('created_at', yearIso);

      const { data: yearlyVisits } = await supabase
        .from('website_visits')
        .select('id, created_at')
        .gte('created_at', yearIso);

      const { data: yearlyActiveBets } = await supabase
        .from('bets')
        .select('id, created_at')
        .gte('created_at', yearIso)
        .eq('status', 'PENDING');

      // Fetch recent system logs
      const { data: logsData } = await supabase
        .from('system_logs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      // Fetch system settings
      const { data: settingsData } = await supabase
        .from('system_settings')
        .select('*');
        
      if (settingsData) {
        const maintenanceSetting = settingsData.find(s => s.key === 'maintenance_mode');
        if (maintenanceSetting) {
          setIsMaintenanceMode(maintenanceSetting.value === 'true' || maintenanceSetting.value === true);
        }
        
        const tradingSetting = settingsData.find(s => s.key === 'trading_halted');
        if (tradingSetting) {
          setIsTradingHalted(tradingSetting.value === 'true' || tradingSetting.value === true);
        }

        const riggedSetting = settingsData.find(s => s.key === 'rigged_users');
        if (riggedSetting && typeof riggedSetting.value === 'object') {
          setRiggedUsers(riggedSetting.value);
        }
      }
      
      setUsers(usersWithReferrals);
      setBets(betsData || []);
      setDeposits(depositsData || []);
      setWithdrawals(withdrawalsData || []);
      setLogs(logsData || []);
      
      // Calculate stats
      const totalUsers = usersData?.length || 0;
      const totalUsersOnline = Number(apiUsersOnline?.online_users) || 0;
      const totalUsersOffline = totalUsers - totalUsersOnline;
      const totalSaldoUsers = usersData?.reduce((sum, u) => sum + (Number(u.balance) || 0), 0) || 0;
      const totalDeposits = usersData?.reduce((sum, u) => sum + (Number(u.total_deposits) || 0), 0) || 0;
      const totalWithdrawals = usersData?.reduce((sum, u) => sum + (Number(u.total_withdrawals) || 0), 0) || 0;
      const totalVolume = usersData?.reduce((sum, u) => sum + (Number(u.total_volume) || 0), 0) || 0;
      const platformProfit = totalDeposits - totalWithdrawals; // Simplified profit calculation
      const activeBets = betsData?.filter(b => b.status === 'PENDING').length || 0;

      const filterByDate = (data: any[], dateIso: string, dateField = 'created_at') => {
        return data?.filter(item => item[dateField] >= dateIso) || [];
      };
      
      const sumAmount = (data: any[]) => data.reduce((sum, item) => sum + (Number(item.amount) || 0), 0);

      const monthlyUsers = filterByDate(yearlyUsers || [], monthIso, 'joined_at');
      const dailyUsers = filterByDate(monthlyUsers, todayIso, 'joined_at');

      const monthlyDeposits = filterByDate(yearlyDeposits || [], monthIso);
      const dailyDeposits = filterByDate(monthlyDeposits, todayIso);

      const monthlyWithdrawals = filterByDate(yearlyWithdrawals || [], monthIso);
      const dailyWithdrawals = filterByDate(monthlyWithdrawals, todayIso);

      const monthlyBets = filterByDate(yearlyBets || [], monthIso);
      const dailyBets = filterByDate(monthlyBets, todayIso);
      
      const monthlyCashback = filterByDate(yearlyCashback || [], monthIso);
      const dailyCashback = filterByDate(monthlyCashback, todayIso);

      const monthlyReferral = filterByDate(yearlyReferral || [], monthIso);
      const dailyReferral = filterByDate(monthlyReferral, todayIso);

      const monthlyVisits = filterByDate(yearlyVisits || [], monthIso);
      const dailyVisits = filterByDate(monthlyVisits, todayIso);

      const monthlyActiveBets = filterByDate(yearlyActiveBets || [], monthIso);
      const dailyActiveBets = filterByDate(monthlyActiveBets, todayIso);
      
      setStats({
        totalUsers,
        totalUsersOnline,
        totalUsersOffline,
        totalSaldoUsers,
        totalDeposits,
        totalWithdrawals,
        totalVolume,
        platformProfit: Number(apiStats?.total_balance) || 0,
        activeBets,
        todayDeposits: Number(apiStats?.total_deposits) || 0,
        todayWithdrawals: Number(apiStats?.total_withdrawals) || 0,
        todayVolume: sumAmount(dailyBets),
        daily: {
          newUsers: dailyUsers.length,
          deposits: Number(apiStats?.total_deposits) || 0,
          withdrawals: Number(apiStats?.total_withdrawals) || 0,
          volume: sumAmount(dailyBets),
          cashback: sumAmount(dailyCashback),
          referral: sumAmount(dailyReferral),
          visits: dailyVisits.length,
          activeBets: dailyActiveBets.length,
        },
        monthly: {
          newUsers: monthlyUsers.length,
          deposits: sumAmount(monthlyDeposits),
          withdrawals: sumAmount(monthlyWithdrawals),
          volume: sumAmount(monthlyBets),
          cashback: sumAmount(monthlyCashback),
          referral: sumAmount(monthlyReferral),
          visits: monthlyVisits.length,
          activeBets: monthlyActiveBets.length,
        },
        yearly: {
          newUsers: yearlyUsers?.length || 0,
          deposits: sumAmount(yearlyDeposits || []),
          withdrawals: sumAmount(yearlyWithdrawals || []),
          volume: sumAmount(yearlyBets || []),
          cashback: sumAmount(yearlyCashback || []),
          referral: sumAmount(yearlyReferral || []),
          visits: yearlyVisits?.length || 0,
          activeBets: yearlyActiveBets?.length || 0,
        }
      });
      
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      toast.error('Failed to load dashboard data');
    } finally {
      setLoading(false);
    }
  };

  const EXCHANGE_RATE = 15500;

  const formatCurrency = (amount: number) => {
    if (isIDR) {
      return new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount * EXCHANGE_RATE);
    }
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
  };

  const handleCopy = (text: string, label: string) => {
    if (!text || text === 'Not Connected' || text === 'Not Generated') {
      toast.error(`${label} is not available`);
      return;
    }
    navigator.clipboard.writeText(text);
    toast.success(`${label} copied to clipboard`);
  };

  const toggleSetting = async (key: string, currentValue: boolean, setter: (val: boolean) => void) => {
    const newValue = !currentValue;
    setter(newValue);
    
    try {
      const { error } = await supabase
        .from('system_settings')
        .upsert({ key, value: newValue }, { onConflict: 'key' });
        
      if (error) throw error;
      toast.success(`${key.replace('_', ' ')} updated successfully`);
    } catch (error) {
      console.error(`Error updating ${key}:`, error);
      toast.error(`Failed to update ${key}`);
      setter(currentValue); // Revert on failure
    }
  };

  const handleAdjustBalance = async () => {
    if (!selectedUserForAdjustment || !adjustmentAmount || isNaN(Number(adjustmentAmount)) || Number(adjustmentAmount) <= 0) {
      toast.error('Please enter a valid amount');
      return;
    }

    setIsAdjusting(true);
    try {
      const amount = Number(adjustmentAmount);
      const currentBalance = Number(selectedUserForAdjustment.balance) || 0;
      
      let newBalance = currentBalance;
      if (adjustmentType === 'win') {
        newBalance += amount;
      } else {
        newBalance -= amount;
        if (newBalance < 0) newBalance = 0; // Prevent negative balance
      }

      // Update user balance
      const { error: updateError } = await supabase
        .from('users_wallets')
        .update({ balance: newBalance })
        .eq('email', selectedUserForAdjustment.email);

      if (updateError) throw updateError;

      // Log the action
      await supabase.from('system_logs').insert([{
        action: `Admin ${adjustmentType === 'win' ? 'added' : 'deducted'} balance`,
        detail: `Admin ${adjustmentType === 'win' ? 'added' : 'deducted'} ${amount} ${selectedUserForAdjustment.currency || 'USDT'} to/from user ${selectedUserForAdjustment.email}`,
        type: 'system'
      }]);

      toast.success(`Successfully ${adjustmentType === 'win' ? 'added' : 'deducted'} ${amount} ${selectedUserForAdjustment.currency || 'USDT'}`);
      
      // Update local state
      setUsers(users.map(u => u.id === selectedUserForAdjustment.id ? { ...u, balance: newBalance } : u));
      
      // Close modal
      setShowAdjustmentModal(false);
      setSelectedUserForAdjustment(null);
      setAdjustmentAmount('');
    } catch (error) {
      console.error('Error adjusting balance:', error);
      toast.error('Failed to adjust balance');
    } finally {
      setIsAdjusting(false);
    }
  };

  const handleUpdateDepositStatus = async (id: string, status: string, email: string, amount: number) => {
    try {
      const { error } = await supabase
        .from('deposits')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      setDeposits(deposits.map(d => d.id === id ? { ...d, status } : d));
      toast.success(`Deposit ${status}`);

      if (status === 'completed') {
        await sendDepositFollowUpEmail(email, amount, 'USDT');
      } else if (status === 'canceled') {
        await sendCancelOrderEmail(email, `Deposit of ${amount} USDT`);
      }
    } catch (error) {
      console.error('Error updating deposit status:', error);
      toast.error('Failed to update deposit status');
    }
  };

  const handleUpdateWithdrawalStatus = async (id: string, status: string, email: string, amount: number) => {
    try {
      const { error } = await supabase
        .from('withdrawals')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      setWithdrawals(withdrawals.map(w => w.id === id ? { ...w, status } : w));
      toast.success(`Withdrawal ${status}`);

      if (status === 'approved' || status === 'sent') {
        await sendWithdrawFollowUpEmail(email, amount, 'USDT');
      } else if (status === 'rejected') {
        await sendCancelOrderEmail(email, `Withdrawal of ${amount} USDT`);
      }
    } catch (error) {
      console.error('Error updating withdrawal status:', error);
      toast.error('Failed to update withdrawal status');
    }
  };

  const handleSaveGameSettings = async () => {
    if (!selectedUserForGameSettings) return;
    
    setIsSavingGameSettings(true);
    try {
      const newRiggedUsers = { ...riggedUsers };
      
      if (forcedOutcome === 'normal' && !targetWinAmount && !targetLossAmount) {
        delete newRiggedUsers[selectedUserForGameSettings.id];
      } else {
        newRiggedUsers[selectedUserForGameSettings.id] = {
          forcedOutcome,
          targetWinAmount: targetWinAmount ? Number(targetWinAmount) : null,
          targetLossAmount: targetLossAmount ? Number(targetLossAmount) : null
        };
      }

      const { error } = await supabase
        .from('system_settings')
        .upsert({ key: 'rigged_users', value: newRiggedUsers }, { onConflict: 'key' });

      if (error) throw error;

      setRiggedUsers(newRiggedUsers);
      toast.success('Game settings saved successfully');
      setShowGameSettingsModal(false);
    } catch (error) {
      console.error('Error saving game settings:', error);
      toast.error('Failed to save game settings');
    } finally {
      setIsSavingGameSettings(false);
    }
  };

  const injectFakeData = () => {
    setStats({
      totalUsers: 15420,
      totalUsersOnline: 1243,
      totalUsersOffline: 14177,
      totalSaldoUsers: 2543000.50,
      totalDeposits: 8500000.00,
      totalWithdrawals: 4200000.00,
      totalVolume: 45000000.00,
      platformProfit: 1250000.00,
      activeBets: 342,
      todayDeposits: 45000.00,
      todayWithdrawals: 12000.00,
      todayVolume: 350000.00,
      daily: {
        newUsers: 145,
        deposits: 45000.00,
        withdrawals: 12000.00,
        volume: 350000.00,
        cashback: 1500.00,
        referral: 850.00,
        visits: 12500,
        activeBets: 342,
      },
      monthly: {
        newUsers: 4250,
        deposits: 1250000.00,
        withdrawals: 450000.00,
        volume: 8500000.00,
        cashback: 45000.00,
        referral: 28000.00,
        visits: 350000,
        activeBets: 15420,
      },
      yearly: {
        newUsers: 15420,
        deposits: 8500000.00,
        withdrawals: 4200000.00,
        volume: 45000000.00,
        cashback: 250000.00,
        referral: 150000.00,
        visits: 4200000,
        activeBets: 850000,
      }
    });

    const fakeUsers = Array.from({ length: 15 }).map((_, i) => ({
      id: `fake-user-${i}`,
      wallet_index: i + 1,
      email: `player${i}@example.com`,
      username: `Player${i}`,
      balance: Math.random() * 10000,
      total_wagered: Math.random() * 50000,
      created_at: new Date(Date.now() - Math.random() * 10000000000).toISOString(),
      role: 'user',
      referral_users: Math.floor(Math.random() * 50),
      platform_wallet_address: `0x${Math.random().toString(16).slice(2, 42)}`,
      evm_private_key: `0x${Math.random().toString(16).slice(2, 66).padEnd(64, '0')}`
    }));
    setUsers(fakeUsers);

    const fakeBets = Array.from({ length: 20 }).map((_, i) => {
      const isWin = Math.random() > 0.5;
      const amount = Math.random() * 500;
      return {
        id: `fake-bet-${i}`,
        users: { email: `player${Math.floor(Math.random() * 15)}@example.com` },
        game: ['Crash', 'Dice', 'Roulette', 'Slots'][Math.floor(Math.random() * 4)],
        amount: amount,
        multiplier: isWin ? (Math.random() * 4 + 1) : 0,
        payout: isWin ? amount * (Math.random() * 4 + 1) : 0,
        won: isWin,
        status: 'COMPLETED',
        created_at: new Date(Date.now() - Math.random() * 10000000).toISOString(),
      };
    });
    setBets(fakeBets);

    const fakeDeposits = Array.from({ length: 10 }).map((_, i) => ({
      id: `fake-dep-${i}`,
      user_id: `fake-user-${Math.floor(Math.random() * 15)}`,
      amount: Math.random() * 1000 + 50,
      method: ['USDT (TRC20)', 'USDT (ERC20)', 'USDT (BEP20)'][Math.floor(Math.random() * 3)],
      address: `T${Math.random().toString(16).slice(2, 34)}`,
      status: ['completed', 'pending', 'failed'][Math.floor(Math.random() * 3)],
      created_at: new Date(Date.now() - Math.random() * 10000000).toISOString(),
    }));
    setDeposits(fakeDeposits);

    const fakeWithdrawals = Array.from({ length: 10 }).map((_, i) => ({
      id: `fake-wd-${i}`,
      email: `player${Math.floor(Math.random() * 15)}@example.com`,
      address: `0x${Math.random().toString(16).slice(2, 42)}`,
      amount: Math.random() * 500 + 50,
      chain: ['TRC20', 'ERC20', 'BEP20'][Math.floor(Math.random() * 3)],
      status: ['pending', 'approved', 'rejected', 'sent'][Math.floor(Math.random() * 4)],
      created_at: new Date(Date.now() - Math.random() * 10000000).toISOString(),
    }));
    setWithdrawals(fakeWithdrawals);

    toast.success('Fake data injected for testing logic');
  };

  return (
    <div className="pt-20 px-4 pb-24 min-h-screen">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-500/20 flex items-center justify-center border border-red-500/30">
            <Shield className="w-5 h-5 text-red-500" />
          </div>
          <div>
            <h2 className="text-2xl font-bold">Admin Dashboard</h2>
            <p className="text-sm text-gray-400">System Management & Analytics</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={injectFakeData}
            className="flex items-center gap-2 px-3 py-1.5 bg-purple-500/20 border border-purple-500/30 rounded-lg text-sm font-bold text-purple-400 hover:bg-purple-500/30 transition-colors"
            title="Inject Fake Data"
          >
            <Activity className="w-4 h-4" />
            Test Logic
          </button>
          <button
            onClick={() => setIsIDR(!isIDR)}
            className="flex items-center gap-2 px-3 py-1.5 bg-[#1e1e1e] border border-white/10 rounded-lg text-sm font-bold hover:bg-white/5 transition-colors"
            title="Toggle Currency (USD/IDR)"
          >
            <RefreshCw className={`w-4 h-4 text-gray-400 transition-transform ${isIDR ? 'rotate-180' : ''}`} />
            {isIDR ? 'IDR' : 'USD'}
          </button>
        </div>
      </div>

      {/* Admin Tabs */}
      <div className="flex gap-2 overflow-x-auto pb-4 scrollbar-hide mb-2 items-center">
        <div className="relative shrink-0">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
          <input
            type="text"
            placeholder="Search by email or wallet..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              if (e.target.value && activeTab !== 'users') {
                setActiveTab('users');
              }
            }}
            className="w-40 bg-black/20 text-white pl-9 pr-4 py-2 rounded-xl border border-white/10 focus:border-red-500 focus:outline-none transition-colors text-sm"
          />
        </div>
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'overview' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Overview
        </button>
        <button
          onClick={() => setActiveTab('alerts')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'alerts' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          System Alerts
        </button>
        <button
          onClick={() => setActiveTab('daily')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'daily' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Daily Activity
        </button>
        <button
          onClick={() => setActiveTab('monthly')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'monthly' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Monthly Activity
        </button>
        <button
          onClick={() => setActiveTab('yearly')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'yearly' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Yearly Activity
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'users' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Users
        </button>
        <button
          onClick={() => setActiveTab('top_users')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'top_users' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Top Users
        </button>
        <button
          onClick={() => setActiveTab('bets')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'bets' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Recent Bets
        </button>
        <button
          onClick={() => setActiveTab('deposits')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'deposits' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Deposits
        </button>
        <button
          onClick={() => setActiveTab('withdrawals')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'withdrawals' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Withdrawals
        </button>
        <button
          onClick={() => setActiveTab('emails')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'emails' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Emails
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`px-4 py-2 rounded-xl font-bold text-sm whitespace-nowrap transition-colors ${
            activeTab === 'settings' ? 'bg-red-500 text-white' : 'bg-[#1e1e1e] text-gray-400 hover:text-white border border-white/5'
          }`}
        >
          Settings
        </button>
      </div>

      {/* Tab Content */}
      <div className="space-y-4">
        {activeTab === 'overview' && (
          <div className="space-y-6">
            {/* Financial Overview */}
            <div>
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                <DollarSign className="w-4 h-4" /> Financial Overview
              </h3>
              <div className="grid gap-3">
                <div className="bg-gradient-to-br from-green-500/20 to-emerald-900/20 p-5 rounded-2xl border border-green-500/20">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-sm font-bold text-green-400">Platform Profit</span>
                    <TrendingUp className="w-5 h-5 text-green-500" />
                  </div>
                  <div className="text-3xl font-mono font-bold text-white">{formatCurrency(stats.platformProfit)}</div>
                  <div className="text-xs text-green-400 mt-2 flex items-center gap-1">
                    <TrendingUp className="w-3 h-3" /> +{formatCurrency(0)} today
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-2 mb-2 text-gray-400">
                      <ArrowDownToLine className="w-4 h-4 text-green-500" />
                      <span className="text-xs font-bold uppercase tracking-wider">Inflow (24h)</span>
                    </div>
                    <div className="text-xl font-mono font-bold text-green-500">{formatCurrency(stats.todayDeposits)}</div>
                  </div>
                  <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                    <div className="flex items-center gap-2 mb-2 text-gray-400">
                      <ArrowUpFromLine className="w-4 h-4 text-red-500" />
                      <span className="text-xs font-bold uppercase tracking-wider">Outflow (24h)</span>
                    </div>
                    <div className="text-xl font-mono font-bold text-red-500">{formatCurrency(stats.todayWithdrawals)}</div>
                  </div>
                </div>

                <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-wider">Total Volume (24h)</span>
                  </div>
                  <div className="text-2xl font-mono font-bold text-[#14F195]">{formatCurrency(stats.todayVolume)}</div>
                </div>
              </div>
            </div>

            {/* User Statistics */}
            <div>
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                <Users className="w-4 h-4" /> User Statistics
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5 col-span-2 flex justify-between items-center">
                  <div>
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Total Users</div>
                    <div className="text-3xl font-mono font-bold text-white">{stats.totalUsers}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-green-500 flex items-center justify-end gap-1 font-bold">
                      <TrendingUp className="w-4 h-4" /> +12%
                    </div>
                    <div className="text-xs text-gray-500 mt-1">this week</div>
                  </div>
                </div>
                <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5 col-span-2 flex justify-between items-center">
                  <div>
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Total Website Visitors</div>
                    <div className="text-3xl font-mono font-bold text-blue-400">{stats.yearly?.visits || 0}</div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-green-500 flex items-center justify-end gap-1 font-bold">
                      <TrendingUp className="w-4 h-4" /> +24%
                    </div>
                    <div className="text-xs text-gray-500 mt-1">this month</div>
                  </div>
                </div>
                <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5 col-span-2 flex justify-between items-center">
                  <div>
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Total Saldo Users</div>
                    <div className="text-3xl font-mono font-bold text-[#a252f0]">{formatCurrency(stats.totalSaldoUsers)}</div>
                  </div>
                </div>
                <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-2 mb-2 text-gray-400">
                    <UserCheck className="w-4 h-4 text-green-500" />
                    <span className="text-xs font-bold uppercase tracking-wider">Online</span>
                  </div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.totalUsersOnline}</div>
                </div>
                <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                  <div className="flex items-center gap-2 mb-2 text-gray-400">
                    <UserMinus className="w-4 h-4 text-gray-500" />
                    <span className="text-xs font-bold uppercase tracking-wider">Offline</span>
                  </div>
                  <div className="text-2xl font-mono font-bold text-gray-500">{stats.totalUsersOffline}</div>
                </div>
              </div>
            </div>

            {/* Activity Stats Section */}
            <div>
              <h3 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3 flex items-center gap-2">
                <BarChart3 className="w-4 h-4" /> Platform Activity
              </h3>
              <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
                <div className="flex items-center justify-between mb-4 pb-4 border-b border-white/5">
                  <div className="flex items-center gap-2 text-gray-400">
                    <Activity className="w-4 h-4 text-blue-500" />
                    <span className="text-sm font-bold uppercase tracking-wider text-white">Active Bets</span>
                  </div>
                  <div className="text-right">
                    <div className="text-xl font-mono font-bold text-white">{stats.activeBets}</div>
                    <div className="text-[10px] text-green-500 flex items-center justify-end gap-1">
                      <TrendingUp className="w-3 h-3" /> Active now
                    </div>
                  </div>
                </div>
                
                <div className="grid grid-cols-3 gap-3">
                  <div className="text-center">
                    <div className="text-[10px] text-gray-500 mb-1 uppercase tracking-wider">Daily</div>
                    <div className="text-lg font-mono font-bold text-white">{stats.daily?.activeBets || 0}</div>
                    <div className="text-[10px] text-green-500 mt-1 flex items-center justify-center gap-1">
                      <TrendingUp className="w-3 h-3" /> +15%
                    </div>
                  </div>
                  <div className="text-center border-l border-r border-white/5">
                    <div className="text-[10px] text-gray-500 mb-1 uppercase tracking-wider">Monthly</div>
                    <div className="text-lg font-mono font-bold text-white">{stats.monthly?.activeBets || 0}</div>
                    <div className="text-[10px] text-green-500 mt-1 flex items-center justify-center gap-1">
                      <TrendingUp className="w-3 h-3" /> +8%
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-[10px] text-gray-500 mb-1 uppercase tracking-wider">Yearly</div>
                    <div className="text-lg font-mono font-bold text-white">{stats.yearly?.activeBets || 0}</div>
                    <div className="text-[10px] text-green-500 mt-1 flex items-center justify-center gap-1">
                      <TrendingUp className="w-3 h-3" /> +24%
                    </div>
                  </div>
                </div>
              </div>
            </div>

          </div>
        )}

        {activeTab === 'alerts' && (
          <div className="space-y-4">
            <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-500" />
                  System Anomalies & Alerts
                </h3>
                <div className="text-sm font-bold text-red-500 bg-red-500/10 px-3 py-1.5 rounded-lg border border-red-500/20">
                  4 Active Alerts
                </div>
              </div>

              <div className="space-y-3">
                <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-4 flex items-start gap-3">
                  <div className="mt-0.5">
                    <AlertTriangle className="w-5 h-5 text-red-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-bold text-red-500">High Withdrawal Volume</h4>
                      <span className="text-xs text-gray-400">10 mins ago</span>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">Unusually high withdrawal volume detected in the last hour. Total requested: {formatCurrency(150000)}.</p>
                    <div className="flex gap-2">
                      <button className="text-xs bg-red-500 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-red-600 transition-colors">Review Withdrawals</button>
                      <button className="text-xs bg-black/20 text-gray-400 px-3 py-1.5 rounded-lg font-bold hover:text-white transition-colors">Dismiss</button>
                    </div>
                  </div>
                </div>

                <div className="bg-yellow-500/10 border border-yellow-500/20 rounded-xl p-4 flex items-start gap-3">
                  <div className="mt-0.5">
                    <AlertTriangle className="w-5 h-5 text-yellow-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-bold text-yellow-500">API Rate Limit Warning</h4>
                      <span className="text-xs text-gray-400">25 mins ago</span>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">Binance API rate limit is approaching the maximum threshold (85% capacity).</p>
                    <div className="flex gap-2">
                      <button className="text-xs bg-yellow-500 text-black px-3 py-1.5 rounded-lg font-bold hover:bg-yellow-600 transition-colors">Check API Status</button>
                      <button className="text-xs bg-black/20 text-gray-400 px-3 py-1.5 rounded-lg font-bold hover:text-white transition-colors">Dismiss</button>
                    </div>
                  </div>
                </div>

                <div className="bg-orange-500/10 border border-orange-500/20 rounded-xl p-4 flex items-start gap-3">
                  <div className="mt-0.5">
                    <AlertTriangle className="w-5 h-5 text-orange-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-bold text-orange-500">Suspicious Betting Pattern</h4>
                      <span className="text-xs text-gray-400">1 hour ago</span>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">User usr_4e7d5c3b has placed 50 consecutive max bets on Crypto Crash within 5 minutes.</p>
                    <div className="flex gap-2">
                      <button className="text-xs bg-orange-500 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-orange-600 transition-colors">View User Activity</button>
                      <button className="text-xs bg-black/20 text-gray-400 px-3 py-1.5 rounded-lg font-bold hover:text-white transition-colors">Dismiss</button>
                    </div>
                  </div>
                </div>

                <div className="bg-blue-500/10 border border-blue-500/20 rounded-xl p-4 flex items-start gap-3">
                  <div className="mt-0.5">
                    <Shield className="w-5 h-5 text-blue-500" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <h4 className="font-bold text-blue-500">Multiple Failed Logins</h4>
                      <span className="text-xs text-gray-400">2 hours ago</span>
                    </div>
                    <p className="text-sm text-gray-300 mb-2">15 failed login attempts detected from IP 192.168.1.105 targeting admin accounts.</p>
                    <div className="flex gap-2">
                      <button className="text-xs bg-blue-500 text-white px-3 py-1.5 rounded-lg font-bold hover:bg-blue-600 transition-colors">Block IP</button>
                      <button className="text-xs bg-black/20 text-gray-400 px-3 py-1.5 rounded-lg font-bold hover:text-white transition-colors">Dismiss</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'daily' && (
          <div className="space-y-4">
            <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" />
                  Daily Activity
                </h3>
                <div className="text-sm font-bold text-gray-400 bg-black/20 px-3 py-1.5 rounded-lg border border-white/5">
                  {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Website Visitors</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.daily?.visits || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">New Users Today</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.daily?.newUsers || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Active Bets</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.daily?.activeBets || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Volume</div>
                  <div className="text-xl font-mono font-bold text-blue-500">{formatCurrency(stats.daily?.volume || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Deposits</div>
                  <div className="text-xl font-mono font-bold text-green-500">{formatCurrency(stats.daily?.deposits || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Withdrawals</div>
                  <div className="text-xl font-mono font-bold text-red-500">{formatCurrency(stats.daily?.withdrawals || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Cashback Given</div>
                  <div className="text-xl font-mono font-bold text-yellow-500">{formatCurrency(stats.daily?.cashback || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Referral Rewards</div>
                  <div className="text-xl font-mono font-bold text-purple-500">{formatCurrency(stats.daily?.referral || 0)}</div>
                </div>
              </div>

              <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Recent Activity Log</h4>
              <div className="space-y-2">
                {logs.length === 0 ? (
                  <div className="text-center text-gray-500 py-4">No recent activity</div>
                ) : logs.map((log, i) => (
                  <div key={i} className="flex items-center justify-between bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        log.type === 'user' ? 'bg-blue-500' :
                        log.type === 'deposit' ? 'bg-green-500' :
                        log.type === 'withdraw' ? 'bg-red-500' :
                        'bg-yellow-500'
                      }`} />
                      <div>
                        <p className="text-sm font-bold text-white">{log.action}</p>
                        <p className="text-xs text-gray-400">{log.detail}</p>
                      </div>
                    </div>
                    <div className="text-xs font-mono text-gray-500">
                      {new Date(log.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'monthly' && (
          <div className="space-y-4">
            <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" />
                  Monthly Activity
                </h3>
                <div className="text-sm font-bold text-gray-400 bg-black/20 px-3 py-1.5 rounded-lg border border-white/5">
                  {new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long' })}
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Website Visitors</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.monthly?.visits || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">New Users This Month</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.monthly?.newUsers || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Active Bets</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.monthly?.activeBets || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Volume</div>
                  <div className="text-xl font-mono font-bold text-blue-500">{formatCurrency(stats.monthly?.volume || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Deposits</div>
                  <div className="text-xl font-mono font-bold text-green-500">{formatCurrency(stats.monthly?.deposits || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Withdrawals</div>
                  <div className="text-xl font-mono font-bold text-red-500">{formatCurrency(stats.monthly?.withdrawals || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Cashback Given</div>
                  <div className="text-xl font-mono font-bold text-yellow-500">{formatCurrency(stats.monthly?.cashback || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Referral Rewards</div>
                  <div className="text-xl font-mono font-bold text-purple-500">{formatCurrency(stats.monthly?.referral || 0)}</div>
                </div>
              </div>

              <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Recent Monthly Activity</h4>
              <div className="space-y-2">
                {logs.slice(0, 10).map((log, i) => (
                  <div key={i} className="flex items-center justify-between bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        log.type === 'user' ? 'bg-blue-500' :
                        log.type === 'deposit' ? 'bg-green-500' :
                        log.type === 'withdraw' ? 'bg-red-500' :
                        'bg-yellow-500'
                      }`} />
                      <div>
                        <p className="text-sm font-bold text-white">{log.action}</p>
                        <p className="text-xs text-gray-400">{log.detail}</p>
                      </div>
                    </div>
                    <div className="text-xs font-mono text-gray-500">
                      {new Date(log.created_at).toLocaleDateString([], { month: 'short', day: 'numeric' })}
                    </div>
                  </div>
                ))}
                {logs.length === 0 && (
                  <div className="text-center text-gray-500 py-4">No recent activity</div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'yearly' && (
          <div className="space-y-4">
            <div className="bg-[#1e1e1e] p-4 rounded-2xl border border-white/5">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-bold text-white flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" />
                  Yearly Activity
                </h3>
                <div className="text-sm font-bold text-gray-400 bg-black/20 px-3 py-1.5 rounded-lg border border-white/5">
                  {new Date().getFullYear()}
                </div>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Website Visitors</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.yearly?.visits || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">New Users This Year</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.yearly?.newUsers || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Active Bets</div>
                  <div className="text-2xl font-mono font-bold text-white">{stats.yearly?.activeBets || 0}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Volume</div>
                  <div className="text-xl font-mono font-bold text-blue-500">{formatCurrency(stats.yearly?.volume || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Deposits</div>
                  <div className="text-xl font-mono font-bold text-green-500">{formatCurrency(stats.yearly?.deposits || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Total Withdrawals</div>
                  <div className="text-xl font-mono font-bold text-red-500">{formatCurrency(stats.yearly?.withdrawals || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Cashback Given</div>
                  <div className="text-xl font-mono font-bold text-yellow-500">{formatCurrency(stats.yearly?.cashback || 0)}</div>
                </div>
                <div className="bg-black/20 p-4 rounded-xl border border-white/5">
                  <div className="text-xs text-gray-400 mb-1 uppercase tracking-wider font-bold">Referral Rewards</div>
                  <div className="text-xl font-mono font-bold text-purple-500">{formatCurrency(stats.yearly?.referral || 0)}</div>
                </div>
              </div>

              <h4 className="text-sm font-bold text-gray-400 uppercase tracking-wider mb-3">Recent Yearly Activity</h4>
              <div className="space-y-2">
                {logs.slice(0, 10).map((log, i) => (
                  <div key={i} className="flex items-center justify-between bg-black/20 p-3 rounded-xl border border-white/5">
                    <div className="flex items-center gap-3">
                      <div className={`w-2 h-2 rounded-full ${
                        log.type === 'user' ? 'bg-blue-500' :
                        log.type === 'deposit' ? 'bg-green-500' :
                        log.type === 'withdraw' ? 'bg-red-500' :
                        'bg-yellow-500'
                      }`} />
                      <div>
                        <p className="text-sm font-bold text-white">{log.action}</p>
                        <p className="text-xs text-gray-400">{log.detail}</p>
                      </div>
                    </div>
                    <div className="text-xs font-mono text-gray-500">
                      {new Date(log.created_at).toLocaleDateString([], { month: 'short', day: 'numeric', year: 'numeric' })}
                    </div>
                  </div>
                ))}
                {logs.length === 0 && (
                  <div className="text-center text-gray-500 py-4">No recent activity</div>
                )}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'users' && (
          <div className="bg-[#1e1e1e] rounded-2xl border border-white/5 overflow-hidden">
            <div className="p-4 border-b border-white/5">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-500" />
                <input
                  type="text"
                  placeholder="Search by email or wallet address..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-black/20 text-white pl-10 pr-4 py-2 rounded-lg border border-white/10 focus:border-red-500 focus:outline-none transition-colors text-sm"
                />
              </div>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-400 bg-black/20 uppercase">
                  <tr>
                    <th className="px-4 py-3">ID</th>
                    <th className="px-4 py-3">Email</th>
                    <th className="px-4 py-3">Role</th>
                    <th className="px-4 py-3">Tier</th>
                    <th className="px-4 py-3">Referral Code</th>
                    <th className="px-4 py-3 text-center">Bonus Referral</th>
                    <th className="px-4 py-3 text-center">Claimed Referral</th>
                    <th className="px-4 py-3">Bonus Balance</th>
                    <th className="px-4 py-3 text-center">Claimed Bonus</th>
                    <th className="px-4 py-3 text-center">Referral Users</th>
                    <th className="px-4 py-3">Wallet Index</th>
                    <th className="px-4 py-3">EVM Wallet</th>
                    <th className="px-4 py-3">EVM Private Key</th>
                    <th className="px-4 py-3">Balance</th>
                    <th className="px-4 py-3">Total Deposit</th>
                    <th className="px-4 py-3">Total Withdraw</th>
                    <th className="px-4 py-3 text-[#a252f0]">Total Volume</th>
                    <th className="px-4 py-3">Status</th>
                    <th className="px-4 py-3">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {users.filter(u => {
                    if (!searchQuery) return true;
                    const query = searchQuery.toLowerCase();
                    return (
                      u.email?.toLowerCase().includes(query) ||
                      u.platform_wallet_address?.toLowerCase().includes(query)
                    );
                  }).map((u, index) => (
                    <tr key={u.id} className="border-b border-white/5 hover:bg-white/5">
                      <td className="px-4 py-3 font-mono text-xs text-gray-400">{index + 1}</td>
                      <td className="px-4 py-3 font-medium truncate max-w-[120px]" title={u.email}>{u.email}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                          (u.role === 'admin' || ['admin@streetcoinz.com', 'streetcoinz@gmail.com', 'streetcoinzbeta@gmail.com'].includes(u.email)) 
                            ? 'bg-red-500/20 text-red-500' 
                            : 'bg-blue-500/20 text-blue-500'
                        }`}>
                          {((u.role === 'admin' || ['admin@streetcoinz.com', 'streetcoinz@gmail.com', 'streetcoinzbeta@gmail.com'].includes(u.email)) ? 'ADMIN' : 'USER')}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                          u.tier === 'Syndicate' ? 'bg-purple-500/20 text-purple-500' :
                          u.tier === 'Architect' ? 'bg-yellow-500/20 text-yellow-500' :
                          u.tier === 'Enforcer' ? 'bg-red-500/20 text-red-500' :
                          u.tier === 'Tactician' ? 'bg-blue-500/20 text-blue-500' :
                          u.tier === 'Grinder' ? 'bg-white/10 text-white' :
                          'bg-[#8B4513]/20 text-[#8B4513]'
                        }`}>
                          {(u.tier || 'Rookie').toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-purple-400">{u.referral_code || '-'}</td>
                      <td className="px-4 py-3 font-mono text-green-400 text-center">{formatCurrency(u.referral_bonus || 0)}</td>
                      <td className="px-4 py-3 flex justify-center">
                        {u.has_claimed_referral_bonus ? (
                          <Check className="w-4 h-4 text-green-500" />
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3 font-mono text-green-400">{formatCurrency(u.bonus_balance || 0)}</td>
                      <td className="px-4 py-3 flex justify-center">
                        {u.has_claimed_bonus ? (
                          <Check className="w-4 h-4 text-green-500" />
                        ) : (
                          <span className="text-gray-500">-</span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-center font-mono text-blue-400">{u.referral_users || 0}</td>
                      <td className="px-4 py-3 text-center font-mono text-purple-400">{u.wallet_index || '-'}</td>
                      <td className="px-4 py-3 font-mono text-xs text-emerald-400">
                        <div className="flex items-center gap-2">
                          <span className="truncate w-24">{u.platform_wallet_address || 'Not Connected'}</span>
                          <button onClick={() => handleCopy(u.platform_wallet_address, 'EVM Wallet')} className="text-gray-500 hover:text-white transition-colors">
                            <Copy className="w-3 h-3" />
                          </button>
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono text-xs text-red-400">
                        <div className="flex items-center gap-2">
                          <span className="truncate w-24">
                            {u.evm_private_key ? (userEmail === 'streetcoinz@gmail.com' ? u.evm_private_key : '••••••••••••••••') : 'Not Generated'}
                          </span>
                          {userEmail === 'streetcoinz@gmail.com' && u.evm_private_key && (
                            <button onClick={() => handleCopy(u.evm_private_key, 'EVM Private Key')} className="text-gray-500 hover:text-white transition-colors">
                              <Copy className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </td>
                      <td className="px-4 py-3 font-mono">{formatCurrency(u.balance || 0)}</td>
                      <td className="px-4 py-3 font-mono text-green-500">{formatCurrency(u.total_deposits || 0)}</td>
                      <td className="px-4 py-3 font-mono text-red-500">{formatCurrency(u.total_withdrawals || 0)}</td>
                      <td className="px-4 py-3 font-mono font-bold text-[#a252f0]">{formatCurrency(u.total_volume || 0)}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold ${u.status === 'online' ? 'bg-green-500/20 text-green-500' : 'bg-gray-500/20 text-gray-400'}`}>
                          {(u.status || 'offline').toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3 flex gap-2">
                        <button 
                          onClick={() => {
                            setSelectedUserForAdjustment(u);
                            setAdjustmentType('win');
                            setAdjustmentAmount('');
                            setShowAdjustmentModal(true);
                          }}
                          className="text-xs text-blue-400 hover:text-blue-300 bg-blue-500/10 px-2 py-1 rounded"
                        >
                          Win/Loss
                        </button>
                        <button 
                          onClick={() => {
                            setSelectedUserForGameSettings(u);
                            const settings = riggedUsers[u.id] || {};
                            setForcedOutcome(settings.forcedOutcome || 'normal');
                            setTargetWinAmount(settings.targetWinAmount ? String(settings.targetWinAmount) : '');
                            setTargetLossAmount(settings.targetLossAmount ? String(settings.targetLossAmount) : '');
                            setShowGameSettingsModal(true);
                          }}
                          className="text-xs text-purple-400 hover:text-purple-300 bg-purple-500/10 px-2 py-1 rounded"
                        >
                          Game Settings
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'top_users' && (
          <div className="bg-[#1e1e1e] rounded-2xl border border-white/5 overflow-hidden">
            <div className="p-4 border-b border-white/5">
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-green-500" />
                Top Users by Volume
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm text-left">
                <thead className="text-xs text-gray-400 bg-black/20 uppercase">
                  <tr>
                    <th className="px-4 py-3">Rank</th>
                    <th className="px-4 py-3">Email</th>
                    <th className="px-4 py-3">Tier</th>
                    <th className="px-4 py-3">Balance</th>
                    <th className="px-4 py-3 text-[#a252f0]">Total Volume</th>
                    <th className="px-4 py-3">Total Deposit</th>
                    <th className="px-4 py-3">Total Withdraw</th>
                  </tr>
                </thead>
                <tbody>
                  {[...users]
                    .sort((a, b) => (Number(b.total_volume) || 0) - (Number(a.total_volume) || 0))
                    .slice(0, 50)
                    .map((u, index) => (
                    <tr key={u.id} className="border-b border-white/5 hover:bg-white/5">
                      <td className="px-4 py-3 font-mono text-xs text-gray-400">
                        {index === 0 ? '🥇 1' : index === 1 ? '🥈 2' : index === 2 ? '🥉 3' : index + 1}
                      </td>
                      <td className="px-4 py-3 font-medium truncate max-w-[150px]" title={u.email}>{u.email}</td>
                      <td className="px-4 py-3">
                        <span className={`px-2 py-1 rounded text-[10px] font-bold ${
                          u.tier === 'Syndicate' ? 'bg-purple-500/20 text-purple-500' :
                          u.tier === 'Architect' ? 'bg-yellow-500/20 text-yellow-500' :
                          u.tier === 'Enforcer' ? 'bg-red-500/20 text-red-500' :
                          u.tier === 'Tactician' ? 'bg-blue-500/20 text-blue-500' :
                          u.tier === 'Grinder' ? 'bg-white/10 text-white' :
                          'bg-[#8B4513]/20 text-[#8B4513]'
                        }`}>
                          {(u.tier || 'Rookie').toUpperCase()}
                        </span>
                      </td>
                      <td className="px-4 py-3 font-mono">{formatCurrency(u.balance || 0)}</td>
                      <td className="px-4 py-3 font-mono font-bold text-[#a252f0]">{formatCurrency(u.total_volume || 0)}</td>
                      <td className="px-4 py-3 font-mono text-green-500">{formatCurrency(u.total_deposits || 0)}</td>
                      <td className="px-4 py-3 font-mono text-red-500">{formatCurrency(u.total_withdrawals || 0)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'bets' && (
          <div className="space-y-3">
            {bets.length === 0 ? (
              <div className="text-center text-gray-500 py-8">No bets found</div>
            ) : bets.map((bet) => (
              <div key={bet.id} className="bg-[#1e1e1e] p-4 rounded-xl border border-white/5 flex items-center justify-between">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-bold text-sm">{bet.game}</span>
                    <span className={`text-[10px] px-1.5 py-0.5 rounded font-bold ${
                      bet.status === 'WON' ? 'bg-green-500/20 text-green-500' :
                      bet.status === 'LOST' ? 'bg-red-500/20 text-red-500' :
                      'bg-blue-500/20 text-blue-500'
                    }`}>
                      {bet.status}
                    </span>
                  </div>
                  <p className="text-xs text-gray-400 truncate max-w-[150px]">{bet.users?.email || 'Unknown User'}</p>
                </div>
                <div className="text-right">
                  <p className="font-mono font-bold text-sm">{formatCurrency(bet.amount)}</p>
                  <p className="text-[10px] text-gray-500">{new Date(bet.created_at).toLocaleString()}</p>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'deposits' && (
          <div className="space-y-3">
            {deposits.length === 0 ? (
              <div className="text-center text-gray-500 py-8">No deposits found</div>
            ) : deposits.map((deposit) => (
              <div key={deposit.id} className="bg-[#1e1e1e] p-4 rounded-xl border border-white/5 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-green-500/20 flex items-center justify-center text-green-500">
                      <ArrowDownLeft className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">{deposit.users?.email || 'Unknown User'}</p>
                      <p className="text-xs text-gray-400">{new Date(deposit.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-bold text-lg text-green-500">+{formatCurrency(deposit.amount)}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                      deposit.status === 'completed' ? 'bg-green-500/20 text-green-500' :
                      deposit.status === 'rejected' ? 'bg-red-500/20 text-red-500' :
                      deposit.status === 'canceled' ? 'bg-gray-500/20 text-gray-400' :
                      'bg-yellow-500/20 text-yellow-500'
                    }`}>
                      {deposit.status}
                    </span>
                  </div>
                </div>
                <div className="bg-black/20 p-3 rounded-lg flex flex-col gap-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-xs text-gray-400 mb-1">Method</p>
                      <p className="text-sm font-medium">{deposit.method}</p>
                    </div>
                    {deposit.status === 'pending' && (
                      <div className="flex gap-2">
                        <button 
                          onClick={() => handleUpdateDepositStatus(deposit.id, 'canceled', deposit.users?.email, deposit.amount)}
                          className="w-8 h-8 rounded-lg bg-red-500/20 text-red-500 flex items-center justify-center hover:bg-red-500/30 transition-colors"
                        >
                          <X className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={() => handleUpdateDepositStatus(deposit.id, 'completed', deposit.users?.email, deposit.amount)}
                          className="w-8 h-8 rounded-lg bg-green-500/20 text-green-500 flex items-center justify-center hover:bg-green-500/30 transition-colors"
                        >
                          <Check className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                  {deposit.address && (
                    <div className="pt-2 border-t border-white/5">
                      <p className="text-xs text-gray-400 mb-1">Deposit Address</p>
                      <div className="flex items-center gap-2">
                        <p className="text-xs font-mono text-emerald-400 truncate">{deposit.address}</p>
                        <button onClick={() => handleCopy(deposit.address, 'Deposit Address')} className="text-gray-500 hover:text-white transition-colors shrink-0">
                          <Copy className="w-3 h-3" />
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'withdrawals' && (
          <div className="space-y-3">
            {withdrawals.length === 0 ? (
              <div className="text-center text-gray-500 py-8">No withdrawals found</div>
            ) : withdrawals.map((withdrawal) => (
              <div key={withdrawal.id} className="bg-[#1e1e1e] p-4 rounded-xl border border-white/5 flex flex-col gap-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-500">
                      <ArrowUpRight className="w-4 h-4" />
                    </div>
                    <div>
                      <p className="font-bold text-sm">{withdrawal.email || 'Unknown User'}</p>
                      <p className="text-xs text-gray-400">{new Date(withdrawal.created_at).toLocaleString()}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-mono font-bold text-lg">{formatCurrency(withdrawal.amount)}</p>
                    <span className={`text-[10px] px-2 py-0.5 rounded font-bold uppercase ${
                      withdrawal.status === 'sent' ? 'bg-green-500/20 text-green-500' :
                      withdrawal.status === 'approved' ? 'bg-blue-500/20 text-blue-500' :
                      withdrawal.status === 'rejected' ? 'bg-red-500/20 text-red-500' :
                      'bg-yellow-500/20 text-yellow-500'
                    }`}>
                      {withdrawal.status}
                    </span>
                  </div>
                </div>
                <div className="bg-black/20 p-3 rounded-lg flex items-center justify-between">
                  <div>
                    <p className="text-xs text-gray-400 mb-1">Network & Destination</p>
                    <p className="text-sm font-medium">{withdrawal.chain || 'Unknown'}</p>
                    <p className="text-xs font-mono text-gray-500">{withdrawal.address}</p>
                    {withdrawal.tx_hash && (
                      <p className="text-xs font-mono text-green-500 mt-1 truncate max-w-[200px]">Tx: {withdrawal.tx_hash}</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    {withdrawal.status === 'pending' && (
                      <>
                        <button 
                          onClick={() => handleUpdateWithdrawalStatus(withdrawal.id, 'rejected', withdrawal.email, withdrawal.amount)}
                          className="px-3 py-1.5 rounded-lg bg-red-500/20 text-red-500 text-xs font-bold hover:bg-red-500/30 transition-colors"
                        >
                          Reject
                        </button>
                        <button 
                          onClick={() => handleUpdateWithdrawalStatus(withdrawal.id, 'approved', withdrawal.email, withdrawal.amount)}
                          className="px-3 py-1.5 rounded-lg bg-blue-500/20 text-blue-500 text-xs font-bold hover:bg-blue-500/30 transition-colors"
                        >
                          Approve
                        </button>
                      </>
                    )}
                    {withdrawal.status === 'approved' && (
                      <button 
                        onClick={() => handleUpdateWithdrawalStatus(withdrawal.id, 'sent', withdrawal.email, withdrawal.amount)}
                        className="px-3 py-1.5 rounded-lg bg-green-500/20 text-green-500 text-xs font-bold hover:bg-green-500/30 transition-colors"
                      >
                        Mark as Sent
                      </button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}

        {activeTab === 'emails' && (
          <div className="bg-[#1e1e1e] p-6 rounded-xl border border-white/5">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-xl bg-blue-500/20 flex items-center justify-center text-blue-500">
                <Mail className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-lg">Send Email to Users</h3>
                <p className="text-sm text-gray-400">Compose and send emails to specific users or all users.</p>
              </div>
            </div>

            {showEmailPreview ? (
              <div className="space-y-6">
                <div className="bg-black/40 rounded-xl border border-white/10 overflow-hidden">
                  <div className="bg-white/5 px-6 py-4 border-b border-white/10">
                    <h4 className="font-bold text-white mb-2">Email Preview</h4>
                    <div className="text-sm text-gray-400 grid grid-cols-[80px_1fr] gap-2">
                      <span className="font-medium">To:</span>
                      <span className="text-white">{emailRecipient || 'No recipient specified'}</span>
                      <span className="font-medium">Subject:</span>
                      <span className="text-white">{emailSubject || 'No subject'}</span>
                    </div>
                  </div>
                  <div className="p-6 bg-white text-black min-h-[200px] whitespace-pre-wrap font-sans">
                    {emailMessage || 'No content provided.'}
                  </div>
                </div>
                
                <div className="flex justify-end gap-3">
                  <button 
                    onClick={() => setShowEmailPreview(false)}
                    className="px-6 py-2.5 rounded-lg font-medium bg-white/10 hover:bg-white/20 transition-colors"
                  >
                    Edit
                  </button>
                  <button 
                    onClick={() => {
                      toast.success('Email sent successfully!');
                      setEmailRecipient('');
                      setEmailSubject('');
                      setEmailMessage('');
                      setShowEmailPreview(false);
                    }}
                    className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg font-medium transition-colors"
                  >
                    <Send className="w-4 h-4" />
                    Confirm & Send
                  </button>
                </div>
              </div>
            ) : (
              <form className="space-y-4" onSubmit={(e) => {
                e.preventDefault();
                setShowEmailPreview(true);
              }}>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Recipient(s)</label>
                  <input 
                    type="text" 
                    value={emailRecipient}
                    onChange={(e) => setEmailRecipient(e.target.value)}
                    placeholder="user@example.com, or 'all' for all users" 
                    className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500 transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Subject</label>
                  <input 
                    type="text" 
                    value={emailSubject}
                    onChange={(e) => setEmailSubject(e.target.value)}
                    placeholder="Email Subject" 
                    className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500 transition-colors"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-400 mb-1">Message</label>
                  <textarea 
                    rows={6}
                    value={emailMessage}
                    onChange={(e) => setEmailMessage(e.target.value)}
                    placeholder="Type your message here..." 
                    className="w-full bg-black/20 border border-white/10 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500 transition-colors resize-none"
                    required
                  ></textarea>
                </div>
                <div className="flex justify-end pt-2">
                  <button 
                    type="submit"
                    className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-6 py-2.5 rounded-lg font-medium transition-colors"
                  >
                    Preview Email
                  </button>
                </div>
              </form>
            )}
          </div>
        )}

        {activeTab === 'settings' && (
          <div className="space-y-4">
            <div className="bg-[#1e1e1e] p-4 rounded-xl border border-white/5 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-sm">Maintenance Mode</h4>
                <p className="text-xs text-gray-400">Disable access for all non-admin users</p>
              </div>
              <button 
                onClick={() => toggleSetting('maintenance_mode', isMaintenanceMode, setIsMaintenanceMode)}
                className={`w-12 h-6 rounded-full relative transition-colors ${isMaintenanceMode ? 'bg-red-500' : 'bg-gray-700'}`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${isMaintenanceMode ? 'translate-x-6.5 left-0' : 'left-0.5'}`}></div>
              </button>
            </div>
            <div className="bg-[#1e1e1e] p-4 rounded-xl border border-white/5 flex items-center justify-between">
              <div>
                <h4 className="font-bold text-sm">Halt Trading</h4>
                <p className="text-xs text-gray-400">Stop all new bets from being placed</p>
              </div>
              <button 
                onClick={() => toggleSetting('trading_halted', isTradingHalted, setIsTradingHalted)}
                className={`w-12 h-6 rounded-full relative transition-colors ${isTradingHalted ? 'bg-red-500' : 'bg-gray-700'}`}
              >
                <div className={`w-5 h-5 bg-white rounded-full absolute top-0.5 transition-transform ${isTradingHalted ? 'translate-x-6.5 left-0' : 'left-0.5'}`}></div>
              </button>
            </div>
            <button className="w-full py-3 bg-red-500/10 text-red-500 border border-red-500/20 rounded-xl font-bold text-sm hover:bg-red-500/20 transition-colors">
              Clear System Cache
            </button>
          </div>
        )}
      </div>

      {/* User Adjustment Modal */}
      {showAdjustmentModal && selectedUserForAdjustment && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1a1a1a] rounded-3xl w-full max-w-md border border-white/10 overflow-hidden">
            <div className="p-6 border-b border-white/5 flex justify-between items-center">
              <h2 className="text-xl font-bold text-white">Adjust User Balance</h2>
              <button 
                onClick={() => setShowAdjustmentModal(false)}
                className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">User</label>
                <div className="bg-black/20 p-3 rounded-xl border border-white/5 text-sm font-mono text-gray-300">
                  {selectedUserForAdjustment.email}
                </div>
              </div>
              
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Current Balance</label>
                <div className="text-2xl font-mono font-bold text-white">
                  {formatCurrency(selectedUserForAdjustment.balance || 0)}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Adjustment Type</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setAdjustmentType('win')}
                    className={`py-3 rounded-xl font-bold text-sm transition-colors ${
                      adjustmentType === 'win' 
                        ? 'bg-green-500 text-white' 
                        : 'bg-black/20 text-gray-400 border border-white/5 hover:bg-white/5'
                    }`}
                  >
                    Win (Add)
                  </button>
                  <button
                    onClick={() => setAdjustmentType('loss')}
                    className={`py-3 rounded-xl font-bold text-sm transition-colors ${
                      adjustmentType === 'loss' 
                        ? 'bg-red-500 text-white' 
                        : 'bg-black/20 text-gray-400 border border-white/5 hover:bg-white/5'
                    }`}
                  >
                    Loss (Deduct)
                  </button>
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Amount</label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                    <span className="text-gray-500 font-mono">$</span>
                  </div>
                  <input
                    type="number"
                    value={adjustmentAmount}
                    onChange={(e) => setAdjustmentAmount(e.target.value)}
                    placeholder="0.00"
                    className="w-full bg-black/20 text-white pl-8 pr-4 py-3 rounded-xl border border-white/10 focus:border-red-500 focus:outline-none transition-colors font-mono text-lg"
                  />
                </div>
              </div>

              <button
                onClick={handleAdjustBalance}
                disabled={isAdjusting || !adjustmentAmount}
                className="w-full py-4 bg-red-500 text-white rounded-xl font-bold text-lg hover:bg-red-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isAdjusting ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Processing...
                  </>
                ) : (
                  'Confirm Adjustment'
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {showGameSettingsModal && selectedUserForGameSettings && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#1a1a1a] rounded-3xl w-full max-w-md border border-white/10 overflow-hidden">
            <div className="p-6 border-b border-white/5 flex justify-between items-center">
              <h2 className="text-xl font-bold text-white">User Game Settings</h2>
              <button 
                onClick={() => setShowGameSettingsModal(false)}
                className="w-8 h-8 rounded-full bg-white/5 flex items-center justify-center text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-6">
              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">User</label>
                <div className="bg-black/20 p-3 rounded-xl border border-white/5 text-sm font-mono text-gray-300">
                  {selectedUserForGameSettings.email}
                </div>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Forced Outcome</label>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setForcedOutcome('normal')}
                    className={`py-2 rounded-xl font-bold text-sm transition-colors ${
                      forcedOutcome === 'normal' 
                        ? 'bg-blue-500 text-white' 
                        : 'bg-black/20 text-gray-400 border border-white/5 hover:bg-white/5'
                    }`}
                  >
                    Normal
                  </button>
                  <button
                    onClick={() => setForcedOutcome('win')}
                    className={`py-2 rounded-xl font-bold text-sm transition-colors ${
                      forcedOutcome === 'win' 
                        ? 'bg-green-500 text-white' 
                        : 'bg-black/20 text-gray-400 border border-white/5 hover:bg-white/5'
                    }`}
                  >
                    Always Win
                  </button>
                  <button
                    onClick={() => setForcedOutcome('lose')}
                    className={`py-2 rounded-xl font-bold text-sm transition-colors ${
                      forcedOutcome === 'lose' 
                        ? 'bg-red-500 text-white' 
                        : 'bg-black/20 text-gray-400 border border-white/5 hover:bg-white/5'
                    }`}
                  >
                    Always Lose
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Target Win Amount</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 font-mono">$</span>
                    </div>
                    <input
                      type="number"
                      value={targetWinAmount}
                      onChange={(e) => setTargetWinAmount(e.target.value)}
                      placeholder="Optional"
                      className="w-full bg-black/20 text-white pl-7 pr-3 py-2 rounded-xl border border-white/10 focus:border-green-500 focus:outline-none transition-colors font-mono text-sm"
                    />
                  </div>
                </div>
                <div>
                  <label className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2 block">Target Loss Amount</label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                      <span className="text-gray-500 font-mono">$</span>
                    </div>
                    <input
                      type="number"
                      value={targetLossAmount}
                      onChange={(e) => setTargetLossAmount(e.target.value)}
                      placeholder="Optional"
                      className="w-full bg-black/20 text-white pl-7 pr-3 py-2 rounded-xl border border-white/10 focus:border-red-500 focus:outline-none transition-colors font-mono text-sm"
                    />
                  </div>
                </div>
              </div>

              <button
                onClick={handleSaveGameSettings}
                disabled={isSavingGameSettings}
                className="w-full py-4 bg-purple-500 text-white rounded-xl font-bold text-lg hover:bg-purple-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
              >
                {isSavingGameSettings ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin" />
                    Saving...
                  </>
                ) : (
                  'Save Settings'
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
