import { motion } from 'motion/react';
import { GameCard } from './GameCard';
import { Flame, Star, Zap } from 'lucide-react';

const GAMES = [
  {
    id: 1,
    title: 'Neon Nights',
    provider: 'Pragmatic Play',
    image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000&auto=format&fit=crop',
    tag: 'Hot',
  },
  {
    id: 2,
    title: 'Cyberpunk Roulette',
    provider: 'Evolution',
    image: 'https://images.unsplash.com/photo-1606167668584-78701c57f13d?q=80&w=1000&auto=format&fit=crop',
    tag: 'Live',
  },
  {
    id: 3,
    title: 'Golden Vault',
    provider: 'Hacksaw Gaming',
    image: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000&auto=format&fit=crop',
  },
  {
    id: 4,
    title: 'Street Blackjack',
    provider: 'Evolution',
    image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=1000&auto=format&fit=crop',
    tag: 'Live',
  },
  {
    id: 5,
    title: 'Crypto Crash',
    provider: 'Originals',
    image: 'https://images.unsplash.com/photo-1621504450181-5d156f0653e7?q=80&w=1000&auto=format&fit=crop',
    tag: 'New',
  },
  {
    id: 6,
    title: 'Neon Dice',
    provider: 'Originals',
    image: 'https://images.unsplash.com/photo-1516567727245-ad8c68f3ca93?q=80&w=1000&auto=format&fit=crop',
  },
];

export function GameLobby() {
  const categories = [
    { id: 'all', label: 'All Games', icon: Star },
    { id: 'slots', label: 'Slots', icon: Zap },
    { id: 'live', label: 'Live Casino', icon: Flame },
  ];

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-8">
        <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide">
          {categories.map((cat, i) => (
            <button
              key={cat.id}
              className={`
                flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-bold transition-all whitespace-nowrap
                ${i === 0 
                  ? 'bg-yellow-500 text-black' 
                  : 'bg-[#141417] text-zinc-400 hover:text-white hover:bg-white/10 border border-white/5'}
              `}
            >
              <cat.icon size={16} />
              {cat.label}
            </button>
          ))}
        </div>
        
        <div className="hidden md:flex gap-2">
          <button className="text-sm font-bold text-zinc-400 hover:text-white transition-colors">
            View All
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4 lg:gap-6">
        {GAMES.map((game, i) => (
          <GameCard
            key={game.id}
            title={game.title}
            provider={game.provider}
            image={game.image}
            isNew={game.tag === 'NEW'}
            isHot={game.tag === 'HOT'}
          />
        ))}
      </div>
    </div>
  );
}
