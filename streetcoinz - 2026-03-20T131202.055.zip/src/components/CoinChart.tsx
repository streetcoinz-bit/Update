import { useEffect, useState } from 'react';
import { HistoryData } from '../types';
import {
  Area,
  AreaChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { format } from 'date-fns';

interface CoinChartProps {
  coinId: string;
  coinName: string;
}

export default function CoinChart({ coinId, coinName }: CoinChartProps) {
  const [data, setData] = useState<HistoryData[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;
    const fetchHistory = async () => {
      setLoading(true);
      setError(null);
      try {
        // Fetch last 30 days of data
        const end = Date.now();
        const start = end - 30 * 24 * 60 * 60 * 1000;
        const res = await fetch(
          `https://api.coincap.io/v2/assets/${coinId}/history?interval=d1&start=${start}&end=${end}`
        );
        if (!res.ok) throw new Error('Failed to fetch history');
        const json = await res.json();
        if (isMounted) {
          setData(json.data);
        }
      } catch (err: any) {
        if (isMounted) setError(err.message);
      } finally {
        if (isMounted) setLoading(false);
      }
    };

    fetchHistory();
    return () => {
      isMounted = false;
    };
  }, [coinId]);

  if (loading) {
    return (
      <div className="h-64 w-full flex items-center justify-center border border-gallery-white/20">
        <span className="font-mono text-neon-green animate-pulse">LOADING_DATA...</span>
      </div>
    );
  }

  if (error) {
    return (
      <div className="h-64 w-full flex items-center justify-center border border-red-500">
        <span className="font-mono text-red-500">ERROR: {error}</span>
      </div>
    );
  }

  const chartData = data.map((d) => ({
    time: d.time,
    price: parseFloat(d.priceUsd),
    date: format(new Date(d.time), 'MMM dd'),
  }));

  const minPrice = Math.min(...chartData.map((d) => d.price));
  const maxPrice = Math.max(...chartData.map((d) => d.price));

  return (
    <div className="w-full h-64 border border-gallery-white p-4 relative bg-brutal-black">
      <div className="absolute top-4 left-4 z-10">
        <h3 className="font-display text-2xl uppercase tracking-wider">{coinName} / 30D</h3>
      </div>
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={chartData}>
          <defs>
            <linearGradient id="colorPrice" x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor="var(--color-neon-green)" stopOpacity={0.3} />
              <stop offset="95%" stopColor="var(--color-neon-green)" stopOpacity={0} />
            </linearGradient>
          </defs>
          <XAxis 
            dataKey="date" 
            hide 
          />
          <YAxis 
            domain={[minPrice * 0.95, maxPrice * 1.05]} 
            hide 
          />
          <Tooltip
            content={({ active, payload }) => {
              if (active && payload && payload.length) {
                return (
                  <div className="bg-gallery-white text-brutal-black p-2 border-2 border-brutal-black font-mono text-sm">
                    <p className="font-bold">{payload[0].payload.date}</p>
                    <p>${payload[0].value?.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
                  </div>
                );
              }
              return null;
            }}
          />
          <Area
            type="monotone"
            dataKey="price"
            stroke="var(--color-neon-green)"
            strokeWidth={2}
            fillOpacity={1}
            fill="url(#colorPrice)"
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
