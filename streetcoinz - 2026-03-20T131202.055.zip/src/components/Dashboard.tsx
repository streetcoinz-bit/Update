import React, { useEffect, useState } from "react";
import { getTopCoins, Coin } from "../services/cryptoApi";
import { formatCurrency, formatCompactNumber, formatPercentage, cn } from "../lib/utils";
import { ArrowUpRight, ArrowDownRight, TrendingUp, Activity, DollarSign, BarChart3 } from "lucide-react";
import { AreaChart, Area, ResponsiveContainer, YAxis } from "recharts";

export default function Dashboard() {
  const [coins, setCoins] = useState<Coin[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function fetchData() {
      const data = await getTopCoins(1, 20);
      setCoins(data);
      setLoading(false);
    }
    fetchData();
    
    // Refresh every 60 seconds
    const interval = setInterval(fetchData, 60000);
    return () => clearInterval(interval);
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-full">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
      </div>
    );
  }

  const topGainers = [...coins].sort((a, b) => b.price_change_percentage_24h - a.price_change_percentage_24h).slice(0, 3);

  return (
    <div className="space-y-6 pb-20 md:pb-0">
      <div>
        <h1 className="text-2xl font-bold tracking-tight mb-1">Market Overview</h1>
        <p className="text-text-muted text-sm">Track the top cryptocurrencies by market cap.</p>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard 
          title="Global Market Cap" 
          value="$2.45T" 
          change={2.4} 
          icon={DollarSign} 
        />
        <StatCard 
          title="24h Volume" 
          value="$84.2B" 
          change={-1.2} 
          icon={BarChart3} 
        />
        <StatCard 
          title="BTC Dominance" 
          value="52.4%" 
          change={0.1} 
          icon={Activity} 
        />
        <StatCard 
          title="Top Gainer (24h)" 
          value={topGainers[0]?.symbol.toUpperCase() || "N/A"} 
          change={topGainers[0]?.price_change_percentage_24h || 0} 
          icon={TrendingUp} 
        />
      </div>

      {/* Main Table */}
      <div className="bg-surface border border-border rounded-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm text-left">
            <thead className="text-xs text-text-muted uppercase bg-surface-hover/50 border-b border-border">
              <tr>
                <th className="px-6 py-4 font-medium">Asset</th>
                <th className="px-6 py-4 font-medium text-right">Price</th>
                <th className="px-6 py-4 font-medium text-right">24h Change</th>
                <th className="px-6 py-4 font-medium text-right hidden md:table-cell">Market Cap</th>
                <th className="px-6 py-4 font-medium text-right hidden lg:table-cell">Volume (24h)</th>
                <th className="px-6 py-4 font-medium text-right hidden sm:table-cell">Last 7 Days</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {coins.map((coin) => (
                <tr key={coin.id} className="hover:bg-surface-hover/50 transition-colors group cursor-pointer">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <img src={coin.image} alt={coin.name} className="w-8 h-8 rounded-full" />
                      <div>
                        <div className="font-medium text-text-main">{coin.name}</div>
                        <div className="text-xs text-text-muted uppercase">{coin.symbol}</div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono">
                    {formatCurrency(coin.current_price)}
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className={cn(
                      "inline-flex items-center gap-1 font-medium",
                      coin.price_change_percentage_24h >= 0 ? "text-success" : "text-danger"
                    )}>
                      {coin.price_change_percentage_24h >= 0 ? (
                        <ArrowUpRight className="w-3 h-3" />
                      ) : (
                        <ArrowDownRight className="w-3 h-3" />
                      )}
                      {Math.abs(coin.price_change_percentage_24h).toFixed(2)}%
                    </div>
                  </td>
                  <td className="px-6 py-4 text-right font-mono text-text-muted hidden md:table-cell">
                    ${formatCompactNumber(coin.market_cap)}
                  </td>
                  <td className="px-6 py-4 text-right font-mono text-text-muted hidden lg:table-cell">
                    ${formatCompactNumber(coin.total_volume)}
                  </td>
                  <td className="px-6 py-4 hidden sm:table-cell w-32">
                    <div className="h-10 w-full">
                      {coin.sparkline_in_7d && (
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={coin.sparkline_in_7d.price.map((p, i) => ({ price: p, index: i }))}>
                            <YAxis domain={['dataMin', 'dataMax']} hide />
                            <Area 
                              type="monotone" 
                              dataKey="price" 
                              stroke={coin.price_change_percentage_24h >= 0 ? "var(--color-success)" : "var(--color-danger)"} 
                              fill="transparent" 
                              strokeWidth={1.5}
                              isAnimationActive={false}
                            />
                          </AreaChart>
                        </ResponsiveContainer>
                      )}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

function StatCard({ title, value, change, icon: Icon }: { title: string, value: string, change: number, icon: any }) {
  const isPositive = change >= 0;
  
  return (
    <div className="bg-surface border border-border rounded-xl p-5 flex flex-col gap-3">
      <div className="flex justify-between items-start">
        <p className="text-sm text-text-muted font-medium">{title}</p>
        <div className="p-2 bg-surface-hover rounded-lg text-text-muted">
          <Icon className="w-4 h-4" />
        </div>
      </div>
      <div>
        <h3 className="text-2xl font-bold font-mono">{value}</h3>
        <div className={cn(
          "flex items-center gap-1 text-sm mt-1",
          isPositive ? "text-success" : "text-danger"
        )}>
          {isPositive ? <ArrowUpRight className="w-3 h-3" /> : <ArrowDownRight className="w-3 h-3" />}
          <span>{Math.abs(change).toFixed(2)}%</span>
          <span className="text-text-muted ml-1">vs last 24h</span>
        </div>
      </div>
    </div>
  );
}
