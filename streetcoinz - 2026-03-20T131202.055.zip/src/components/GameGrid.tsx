import React from 'react';
import { Flame, Sparkles, MonitorPlay, Play, Star, ChevronRight } from 'lucide-react';

interface GameGridProps {
  title: string;
  icon: 'flame' | 'sparkles' | 'monitor-play';
}

export function GameGrid({ title, icon }: GameGridProps) {
  const IconComponent = {
    flame: Flame,
    sparkles: Sparkles,
    'monitor-play': MonitorPlay,
  }[icon];

  const games = [
    { id: 1, title: 'Neon Nights', provider: 'NetEnt', image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=600&auto=format&fit=crop', tag: 'Hot' },
    { id: 2, title: 'Cyber City', provider: 'Pragmatic', image: 'https://images.unsplash.com/photo-1614027164847-1b28cfe1df60?q=80&w=600&auto=format&fit=crop', tag: 'New' },
    { id: 3, title: 'Street Dice', provider: 'StreetCoinz Games', image: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Dice.jpg', tag: '' },
    { id: 4, title: 'Crypto Crash', provider: 'StreetCoinz Games', image: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Crash.jpg', tag: 'Trending' },
    { id: 5, title: 'Midnight Run', provider: 'Hacksaw', image: 'https://images.unsplash.com/photo-1555680202-c86f0e12f086?q=80&w=600&auto=format&fit=crop', tag: 'Hot' },
    { id: 6, title: 'Neon Roulette', provider: 'Evolution', image: 'https://images.unsplash.com/photo-1605806616949-1e87b487cb2a?q=80&w=600&auto=format&fit=crop', tag: 'Live' },
    { id: 7, title: 'Synthwave Slots', provider: 'NetEnt', image: 'https://images.unsplash.com/photo-1511512578047-dfb367046420?q=80&w=600&auto=format&fit=crop', tag: '' },
    { id: 8, title: 'Jackpot City', provider: 'Microgaming', image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?q=80&w=600&auto=format&fit=crop', tag: 'Jackpot' },
  ];

  return (
    <section className="space-y-4">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-[var(--color-bg-surface)] flex items-center justify-center border border-white/5">
            <IconComponent className="w-5 h-5 text-emerald-500" />
          </div>
          <h2 className="text-2xl font-display font-bold text-white tracking-tight">{title}</h2>
        </div>
        <button className="flex items-center gap-1 text-sm font-medium text-zinc-400 hover:text-emerald-400 transition-colors">
          View All
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {games.map((game, i) => (
          <div key={i} className="group relative rounded-2xl overflow-hidden bg-[var(--color-bg-surface)] border border-white/5 cursor-pointer hover:border-emerald-500/50 transition-all duration-300">
            
            {/* Image Container */}
            <div className="aspect-[3/4] relative overflow-hidden">
              <img 
                src={game.image} 
                alt={game.title} 
                className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-500"
                referrerPolicy="no-referrer"
              />
              
              {/* Overlay */}
              <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col items-center justify-center gap-4">
                <div className="w-14 h-14 rounded-full bg-emerald-500 flex items-center justify-center text-zinc-950 transform scale-50 group-hover:scale-100 transition-transform duration-300 delay-75">
                  <Play className="w-6 h-6 ml-1" fill="currentColor" />
                </div>
                <button className="text-white hover:text-emerald-400 text-sm font-medium flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity duration-300 delay-150">
                  <Star className="w-4 h-4" /> Favorite
                </button>
              </div>

              {/* Tags */}
              {game.tag && (
                <div className="absolute top-2 right-2 px-2 py-1 rounded-md bg-emerald-500 text-zinc-950 text-[10px] font-bold uppercase tracking-wider">
                  {game.tag}
                </div>
              )}
            </div>

            {/* Info */}
            <div className="p-3 bg-gradient-to-t from-[var(--color-bg-surface)] to-transparent absolute bottom-0 inset-x-0">
              <p className="font-display font-bold text-white text-sm truncate">{game.title}</p>
              <p className="text-xs truncate">
                {game.provider === 'StreetCoinz Games' ? (
                  <span className="text-[#a252f0] font-bold">{game.provider}</span>
                ) : (
                  <span className="text-zinc-400">{game.provider}</span>
                )}
              </p>
            </div>

          </div>
        ))}
      </div>
    </section>
  );
}
