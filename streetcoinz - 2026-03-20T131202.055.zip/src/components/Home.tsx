import React from 'react';
import { motion } from 'motion/react';
import { Zap, Coins, ArrowRight, Trophy, Users, ShieldCheck } from 'lucide-react';

interface HomeProps {
  onNavigate: (view: string) => void;
}

export function Home({ onNavigate }: HomeProps) {
  return (
    <div className="space-y-8 pb-12">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-zinc-900 to-zinc-950 border border-zinc-800 p-8 md:p-12">
        <div className="absolute top-0 right-0 w-1/2 h-full bg-emerald-500/10 blur-[100px] pointer-events-none"></div>
        <div className="absolute bottom-0 left-0 w-1/2 h-full bg-purple-500/10 blur-[100px] pointer-events-none"></div>
        
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm font-bold mb-6">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            LIVE MULTIPLAYER CASINO
          </div>
          <h1 className="text-5xl md:text-7xl font-black tracking-tighter text-white leading-[1.1] mb-6">
            RULE THE <br/>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-emerald-600">STREETS.</span>
          </h1>
          <p className="text-lg text-zinc-400 mb-8 max-w-xl">
            The most authentic urban casino experience. Provably fair games, instant payouts, and high-stakes action.
          </p>
          <div className="flex flex-wrap gap-4">
            <button 
              onClick={() => onNavigate('slots')}
              className="bg-emerald-500 hover:bg-emerald-400 text-zinc-950 px-8 py-4 rounded-xl font-black tracking-wide transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] flex items-center gap-2"
            >
              PLAY NOW <ArrowRight className="w-5 h-5" />
            </button>
            <button className="bg-zinc-800 hover:bg-zinc-700 text-white px-8 py-4 rounded-xl font-bold tracking-wide transition-all border border-zinc-700">
              VIP PROGRAM
            </button>
          </div>
        </div>
      </div>

      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: 'Total Payouts', value: '$2.4M+', icon: Trophy, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
          { label: 'Active Players', value: '12,403', icon: Users, color: 'text-blue-500', bg: 'bg-blue-500/10' },
          { label: 'Provably Fair', value: '100%', icon: ShieldCheck, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
        ].map((stat, i) => (
          <div key={i} className="bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex items-center gap-4">
            <div className={`w-12 h-12 rounded-xl ${stat.bg} flex items-center justify-center`}>
              <stat.icon className={`w-6 h-6 ${stat.color}`} />
            </div>
            <div>
              <div className="text-2xl font-black text-white">{stat.value}</div>
              <div className="text-sm font-bold text-zinc-500 uppercase tracking-wider">{stat.label}</div>
            </div>
          </div>
        ))}
      </div>

      {/* Games Grid */}
      <div>
        <h2 className="text-2xl font-black tracking-tight text-white mb-6 flex items-center gap-2">
          FEATURED GAMES
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Slots Card */}
          <motion.div 
            whileHover={{ y: -5 }}
            onClick={() => onNavigate('slots')}
            className="group cursor-pointer bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative"
          >
            <div className="h-48 bg-gradient-to-br from-zinc-800 to-zinc-950 relative overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/casino/800/400')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
              <Zap className="w-24 h-24 text-emerald-500 opacity-50 group-hover:scale-110 transition-transform duration-500" />
            </div>
            <div className="p-6 relative">
              <div className="absolute top-0 right-6 -translate-y-1/2 bg-emerald-500 text-zinc-950 text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider">
                Hot
              </div>
              <h3 className="text-2xl font-black text-white mb-2">Neon Slots</h3>
              <p className="text-zinc-400 text-sm mb-4">Classic 3-reel action with a modern cyberpunk twist. Win up to 50x your bet!</p>
              <div className="flex items-center text-emerald-400 font-bold text-sm group-hover:translate-x-2 transition-transform">
                Play Now <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </div>
          </motion.div>

          {/* Coin Flip Card */}
          <motion.div 
            whileHover={{ y: -5 }}
            onClick={() => onNavigate('coinflip')}
            className="group cursor-pointer bg-zinc-900 border border-zinc-800 rounded-3xl overflow-hidden relative"
          >
            <div className="h-48 bg-gradient-to-br from-zinc-800 to-zinc-950 relative overflow-hidden flex items-center justify-center">
              <div className="absolute inset-0 bg-[url('https://picsum.photos/seed/coins/800/400')] opacity-20 bg-cover bg-center mix-blend-overlay"></div>
              <Coins className="w-24 h-24 text-yellow-500 opacity-50 group-hover:scale-110 transition-transform duration-500" />
            </div>
            <div className="p-6 relative">
              <h3 className="text-2xl font-black text-white mb-2">Street Flip</h3>
              <p className="text-zinc-400 text-sm mb-4">Pure 50/50 odds. Double your money instantly in this high-stakes coin flip.</p>
              <div className="flex items-center text-yellow-500 font-bold text-sm group-hover:translate-x-2 transition-transform">
                Play Now <ArrowRight className="w-4 h-4 ml-1" />
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
