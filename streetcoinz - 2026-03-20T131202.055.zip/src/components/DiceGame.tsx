import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Dices, AlertCircle } from 'lucide-react';

interface DiceGameProps {
  balance: number;
  updateBalance: (newBalance: number) => void;
}

export function DiceGame({ balance, updateBalance }: DiceGameProps) {
  const [betAmount, setBetAmount] = useState<number>(10);
  const [multiplier, setMultiplier] = useState<number>(2.0);
  const [isRolling, setIsRolling] = useState(false);
  const [lastResult, setLastResult] = useState<{ won: boolean; roll: number; payout: number } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const winChance = (99 / multiplier).toFixed(2);

  const handleRoll = async () => {
    if (betAmount > balance) {
      setError("Insufficient funds");
      return;
    }
    if (betAmount <= 0 || multiplier <= 1) {
      setError("Invalid bet parameters");
      return;
    }

    setError(null);
    setIsRolling(true);
    setLastResult(null);

    try {
      const response = await fetch('/api/games/dice', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ betAmount, multiplier }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to roll');
      }

      // Simulate rolling animation delay
      setTimeout(() => {
        setLastResult({ won: data.won, roll: data.roll, payout: data.payout });
        updateBalance(data.newBalance);
        setIsRolling(false);
      }, 600);
    } catch (err: any) {
      setError(err.message);
      setIsRolling(false);
    }
  };

  return (
    <div className="p-6 lg:p-10 max-w-5xl mx-auto w-full">
      <div className="flex items-center gap-4 mb-8">
        <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-neon-yellow to-orange-500 flex items-center justify-center shadow-lg">
          <Dices size={24} className="text-street-950" />
        </div>
        <div>
          <h1 className="text-3xl font-display font-bold">Neon Dice</h1>
          <p className="text-gray-400 text-sm">Roll under the target to win.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Controls Panel */}
        <div className="lg:col-span-1 bg-street-900 border border-white/5 rounded-2xl p-6 flex flex-col gap-6">
          
          {/* Bet Amount */}
          <div>
            <div className="flex justify-between items-center mb-2">
              <label className="text-xs font-mono text-gray-400 uppercase tracking-wider">Bet Amount</label>
              <span className="text-xs font-mono text-neon-yellow">${balance.toFixed(2)}</span>
            </div>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                <span className="text-gray-500 font-bold">$</span>
              </div>
              <input
                type="number"
                value={betAmount}
                onChange={(e) => setBetAmount(Number(e.target.value))}
                className="w-full bg-street-950 border border-white/10 rounded-xl py-3 pl-8 pr-4 text-white font-mono focus:outline-none focus:border-neon-yellow transition-colors"
                min="0.01"
                step="0.01"
              />
              <div className="absolute inset-y-0 right-1 flex items-center gap-1">
                <button onClick={() => setBetAmount(balance / 2)} className="bg-white/5 hover:bg-white/10 text-xs font-bold px-2 py-1.5 rounded text-gray-300">1/2</button>
                <button onClick={() => setBetAmount(balance)} className="bg-white/5 hover:bg-white/10 text-xs font-bold px-2 py-1.5 rounded text-gray-300">MAX</button>
              </div>
            </div>
          </div>

          {/* Multiplier */}
          <div>
            <label className="text-xs font-mono text-gray-400 uppercase tracking-wider mb-2 block">Multiplier</label>
            <div className="relative">
              <input
                type="number"
                value={multiplier}
                onChange={(e) => setMultiplier(Number(e.target.value))}
                className="w-full bg-street-950 border border-white/10 rounded-xl py-3 px-4 text-white font-mono focus:outline-none focus:border-neon-yellow transition-colors"
                min="1.01"
                step="0.01"
              />
              <div className="absolute inset-y-0 right-4 flex items-center pointer-events-none">
                <span className="text-gray-500 font-bold">x</span>
              </div>
            </div>
          </div>

          {/* Win Chance */}
          <div className="bg-street-950 border border-white/5 rounded-xl p-4 flex justify-between items-center">
            <span className="text-sm text-gray-400">Win Chance</span>
            <span className="font-mono font-bold text-neon-green">{winChance}%</span>
          </div>

          {/* Profit on Win */}
          <div className="bg-street-950 border border-white/5 rounded-xl p-4 flex justify-between items-center">
            <span className="text-sm text-gray-400">Profit on Win</span>
            <span className="font-mono font-bold text-neon-yellow">+${(betAmount * (multiplier - 1)).toFixed(2)}</span>
          </div>

          {error && (
            <div className="flex items-center gap-2 text-red-500 text-sm bg-red-500/10 p-3 rounded-lg">
              <AlertCircle size={16} />
              <span>{error}</span>
            </div>
          )}

          <button
            onClick={handleRoll}
            disabled={isRolling || betAmount > balance || betAmount <= 0}
            className={`
              w-full py-4 rounded-xl font-display font-bold text-lg uppercase tracking-wider transition-all
              ${isRolling 
                ? 'bg-street-800 text-gray-500 cursor-not-allowed' 
                : 'bg-neon-yellow text-street-950 hover:bg-yellow-400 hover:shadow-[0_0_20px_rgba(250,204,21,0.3)]'}
            `}
          >
            {isRolling ? 'Rolling...' : 'Roll Dice'}
          </button>
        </div>

        {/* Game Display Panel */}
        <div className="lg:col-span-2 bg-street-900 border border-white/5 rounded-2xl p-6 flex flex-col items-center justify-center min-h-[400px] relative overflow-hidden">
          {/* Decorative background grid */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff05_1px,transparent_1px),linear-gradient(to_bottom,#ffffff05_1px,transparent_1px)] bg-[size:40px_40px]" />
          
          <div className="relative z-10 w-full max-w-md">
            {/* Slider track */}
            <div className="h-4 bg-street-950 rounded-full w-full relative overflow-hidden border border-white/10">
              <div 
                className="absolute top-0 bottom-0 left-0 bg-neon-green/20"
                style={{ width: `${winChance}%` }}
              />
              <div 
                className="absolute top-0 bottom-0 right-0 bg-red-500/20"
                style={{ width: `${100 - Number(winChance)}%` }}
              />
            </div>
            
            <div className="flex justify-between mt-2 text-xs font-mono text-gray-500">
              <span>0</span>
              <span>{winChance}</span>
              <span>100</span>
            </div>

            {/* Result Display */}
            <div className="mt-16 text-center h-40 flex flex-col items-center justify-center">
              {isRolling ? (
                <motion.div
                  animate={{ rotate: 360 }}
                  transition={{ repeat: Infinity, duration: 0.5, ease: "linear" }}
                >
                  <Dices size={64} className="text-neon-yellow opacity-50" />
                </motion.div>
              ) : lastResult ? (
                <motion.div
                  initial={{ scale: 0.5, opacity: 0 }}
                  animate={{ scale: 1, opacity: 1 }}
                  className="flex flex-col items-center"
                >
                  <span className={`text-6xl font-mono font-bold mb-4 ${lastResult.won ? 'text-neon-green' : 'text-red-500'}`}>
                    {lastResult.roll.toFixed(2)}
                  </span>
                  {lastResult.won ? (
                    <div className="bg-neon-green/10 text-neon-green border border-neon-green/20 px-6 py-2 rounded-full font-bold flex items-center gap-2">
                      <span>YOU WON</span>
                      <span className="font-mono">${lastResult.payout.toFixed(2)}</span>
                    </div>
                  ) : (
                    <div className="bg-red-500/10 text-red-500 border border-red-500/20 px-6 py-2 rounded-full font-bold">
                      YOU LOST
                    </div>
                  )}
                </motion.div>
              ) : (
                <div className="text-gray-500 font-display text-xl">
                  Place your bet to start
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
