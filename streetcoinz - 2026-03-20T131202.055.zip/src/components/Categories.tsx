import { motion } from 'motion/react';
import { Gamepad2, Coins, Dice5, Zap, Trophy, Flame } from 'lucide-react';

const categories = [
  { name: 'Slots', icon: Coins, color: 'text-yellow-500', bg: 'bg-yellow-500/10' },
  { name: 'Live Casino', icon: Zap, color: 'text-red-500', bg: 'bg-red-500/10' },
  { name: 'Table Games', icon: Dice5, color: 'text-blue-500', bg: 'bg-blue-500/10' },
  { name: 'Crash', icon: Flame, color: 'text-orange-500', bg: 'bg-orange-500/10' },
  { name: 'Originals', icon: Gamepad2, color: 'text-emerald-500', bg: 'bg-emerald-500/10' },
  { name: 'Tournaments', icon: Trophy, color: 'text-purple-500', bg: 'bg-purple-500/10' },
];

export default function Categories() {
  return (
    <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {categories.map((category, index) => {
          const Icon = category.icon;
          return (
            <motion.button
              key={category.name}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.1 }}
              className="group relative flex flex-col items-center justify-center gap-3 overflow-hidden rounded-2xl border border-zinc-800 bg-zinc-900/50 p-6 transition-all hover:border-zinc-700 hover:bg-zinc-800"
            >
              <div className={`rounded-xl p-3 transition-transform group-hover:scale-110 ${category.bg}`}>
                <Icon className={`h-8 w-8 ${category.color}`} />
              </div>
              <span className="text-sm font-semibold tracking-wide text-zinc-300 group-hover:text-white">
                {category.name}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
