import { motion } from 'motion/react';
import { Users, Radio } from 'lucide-react';

const liveGames = [
  { id: 1, title: 'Lightning Roulette', dealer: 'Sarah', players: 1240, image: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81?q=80&w=800&auto=format&fit=crop' },
  { id: 2, title: 'Crazy Time', dealer: 'Mike', players: 3500, image: 'https://images.unsplash.com/photo-1596838132731-3301c3fd4317?q=80&w=800&auto=format&fit=crop' },
  { id: 3, title: 'Street Blackjack', dealer: 'Elena', players: 450, image: 'https://images.unsplash.com/photo-1511193311914-0346f16efe90?q=80&w=800&auto=format&fit=crop' },
  { id: 4, title: 'Mega Baccarat', dealer: 'David', players: 890, image: 'https://images.unsplash.com/photo-1595859703010-38148b813a04?q=80&w=800&auto=format&fit=crop' },
];

export function LiveCasino() {
  return (
    <section className="w-full mt-24">
      <div className="flex items-center justify-between mb-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-red-500/10 border border-red-500/20 flex items-center justify-center text-red-500">
            <Radio size={20} className="animate-pulse" />
          </div>
          <h2 className="text-2xl font-display font-bold">Live Casino</h2>
        </div>
        <button className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
          View All
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {liveGames.map((game, i) => (
          <motion.div
            key={game.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: i * 0.1 }}
            className="group relative aspect-video rounded-2xl overflow-hidden bg-street-surface border border-street-border cursor-pointer"
          >
            <img 
              src={game.image} 
              alt={game.title} 
              className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
              referrerPolicy="no-referrer"
            />
            
            <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-90" />
            
            {/* Live Badge */}
            <div className="absolute top-3 left-3 flex items-center gap-2">
              <span className="bg-red-500 text-white text-[10px] font-bold px-2 py-1 rounded-md flex items-center gap-1 uppercase tracking-wider">
                <span className="w-1.5 h-1.5 bg-white rounded-full animate-pulse"></span>
                Live
              </span>
              <span className="bg-black/50 backdrop-blur-md text-white text-[10px] font-bold px-2 py-1 rounded-md flex items-center gap-1">
                <Users size={12} /> {game.players}
              </span>
            </div>

            {/* Game Info */}
            <div className="absolute bottom-0 left-0 right-0 p-4">
              <h3 className="text-white font-display font-bold text-lg leading-tight mb-1">
                {game.title}
              </h3>
              <p className="text-zinc-400 text-xs font-medium">
                Dealer: <span className="text-white">{game.dealer}</span>
              </p>
            </div>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
