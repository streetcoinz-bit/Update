import React from 'react';
import { Gamepad2, MonitorPlay, Spade, Dice1, Trophy, Star, Flame, Zap } from 'lucide-react';

export function CategoryNav() {
  const categories = [
    { icon: Flame, label: 'Hot', active: true },
    { icon: Zap, label: 'New Releases' },
    { icon: Gamepad2, label: 'Slots' },
    { icon: MonitorPlay, label: 'Live Casino' },
    { icon: Spade, label: 'Table Games' },
    { icon: Dice1, label: 'Crash Games' },
    { icon: Trophy, label: 'Tournaments' },
    { icon: Star, label: 'Favorites' },
  ];

  return (
    <div className="flex items-center gap-3 overflow-x-auto pb-4 scrollbar-hide -mx-4 px-4 sm:mx-0 sm:px-0">
      {categories.map((category, i) => (
        <button
          key={i}
          className={`flex items-center gap-2 px-5 py-3 rounded-xl whitespace-nowrap transition-all border ${
            category.active
              ? 'bg-emerald-500 text-zinc-950 border-emerald-400 font-semibold shadow-[0_0_15px_rgba(16,185,129,0.3)]'
              : 'bg-[var(--color-bg-surface)] text-zinc-400 border-white/5 hover:bg-white/5 hover:text-white hover:border-white/10 font-medium'
          }`}
        >
          <category.icon className={`w-4 h-4 ${category.active ? 'text-zinc-950' : 'text-zinc-500'}`} />
          {category.label}
        </button>
      ))}
    </div>
  );
}
