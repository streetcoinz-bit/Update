import React, { useState } from 'react';
import { motion } from 'motion/react';
import { DollarSign, ArrowUp, ArrowDown, Wallet } from 'lucide-react';

interface MobileBetControlsProps {
  balance: number;
  onPlaceBet: (amount: number, direction: 'UP' | 'DOWN') => void;
  minBet?: number;
  maxBet?: number;
}

export const MobileBetControls: React.FC<MobileBetControlsProps> = ({ balance, onPlaceBet, minBet = 1, maxBet = 10000 }) => {
  const [betAmount, setBetAmount] = useState<string>('10.00');

  const handleQuickAmount = (multiplier: number) => {
    const current = parseFloat(betAmount) || 0;
    setBetAmount((current * multiplier).toFixed(2));
  };

  const handlePlaceBet = (direction: 'UP' | 'DOWN') => {
    const amount = parseFloat(betAmount);
    if (isNaN(amount) || amount < minBet || amount > maxBet || amount > balance) {
      return;
    }
    onPlaceBet(amount, direction);
  };

  return (
    <div className="bg-[#141414] border-t border-white/5 p-4 pb-8 space-y-4">
      {/* Wallet Info */}
      <div className="flex items-center justify-between text-xs font-mono text-zinc-500">
        <div className="flex items-center gap-1">
          <Wallet className="w-3 h-3" />
          <span>Balance: {balance.toLocaleString()} SC</span>
        </div>
        <div className="flex items-center gap-1">
          <span>Max: {maxBet.toLocaleString()} SC</span>
        </div>
      </div>

      {/* Bet Input */}
      <div className="flex items-center gap-2">
        <div className="flex-1 bg-[#09090b] border border-white/10 rounded-xl p-1 flex items-center">
          <div className="px-3 text-zinc-500 font-mono text-sm">SC</div>
          <input
            type="number"
            value={betAmount}
            onChange={(e) => setBetAmount(e.target.value)}
            className="flex-1 bg-transparent text-white font-mono font-bold text-right outline-none py-3 pr-2 text-lg"
          />
        </div>
        <div className="flex flex-col gap-1">
          <button
            onClick={() => handleQuickAmount(0.5)}
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[10px] font-bold text-zinc-400 transition-colors"
          >
            1/2
          </button>
          <button
            onClick={() => handleQuickAmount(2)}
            className="px-3 py-1.5 rounded-lg bg-white/5 hover:bg-white/10 text-[10px] font-bold text-zinc-400 transition-colors"
          >
            2x
          </button>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="grid grid-cols-2 gap-3">
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => handlePlaceBet('UP')}
          className="bg-emerald-500 hover:bg-emerald-400 text-black font-bold py-4 rounded-2xl flex flex-col items-center justify-center gap-1 shadow-[0_0_20px_rgba(16,185,129,0.2)]"
        >
          <ArrowUp className="w-6 h-6" />
          <span className="text-xs uppercase tracking-widest">Predict UP</span>
        </motion.button>
        <motion.button
          whileTap={{ scale: 0.95 }}
          onClick={() => handlePlaceBet('DOWN')}
          className="bg-red-500 hover:bg-red-400 text-white font-bold py-4 rounded-2xl flex flex-col items-center justify-center gap-1 shadow-[0_0_20px_rgba(239,68,68,0.2)]"
        >
          <ArrowDown className="w-6 h-6" />
          <span className="text-xs uppercase tracking-widest">Predict DOWN</span>
        </motion.button>
      </div>
    </div>
  );
};
