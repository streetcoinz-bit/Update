import { Trophy, TrendingUp } from 'lucide-react';

const WINNERS = [
  { user: 'CryptoKing99', game: 'Neon Nights', amount: '12,450.00 SCZ' },
  { user: 'LuckyStar', game: 'Live Blackjack', amount: '3,200.50 SCZ' },
  { user: 'HighRollerX', game: 'Mega Moolah', amount: '85,000.00 SCZ' },
  { user: 'StreetBoss', game: 'Crypto Crash', amount: '1,500.00 SCZ' },
  { user: 'NeonRider', game: 'Cyber Roulette', amount: '4,800.25 SCZ' },
  { user: 'GoldenBoy', game: 'Golden Vault', amount: '22,100.00 SCZ' },
];

export function WinnersTicker() {
  return (
    <div className="w-full bg-casino-surface border-y border-casino-border py-3 mb-12 flex items-center">
      <div className="px-6 flex items-center gap-3 border-r border-casino-border shrink-0">
        <Trophy size={18} className="text-casino-accent" />
        <span className="text-sm font-bold uppercase tracking-wider text-gray-300">Latest Wins</span>
      </div>
      
      <div className="marquee-container flex-1">
        <div className="marquee-content gap-12 px-6">
          {/* Duplicate array for seamless loop */}
          {[...WINNERS, ...WINNERS].map((winner, idx) => (
            <div key={idx} className="flex items-center gap-4 shrink-0">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 rounded-full bg-casino-bg border border-casino-border flex items-center justify-center">
                  <TrendingUp size={12} className="text-green-400" />
                </div>
                <span className="text-sm font-medium text-gray-300">{winner.user}</span>
              </div>
              <span className="text-xs text-gray-500">in</span>
              <span className="text-sm font-medium text-casino-neon">{winner.game}</span>
              <span className="text-sm font-mono font-bold text-casino-accent">{winner.amount}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
