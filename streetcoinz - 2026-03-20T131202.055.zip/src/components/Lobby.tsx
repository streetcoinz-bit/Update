import React from 'react';
import { motion } from 'motion/react';
import { Dices, TrendingUp, Play, Star } from 'lucide-react';

interface LobbyProps {
  onSelectGame: (game: string) => void;
}

export function Lobby({ onSelectGame }: LobbyProps) {
  const games = [
    {
      id: 'dice',
      title: 'Neon Dice',
      description: 'Roll the dice and multiply your Coinz.',
      icon: Dices,
      color: 'from-neon-yellow to-orange-500',
      bg: 'bg-street-900',
      popular: true,
    },
    {
      id: 'crash',
      title: 'Street Crash',
      description: 'Cash out before the multiplier crashes.',
      icon: TrendingUp,
      color: 'from-neon-green to-emerald-600',
      bg: 'bg-street-900',
      popular: true,
    },
  ];

  return (
    <div className="p-6 lg:p-10 max-w-7xl mx-auto w-full">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-12"
      >
        <h1 className="text-4xl lg:text-5xl font-display font-bold mb-4 tracking-tight">
          Welcome to the <span className="text-transparent bg-clip-text bg-gradient-to-r from-neon-yellow to-neon-purple">Streets</span>
        </h1>
        <p className="text-gray-400 text-lg max-w-2xl">
          Play provably fair games, multiply your Coinz, and climb the leaderboard.
          The house edge is low, but the stakes are high.
        </p>
      </motion.div>

      <div className="flex items-center gap-3 mb-6">
        <Star className="text-neon-yellow" size={24} />
        <h2 className="text-2xl font-display font-semibold">Featured Games</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {games.map((game, index) => {
          const Icon = game.icon;
          return (
            <motion.div
              key={game.id}
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -5, scale: 1.02 }}
              onClick={() => onSelectGame(game.id)}
              className={`${game.bg} border border-white/5 rounded-2xl p-6 cursor-pointer group relative overflow-hidden`}
            >
              {/* Background Glow */}
              <div className={`absolute -inset-20 bg-gradient-to-tr ${game.color} opacity-0 group-hover:opacity-10 blur-3xl transition-opacity duration-500`} />
              
              <div className="relative z-10">
                <div className="flex justify-between items-start mb-6">
                  <div className={`w-14 h-14 rounded-xl bg-gradient-to-br ${game.color} flex items-center justify-center shadow-lg`}>
                    <Icon size={28} className="text-street-950" />
                  </div>
                  {game.popular && (
                    <span className="bg-white/10 text-xs font-bold px-3 py-1 rounded-full text-gray-300 backdrop-blur-md">
                      HOT
                    </span>
                  )}
                </div>
                
                <h3 className="text-2xl font-display font-bold mb-2 group-hover:text-white transition-colors">
                  {game.title}
                </h3>
                <p className="text-gray-400 text-sm mb-8 line-clamp-2">
                  {game.description}
                </p>

                <div className="flex items-center justify-between">
                  <span className="text-xs font-mono text-gray-500 uppercase tracking-wider">
                    Provably Fair
                  </span>
                  <button className="flex items-center gap-2 bg-white/5 hover:bg-white/10 text-white px-4 py-2 rounded-lg font-medium transition-colors">
                    <Play size={16} className="text-neon-yellow" />
                    Play Now
                  </button>
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
