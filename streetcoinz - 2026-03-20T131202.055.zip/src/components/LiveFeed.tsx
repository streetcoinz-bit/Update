import React, { useEffect, useState } from 'react';

type Bet = {
  id: string;
  game: string;
  user: string;
  time: string;
  betAmount: number;
  multiplier: number;
  payout: number;
};

const generateRandomBet = (): Bet => {
  const games = ['Sweet Bonanza', 'Gates of Olympus', 'Crazy Time', 'Lightning Roulette', 'Book of Dead', 'Plinko', 'Dice', 'Mines'];
  const isWin = Math.random() > 0.6;
  const betAmount = Number((Math.random() * 100 + 1).toFixed(2));
  const multiplier = isWin ? Number((Math.random() * 10 + 1.1).toFixed(2)) : 0;
  
  return {
    id: Math.random().toString(36).substring(7),
    game: games[Math.floor(Math.random() * games.length)],
    user: `Anonim`,
    time: new Date().toLocaleTimeString([], { hour12: false }),
    betAmount,
    multiplier,
    payout: isWin ? Number((betAmount * multiplier).toFixed(2)) : 0,
  };
};

export function LiveFeed() {
  const [bets, setBets] = useState<Bet[]>([]);

  useEffect(() => {
    // Initial bets
    setBets(Array.from({ length: 8 }, generateRandomBet));

    // Add new bet every 2 seconds
    const interval = setInterval(() => {
      setBets(prev => [generateRandomBet(), ...prev].slice(0, 8));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="bg-zinc-900 rounded-2xl border border-zinc-800 overflow-hidden">
      <div className="overflow-x-auto">
        <table className="w-full text-sm text-left">
          <thead className="text-xs text-zinc-400 uppercase bg-zinc-950/50 border-b border-zinc-800">
            <tr>
              <th className="px-6 py-4 font-medium">Game</th>
              <th className="px-6 py-4 font-medium">User</th>
              <th className="px-6 py-4 font-medium">Time</th>
              <th className="px-6 py-4 font-medium text-right">Bet Amount</th>
              <th className="px-6 py-4 font-medium text-right">Multiplier</th>
              <th className="px-6 py-4 font-medium text-right">Payout</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-zinc-800/50">
            {bets.map((bet) => (
              <tr key={bet.id} className="hover:bg-zinc-800/30 transition-colors animate-slide-down">
                <td className="px-6 py-3 font-medium text-zinc-200">{bet.game}</td>
                <td className="px-6 py-3 text-zinc-400">{bet.user}</td>
                <td className="px-6 py-3 text-zinc-500">{bet.time}</td>
                <td className="px-6 py-3 text-right font-mono text-zinc-300">
                  {bet.betAmount.toFixed(2)} SC
                </td>
                <td className="px-6 py-3 text-right font-mono">
                  {bet.multiplier > 0 ? (
                    <span className="text-emerald-400">{bet.multiplier.toFixed(2)}x</span>
                  ) : (
                    <span className="text-zinc-600">0.00x</span>
                  )}
                </td>
                <td className="px-6 py-3 text-right font-mono font-medium">
                  {bet.payout > 0 ? (
                    <span className="text-emerald-400">+{bet.payout.toFixed(2)} SC</span>
                  ) : (
                    <span className="text-zinc-500">-{bet.betAmount.toFixed(2)} SC</span>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
