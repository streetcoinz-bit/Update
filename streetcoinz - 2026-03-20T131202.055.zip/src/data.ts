import { Game } from './types';

export const GAMES: Game[] = [
  { id: '1', title: 'Neon Rush', provider: 'StreetGaming', imageUrl: 'https://picsum.photos/seed/neonrush/400/300', category: 'slots', isHot: true },
  { id: '2', title: 'Crypto Crash', provider: 'StreetCoinz Games', imageUrl: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Crash.jpg', category: 'crash', isNew: true },
  { id: '3', title: 'Live Blackjack', provider: 'DealerPro', imageUrl: 'https://picsum.photos/seed/liveblackjack/400/300', category: 'live' },
  { id: '4', title: 'Cyber Roulette', provider: 'StreetGaming', imageUrl: 'https://picsum.photos/seed/cyberroulette/400/300', category: 'table', isHot: true },
  { id: '5', title: 'Mega Moolah', provider: 'JackpotInc', imageUrl: 'https://picsum.photos/seed/megamoolah/400/300', category: 'slots' },
  { id: '6', title: 'Plinko', provider: 'StreetCoinz Games', imageUrl: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Plinko.jpg', category: 'originals', isHot: true },
  { id: '7', title: 'Dice', provider: 'StreetCoinz Games', imageUrl: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Dice.jpg', category: 'originals' },
  { id: '8', title: 'Baccarat', provider: 'DealerPro', imageUrl: 'https://picsum.photos/seed/baccarat/400/300', category: 'table' },
  { id: '9', title: 'Sweet Bonanza', provider: 'Pragmatic', imageUrl: 'https://picsum.photos/seed/sweetbonanza/400/300', category: 'slots', isHot: true },
  { id: '10', title: 'Mines', provider: 'StreetCoinz Games', imageUrl: 'https://is3.cloudhost.id/streetcoinzstorage/GAMES/Mines.jpg', category: 'originals' },
  { id: '11', title: 'Crazy Time', provider: 'Evolution', imageUrl: 'https://picsum.photos/seed/crazytime/400/300', category: 'live', isHot: true },
  { id: '12', title: 'Keno', provider: 'StreetCoinz Games', imageUrl: 'https://picsum.photos/seed/keno/400/300', category: 'originals' },
];

export const CATEGORIES = [
  { id: 'all', name: 'Lobby', icon: 'Home' },
  { id: 'originals', name: 'Originals', icon: 'Zap' },
  { id: 'slots', name: 'Slots', icon: 'Cherry' },
  { id: 'live', name: 'Live Casino', icon: 'Video' },
  { id: 'table', name: 'Table Games', icon: 'Spade' },
  { id: 'crash', name: 'Crash', icon: 'TrendingUp' },
];
