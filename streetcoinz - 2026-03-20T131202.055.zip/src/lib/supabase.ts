import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'https://nyoxxkxueuorhvcnzgxu.supabase.co';
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im55b3h4a3h1ZXVvcmh2Y256Z3h1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE4NzMyMTIsImV4cCI6MjA4NzQ0OTIxMn0.tgmihtWQcrsYLjRXq19YdVOud7xaAY7xPN3zbI3KGTA';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export async function fetchUserWalletHistory(email: string) {
  try {
    // First get the user ID
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('id')
      .eq('email', email)
      .single();

    if (userError || !userData) {
      console.error('Error fetching user for history:', userError);
      return [];
    }

    const userId = userData.id;

    // Fetch all history types in parallel
    const [
      { data: deposits },
      { data: withdrawals }
    ] = await Promise.all([
      supabase.from('deposits').select('*').eq('user_id', userId).order('created_at', { ascending: false }),
      supabase.from('withdrawals').select('*').eq('user_id', userId).order('created_at', { ascending: false })
    ]);

    // Combine and format
    const history: any[] = [];

    if (deposits) {
      deposits.forEach((d: any) => {
        history.push({
          id: d.id,
          type: 'deposit',
          title: 'Deposit',
          amount: d.amount,
          status: d.status === 'completed' ? 'COMPLETED' : d.status === 'pending' ? 'PENDING' : 'FAILED',
          date: d.created_at,
          details: d.method
        });
      });
    }

    if (withdrawals) {
      withdrawals.forEach((w: any) => {
        history.push({
          id: w.id,
          type: 'withdraw',
          title: 'Withdrawal',
          amount: w.amount,
          status: w.status === 'completed' ? 'COMPLETED' : w.status === 'pending' ? 'PENDING' : 'FAILED',
          date: w.created_at,
          details: w.method
        });
      });
    }

    // Sort by date descending
    history.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());

    return history;
  } catch (error) {
    console.error('Unexpected error fetching wallet history:', error);
    return [];
  }
}

export async function saveUserWallet(email: string, walletAddress: string, platformWalletAddress?: string) {

  try {
    const payload: any = { 
      email, 
      wallet_address: walletAddress, 
      updated_at: new Date().toISOString() 
    };
    
    if (platformWalletAddress) {
      payload.platform_wallet_address = platformWalletAddress;
    }

    const { data, error } = await supabase
      .from('users')
      .upsert(
        payload,
        { onConflict: 'email' }
      )
      .select('id')
      .single();

    if (error) {
      console.error('Error saving user wallet to Supabase:', error);
      return null;
    }
    
    console.log('Successfully saved user wallet to Supabase');
    return data?.id;
  } catch (error) {
    console.error('Unexpected error saving user wallet:', error);
    return null;
  }
}
