import { toast as sonnerToast, ExternalToast } from 'sonner';
import { Check, X, Loader2, Info } from 'lucide-react';
import { motion } from 'motion/react';

interface ToastProps {
  title: string;
  description?: string;
  type: 'success' | 'error' | 'loading' | 'info';
  duration?: number;
}

const CustomToast = ({ title, description, type, duration = 5000 }: ToastProps) => {
  const Icon = type === 'success' ? Check : type === 'error' ? X : type === 'loading' ? Loader2 : Info;
  const colorClass = type === 'success' ? 'text-green-500' : type === 'error' ? 'text-red-500' : type === 'loading' ? 'text-blue-500' : 'text-purple-500';
  const bgClass = type === 'success' ? 'bg-green-500/20' : type === 'error' ? 'bg-red-500/20' : type === 'loading' ? 'bg-blue-500/20' : 'bg-purple-500/20';
  const barClass = type === 'success' ? 'bg-green-500' : type === 'error' ? 'bg-red-500' : type === 'loading' ? 'bg-blue-500' : 'bg-purple-500';

  return (
    <div className="bg-[#1e1e1e] border border-white/10 rounded-xl p-4 w-[356px] shadow-2xl relative overflow-hidden pointer-events-auto">
      <div className="flex items-center gap-3 mb-3">
        <div className={`w-8 h-8 rounded-full ${bgClass} flex items-center justify-center ${colorClass}`}>
          <Icon className={`w-4 h-4 ${type === 'loading' ? 'animate-spin' : ''}`} />
        </div>
        <div>
          <h4 className="text-sm font-bold text-white">{title}</h4>
          {description && <p className="text-xs text-gray-400">{description}</p>}
        </div>
      </div>
      {type !== 'loading' && (
        <div className="w-full h-1 bg-white/10 rounded-full overflow-hidden">
          <motion.div 
            initial={{ width: 0 }}
            animate={{ width: '100%' }}
            transition={{ duration: duration / 1000, ease: "linear" }}
            className={`h-full ${barClass}`}
          />
        </div>
      )}
    </div>
  );
};

export const toast = {
  success: (title: string, options?: ExternalToast & { description?: string }) => {
    const duration = options?.duration || 5000;
    return sonnerToast.custom(() => <CustomToast title={title} description={options?.description} type="success" duration={duration} />, { duration, ...options });
  },
  error: (title: string, options?: ExternalToast & { description?: string }) => {
    const duration = options?.duration || 5000;
    return sonnerToast.custom(() => <CustomToast title={title} description={options?.description} type="error" duration={duration} />, { duration, ...options });
  },
  loading: (title: string, options?: ExternalToast & { description?: string }) => {
    return sonnerToast.custom(() => <CustomToast title={title} description={options?.description} type="loading" />, { duration: Infinity, ...options });
  },
  info: (title: string, options?: ExternalToast & { description?: string }) => {
    const duration = options?.duration || 5000;
    return sonnerToast.custom(() => <CustomToast title={title} description={options?.description} type="info" duration={duration} />, { duration, ...options });
  },
  custom: sonnerToast.custom,
  dismiss: sonnerToast.dismiss,
};
