const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'https://apiv1.streetcoinz.com';

export async function authenticateWithBackend(didToken: string) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/auth/magic`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${didToken}`
      }
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(errorData.error || 'Failed to authenticate with backend');
    }

    const data = await response.json();
    return data.user;
  } catch (error) {
    console.error('Error authenticating with backend:', error);
    throw error;
  }
}
