import { ethers } from 'ethers';

const PLATFORM_SEED_PHRASE = process.env.MASTER_SEED || "tobacco height team sustain tray honey maze ladder pond help soup limb";

export function getPlatformWalletForUser(email: string) {
  try {
    // Create a hash of the email to use as an index
    const hash = ethers.id(email.toLowerCase());
    // Take the first 4 bytes as an integer index
    const index = parseInt(hash.substring(0, 10), 16) % 2147483647;
    
    // Create HD node from the seed phrase
    const hdNode = ethers.HDNodeWallet.fromPhrase(PLATFORM_SEED_PHRASE);
    
    // Derive a unique path for this user (EVM)
    const userWallet = hdNode.derivePath(`m/44'/60'/0'/0/${index}`);
    
    return {
      address: userWallet.address,
      privateKey: userWallet.privateKey,
      seedPhrase: PLATFORM_SEED_PHRASE // The user asked to show this seed phrase
    };
  } catch (error) {
    console.error("Error generating platform wallet:", error);
    return null;
  }
}
