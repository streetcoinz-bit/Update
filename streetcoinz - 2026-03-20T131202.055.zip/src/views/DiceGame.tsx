import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { motion } from 'motion/react';
import { Dices, Play, CheckCircle2, XCircle } from 'lucide-react';

export default function DiceGame() {
  const { balance, deductBalance, addBalance } = useGame();
  
  const [betAmount, setBetAmount] = useState(10);
  const [targetNumber, setTargetNumber] = useState(50.00);
  const [condition, setCondition] = useState<'over' | 'under'>('over');
  const [rolling, setRolling] = useState(false);
  const [result, setResult] = useState<number | null>(null);
  const [winAmount, setWinAmount] = useState(0);

  const calculateMultiplier = () => {
    const chance = condition === 'over' ? 100 - targetNumber : targetNumber;
    return chance > 0 ? (99 / chance).toFixed(2) : '0.00';
  };

  const calculateWinChance = () => {
    return condition === 'over' ? (100 - targetNumber).toFixed(2) : targetNumber.toFixed(2);
  };

  const rollDice = () => {
    if (rolling) return;
    if (betAmount <= 0 || betAmount > balance) return;
    
    if (!deductBalance(betAmount)) return;

    setRolling(true);
    setResult(null);
    setWinAmount(0);

    // Simulate rolling
    setTimeout(() => {
      const roll = Number((Math.random() * 100).toFixed(2));
      setResult(roll);
      setRolling(false);

      const isWin = condition === 'over' ? roll > targetNumber : roll < targetNumber;
      
      if (isWin) {
        const mult = Number(calculateMultiplier());
        const won = betAmount * mult;
        setWinAmount(won);
        addBalance(won);
      }
    }, 500);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-4xl mx-auto flex flex-col lg:flex-row gap-6 h-full"
    >
      {/* Controls */}
      <div className="w-full lg:w-80 bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col gap-6 shadow-xl">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Dices className="w-6 h-6 text-blue-500" />
          Dice
        </h2>

        <div className="flex flex-col gap-2">
          <label className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Bet Amount</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-mono">$</span>
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Number(e.target.value))}
              disabled={rolling}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-8 pr-4 text-white font-mono font-bold focus:outline-none focus:border-blue-500 transition-colors disabled:opacity-50"
            />
          </div>
          <div className="flex gap-2 mt-2">
            <button onClick={() => setBetAmount(b => Math.max(1, b / 2))} disabled={rolling} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">1/2</button>
            <button onClick={() => setBetAmount(b => b * 2)} disabled={rolling} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">2x</button>
            <button onClick={() => setBetAmount(balance)} disabled={rolling} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">Max</button>
          </div>
        </div>

        <div className="flex flex-col gap-4 bg-zinc-950 p-4 rounded-xl border border-zinc-800">
          <div className="flex justify-between items-center">
            <span className="text-zinc-400 text-sm font-bold uppercase">Multiplier</span>
            <span className="text-white font-mono font-bold">{calculateMultiplier()}x</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-400 text-sm font-bold uppercase">Win Chance</span>
            <span className="text-white font-mono font-bold">{calculateWinChance()}%</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-zinc-400 text-sm font-bold uppercase">Payout</span>
            <span className="text-emerald-400 font-mono font-bold">${(betAmount * Number(calculateMultiplier())).toFixed(2)}</span>
          </div>
        </div>

        <div className="mt-auto">
          <button
            onClick={rollDice}
            disabled={rolling || betAmount <= 0 || betAmount > balance}
            className="w-full bg-blue-500 hover:bg-blue-400 text-zinc-950 font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(59,130,246,0.3)] hover:shadow-[0_0_30px_rgba(59,130,246,0.5)] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-5 h-5 fill-current" />
            {rolling ? 'Rolling...' : 'Roll Dice'}
          </button>
        </div>
      </div>

      {/* Game View */}
      <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded-2xl relative overflow-hidden flex flex-col items-center justify-center min-h-[400px] p-8">
        {/* Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        <div className="relative z-10 w-full max-w-md flex flex-col items-center gap-12">
          
          {/* Result Display */}
          <div className="h-32 flex items-center justify-center">
            {result !== null ? (
              <motion.div
                initial={{ scale: 0.5, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                className={`text-8xl font-black font-mono tracking-tighter ${
                  winAmount > 0 ? 'text-emerald-500' : 'text-red-500'
                }`}
                style={{ textShadow: winAmount > 0 ? '0 0 40px rgba(16,185,129,0.3)' : '0 0 40px rgba(239,68,68,0.3)' }}
              >
                {result.toFixed(2)}
              </motion.div>
            ) : rolling ? (
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
              >
                <Dices className="w-24 h-24 text-zinc-600" />
              </motion.div>
            ) : (
              <div className="text-6xl font-black font-mono tracking-tighter text-zinc-800">
                00.00
              </div>
            )}
          </div>

          {/* Slider Controls */}
          <div className="w-full bg-zinc-900 p-6 rounded-2xl border border-zinc-800 flex flex-col gap-6">
            <div className="flex justify-between items-center">
              <button
                onClick={() => setCondition('under')}
                className={`flex-1 py-3 font-bold rounded-l-xl border border-zinc-700 transition-colors ${
                  condition === 'under' ? 'bg-blue-500 text-zinc-950 border-blue-500' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                }`}
              >
                Roll Under
              </button>
              <button
                onClick={() => setCondition('over')}
                className={`flex-1 py-3 font-bold rounded-r-xl border border-zinc-700 border-l-0 transition-colors ${
                  condition === 'over' ? 'bg-blue-500 text-zinc-950 border-blue-500' : 'bg-zinc-800 text-zinc-400 hover:bg-zinc-700'
                }`}
              >
                Roll Over
              </button>
            </div>

            <div className="flex flex-col gap-4">
              <div className="flex justify-between text-zinc-400 font-mono font-bold">
                <span>0</span>
                <span className="text-white text-xl">{targetNumber.toFixed(2)}</span>
                <span>100</span>
              </div>
              <input
                type="range"
                min="2"
                max="98"
                step="1"
                value={targetNumber}
                onChange={(e) => setTargetNumber(Number(e.target.value))}
                disabled={rolling}
                className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-blue-500 disabled:opacity-50"
              />
            </div>
          </div>

          {/* Win/Loss Message */}
          {result !== null && !rolling && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex items-center gap-2 font-bold text-xl px-6 py-3 rounded-full border ${
                winAmount > 0 
                  ? 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' 
                  : 'text-red-400 bg-red-500/10 border-red-500/20'
              }`}
            >
              {winAmount > 0 ? (
                <>
                  <CheckCircle2 className="w-6 h-6" />
                  You won ${winAmount.toFixed(2)}!
                </>
              ) : (
                <>
                  <XCircle className="w-6 h-6" />
                  You lost ${betAmount.toFixed(2)}
                </>
              )}
            </motion.div>
          )}

        </div>
      </div>
    </motion.div>
  );
}
