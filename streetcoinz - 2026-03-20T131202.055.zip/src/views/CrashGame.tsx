import React, { useState, useEffect, useRef } from 'react';
import { useGame } from '../store/GameContext';
import { motion } from 'motion/react';
import { Rocket, AlertTriangle, Play } from 'lucide-react';

export default function CrashGame() {
  const { balance, deductBalance, addBalance } = useGame();
  
  const [gameState, setGameState] = useState<'idle' | 'playing' | 'crashed'>('idle');
  const [multiplier, setMultiplier] = useState(1.00);
  const [betAmount, setBetAmount] = useState(10);
  const [cashedOut, setCashedOut] = useState(false);
  const [crashPoint, setCrashPoint] = useState(0);
  const [winAmount, setWinAmount] = useState(0);

  const timerRef = useRef<number | null>(null);

  const startGame = () => {
    if (gameState === 'playing') return;
    if (betAmount <= 0 || betAmount > balance) return;
    
    if (!deductBalance(betAmount)) return;

    // Generate crash point (simple logic: mostly low, sometimes high)
    const random = Math.random();
    const point = Math.max(1.00, 0.99 / (1 - random));
    
    setCrashPoint(point);
    setMultiplier(1.00);
    setCashedOut(false);
    setWinAmount(0);
    setGameState('playing');
  };

  const cashOut = () => {
    if (gameState !== 'playing' || cashedOut) return;
    
    setCashedOut(true);
    const won = betAmount * multiplier;
    setWinAmount(won);
    addBalance(won);
  };

  useEffect(() => {
    if (gameState === 'playing') {
      let currentMult = 1.00;
      let speed = 0.01;

      timerRef.current = window.setInterval(() => {
        currentMult += speed;
        speed += 0.001; // Accelerate

        if (currentMult >= crashPoint) {
          setMultiplier(crashPoint);
          setGameState('crashed');
          if (timerRef.current) clearInterval(timerRef.current);
        } else {
          setMultiplier(currentMult);
        }
      }, 50);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [gameState, crashPoint]);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-4xl mx-auto flex flex-col lg:flex-row gap-6 h-full"
    >
      {/* Controls */}
      <div className="w-full lg:w-80 bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col gap-6 shadow-xl">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Rocket className="w-6 h-6 text-emerald-500" />
          Crash
        </h2>

        <div className="flex flex-col gap-2">
          <label className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Bet Amount</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-mono">$</span>
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Number(e.target.value))}
              disabled={gameState === 'playing'}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-8 pr-4 text-white font-mono font-bold focus:outline-none focus:border-emerald-500 transition-colors disabled:opacity-50"
            />
          </div>
          <div className="flex gap-2 mt-2">
            <button onClick={() => setBetAmount(b => Math.max(1, b / 2))} disabled={gameState === 'playing'} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">1/2</button>
            <button onClick={() => setBetAmount(b => b * 2)} disabled={gameState === 'playing'} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">2x</button>
            <button onClick={() => setBetAmount(balance)} disabled={gameState === 'playing'} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">Max</button>
          </div>
        </div>

        <div className="mt-auto">
          {gameState === 'idle' || gameState === 'crashed' ? (
            <button
              onClick={startGame}
              disabled={betAmount <= 0 || betAmount > balance}
              className="w-full bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(16,185,129,0.3)] hover:shadow-[0_0_30px_rgba(16,185,129,0.5)] disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Play className="w-5 h-5 fill-current" />
              Place Bet
            </button>
          ) : (
            <button
              onClick={cashOut}
              disabled={cashedOut}
              className={`w-full font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-lg ${
                cashedOut 
                  ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed' 
                  : 'bg-orange-500 hover:bg-orange-400 text-zinc-950 shadow-[0_0_20px_rgba(249,115,22,0.3)] hover:shadow-[0_0_30px_rgba(249,115,22,0.5)]'
              }`}
            >
              {cashedOut ? 'Cashed Out' : `Cash Out (${(betAmount * multiplier).toFixed(2)})`}
            </button>
          )}
        </div>
      </div>

      {/* Game View */}
      <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded-2xl relative overflow-hidden flex flex-col items-center justify-center min-h-[400px]">
        {/* Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <motion.div 
            className={`text-7xl md:text-9xl font-black font-mono tracking-tighter ${
              gameState === 'crashed' ? 'text-red-500' : 
              cashedOut ? 'text-emerald-500' : 'text-white'
            }`}
            animate={{ 
              scale: gameState === 'playing' ? [1, 1.02, 1] : 1,
              textShadow: gameState === 'playing' ? '0 0 40px rgba(16,185,129,0.3)' : 'none'
            }}
            transition={{ repeat: gameState === 'playing' ? Infinity : 0, duration: 0.5 }}
          >
            {multiplier.toFixed(2)}x
          </motion.div>

          {gameState === 'crashed' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 flex items-center gap-2 text-red-500 font-bold text-xl bg-red-500/10 px-6 py-3 rounded-full border border-red-500/20"
            >
              <AlertTriangle className="w-6 h-6" />
              CRASHED
            </motion.div>
          )}

          {cashedOut && gameState === 'playing' && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 flex items-center gap-2 text-emerald-400 font-bold text-xl bg-emerald-500/10 px-6 py-3 rounded-full border border-emerald-500/20"
            >
              Waiting for crash...
            </motion.div>
          )}

          {gameState === 'crashed' && cashedOut && (
            <motion.div 
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-6 flex items-center gap-2 text-emerald-400 font-bold text-xl bg-emerald-500/10 px-6 py-3 rounded-full border border-emerald-500/20"
            >
              You won ${winAmount.toFixed(2)}!
            </motion.div>
          )}
        </div>

        {/* Simple graph visualization */}
        {gameState === 'playing' && (
          <svg className="absolute bottom-0 left-0 w-full h-1/2 pointer-events-none opacity-50" preserveAspectRatio="none" viewBox="0 0 100 100">
            <motion.path
              d={`M 0 100 Q 50 ${100 - (multiplier * 5)} 100 ${100 - (multiplier * 10)}`}
              fill="none"
              stroke="url(#gradient)"
              strokeWidth="2"
              initial={{ pathLength: 0 }}
              animate={{ pathLength: 1 }}
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="0%">
                <stop offset="0%" stopColor="#10b981" stopOpacity="0" />
                <stop offset="100%" stopColor="#10b981" stopOpacity="1" />
              </linearGradient>
            </defs>
          </svg>
        )}
      </div>
    </motion.div>
  );
}
