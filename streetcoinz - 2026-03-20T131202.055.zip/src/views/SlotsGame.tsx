import React, { useState } from 'react';
import { useGame } from '../store/GameContext';
import { motion } from 'motion/react';
import { Cherry, Play, Coins } from 'lucide-react';

const SYMBOLS = ['🍒', '🍋', '🍇', '🍉', '⭐', '💎', '7️⃣'];
const PAYOUTS: Record<string, number> = {
  '🍒': 2,
  '🍋': 3,
  '🍇': 5,
  '🍉': 10,
  '⭐': 20,
  '💎': 50,
  '7️⃣': 100,
};

export default function SlotsGame() {
  const { balance, deductBalance, addBalance } = useGame();
  
  const [reels, setReels] = useState<string[]>(['🍒', '🍒', '🍒']);
  const [spinning, setSpinning] = useState(false);
  const [betAmount, setBetAmount] = useState(10);
  const [winAmount, setWinAmount] = useState(0);

  const spin = () => {
    if (spinning) return;
    if (betAmount <= 0 || betAmount > balance) return;
    
    if (!deductBalance(betAmount)) return;

    setSpinning(true);
    setWinAmount(0);

    // Simulate spinning
    let spins = 0;
    const interval = setInterval(() => {
      setReels([
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
      ]);
      spins++;

      if (spins > 20) {
        clearInterval(interval);
        
        // Final result
        const finalReels = [
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
          SYMBOLS[Math.floor(Math.random() * SYMBOLS.length)],
        ];
        
        setReels(finalReels);
        setSpinning(false);

        // Check win
        if (finalReels[0] === finalReels[1] && finalReels[1] === finalReels[2]) {
          const won = betAmount * PAYOUTS[finalReels[0]];
          setWinAmount(won);
          addBalance(won);
        } else if (finalReels[0] === finalReels[1] || finalReels[1] === finalReels[2] || finalReels[0] === finalReels[2]) {
          // Two match - small payout
          const won = betAmount * 1.5;
          setWinAmount(won);
          addBalance(won);
        }
      }
    }, 100);
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="max-w-4xl mx-auto flex flex-col lg:flex-row gap-6 h-full"
    >
      {/* Controls */}
      <div className="w-full lg:w-80 bg-zinc-900 border border-zinc-800 rounded-2xl p-6 flex flex-col gap-6 shadow-xl">
        <h2 className="text-2xl font-bold text-white flex items-center gap-2">
          <Cherry className="w-6 h-6 text-purple-500" />
          Slots
        </h2>

        <div className="flex flex-col gap-2">
          <label className="text-sm font-bold text-zinc-400 uppercase tracking-wider">Bet Amount</label>
          <div className="relative">
            <span className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-500 font-mono">$</span>
            <input
              type="number"
              value={betAmount}
              onChange={(e) => setBetAmount(Number(e.target.value))}
              disabled={spinning}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl py-3 pl-8 pr-4 text-white font-mono font-bold focus:outline-none focus:border-purple-500 transition-colors disabled:opacity-50"
            />
          </div>
          <div className="flex gap-2 mt-2">
            <button onClick={() => setBetAmount(b => Math.max(1, b / 2))} disabled={spinning} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">1/2</button>
            <button onClick={() => setBetAmount(b => b * 2)} disabled={spinning} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">2x</button>
            <button onClick={() => setBetAmount(balance)} disabled={spinning} className="flex-1 bg-zinc-800 hover:bg-zinc-700 text-xs font-bold py-2 rounded-lg transition-colors">Max</button>
          </div>
        </div>

        <div className="mt-auto">
          <button
            onClick={spin}
            disabled={spinning || betAmount <= 0 || betAmount > balance}
            className="w-full bg-purple-500 hover:bg-purple-400 text-zinc-950 font-bold text-lg py-4 rounded-xl flex items-center justify-center gap-2 transition-all shadow-[0_0_20px_rgba(168,85,247,0.3)] hover:shadow-[0_0_30px_rgba(168,85,247,0.5)] disabled:opacity-50 disabled:cursor-not-allowed"
          >
            <Play className="w-5 h-5 fill-current" />
            {spinning ? 'Spinning...' : 'Spin'}
          </button>
        </div>
      </div>

      {/* Game View */}
      <div className="flex-1 bg-zinc-950 border border-zinc-800 rounded-2xl relative overflow-hidden flex flex-col items-center justify-center min-h-[400px]">
        {/* Grid Background */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#80808012_1px,transparent_1px),linear-gradient(to_bottom,#80808012_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <div className="bg-zinc-900 border-4 border-zinc-800 rounded-3xl p-8 shadow-2xl flex gap-4">
            {reels.map((symbol, i) => (
              <motion.div 
                key={i}
                className="w-24 h-32 bg-zinc-950 rounded-xl border border-zinc-800 flex items-center justify-center text-6xl shadow-inner overflow-hidden relative"
                animate={{ y: spinning ? [0, -20, 20, 0] : 0 }}
                transition={{ repeat: spinning ? Infinity : 0, duration: 0.2, delay: i * 0.1 }}
              >
                {symbol}
                {/* Gradient overlay for depth */}
                <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-transparent to-black/50 pointer-events-none"></div>
              </motion.div>
            ))}
          </div>

          {winAmount > 0 && !spinning && (
            <motion.div 
              initial={{ opacity: 0, scale: 0.5, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              className="mt-8 flex items-center gap-3 text-purple-400 font-bold text-3xl bg-purple-500/10 px-8 py-4 rounded-full border border-purple-500/20 shadow-[0_0_30px_rgba(168,85,247,0.2)]"
            >
              <Coins className="w-8 h-8 text-yellow-500" />
              YOU WON ${winAmount.toFixed(2)}!
            </motion.div>
          )}
        </div>
      </div>
    </motion.div>
  );
}
