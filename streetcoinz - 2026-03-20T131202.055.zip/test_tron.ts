import bs58check from 'bs58check';
import { ethers } from 'ethers';

const address = "0x7fa3d290e397dfbc8c07b8397fb9fa02806850d8";
const hex = "41" + address.substring(2);
const buffer = Buffer.from(hex, 'hex');
console.log(bs58check.encode(buffer));
