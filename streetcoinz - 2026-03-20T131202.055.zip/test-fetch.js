import WebSocket from 'ws';
const ws = new WebSocket('wss://ws.streetcoinz.com/');
ws.on('open', () => {
  console.log('Connected');
});
ws.on('message', (data) => {
  console.log(data.toString());
});
ws.on('error', (err) => {
  console.log('Error:', err);
});
setTimeout(() => ws.close(), 5000);
