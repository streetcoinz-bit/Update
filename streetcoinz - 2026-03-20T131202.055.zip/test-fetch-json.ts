async function run() {
  try {
    const res = await fetch('https://apiv1.streetcoinz.com/', {
      headers: {
        'Accept': 'application/json'
      }
    });
    const text = await res.text();
    console.log('Status:', res.status);
    console.log('Headers:', res.headers);
    console.log('Body:', text);
  } catch (e) {
    console.error(e);
  }
}
run();
