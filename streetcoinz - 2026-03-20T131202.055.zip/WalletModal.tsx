
import React from 'react';
import { Language } from '../types';

interface WalletModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConnect: (provider: string) => void;
  language: Language;
}

const translations = {
  [Language.EN]: { title: 'Connect Wallet', footer: 'Connecting your wallet allows you to authorize transactions on the StreetCoinz network.' },
  [Language.ID]: { title: 'Hubungkan Dompet', footer: 'Menghubungkan dompet memungkinkan Anda melakukan otorisasi transaksi di jaringan StreetCoinz.' },
  [Language.ES]: { title: 'Conectar Billetera', footer: 'Conectar tu billetera te permite autorizar transacciones en la red StreetCoinz.' },
  [Language.CN]: { title: '连接钱包', footer: '连接您的钱包允许您在 StreetCoinz 网络上授权交易。' }
};

const WalletModal: React.FC<WalletModalProps> = ({ isOpen, onClose, onConnect, language }) => {
  if (!isOpen) return null;
  const t = translations[language];

  const wallets = [
    { name: 'MetaMask', icon: '🦊', color: 'hover:border-orange-500/50' },
    { name: 'Phantom', icon: '👻', color: 'hover:border-purple-500/50' },
    { name: 'Trust Wallet', icon: '🛡️', color: 'hover:border-blue-500/50' },
    { name: 'Coinbase', icon: '🔵', color: 'hover:border-blue-600/50' }
  ];

  return (
    <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm animate-in fade-in duration-300" onClick={onClose}></div>
      
      <div className="relative w-full max-w-[340px] bg-zinc-900 border border-zinc-800 rounded-[40px] overflow-hidden shadow-[0_32px_64px_-12px_rgba(0,0,0,0.8)] animate-in fade-in zoom-in-95 duration-300">
        <div className="p-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-sm font-black text-white uppercase tracking-widest italic font-heading">{t.title}</h3>
            <button onClick={onClose} className="text-zinc-500 hover:text-white transition-colors">
              <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          
          <div className="grid grid-cols-1 gap-3">
            {wallets.map((wallet) => (
              <button
                key={wallet.name}
                onClick={() => onConnect(wallet.name)}
                className={`flex items-center justify-between p-4 bg-zinc-950 border border-zinc-800 rounded-2xl transition-all ${wallet.color} group active:scale-95`}
              >
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{wallet.icon}</span>
                  <span className="font-black text-xs uppercase tracking-tight text-zinc-300 group-hover:text-white transition-colors">{wallet.name}</span>
                </div>
                <div className="w-2 h-2 rounded-full bg-zinc-800 group-hover:bg-purple-500 group-hover:shadow-[0_0_10px_rgba(168,85,247,0.8)] transition-all"></div>
              </button>
            ))}
          </div>
          
          <div className="mt-8 p-5 bg-purple-500/5 rounded-2xl border border-purple-500/10">
            <p className="text-[9px] text-zinc-600 leading-relaxed font-bold uppercase tracking-widest text-center">
              {t.footer}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WalletModal;
