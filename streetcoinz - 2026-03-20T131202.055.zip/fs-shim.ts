
/**
 * StreetCoinz FS Shim
 * Definitive fix for [unenv] 'not implemented' errors.
 */

const noop = () => {};
const emptyUint8 = new Uint8Array(0);

const statResult = {
  isDirectory: () => false,
  isFile: () => true,
  isBlockDevice: () => false,
  isCharacterDevice: () => false,
  isSymbolicLink: () => false,
  isFIFO: () => false,
  isSocket: () => false,
  size: 0,
  atime: new Date(),
  mtime: new Date(),
  ctime: new Date(),
  birthtime: new Date(),
};

export const readFile = (path: any, options: any, callback: any) => {
  const cb = typeof options === 'function' ? options : callback;
  if (cb) setTimeout(() => cb(null, emptyUint8), 0);
};
export const readFileSync = () => emptyUint8;

export const writeFile = (path: any, data: any, options: any, callback: any) => {
  const cb = typeof options === 'function' ? options : callback;
  if (cb) setTimeout(() => cb(null), 0);
};
export const writeFileSync = noop;

export const existsSync = () => false;
export const exists = (path: any, cb: any) => { if (cb) setTimeout(() => cb(false), 0); };

export const stat = (path: any, cb: any) => { if (cb) setTimeout(() => cb(null, statResult), 0); };
export const statSync = () => statResult;
export const lstat = stat;
export const lstatSync = statSync;

export const readdir = (path: any, cb: any) => { if (cb) setTimeout(() => cb(null, []), 0); };
export const readdirSync = () => [];

export const mkdir = (path: any, options: any, cb: any) => {
  const _cb = typeof options === 'function' ? options : cb;
  if (_cb) setTimeout(() => _cb(null), 0);
};
export const mkdirSync = noop;

export const access = (path: any, mode: any, cb: any) => {
  const _cb = typeof mode === 'function' ? mode : cb;
  if (_cb) setTimeout(() => _cb(null), 0);
};
export const accessSync = noop;

export const createReadStream = () => ({ on: noop, pipe: noop, close: noop });
export const createWriteStream = () => ({ on: noop, write: noop, end: noop, close: noop });

export const promises = {
  readFile: () => Promise.resolve(emptyUint8),
  writeFile: () => Promise.resolve(),
  stat: () => Promise.resolve(statResult),
  lstat: () => Promise.resolve(statResult),
  readdir: () => Promise.resolve([]),
  mkdir: () => Promise.resolve(),
  access: () => Promise.resolve(),
  realpath: (path: any) => Promise.resolve(path),
};

const fs = {
  readFile,
  readFileSync,
  writeFile,
  writeFileSync,
  exists,
  existsSync,
  stat,
  statSync,
  lstat,
  lstatSync,
  readdir,
  readdirSync,
  mkdir,
  mkdirSync,
  access,
  accessSync,
  createReadStream,
  createWriteStream,
  promises,
  watch: () => ({ close: noop, on: noop }),
  watchFile: noop,
  unwatchFile: noop,
  realpath: (path: any, cb: any) => { if (cb) setTimeout(() => cb(null, path), 0); },
  realpathSync: (path: any) => path,
};

export default fs;
