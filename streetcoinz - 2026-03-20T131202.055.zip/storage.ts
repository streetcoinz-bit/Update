
import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";

// Storage Configuration with provided keys and new endpoint/bucket
const STORAGE_CONFIG = {
  region: "id-west-1", 
  endpoint: "https://is3.cloudhost.id", 
  credentials: {
    accessKeyId: "JHOV5S6BMHF9HSNPXZVV",
    secretAccessKey: "CbGxCHBskETBKjuLBoJuSNDVccLQKBm3u1xlDw7P",
  },
};

const BUCKET_NAME = "streetcoinzidn40gb";

/**
 * Initialize S3 Client with explicit browser-friendly settings.
 */
const s3Client = new S3Client({
  region: STORAGE_CONFIG.region,
  endpoint: STORAGE_CONFIG.endpoint,
  credentials: STORAGE_CONFIG.credentials,
  forcePathStyle: true,
});

/**
 * Uploads a file to the S3-compatible storage organized by User.
 * @param file The file object to upload.
 * @param userIdentifier Unique ID or username to isolate storage.
 * @returns The public URL of the uploaded file.
 */
export async function uploadFile(file: File, userIdentifier: string = "anonymous"): Promise<string> {
  // Determine category based on MIME type
  let category = "misc";
  if (file.type.startsWith("image/")) category = "photos";
  else if (file.type.startsWith("video/")) category = "videos";
  else if (file.type.startsWith("audio/")) category = "audio";

  // Clean identifiers for URL safety
  const safeUser = userIdentifier.replace(/[^a-zA-Z0-9]/g, "_").toLowerCase();
  const safeFileName = `${Date.now()}-${file.name.replace(/[^a-zA-Z0-9._-]/g, "_")}`;
  
  // Final Key Structure: users/{username}/{category}/{filename}
  const key = `users/${safeUser}/${category}/${safeFileName}`;
  
  try {
    const command = new PutObjectCommand({
      Bucket: BUCKET_NAME,
      Key: key,
      Body: file,
      ContentType: file.type,
    });

    await s3Client.send(command);
    
    // Construct the public URL
    return `${STORAGE_CONFIG.endpoint}/${BUCKET_NAME}/${key}`;
  } catch (error) {
    console.error("Storage Upload Error:", error);
    // Fallback to local URL if storage fails
    return URL.createObjectURL(file);
  }
}
