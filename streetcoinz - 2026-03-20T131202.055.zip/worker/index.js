export default {
  async fetch(request, env) {

    if (request.method !== "POST") {
      return new Response(JSON.stringify({
        error: "POST required"
      }), { headers: { "content-type": "application/json" } })
    }

    const body = await request.json()
    const email = body.email

    if (!email) {
      return new Response(JSON.stringify({
        error: "email required"
      }), { headers: { "content-type": "application/json" } })
    }

    const seed = env.MASTER_SEED

    // index deterministik dari email
    let index = 0
    for (let i = 0; i < email.length; i++) {
      index += email.charCodeAt(i)
    }

    // hash dasar
    const encoder = new TextEncoder()
    const data = encoder.encode(seed + index)

    const hashBuffer = await crypto.subtle.digest("SHA-256", data)
    const hashArray = new Uint8Array(hashBuffer)
    const hashHex = Array.from(hashArray).map(b => b.toString(16).padStart(2,"0")).join("")

    // ===== EVM =====
    const evm = "0x" + hashHex.slice(0,40)

    // ===== TRON =====
    // payload: 0x41 + 20 byte
    const tronPayload = new Uint8Array(21)
    tronPayload[0] = 0x41
    tronPayload.set(hashArray.slice(0,20),1)

    const tronChecksum = await crypto.subtle.digest("SHA-256", tronPayload)
    const tronChecksum2 = await crypto.subtle.digest("SHA-256", tronChecksum)

    const checksumBytes = new Uint8Array(tronChecksum2).slice(0,4)

    const tronAddressBytes = new Uint8Array(25)
    tronAddressBytes.set(tronPayload,0)
    tronAddressBytes.set(checksumBytes,21)

    const tron = base58Encode(tronAddressBytes)

    // ===== SOLANA =====
    const sol = base58Encode(hashArray.slice(0,32))

    return new Response(JSON.stringify({
      email,
      wallet_index: index,
      evm,
      tron,
      sol
    }), {
      headers: { "content-type": "application/json", "Access-Control-Allow-Origin": "*" }
    })
  }
}

// ===== Base58 encoder =====
const ALPHABET = "123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"

function base58Encode(buffer) {
  let digits = [0]

  for (let i = 0; i < buffer.length; i++) {
    let carry = buffer[i]
    for (let j = 0; j < digits.length; j++) {
      carry += digits[j] << 8
      digits[j] = carry % 58
      carry = (carry / 58) | 0
    }
    while (carry) {
      digits.push(carry % 58)
      carry = (carry / 58) | 0
    }
  }

  let result = ""
  for (let k = 0; buffer[k] === 0 && k < buffer.length - 1; k++) {
    result += ALPHABET[0]
  }

  for (let q = digits.length - 1; q >= 0; q--) {
    result += ALPHABET[digits[q]]
  }

  return result
}

