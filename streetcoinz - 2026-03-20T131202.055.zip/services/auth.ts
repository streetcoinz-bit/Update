
/**
 * StreetCoinz Authentication Service
 */

const API_BASE_URL = "http://103.13.207.245:5000/api";

export interface AuthResponse {
  success: boolean;
  message: string;
  user?: {
    name: string;
    email: string;
    avatar: string;
    address: string;
  };
}

export const authService = {
  /**
   * Login or Register user.
   */
  async loginOrRegister(email: string, username: string, password?: string): Promise<AuthResponse> {
    try {
      const response = await fetch(`${API_BASE_URL}/auth`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, username, password }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to contact street server.");
      }

      return await response.json();
    } catch (error: any) {
      console.error("Auth Error:", error);
      return { 
        success: false, 
        message: error.message || "Connection to Street Server failed." 
      };
    }
  }
};
