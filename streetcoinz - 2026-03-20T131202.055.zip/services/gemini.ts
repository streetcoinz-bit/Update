
/**
 * StreetCoinz AI Service
 * Migrated to OpenRouter with Mistral Devstral 2512
 * This service now uses the OpenRouter API to provide market insights and chat functionality.
 */

const OPENROUTER_URL = "https://openrouter.ai/api/v1/chat/completions";
const MODEL_NAME = "mistralai/devstral-2512:free";

/**
 * Mengambil sentimen pasar untuk koin tertentu menggunakan OpenRouter.
 */
export async function getMarketSentiment(coin: string = "Bitcoin") {
  try {
    const prompt = `Lakukan analisis sentimen sosial cepat untuk ${coin}. Gunakan getaran terbaru dari komunitas trading. 
                   Kembalikan HANYA objek JSON dengan struktur:
                   {
                     "sentiment": "Bullish" atau "Bearish",
                     "confidence": angka 0-100,
                     "reasoning": "frasa pendek yang menarik"
                   }`;

    const response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": window.location.origin,
        "X-Title": "StreetCoinz Dashboard"
      },
      body: JSON.stringify({
        model: MODEL_NAME,
        messages: [
          { 
            role: "system", 
            content: "Anda adalah bot sentimen crypto jalanan. Berikan respons HANYA dalam format objek JSON yang valid tanpa teks tambahan." 
          },
          { role: "user", content: prompt }
        ],
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || "OpenRouter error");
    }

    const data = await response.json();
    const content = data.choices[0].message.content.trim();
    
    return JSON.parse(content);
  } catch (err) {
    console.error("Analisis Sentimen OpenRouter Gagal:", err);
    return { 
      sentiment: 'Netral', 
      confidence: 50, 
      reasoning: 'Sinyal jalanan kabur. Kalibrasi ulang sinyal OpenRouter...',
      isFallback: true
    };
  }
}

/**
 * Berinteraksi dengan Street AI untuk saran pasar menggunakan OpenRouter.
 */
export async function askMarketAI(userPrompt: string, currentPrice: number) {
  try {
    const response = await fetch(OPENROUTER_URL, {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${process.env.API_KEY}`,
        "Content-Type": "application/json",
        "HTTP-Referer": window.location.origin,
        "X-Title": "StreetCoinz AI Chat"
      },
      body: JSON.stringify({
        model: MODEL_NAME,
        messages: [
          { 
            role: "system", 
            content: `Anda adalah StreetCoinz AI, pakar trading crypto yang cerdas. 
                      Harga BTC saat ini adalah $${currentPrice}. 
                      Jawab dalam 1-2 kalimat pendek dan lugas menggunakan bahasa gaul trader. 
                      Bantu mereka tapi ingatkan bahwa ini bukan saran keuangan.` 
          },
          { role: "user", content: userPrompt }
        ]
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error?.message || "OpenRouter error");
    }

    const data = await response.json();
    return data.choices[0].message.content || "Street AI sedang istirahat. Coba lagi nanti, kawan.";
  } catch (err: any) {
    console.error("Chat OpenRouter Gagal:", err);
    return "Street AI sedang istirahat. Coba lagi nanti, kawan.";
  }
}
