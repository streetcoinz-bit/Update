import fetch from 'node-fetch';

async function test() {
  const evmAddress = "0x742d35Cc6634C0532925a3b844Bc454e4438f44e"; // Binance Hot Wallet 14
  
  // ETH USDT
  let res = await fetch('https://eth-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc:"2.0",
      method:"eth_call",
      params:[{
        to: "0xdAC17F958D2ee523a2206206994597C13D831ec7",
        data: "0x70a08231000000000000000000000000" + evmAddress.substring(2)
      },"latest"],
      id:1
    })
  });
  console.log("ETH USDT:", await res.json());

  // BNB USDT
  res = await fetch('https://bnb-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc:"2.0",
      method:"eth_call",
      params:[{
        to: "0x55d398326f99059fF775485246999027B3197955",
        data: "0x70a08231000000000000000000000000" + evmAddress.substring(2)
      },"latest"],
      id:1
    })
  });
  console.log("BNB USDT:", await res.json());

  // TRON USDT
  const tronHex = "0x" + evmAddress.substring(2);
  res = await fetch('https://tron-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc:"2.0",
      method:"eth_call",
      params:[{
        to: "0x41a614f803b6fd780986a42c78ec9c7f77e6ded13c",
        data: "0x70a08231000000000000000000000000" + evmAddress.substring(2)
      },"latest"],
      id:1
    })
  });
  console.log("TRON USDT:", await res.json());

  // SOL USDT
  const solAddress = "vines1vzrYbzLMRdu58ou5XTby4qAqVRLmqo36NKPTg";
  res = await fetch('https://solana-mainnet.g.alchemy.com/v2/YAl50N3qSm3hhdv0iyMA6', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      jsonrpc:"2.0",
      method:"getTokenAccountsByOwner",
      params:[
        solAddress,
        { mint: "Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB" },
        { encoding: "jsonParsed" }
      ],
      id:1
    })
  });
  console.log("SOL USDT:", JSON.stringify(await res.json(), null, 2));
}

test();
