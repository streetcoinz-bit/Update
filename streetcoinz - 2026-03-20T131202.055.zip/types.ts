
export enum AppTab {
  HOME = 'HOME',
  PREDICT = 'PREDICT',
  POST = 'POST',
  CHAT = 'CHAT',
  TOPUP = 'TOPUP',
  PROFILE = 'PROFILE'
}

export enum Language {
  EN = 'EN',
  ID = 'ID',
  ES = 'ES',
  CN = 'CN'
}

export enum AppTheme {
  SYSTEM = 'SYSTEM',
  CLEAN = 'CLEAN',
  DARK = 'DARK'
}

export enum NotificationType {
  LIKE = 'LIKE',
  REPLY = 'REPLY',
  FOLLOW = 'FOLLOW',
  SYSTEM = 'SYSTEM',
  SHARE = 'SHARE'
}

export interface Notification {
  id: string;
  type: NotificationType;
  username: string;
  avatar: string;
  content: string;
  timestamp: Date;
  postId?: string;
  sharedProfileUsername?: string;
  isRead: boolean;
}

export interface Comment {
  id: string;
  username: string;
  avatar: string;
  text: string;
  timestamp: Date;
  replies?: Comment[];
}

export interface UserStatus {
  id: string;
  username: string;
  avatar: string;
  text: string;
  bgColor: string;
  imageUrl?: string;
  timestamp: Date;
  commentsList?: Comment[];
  viewers?: { username: string; avatar: string }[];
}

export interface UserProfile {
  name: string;
  email: string;
  avatar: string;
  bio: string;
  referralCode: string;
  referralCount: number;
  followerCount: number;
  followingCount: number;
  totalLikes: number;
  links?: string[];
}

export interface VideoPost {
  id: string;
  url: string;
  username: string;
  caption: string;
  likes: number;
  comments: number;
  tags: string[];
  mediaType: 'video' | 'image';
  commentsList?: Comment[];
}

export interface Message {
  id: string;
  text?: string;
  imageUrl?: string;
  sender: 'me' | 'partner';
  timestamp: Date;
  username?: string;
  replyTo?: {
    text?: string;
    username?: string;
  };
  sharedPostId?: string;
  sharedProfileUsername?: string;
  sharedStatusId?: string;
}

export interface ChatGroup {
  id: string;
  name: string;
  description: string;
  avatar: string;
  memberCount: number;
  lastMsg: string;
  time: string;
  isGroup: true;
  owner?: string;
  isMuted?: boolean;
}

export interface UserWallet {
  address: string | null;
  balance: number;
  referralEarnings: number;
  connected: boolean;
  history: Transaction[];
}

export interface UserWallet {
  address: string | null;
  balance: number;
  referralEarnings: number;
  connected: boolean;
  history: Transaction[];
}

export interface Transaction {
  id: string;
  type: 'TOPUP' | 'BET' | 'WIN' | 'REFERRAL_BONUS' | 'WITHDRAW';
  amount: number;
  timestamp: Date;
  status: 'COMPLETED' | 'PENDING';
}
