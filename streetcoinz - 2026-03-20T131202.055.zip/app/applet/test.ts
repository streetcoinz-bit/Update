import WebSocket from 'ws';
const ws = new WebSocket('wss://ws.streetcoinz.com/');
let count = 0;
ws.on('open', () => console.log('connected'));
ws.on('message', (data) => { 
  console.log('msg:', data.toString()); 
  count++;
  if (count >= 10) ws.close(); 
});
ws.on('close', (code, reason) => console.log('closed:', code, reason.toString()));
ws.on('error', (err) => console.error('err:', err));