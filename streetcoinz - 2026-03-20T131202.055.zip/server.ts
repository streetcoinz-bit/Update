import express from 'express';
import { createServer as createViteServer } from 'vite';
import { Magic } from '@magic-sdk/admin';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import cors from 'cors';
import { getPlatformWalletForUser } from './src/lib/wallet';

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());
  app.use(cors());

  // Initialize Magic Admin SDK
  // The user said they put the secret magic key in the environment
  const magicSecretKey = process.env.MAGIC_SECRET_KEY || 'sk_live_...';
  const magic = new Magic(magicSecretKey);

  // Initialize Supabase with Service Role Key
  // The user said they put the supabase url and service role in the environment
  const supabaseUrl = process.env.VITE_SUPABASE_URL || 'https://nyoxxkxueuorhvcnzgxu.supabase.co';
  const supabaseServiceRoleKey = process.env.SUPABASE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im55b3h4a3h1ZXVvcmh2Y256Z3h1Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MTg3MzIxMiwiZXhwIjoyMDg3NDQ5MjEyfQ.ThprINsNn71KGRsXVRf8AzcL1XDTMIuEbEjHvPaWKP8';
  const supabase = createClient(supabaseUrl, supabaseServiceRoleKey);

  // API routes FIRST
  app.get('/api/health', (req, res) => {
    res.json({ status: 'ok', message: 'StreetCoinz API Running' });
  });

  app.post('/api/auth/magic', async (req, res) => {
    try {
      const authHeader = req.headers.authorization;
      if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return res.status(401).json({ error: 'Missing or invalid authorization header' });
      }

      const didToken = authHeader.substring(7);
      
      // Validate the DID token
      magic.token.validate(didToken);
      
      // Get user metadata from Magic
      const issuer = magic.token.getIssuer(didToken);
      const userMetadata = await magic.users.getMetadataByIssuer(issuer);
      
      const email = userMetadata.email;
      const walletAddress = userMetadata.publicAddress; // This is the consistent wallet address!

      if (!email || !walletAddress) {
        return res.status(400).json({ error: 'Failed to retrieve user email or wallet address' });
      }

      // Generate HD Wallet for user
      const platformWallet = getPlatformWalletForUser(email);
      
      const upsertPayload: any = { 
        email, 
        wallet_address: walletAddress, 
        updated_at: new Date().toISOString() 
      };

      if (platformWallet) {
        upsertPayload.platform_wallet_address = platformWallet.address;
        upsertPayload.platform_wallet_tron = platformWallet.tronAddress;
        upsertPayload.platform_wallet_solana = platformWallet.solanaAddress;
      }

      // Save user to Supabase using Service Role Key
      const { data, error } = await supabase
        .from('users')
        .upsert(
          upsertPayload,
          { onConflict: 'email' }
        );

      if (error) {
        console.error('Error saving user to Supabase:', error);
        return res.status(500).json({ error: 'Failed to save user data' });
      }

      res.json({ 
        success: true, 
        user: {
          email,
          walletAddress,
          platformWalletAddress: platformWallet?.address,
          platformPrivateKey: platformWallet?.privateKey,
          platformWalletTron: platformWallet?.tronAddress,
          platformPkTron: platformWallet?.tronPrivateKey,
          platformWalletSolana: platformWallet?.solanaAddress,
          platformPkSolana: platformWallet?.solanaPrivateKey,
          platformSeedPhrase: platformWallet?.seedPhrase
        }
      });
    } catch (error) {
      console.error('Magic auth error:', error);
      res.status(500).json({ error: 'Authentication failed' });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    // Serve static files in production
    app.use(express.static('dist'));
    app.get('*', (req, res) => {
      res.sendFile('index.html', { root: 'dist' });
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
