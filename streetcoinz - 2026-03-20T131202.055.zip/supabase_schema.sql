-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Users Table
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT UNIQUE NOT NULL,
    username TEXT,
    avatar_url TEXT,
    balance NUMERIC DEFAULT 0,
    cashback_balance NUMERIC DEFAULT 0,
    total_wagered NUMERIC DEFAULT 0,
    referral_code TEXT UNIQUE,
    referred_by UUID REFERENCES public.users(id),
    referral_rewards NUMERIC DEFAULT 0,
    wallet_address TEXT,
    platform_wallet_address TEXT,
    evm_private_key TEXT,
    tron_private_key TEXT,
    sol_private_key TEXT,
    currency TEXT DEFAULT 'USDT',
    role TEXT DEFAULT 'user',
    joined_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 2. Deposits Table
CREATE TABLE IF NOT EXISTS public.deposits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    amount NUMERIC NOT NULL,
    method TEXT,
    status TEXT DEFAULT 'pending', -- 'pending', 'completed', 'failed'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 3. Withdrawals Table
CREATE TABLE IF NOT EXISTS public.withdrawals (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email TEXT,
    address TEXT,
    amount NUMERIC,
    chain TEXT,
    status TEXT DEFAULT 'pending', -- 'pending', 'approved', 'rejected', 'sent'
    tx_hash TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Bets Table
CREATE TABLE IF NOT EXISTS public.bets (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    game TEXT,
    amount NUMERIC NOT NULL,
    multiplier NUMERIC,
    payout NUMERIC,
    won BOOLEAN,
    status TEXT DEFAULT 'COMPLETED', -- 'PENDING', 'COMPLETED'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 5. Website Visits Table
CREATE TABLE IF NOT EXISTS public.website_visits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id TEXT,
    user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 6. Tier Upgrades Table
CREATE TABLE IF NOT EXISTS public.tier_upgrades (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    tier TEXT,
    amount NUMERIC,
    status TEXT DEFAULT 'completed',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 7. Cashback Rewards Table
CREATE TABLE IF NOT EXISTS public.cashback_rewards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    amount NUMERIC,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 8. Referral Rewards Table
CREATE TABLE IF NOT EXISTS public.referral_rewards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    referred_user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
    amount NUMERIC,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 9. System Logs Table
CREATE TABLE IF NOT EXISTS public.system_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    action TEXT,
    detail TEXT,
    type TEXT,
    user_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 10. System Settings Table
CREATE TABLE IF NOT EXISTS public.system_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    key TEXT UNIQUE NOT NULL,
    value JSONB,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Disable RLS for all tables to allow the client to read/write directly (since the app uses anon key for everything)
-- If you want to secure it, you would enable RLS and add policies.
-- For now, we enable RLS but add permissive policies so the app works as currently designed.

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.deposits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.withdrawals ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.bets ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_visits ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tier_upgrades ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.cashback_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.referral_rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

-- Create permissive policies for all tables (Allow all operations for anon/authenticated)
-- Note: In a production environment, you should restrict these policies based on user_id and roles.

-- Users
CREATE POLICY "Allow all operations on users" ON public.users FOR ALL USING (true) WITH CHECK (true);

-- Deposits
CREATE POLICY "Allow all operations on deposits" ON public.deposits FOR ALL USING (true) WITH CHECK (true);

-- Withdrawals
CREATE POLICY "Allow all operations on withdrawals" ON public.withdrawals FOR ALL USING (true) WITH CHECK (true);

-- Bets
CREATE POLICY "Allow all operations on bets" ON public.bets FOR ALL USING (true) WITH CHECK (true);

-- Website Visits
CREATE POLICY "Allow all operations on website_visits" ON public.website_visits FOR ALL USING (true) WITH CHECK (true);

-- Tier Upgrades
CREATE POLICY "Allow all operations on tier_upgrades" ON public.tier_upgrades FOR ALL USING (true) WITH CHECK (true);

-- Cashback Rewards
CREATE POLICY "Allow all operations on cashback_rewards" ON public.cashback_rewards FOR ALL USING (true) WITH CHECK (true);

-- Referral Rewards
CREATE POLICY "Allow all operations on referral_rewards" ON public.referral_rewards FOR ALL USING (true) WITH CHECK (true);

-- System Logs
CREATE POLICY "Allow all operations on system_logs" ON public.system_logs FOR ALL USING (true) WITH CHECK (true);

-- System Settings
CREATE POLICY "Allow all operations on system_settings" ON public.system_settings FOR ALL USING (true) WITH CHECK (true);

-- Create updated_at triggers
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_deposits_updated_at BEFORE UPDATE ON public.deposits FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON public.system_settings FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- Initialize some default system settings
INSERT INTO public.system_settings (key, value) VALUES 
('maintenance_mode', 'false'::jsonb),
('trading_halted', 'false'::jsonb),
('rigged_users', '[]'::jsonb)
ON CONFLICT (key) DO NOTHING;

-- View for Top Users based on total wagered volume
CREATE OR REPLACE VIEW public.top_users AS
SELECT 
    id,
    email,
    username,
    avatar_url,
    balance,
    total_wagered,
    created_at
FROM public.users
ORDER BY total_wagered DESC;

-- If you want to query top users by balance instead:
CREATE OR REPLACE VIEW public.top_users_by_balance AS
SELECT 
    id,
    email,
    username,
    avatar_url,
    balance,
    total_wagered,
    created_at
FROM public.users
ORDER BY balance DESC;

-- Grant access to the views
GRANT SELECT ON public.top_users TO anon, authenticated;
GRANT SELECT ON public.top_users_by_balance TO anon, authenticated;
