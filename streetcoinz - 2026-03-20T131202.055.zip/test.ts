import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://nyoxxkxueuorhvcnzgxu.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im55b3h4a3h1ZXVvcmh2Y256Z3h1Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzE4NzMyMTIsImV4cCI6MjA4NzQ0OTIxMn0.tgmihtWQcrsYLjRXq19YdVOud7xaAY7xPN3zbI3KGTA';

const supabase = createClient(supabaseUrl, supabaseAnonKey);

async function test() {
  const { data, error } = await supabase
    .from('users')
    .select('id')
    .eq('email', 'test@example.com')
    .single();
  console.log('Data:', data);
  console.log('Error:', error);
}

test();
